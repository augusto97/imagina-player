<?php
/**
 * What the three Elementor widgets share.
 *
 * Elementor keeps a widget's settings in its own shape — a media control is
 * an array with an id and a url, a switch is "yes" or nothing, a repeater a
 * list of rows — and the renderer takes the block's attributes. The mapping
 * between the two lives here, in one place and in the open, so it can be
 * read and tested without Elementor on hand: `attributes_from()` is pure.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;
use ImaginaPlayer\Assets;
use ImaginaPlayer\Player\Attributes;
use ImaginaPlayer\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class PlayerWidget extends Widget_Base {

	/** The three ways a widget can be told which file to play. */
	public const SOURCE_LIBRARY = 'library';
	public const SOURCE_URL     = 'url';
	public const SOURCE_FIELD   = 'field';

	public function get_categories(): array {
		return array( Integration::CATEGORY );
	}

	/**
	 * The front-end bundle, so the editor's preview frame loads it and a
	 * widget dropped into the page becomes a player there and then.
	 *
	 * @return string[]
	 */
	public function get_script_depends(): array {
		return array( Assets::FRONTEND_HANDLE );
	}

	/**
	 * @return string[]
	 */
	public function get_style_depends(): array {
		return array( Assets::FRONTEND_HANDLE );
	}

	/**
	 * The block attributes a set of widget settings amounts to.
	 *
	 * @param array<string, mixed> $settings What Elementor stored.
	 * @return array<string, mixed>
	 */
	abstract public function attributes_from( array $settings ): array;

	/**
	 * The markup for a set of settings. Its own method so a test can render
	 * without Elementor's output buffering around it.
	 *
	 * @param array<string, mixed> $settings What Elementor stored.
	 */
	abstract public function markup( array $settings ): string;

	protected function render(): void {
		$settings = $this->get_settings_for_display();
		$settings = is_array( $settings ) ? $settings : array();

		/*
		 * Elementor leaves a control its condition hides out of the settings
		 * for display, value and all. A lone button drawn in 1.58.1 took its
		 * colour from the accent control, which that skin hides now, so the
		 * colour saved there is read from what was stored.
		 */
		if ( empty( $settings['accent'] ) ) {
			$saved                    = $this->get_settings( 'accent' );
			$settings['saved_accent'] = is_string( $saved ) ? $saved : '';
		}

		echo $this->markup( $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- the renderer escapes everything it prints.
	}

	/* ---- Controls shared by the audio and video widgets ------------------ */

	/**
	 * Where the file comes from: the library, an address, or a custom field
	 * of the post the page shows.
	 *
	 * @param string   $medium      'audio' or 'video'.
	 * @param string[] $media_types What the library picker offers.
	 */
	protected function source_controls( string $medium, array $media_types ): void {
		$this->add_control(
			'source',
			array(
				'label'   => __( 'Source', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => self::SOURCE_LIBRARY,
				'options' => array(
					self::SOURCE_LIBRARY => __( 'Media library', 'imagina-player' ),
					self::SOURCE_URL     => __( 'Address', 'imagina-player' ),
					self::SOURCE_FIELD   => __( 'Custom field of the post', 'imagina-player' ),
				),
			)
		);

		$this->add_control(
			'media',
			array(
				'label'       => 'audio' === $medium ? __( 'Audio file', 'imagina-player' ) : __( 'Video file', 'imagina-player' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => $media_types,
				'condition'   => array( 'source' => self::SOURCE_LIBRARY ),
			)
		);

		$this->add_control(
			'url',
			array(
				'label'       => __( 'Address', 'imagina-player' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'audio' === $medium
					? 'https://example.com/track.mp3'
					: 'https://www.youtube.com/watch?v=…',
				'description' => 'audio' === $medium
					? __( 'A file on another site or a streaming provider.', 'imagina-player' )
					: __( 'A YouTube or Vimeo address, an MP4, or an HLS stream (.m3u8).', 'imagina-player' ),
				'options'     => false,
				'dynamic'     => array( 'active' => true ),
				'condition'   => array( 'source' => self::SOURCE_URL ),
			)
		);

		$this->add_control(
			'source_field',
			array(
				'label'       => __( 'Custom field key', 'imagina-player' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => 'video_url',
				'description' => __( 'The name of a custom field on the post this widget is shown on — an ACF or JetEngine field, or any post meta — whose value is the file’s address or its media library ID. In a product template, each product supplies its own file.', 'imagina-player' ),
				'condition'   => array( 'source' => self::SOURCE_FIELD ),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => __( 'Title', 'imagina-player' ),
				'type'        => Controls_Manager::TEXT,
				'description' => __( 'Leave empty to use the file’s own title.', 'imagina-player' ),
				'dynamic'     => array( 'active' => true ),
			)
		);
	}

	/** The preset and the skin, and the one colour most people change. */
	protected function appearance_controls( string $medium ): void {
		$this->start_controls_section(
			'appearance',
			array( 'label' => __( 'Appearance', 'imagina-player' ) )
		);

		$presets = array();

		foreach ( Settings::presets() as $key => $preset ) {
			$presets[ (string) $key ] = (string) ( $preset['label'] ?? $key );
		}

		$this->add_control(
			'preset',
			array(
				'label'   => __( 'Preset', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => Settings::DEFAULT_PRESET,
				'options' => $presets,
			)
		);

		$skins = array( '' => __( 'Use preset', 'imagina-player' ) );

		foreach ( 'audio' === $medium ? \ImaginaPlayer\Player\Skins::all() : \ImaginaPlayer\Player\Skins::video() as $key => $label ) {
			$skins[ (string) $key ] = (string) $label;
		}

		$this->add_control(
			'skin',
			array(
				'label'   => __( 'Skin', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $skins,
			)
		);

		// The play-button-only skin's two questions, shown once it is chosen.
		if ( 'audio' === $medium ) {
			$this->add_control(
				'button_size',
				array(
					'label'     => __( 'Button size', 'imagina-player' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'medium',
					'options'   => array(
						'small'  => __( 'Small', 'imagina-player' ),
						'medium' => __( 'Medium', 'imagina-player' ),
						'large'  => __( 'Large', 'imagina-player' ),
					),
					'condition' => array( 'skin' => 'button' ),
				)
			);

			$this->add_control(
				'button_align',
				array(
					'label'     => __( 'Button position', 'imagina-player' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'start',
					'options'   => array(
						'start'  => __( 'At the start of the line', 'imagina-player' ),
						'center' => __( 'Centred', 'imagina-player' ),
						'end'    => __( 'At the end of the line', 'imagina-player' ),
					),
					'condition' => array( 'skin' => 'button' ),
				)
			);

			$this->add_control(
				'button_shape',
				array(
					'label'     => __( 'Shape', 'imagina-player' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'circle',
					'options'   => array(
						'circle'  => __( 'Circle', 'imagina-player' ),
						'rounded' => __( 'Rounded square', 'imagina-player' ),
						'square'  => __( 'Square', 'imagina-player' ),
					),
					'condition' => array( 'skin' => 'button' ),
				)
			);

			$this->add_control(
				'button_style',
				array(
					'label'     => __( 'Style', 'imagina-player' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'filled',
					'options'   => array(
						'filled'  => __( 'Filled', 'imagina-player' ),
						'outline' => __( 'Outline', 'imagina-player' ),
					),
					'condition' => array( 'skin' => 'button' ),
				)
			);

			$this->add_control(
				'button_label',
				array(
					'label'       => __( 'Text beside the icon', 'imagina-player' ),
					'type'        => Controls_Manager::TEXT,
					'description' => __( 'Optional, such as “Listen live”. Empty leaves the icon on its own.', 'imagina-player' ),
					'condition'   => array( 'skin' => 'button' ),
				)
			);

			/*
			 * The button's colour is the accent, under its own name: offered
			 * as "Accent colour" below the icon's, it was not found. It is
			 * mapped onto the accent, and the accent control is hidden here.
			 */
			$this->add_control(
				'button_color',
				array(
					'label'       => __( 'Button background', 'imagina-player' ),
					'type'        => Controls_Manager::COLOR,
					'alpha'       => false,
					'description' => __( 'With the outline style, the colour of its edge. Leave empty to use the preset’s.', 'imagina-player' ),
					'condition'   => array( 'skin' => 'button' ),
				)
			);

			$this->add_control(
				'button_icon_color',
				array(
					'label'       => __( 'Icon colour', 'imagina-player' ),
					'type'        => Controls_Manager::COLOR,
					'alpha'       => false,
					'description' => __( 'Leave empty for white or black, whichever reads on the button; an outline’s icon takes the button’s colour.', 'imagina-player' ),
					'condition'   => array( 'skin' => 'button' ),
				)
			);
		}

		$this->add_control(
			'accent',
			array(
				'condition'   => array( 'skin!' => 'button' ),
				'label'       => __( 'Accent colour', 'imagina-player' ),
				'type'        => Controls_Manager::COLOR,
				/*
				 * Solid colours only. Elementor's picker otherwise offers
				 * transparency and returns `rgba()`, which the player's colour
				 * filter does not take — the choice was dropped without a
				 * word and the preset's colour shown instead.
				 */
				'alpha'       => false,
				'description' => __( 'Leave empty to use the preset’s.', 'imagina-player' ),
			)
		);

		$this->add_control(
			'border_radius',
			array(
				// A lone button has a shape of its own instead.
				'condition' => array( 'skin!' => 'button' ),
				'label'   => __( 'Corner radius (px)', 'imagina-player' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 64,
				'default' => '',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * One three-way choice per control: the preset's answer, on, or off.
	 *
	 * @param array<string, string> $switches  Attribute name => label.
	 * @param array<string, string> $condition When the section is offered.
	 */
	protected function tristate_controls( string $section, string $label, array $switches, array $condition = array() ): void {
		$this->start_controls_section( $section, array( 'label' => $label ) + ( $condition ? array( 'condition' => $condition ) : array() ) );

		foreach ( $switches as $attribute => $text ) {
			$this->add_control(
				$attribute,
				array(
					'label'   => $text,
					'type'    => Controls_Manager::SELECT,
					'default' => '',
					'options' => self::tristate_options(),
				)
			);
		}

		$this->end_controls_section();
	}

	/**
	 * @return array<string, string>
	 */
	public static function tristate_options(): array {
		return array(
			''    => __( 'Use preset', 'imagina-player' ),
			'yes' => __( 'Show', 'imagina-player' ),
			'no'  => __( 'Hide', 'imagina-player' ),
		);
	}

	/** Calls to action: a card, a bar, or an email gate at a point in the playback. */
	protected function layer_controls(): void {
		$this->start_controls_section(
			'layers_section',
			array( 'label' => __( 'Overlays and calls to action', 'imagina-player' ) )
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'type',
			array(
				'label'   => __( 'Kind', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'cta',
				'options' => array(
					'cta'       => __( 'Card with a button', 'imagina-player' ),
					'bar'       => __( 'Bar with a button', 'imagina-player' ),
					'email'     => __( 'Email gate', 'imagina-player' ),
					'text'      => __( 'Text over the picture', 'imagina-player' ),
					'image'     => __( 'Image over the picture', 'imagina-player' ),
					'hotspot'   => __( 'Hotspot (a spot to press)', 'imagina-player' ),
					'shortcode' => __( 'Shortcode', 'imagina-player' ),
				),
			)
		);
		// Empty by default: each kind then appears when it naturally would — a
		// decoration from the start, a call to action at the end. A fixed 100
		// left a logo or a caption invisible until the video had finished.
		$repeater->add_control( 'at', array( 'label' => __( 'Show at (percent of playback)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => '', 'description' => __( 'Empty: from the start for text, images, hotspots and shortcodes; at the end for a call to action.', 'imagina-player' ) ) );
		$repeater->add_control( 'until', array( 'label' => __( 'Hide again at (percent of playback, 0 for never)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => 0 ) );
		$repeater->add_control( 'shortcode', array( 'label' => __( 'Shortcode', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => '[contact-form-7 id="12"]', 'description' => __( 'Any shortcode another plugin provides. It runs when the page is shown.', 'imagina-player' ), 'condition' => array( 'type' => 'shortcode' ) ) );
		$repeater->add_control( 'image', array( 'label' => __( 'Image', 'imagina-player' ), 'type' => Controls_Manager::MEDIA, 'media_types' => array( 'image' ), 'dynamic' => array( 'active' => true ), 'condition' => array( 'type' => 'image' ) ) );
		$repeater->add_control( 'width', array( 'label' => __( 'Width (percent of the picture)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 5, 'max' => 100, 'default' => 25, 'condition' => array( 'type' => 'image' ) ) );
		$repeater->add_control( 'x', array( 'label' => __( 'Across (percent from the left)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => 50, 'condition' => array( 'type' => 'hotspot' ) ) );
		$repeater->add_control( 'y', array( 'label' => __( 'Down (percent from the top)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => 50, 'condition' => array( 'type' => 'hotspot' ) ) );
		$repeater->add_control(
			'position',
			array(
				'label'     => __( 'Position', 'imagina-player' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''             => __( 'Default for the kind', 'imagina-player' ),
					'top-left'     => __( 'Top left', 'imagina-player' ),
					'top'          => __( 'Top', 'imagina-player' ),
					'top-right'    => __( 'Top right', 'imagina-player' ),
					'left'         => __( 'Left', 'imagina-player' ),
					'center'       => __( 'Centre', 'imagina-player' ),
					'right'        => __( 'Right', 'imagina-player' ),
					'bottom-left'  => __( 'Bottom left', 'imagina-player' ),
					'bottom'       => __( 'Bottom', 'imagina-player' ),
					'bottom-right' => __( 'Bottom right', 'imagina-player' ),
				),
				'condition' => array( 'type' => array( 'text', 'image', 'shortcode' ) ),
			)
		);
		$repeater->add_control( 'title', array( 'label' => __( 'Title', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'dynamic' => array( 'active' => true ), 'condition' => array( 'type!' => 'shortcode' ) ) );
		$repeater->add_control( 'text', array( 'label' => __( 'Text', 'imagina-player' ), 'type' => Controls_Manager::TEXTAREA, 'dynamic' => array( 'active' => true ), 'condition' => array( 'type!' => array( 'shortcode', 'image' ) ) ) );
		$repeater->add_control( 'button', array( 'label' => __( 'Button label', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'type' => array( 'cta', 'bar', 'email' ) ) ) );
		$repeater->add_control( 'url', array( 'label' => __( 'Link', 'imagina-player' ), 'type' => Controls_Manager::URL, 'options' => false, 'dynamic' => array( 'active' => true ), 'condition' => array( 'type!' => array( 'email', 'shortcode' ) ) ) );
		$repeater->add_control( 'new_tab', array( 'label' => __( 'Open in a new tab', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER, 'condition' => array( 'type!' => array( 'email', 'shortcode' ) ) ) );
		$repeater->add_control( 'skip', array( 'label' => __( 'Can be dismissed', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ) );
		$repeater->add_control( 'list', array( 'label' => __( 'List name', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Where the address is filed in Leads.', 'imagina-player' ), 'condition' => array( 'type' => 'email' ) ) );
		$repeater->add_control( 'consent', array( 'label' => __( 'Consent text', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'type' => 'email' ) ) );
		$repeater->add_control( 'thanks', array( 'label' => __( 'Thank-you text', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'type' => 'email' ) ) );

		$this->add_control(
			'layers',
			array(
				'label'       => __( 'Overlays', 'imagina-player' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ title || type }}}',
			)
		);

		$this->end_controls_section();
	}

	/* ---- Reading Elementor's settings ------------------------------------ */

	/**
	 * The file, from whichever of the three sources the widget was told.
	 *
	 * @param array<string, mixed> $settings
	 * @return array{src: string, attachmentId: int, sourceField: string}
	 */
	/**
	 * Who may play it: the same rule as the blocks, in a section of its own.
	 */
	protected function access_controls(): void {
		$this->start_controls_section(
			'access_section',
			array( 'label' => __( 'Who can play it', 'imagina-player' ) )
		);

		$rules = array( '' => __( 'Everyone', 'imagina-player' ) );

		foreach ( \ImaginaPlayer\Player\Access::rules() as $key => $rule ) {
			$rules[ $key ] = $rule['available']
				? $rule['label']
				/* translators: %s: the rule's name. */
				: sprintf( __( '%s — not active', 'imagina-player' ), $rule['label'] );
		}

		$this->add_control(
			'access_rule',
			array(
				'label'       => __( 'Plays for', 'imagina-player' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $rules,
				'description' => __( 'Whoever can edit the page always sees the player. Everybody else who may not play it gets no part of the file: no address, no subtitles, no download.', 'imagina-player' ),
			)
		);
		$this->add_control( 'access_ids', array( 'label' => __( 'Roles or IDs', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Separated by commas: role names, or product, plan, membership or course IDs.', 'imagina-player' ), 'condition' => array( 'access_rule!' => array( '', 'logged_in' ) ) ) );
		$this->add_control( 'access_message', array( 'label' => __( 'Message', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'access_rule!' => '' ) ) );
		$this->add_control( 'access_button', array( 'label' => __( 'Button label', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'condition' => array( 'access_rule!' => '' ) ) );
		$this->add_control( 'access_url', array( 'label' => __( 'Button links to', 'imagina-player' ), 'type' => Controls_Manager::URL, 'options' => false, 'condition' => array( 'access_rule!' => '' ) ) );

		$this->end_controls_section();
	}

	/**
	 * @param array<string, mixed> $settings Widget settings.
	 * @return array<string, string>
	 */
	protected static function access_from( array $settings ): array {
		return array(
			'accessRule'    => (string) ( $settings['access_rule'] ?? '' ),
			'accessIds'     => (string) ( $settings['access_ids'] ?? '' ),
			'accessMessage' => (string) ( $settings['access_message'] ?? '' ),
			'accessButton'  => (string) ( $settings['access_button'] ?? '' ),
			'accessUrl'     => self::url_from( $settings['access_url'] ?? '' ),
		);
	}

	protected static function source_from( array $settings ): array {
		$source = (string) ( $settings['source'] ?? self::SOURCE_LIBRARY );
		$out    = array(
			'src'          => '',
			'attachmentId' => 0,
			'sourceField'  => '',
		);

		if ( self::SOURCE_FIELD === $source ) {
			$out['sourceField'] = (string) ( $settings['source_field'] ?? '' );

			return $out;
		}

		if ( self::SOURCE_URL === $source ) {
			$out['src'] = self::url_from( $settings['url'] ?? '' );

			return $out;
		}

		$media = $settings['media'] ?? array();

		if ( is_array( $media ) ) {
			$out['attachmentId'] = (int) ( $media['id'] ?? 0 );
			$out['src']          = (string) ( $media['url'] ?? '' );
		}

		return $out;
	}

	/**
	 * An address from a URL control, which stores an array, or from a plain
	 * string, which a dynamic tag may hand over.
	 *
	 * @param mixed $value
	 */
	protected static function url_from( $value ): string {
		if ( is_array( $value ) ) {
			return (string) ( $value['url'] ?? '' );
		}

		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * An image from a MEDIA control: its id and its address.
	 *
	 * @param mixed $value
	 * @return array{id: int, url: string}
	 */
	protected static function image_from( $value ): array {
		if ( ! is_array( $value ) ) {
			return array(
				'id'  => 0,
				'url' => '',
			);
		}

		return array(
			'id'  => (int) ( $value['id'] ?? 0 ),
			'url' => (string) ( $value['url'] ?? '' ),
		);
	}

	/** A switcher: "yes" or nothing. */
	protected static function switch_from( array $settings, string $key ): bool {
		return 'yes' === ( $settings[ $key ] ?? '' );
	}

	/**
	 * Every three-way choice the widget offers, copied across by name.
	 *
	 * @param array<string, mixed> $settings
	 * @param string[]             $names
	 * @return array<string, string>
	 */
	protected static function tristates_from( array $settings, array $names ): array {
		$out = array();

		foreach ( $names as $name ) {
			$out[ $name ] = Attributes::to_tristate( $settings[ $name ] ?? '' );
		}

		return $out;
	}

	/**
	 * The calls to action, in the shape the renderer's own sanitiser takes.
	 *
	 * @param mixed $rows What the repeater stored.
	 * @return array<int, array<string, mixed>>
	 */
	protected static function layers_from( $rows ): array {
		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$image = self::image_from( $row['image'] ?? null );

			$layer = array(
				'type'      => (string) ( $row['type'] ?? 'cta' ),
				'at'        => (int) ( $row['at'] ?? 100 ),
				'until'     => (int) ( $row['until'] ?? 0 ),
				'title'     => (string) ( $row['title'] ?? '' ),
				'text'      => (string) ( $row['text'] ?? '' ),
				'button'    => (string) ( $row['button'] ?? '' ),
				'url'       => self::url_from( $row['url'] ?? '' ),
				'newTab'    => 'yes' === ( $row['new_tab'] ?? '' ),
				'skip'      => 'yes' === ( $row['skip'] ?? '' ),
				'list'      => (string) ( $row['list'] ?? '' ),
				'consent'   => (string) ( $row['consent'] ?? '' ),
				'thanks'    => (string) ( $row['thanks'] ?? '' ),
				'position'  => (string) ( $row['position'] ?? '' ),
				'image'     => $image['url'],
				'imageId'   => $image['id'],
				'width'     => (int) ( $row['width'] ?? 25 ),
				'x'         => (int) ( $row['x'] ?? 50 ),
				'y'         => (int) ( $row['y'] ?? 50 ),
				'shortcode' => (string) ( $row['shortcode'] ?? '' ),
			);

			// Left empty, the kind decides when it appears (see `Layers::sanitize`).
			if ( ! isset( $row['at'] ) || '' === $row['at'] || null === $row['at'] ) {
				unset( $layer['at'] );
			}

			$out[] = $layer;
		}

		return $out;
	}

	/**
	 * A number control that may be empty, as the text the attribute takes.
	 *
	 * @param mixed  $value
	 * @param string $unit  Appended when there is a number.
	 */
	protected static function number_from( $value, string $unit = '' ): string {
		if ( null === $value || '' === $value || ! is_numeric( $value ) ) {
			return '';
		}

		return (string) ( 0 + $value ) . $unit;
	}
}
