<?php
/**
 * Removes everything the plugin stored.
 *
 * Everything, which the first version of this did not: it left the table of
 * captured email addresses — personal data — and, worse, every file that had
 * been moved into the protected vault. The vault directory carries a rule that
 * denies direct access, and with the plugin gone there is nothing left to serve
 * those files through, so they were unreachable by anyone for ever. Moving
 * them back is the first thing done here, before anything that records where
 * they are is deleted.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

/*
 * Protected files back into the open, using the plugin's own code while it is
 * still on disk. Done before the options go, because the vault's location is
 * derived from them.
 */
require_once __DIR__ . '/src/Support/Autoloader.php';

ImaginaPlayer\Support\Autoloader::register( 'ImaginaPlayer', __DIR__ . '/src' );

// The main file is not loaded during uninstall, and one default reads this.
if ( ! defined( 'ImaginaPlayer\\VERSION' ) ) {
	define( 'ImaginaPlayer\\VERSION', '0' );
}

/**
 * Remove a directory tree that holds nothing but guard files.
 *
 * @param string $dir Absolute path.
 * @return bool Whether the directory is gone.
 */
function imagina_player_remove_empty_vault( string $dir ): bool {
	if ( ! is_dir( $dir ) ) {
		return true;
	}

	$entries = scandir( $dir );

	if ( false === $entries ) {
		return false;
	}

	$empty  = true;
	$guards = array();

	foreach ( $entries as $entry ) {
		if ( '.' === $entry || '..' === $entry ) {
			continue;
		}

		$path = $dir . DIRECTORY_SEPARATOR . $entry;

		if ( is_dir( $path ) ) {
			if ( ! imagina_player_remove_empty_vault( $path ) ) {
				$empty = false;
			}

			continue;
		}

		if ( in_array( $entry, array( 'index.php', '.htaccess', 'web.config' ), true ) ) {
			$guards[] = $path;

			continue;
		}

		$empty = false;
	}

	/*
	 * The guard files go last, and only when nothing else is left: they are
	 * the rules that keep whatever is in here from being served, and a folder
	 * that still holds a file keeps them.
	 */
	if ( ! $empty ) {
		return false;
	}

	foreach ( $guards as $guard ) {
		wp_delete_file( $guard );
	}

	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- own directory, uninstall.
	return @rmdir( $dir );
}

/**
 * Everything this plugin keeps for one site.
 *
 * A function so a network install can run it for every site. Run once, at
 * the network's main site, it left every other site's options, tables,
 * waveforms and captured addresses behind.
 */
function imagina_player_uninstall_site(): void {
	global $wpdb;

	if ( class_exists( 'ImaginaPlayer\\Protection\\Vault' ) ) {
		$protected = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_imagina_protected', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- uninstall, runs once.
				'meta_value'     => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
			)
		);

		foreach ( $protected as $attachment_id ) {
			ImaginaPlayer\Protection\Vault::unprotect( (int) $attachment_id );
		}
	}

	/*
	 * The vault directory itself, once nothing is left in it. Seen on a real
	 * site: every file had been moved back and an empty tree stayed behind, with
	 * the deny rules still in it — a folder nobody can open, for nothing. Only
	 * the guard files this plugin wrote and empty folders are removed; a file of
	 * any other kind, however it got there, stops the removal at that level.
	 */
	if ( class_exists( 'ImaginaPlayer\\Protection\\Vault' ) ) {
		imagina_player_remove_empty_vault( ImaginaPlayer\Protection\Vault::base_dir() );
	}

	delete_post_meta_by_key( '_imagina_protected' );

	// Options, including the ones earlier versions used.
	foreach ( array(
		'imagina_player_settings',
		'imagina_player_version',
		'imagina_player_schema',
		'imagina_player_peaks_db_version',
		'imagina_player_leads_db',
		// Where captured addresses are sent, with the API keys, and how it went.
		'imagina_player_integrations',
		'imagina_player_integration_log',
		// The version of the statistics tables.
		'imagina_player_stats_db',
	) as $option ) {
		delete_option( $option );
	}

	// Waveforms cached against attachments.
	delete_post_meta_by_key( '_imagina_player_peaks' );

	// Students' progress through courses. User meta is shared by a network,
	// so this runs once per site and finds nothing after the first.
	if ( function_exists( 'delete_metadata' ) ) {
		delete_metadata( 'user', 0, 'imagina_player_progress', '', true );
	}

	// Waveforms cached against external URLs, the captured addresses, and the
	// play counts.
	foreach ( array( 'imagina_player_peaks', 'imagina_player_leads', 'imagina_player_stats', 'imagina_player_stats_media' ) as $table ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- own tables, fixed names.
		$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . $table );
	}

	/*
	 * Transients, by prefix. There is no core call for "every transient starting
	 * with", and waiting for them to expire leaves rows behind for up to a month.
	 */
	foreach ( array( 'imgp_vimeo_thumb_', 'imagina_peaks_queued_', 'imagina_peaks_lock_', 'imagina_peaks_running_', 'imgp_lead_', 'imgp_stream_net_', 'imgp_proxy_user_', 'imgp_stats_net_', 'imgp_tx_' ) as $prefix ) {
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- uninstall, runs once.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . $prefix ) . '%',
				$wpdb->esc_like( '_transient_timeout_' . $prefix ) . '%'
			)
		);
	}

	wp_clear_scheduled_hook( 'imagina_player_generate_peaks' );
	wp_clear_scheduled_hook( 'imagina_player_purge_counters' );
	wp_clear_scheduled_hook( 'imagina_player_vimeo_thumbnail' );
	wp_clear_scheduled_hook( 'imagina_player_deliver_lead' );
	wp_clear_scheduled_hook( 'imagina_player_transcribe' );
	wp_clear_scheduled_hook( 'imagina_player_purge_stats' );
}

if ( is_multisite() && function_exists( 'get_sites' ) ) {
	foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $site_id ) {
		switch_to_blog( (int) $site_id );
		imagina_player_uninstall_site();
		restore_current_blog();
	}
} else {
	imagina_player_uninstall_site();
}
