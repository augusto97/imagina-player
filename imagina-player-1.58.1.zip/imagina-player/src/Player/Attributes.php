<?php
/**
 * The canonical per-instance attribute schema.
 *
 * Block attributes, shortcode attributes and the REST preview endpoint all read
 * from this schema so the three entry points can never drift apart.
 *
 * Visual toggles are tri-state strings — `''` means "inherit from the preset",
 * `'yes'`/`'no'` force the value. Booleans would have made "inherit" impossible
 * to express in a shortcode.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Player;

use ImaginaPlayer\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Attributes {

	public const INHERIT = '';

	/** How big the play-button-only skin draws its button. */
	public const BUTTON_SIZES = array( 'small', 'medium', 'large' );

	/** Where in its column that button sits. */
	public const BUTTON_ALIGNS = array( 'start', 'center', 'end' );

	/** Its shape, and whether it is filled or drawn as an outline. */
	public const BUTTON_SHAPES = array( 'circle', 'rounded', 'square' );

	public const BUTTON_STYLES = array( 'filled', 'outline' );

	/**
	 * Preset keys that a single instance may override, mapped to the attribute
	 * name used by blocks and shortcodes.
	 *
	 * @var array<string, string>
	 */
	private const OVERRIDE_MAP = array(
		'skin'              => 'skin',
		'accent'            => 'accent',
		'wave_color'        => 'waveColor',
		'wave_progress'     => 'waveProgress',
		'text_color'        => 'textColor',
		'meta_color'        => 'metaColor',
		'control_color'     => 'controlColor',
		'background'        => 'background',
		'height'            => 'height',
		// A block could not round its own corners: the radius existed on the
		// preset, so a site had one answer and no single player could differ.
		'border_radius'     => 'borderRadius',
		'preload'           => 'preload',
		'show_artist'       => 'showArtist',
		'show_title'        => 'showTitle',
		'show_thumbnail'    => 'showThumbnail',
		'show_volume'       => 'showVolume',
		'show_time'         => 'showTime',
		'show_download'     => 'showDownload',
		'show_speed'        => 'showSpeed',
		'show_skip'         => 'showSkip',
		'show_more'         => 'showMore',
		'skip_seconds'      => 'skipSeconds',
		'sticky'            => 'sticky',
		'remember_position' => 'rememberPosition',
	);

	/**
	 * @return array<string, string> Preset key => attribute name.
	 */
	public static function override_map(): array {
		return self::OVERRIDE_MAP;
	}

	/**
	 * Full schema: attribute name => [ type, default ].
	 *
	 * `type` is one of string|int|float|bool|tristate|array.
	 *
	 * @return array<string, array{type: string, default: mixed}>
	 */
	/** Landscape 16:9, which is what almost every recording is. */
	public const DEFAULT_RATIO = '16:9';

	public static function schema(): array {
		$schema = array(
			'src'          => array(
				'type'    => 'string',
				'default' => '',
			),
			'attachmentId' => array(
				'type'    => 'int',
				'default' => 0,
			),
			// A custom field of the post the block is shown on, whose value
			// is the file: for a template that shows many posts. See
			// Media\DynamicSource.
			'sourceField'  => array(
				'type'    => 'string',
				'default' => '',
			),
			'title'        => array(
				'type'    => 'string',
				'default' => '',
			),
			'artist'       => array(
				'type'    => 'string',
				'default' => '',
			),
			'thumbnail'    => array(
				'type'    => 'string',
				'default' => '',
			),
			'thumbnailId'  => array(
				'type'    => 'int',
				'default' => 0,
			),
			'downloadUrl'  => array(
				'type'    => 'string',
				'default' => '',
			),
			'preset'       => array(
				'type'    => 'string',
				'default' => Settings::DEFAULT_PRESET,
			),
			'autoplay'     => array(
				'type'    => 'bool',
				'default' => false,
			),
			'loop'         => array(
				'type'    => 'bool',
				'default' => false,
			),
			'muted'        => array(
				'type'    => 'bool',
				'default' => false,
			),
			'startTime'    => array(
				'type'    => 'float',
				'default' => 0.0,
			),
			'className'    => array(
				'type'    => 'string',
				'default' => '',
			),
			'borderRadius' => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),

			/*
			 * The video settings a block may answer for itself. Tristate, like
			 * every other override: an unset one inherits whatever the site was
			 * set up with, which is what an author who configured it once
			 * expects and what keeps a block from freezing today's defaults
			 * into every post.
			 */
			'videoBigPlay'       => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			/*
			 * Hide the provider's own interface on a video hosted elsewhere,
			 * so it looks like every other video on the site.
			 */
			'videoProviderBare'  => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoFullscreen'    => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoPip'           => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoSpeed'         => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoBlockDownload' => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoPosterFit'     => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			// Milliseconds before the controls fade during playback; empty
			// inherits, and zero is a real answer meaning "never".
			'videoHideAfter'     => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			/*
			 * A WebVTT storyboard: cues whose payload is a sprite sheet with a
			 * `#xywh=` fragment naming the tile. Every tool that makes these
			 * produces that shape, and one image holds a hundred stills, so the
			 * whole feature costs one request — and only for a reader who
			 * actually drags the bar.
			 */
			// How the picture and its bar are painted, per block. Presto keeps
			// these on the preset and Fluent on the player; a block that can
			// answer for one video is the more useful of the two, and leaving
			// them unset still follows the site.
			'videoCaptions'      => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoSearch'        => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoTranscript'    => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoChapters'      => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoSkip'          => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoTime'          => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoVolume'        => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoTitle'         => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			// A mark over the picture: a logo in a corner, faint, the whole way
			// through. Presto keeps one per preset; this one is per block,
			// because the reason to put a mark on a video is usually that this
			// particular video is going somewhere it should be traceable from.
			'watermark'          => array(
				'type'    => 'string',
				'default' => '',
			),
			'watermarkId'        => array(
				'type'    => 'int',
				'default' => 0,
			),
			'watermarkPosition'  => array(
				'type'    => 'string',
				'default' => 'top-right',
			),
			'watermarkOpacity'   => array(
				'type'    => 'int',
				'default' => 55,
			),
			'videoFocusMode'     => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoCaptionsOn'    => array(
				'type'    => 'tristate',
				'default' => self::INHERIT,
			),
			'videoCaptionSize'   => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			// The play-button-only skin: how big the button is, and which side
			// of its column it sits on.
			'buttonSize'         => array(
				'type'    => 'string',
				'default' => 'medium',
			),
			'buttonAlign'        => array(
				'type'    => 'string',
				'default' => 'start',
			),
			// Its look: the shape, filled or an outline, words beside the
			// icon if any, and the icon's own colour — the button's colour is
			// the accent, as it is on every player.
			'buttonShape'        => array(
				'type'    => 'string',
				'default' => 'circle',
			),
			'buttonStyle'        => array(
				'type'    => 'string',
				'default' => 'filled',
			),
			'buttonLabel'        => array(
				'type'    => 'string',
				'default' => '',
			),
			'buttonIconColor'    => array(
				'type'    => 'string',
				'default' => '',
			),
			'videoCaptionBg'     => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			'videoChromeColor'   => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			'videoCaptionColor'  => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			'videoControlColor'  => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			'videoProgressColor' => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
			'storyboard'         => array(
				'type'    => 'string',
				'default' => '',
			),
			'storyboardId'       => array(
				'type'    => 'int',
				'default' => 0,
			),

			// Video. Ignored for audio, which is why they carry empty defaults
			// rather than being a separate schema: one block, one shape, and a
			// track that changes kind does not lose its settings.
			'poster'       => array(
				'type'    => 'string',
				'default' => '',
			),
			'posterId'     => array(
				'type'    => 'int',
				'default' => 0,
			),
			'aspectRatio'  => array(
				'type'    => 'string',
				// Empty, not 16:9: an unset block follows the site's setting.
				'default' => '',
			),
			'tracks'       => array(
				'type'    => 'array',
				'default' => array(),
			),
			'chapters'     => array(
				'type'    => 'array',
				'default' => array(),
			),

			/*
			 * The same video in other sizes, for the viewer to choose from, and
			 * other soundtracks for it — a dubbing — played in step with the
			 * picture. Each label names the main file's own entry in the list;
			 * empty is "Original".
			 */
			'sources'      => array(
				'type'    => 'array',
				'default' => array(),
			),
			'qualityLabel' => array(
				'type'    => 'string',
				'default' => '',
			),
			'audioTracks'  => array(
				'type'    => 'array',
				'default' => array(),
			),
			'audioLabel'   => array(
				'type'    => 'string',
				'default' => '',
			),
			'layers'       => array(
				'type'    => 'array',
				'default' => array(),
			),

			/*
			 * Who may play it, and what the rest are offered instead. Empty is
			 * everyone. See `Access`.
			 */
			'accessRule'    => array(
				'type'    => 'string',
				'default' => '',
			),
			'accessIds'     => array(
				'type'    => 'string',
				'default' => '',
			),
			'accessMessage' => array(
				'type'    => 'string',
				'default' => '',
			),
			'accessButton'  => array(
				'type'    => 'string',
				'default' => '',
			),
			'accessUrl'     => array(
				'type'    => 'string',
				'default' => '',
			),

			// The viewer's own name or email over the picture. Empty follows
			// the site's video settings.
			'videoViewerMark' => array(
				'type'    => 'string',
				'default' => self::INHERIT,
			),
		);

		$preset_defaults = Settings::preset_defaults();

		foreach ( self::OVERRIDE_MAP as $preset_key => $attribute ) {
			$default = $preset_defaults[ $preset_key ] ?? '';

			$schema[ $attribute ] = array(
				'type'    => is_bool( $default ) ? 'tristate' : 'string',
				'default' => self::INHERIT,
			);
		}

		/**
		 * Filter the player attribute schema.
		 *
		 * @param array<string, array{type: string, default: mixed}> $schema Attribute schema.
		 */
		return apply_filters( 'imagina_player_attribute_schema', $schema );
	}

	/**
	 * @return array<string, mixed> Attribute name => default value.
	 */
	public static function defaults(): array {
		return array_map(
			static fn( array $definition ): mixed => $definition['default'],
			self::schema()
		);
	}

	/**
	 * Coerce raw input (shortcode strings, block JSON) into the schema.
	 *
	 * @param array<string, mixed> $input Raw attributes.
	 * @return array<string, mixed>
	 */
	public static function sanitize( array $input ): array {
		$out = array();

		foreach ( self::schema() as $name => $definition ) {
			$raw = $input[ $name ] ?? $definition['default'];

			$out[ $name ] = match ( $definition['type'] ) {
				'int'      => (int) $raw,
				'float'    => (float) $raw,
				'bool'     => self::to_bool( $raw ),
				'tristate' => self::to_tristate( $raw ),
				'array'    => self::to_array( $raw ),
				default    => is_scalar( $raw ) ? (string) $raw : '',
			};
		}

		$out['src']         = self::sanitize_media_url( (string) $out['src'] );
		$out['sourceField'] = \ImaginaPlayer\Media\DynamicSource::sanitize_key( (string) $out['sourceField'] );
		$out['downloadUrl'] = self::sanitize_media_url( (string) $out['downloadUrl'] );
		$out['thumbnail']   = self::sanitize_media_url( (string) $out['thumbnail'] );
		$out['title']       = sanitize_text_field( (string) $out['title'] );
		$out['artist']      = sanitize_text_field( (string) $out['artist'] );
		$out['preset']      = sanitize_key( (string) $out['preset'] ) ?: Settings::DEFAULT_PRESET;
		$out['className']   = trim( preg_replace( '/[^A-Za-z0-9 _-]/', '', (string) $out['className'] ) ?? '' );
		// `start_time="1:30"` in a shortcode is a minute and a half, as it is
		// for a chapter; the plain cast made it one second.
		$out['startTime']   = max( 0.0, self::to_seconds( $input['startTime'] ?? $out['startTime'] ) );
		$out['poster']      = self::sanitize_media_url( (string) $out['poster'] );
		// The one address that was not on this list. It reaches fetch() and a
		// CSS url() in every visitor's browser, so it gets the same treatment.
		$out['storyboard']  = self::sanitize_media_url( (string) $out['storyboard'] );
		// An empty ratio means "whatever the site says", not "16:9 regardless":
		// a site that works in vertical video should not have to set it on
		// every block.
		$out['aspectRatio'] = '' === trim( (string) $out['aspectRatio'] )
			? self::sanitize_ratio( (string) ( Settings::video()['ratio'] ?? self::DEFAULT_RATIO ) )
			: self::sanitize_ratio( (string) $out['aspectRatio'] );
		$out['tracks']      = self::sanitize_tracks( (array) $out['tracks'] );
		$out['chapters']    = self::sanitize_chapters( (array) $out['chapters'] );
		$out['sources']      = self::sanitize_sources( (array) $out['sources'] );
		$out['qualityLabel'] = self::label( (string) $out['qualityLabel'] );
		$out['audioTracks']  = self::sanitize_audio_tracks( (array) $out['audioTracks'] );
		$out['audioLabel']   = self::label( (string) $out['audioLabel'] );
		$out['layers']      = Layers::sanitize( (array) $out['layers'] );
		$out['buttonSize']  = in_array( $out['buttonSize'], self::BUTTON_SIZES, true ) ? $out['buttonSize'] : 'medium';
		$out['buttonAlign'] = in_array( $out['buttonAlign'], self::BUTTON_ALIGNS, true ) ? $out['buttonAlign'] : 'start';
		$out['buttonShape'] = in_array( $out['buttonShape'], self::BUTTON_SHAPES, true ) ? $out['buttonShape'] : 'circle';
		$out['buttonStyle'] = in_array( $out['buttonStyle'], self::BUTTON_STYLES, true ) ? $out['buttonStyle'] : 'filled';
		$out['buttonLabel'] = mb_substr( sanitize_text_field( (string) $out['buttonLabel'] ), 0, 60 );
		$out['buttonIconColor'] = Settings::sanitize_color( (string) $out['buttonIconColor'], '' );

		$out['accessRule']    = Access::rule( (string) $out['accessRule'] );
		$out['accessIds']     = implode( ',', Access::ids( (string) $out['accessIds'] ) );
		$out['accessMessage'] = sanitize_text_field( (string) $out['accessMessage'] );
		$out['accessButton']  = sanitize_text_field( (string) $out['accessButton'] );
		$out['accessUrl']     = esc_url_raw( (string) $out['accessUrl'], array( 'http', 'https' ) );

		return $out;
	}

	/**
	 * Media URLs may be relative (`/wp-content/...`) or protocol-relative, and
	 * `esc_url_raw` keeps both while dropping `javascript:` and friends.
	 */
	public static function sanitize_media_url( string $url ): string {
		$url = trim( $url );

		if ( '' === $url ) {
			return '';
		}

		return esc_url_raw( $url, array( 'http', 'https' ) );
	}

	/**
	 * An aspect ratio, as `w:h`.
	 *
	 * This reaches CSS, so it is rebuilt from two integers rather than escaped:
	 * a value that arrives as anything other than two numbers cannot leave here
	 * as anything at all. Bounded because a ratio of 1:900 is a page-breaking
	 * sliver, not a design choice.
	 */
	public static function sanitize_ratio( string $ratio ): string {
		if ( ! preg_match( '/^\s*(\d{1,4})\s*[:\/]\s*(\d{1,4})\s*$/', $ratio, $parts ) ) {
			return self::DEFAULT_RATIO;
		}

		$width  = (int) $parts[1];
		$height = (int) $parts[2];

		if ( $width < 1 || $height < 1 ) {
			return self::DEFAULT_RATIO;
		}

		$factor = $width / $height;

		if ( $factor < 0.25 || $factor > 4.0 ) {
			return self::DEFAULT_RATIO;
		}

		return $width . ':' . $height;
	}

	/**
	 * A list, from a block's JSON or a shortcode's JSON string.
	 *
	 * @return array<int, mixed>
	 */
	public static function to_array( mixed $value ): array {
		if ( is_array( $value ) ) {
			return array_values( $value );
		}

		if ( is_string( $value ) && '' !== trim( $value ) ) {
			$decoded = json_decode( $value, true );

			return is_array( $decoded ) ? array_values( $decoded ) : array();
		}

		return array();
	}

	/** Choices offered to a viewer at most, of each kind. */
	public const MAX_CHOICES = 8;

	/**
	 * Other files for the same video: a quality each.
	 *
	 * One from the library keeps its number, so the address is asked for
	 * when the page is drawn — a protected file answers on a signed link —
	 * rather than trusted from what was saved.
	 *
	 * @param array<int, mixed> $sources Raw sources.
	 * @return array<int, array{src: string, id: int, label: string}>
	 */
	public static function sanitize_sources( array $sources ): array {
		$clean = array();

		foreach ( $sources as $source ) {
			if ( ! is_array( $source ) ) {
				continue;
			}

			$src = self::sanitize_media_url( (string) ( $source['src'] ?? '' ) );
			$id  = max( 0, (int) ( $source['id'] ?? 0 ) );

			if ( '' === $src && 0 === $id ) {
				continue;
			}

			$clean[] = array(
				'src'   => $src,
				'id'    => $id,
				'label' => self::label( (string) ( $source['label'] ?? '' ) ),
			);
		}

		return array_slice( $clean, 0, self::MAX_CHOICES );
	}

	/**
	 * Other soundtracks for the video, played in step with it.
	 *
	 * @param array<int, mixed> $tracks Raw tracks.
	 * @return array<int, array{src: string, id: int, label: string, srclang: string}>
	 */
	public static function sanitize_audio_tracks( array $tracks ): array {
		$clean = array();

		foreach ( $tracks as $track ) {
			$source = is_array( $track ) ? self::sanitize_sources( array( $track ) ) : array();

			if ( array() === $source ) {
				continue;
			}

			// It reaches a `lang`-like choice a browser parses: cut down to
			// what a language tag may hold, as a subtitle's is.
			$language = strtolower( (string) preg_replace( '/[^A-Za-z0-9-]/', '', (string) ( $track['srclang'] ?? '' ) ) );
			$clean[]  = $source[0] + array( 'srclang' => substr( $language, 0, 20 ) );
		}

		return array_slice( $clean, 0, self::MAX_CHOICES );
	}

	/** A name a viewer reads in a menu: plain, and short. */
	private static function label( string $label ): string {
		return mb_substr( sanitize_text_field( $label ), 0, 40 );
	}

	/**
	 * Subtitle tracks.
	 *
	 * A track with no source is not a track. A language code reaches the `srclang`
	 * attribute, which browsers parse, so it is cut down to what BCP 47 allows
	 * rather than escaped and hoped for.
	 *
	 * @param array<int, mixed> $tracks Raw tracks.
	 * @return array<int, array{src: string, srclang: string, label: string, kind: string, default: bool}>
	 */
	public static function sanitize_tracks( array $tracks ): array {
		$clean   = array();
		$default = false;

		foreach ( $tracks as $track ) {
			if ( ! is_array( $track ) ) {
				continue;
			}

			$src = self::sanitize_media_url( (string) ( $track['src'] ?? '' ) );

			if ( '' === $src ) {
				continue;
			}

			$kind = (string) ( $track['kind'] ?? 'subtitles' );

			if ( ! in_array( $kind, array( 'subtitles', 'captions', 'descriptions' ), true ) ) {
				$kind = 'subtitles';
			}

			$language = strtolower( (string) preg_replace( '/[^A-Za-z0-9-]/', '', (string) ( $track['srclang'] ?? '' ) ) );
			$language = substr( $language, 0, 20 );

			// Only the first default wins: two default tracks is not a state a
			// browser has an answer for.
			$is_default = ! $default && ! empty( $track['default'] );
			$default    = $default || $is_default;

			$clean[] = array(
				'src'     => $src,
				'srclang' => $language,
				'label'   => sanitize_text_field( (string) ( $track['label'] ?? $language ) ),
				'kind'    => $kind,
				'default' => $is_default,
			);
		}

		return $clean;
	}

	/**
	 * Chapters, in order and without overlaps.
	 *
	 * Sorted here rather than trusted from the editor, because the VTT built from
	 * them has to be monotonic and a browser given cues out of order simply drops
	 * the ones it does not like — silently.
	 *
	 * @param array<int, mixed> $chapters Raw chapters.
	 * @return array<int, array{start: float, title: string}>
	 */
	public static function sanitize_chapters( array $chapters ): array {
		$clean = array();

		foreach ( $chapters as $chapter ) {
			if ( ! is_array( $chapter ) ) {
				continue;
			}

			$title = sanitize_text_field( (string) ( $chapter['title'] ?? '' ) );

			if ( '' === $title ) {
				continue;
			}

			$clean[] = array(
				'start' => max( 0.0, self::to_seconds( $chapter['start'] ?? 0 ) ),
				'title' => $title,
			);
		}

		usort( $clean, static fn( array $a, array $b ): int => $a['start'] <=> $b['start'] );

		// Two chapters starting at the same second would produce a zero-length
		// cue, which is not a cue.
		$seen = array();

		return array_values(
			array_filter(
				$clean,
				static function ( array $chapter ) use ( &$seen ): bool {
					$key = (string) $chapter['start'];

					if ( isset( $seen[ $key ] ) ) {
						return false;
					}

					$seen[ $key ] = true;

					return true;
				}
			)
		);
	}

	/**
	 * Seconds from a number or a `mm:ss` / `hh:mm:ss` string.
	 */
	public static function to_seconds( mixed $value ): float {
		if ( is_numeric( $value ) ) {
			return (float) $value;
		}

		if ( ! is_string( $value ) ) {
			return 0.0;
		}

		$parts = array_reverse( array_map( 'trim', explode( ':', $value ) ) );
		$total = 0.0;

		foreach ( $parts as $index => $part ) {
			if ( ! is_numeric( $part ) || $index > 2 ) {
				return 0.0;
			}

			$total += (float) $part * ( 60 ** $index );
		}

		return $total;
	}

	public static function to_bool( mixed $value ): bool {
		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'on', 'yes', 'true' ), true );
		}

		return (bool) $value;
	}

	/**
	 * Normalise anything into `''` (inherit), `'yes'` or `'no'`.
	 */
	public static function to_tristate( mixed $value ): string {
		if ( null === $value || '' === $value || 'inherit' === $value || 'default' === $value ) {
			return self::INHERIT;
		}

		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}

		if ( is_string( $value ) ) {
			$value = strtolower( trim( $value ) );

			if ( in_array( $value, array( '1', 'on', 'yes', 'true' ), true ) ) {
				return 'yes';
			}

			if ( in_array( $value, array( '0', 'off', 'no', 'false' ), true ) ) {
				return 'no';
			}

			return self::INHERIT;
		}

		return $value ? 'yes' : 'no';
	}
}
