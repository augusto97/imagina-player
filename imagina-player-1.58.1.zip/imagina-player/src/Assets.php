<?php
/**
 * Script and style registration.
 *
 * Front-end assets are registered but never enqueued globally: a page only
 * loads the player bundle if it actually renders a player.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Assets {

	public const FRONTEND_HANDLE = 'imagina-player';

	public const EDITOR_HANDLE = 'imagina-player-editor';

	private static bool $frontend_enqueued = false;

	/** Whether `window.imaginaPlayer` has been attached to the script yet. */
	private static bool $runtime_attached = false;

	public function hooks(): void {
		add_action( 'init', array( $this, 'register' ) );
		/*
		 * The runtime object goes with the script however the script came to
		 * be on the page. A player renders it through `enqueue_frontend()`,
		 * but WordPress also enqueues a block's `viewScript` by itself, and a
		 * page builder serving a cached element enqueues the script without
		 * rendering anything — and a player with no runtime object loads its
		 * chunks from the wrong place and has no strings.
		 */
		add_action( 'wp_print_footer_scripts', array( self::class, 'attach_runtime' ), 1 );
		add_action( 'wp_print_scripts', array( self::class, 'attach_runtime' ), 1 );
	}

	public function register(): void {
		$frontend = self::asset_meta( 'frontend' );

		wp_register_script(
			self::FRONTEND_HANDLE,
			URL . 'build/frontend.js',
			$frontend['dependencies'],
			$frontend['version'],
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_register_style(
			self::FRONTEND_HANDLE,
			URL . 'build/style-frontend.css',
			array(),
			$frontend['version']
		);
		// The build writes a mirrored sheet beside each one; without this a
		// right-to-left site was served the left-to-right one.
		wp_style_add_data( self::FRONTEND_HANDLE, 'rtl', 'replace' );

		$editor = self::asset_meta( 'editor' );

		/*
		 * `wp-api-request` on top of what webpack worked out.
		 *
		 * It is what puts `window.wpApiSettings` on the page, and that is where
		 * the REST nonce comes from. The editor builds one URL by hand rather
		 * than through `apiFetch` — the doorway that fetches a file from another
		 * domain, which has to be a URL the audio decoder can be pointed at —
		 * and without the nonce WordPress refuses it.
		 *
		 * Nothing failed loudly. The file simply could not be measured, and the
		 * one path that exists for exactly that case had never worked.
		 */
		$editor['dependencies'][] = 'wp-api-request';

		wp_register_script(
			self::EDITOR_HANDLE,
			URL . 'build/editor.js',
			array_values( array_unique( $editor['dependencies'] ) ),
			$editor['version'],
			true
		);

		wp_register_style(
			self::EDITOR_HANDLE,
			URL . 'build/editor.css',
			array( 'wp-edit-blocks' ),
			$editor['version']
		);
		wp_style_add_data( self::EDITOR_HANDLE, 'rtl', 'replace' );

		/*
		 * Only the editor bundle. Nothing in the front-end bundle calls `__()`
		 * — every label a visitor sees is rendered by PHP — so pointing this at
		 * the front-end handle only made WordPress print a translation file on
		 * every page view for strings no script would ever ask for.
		 */
		wp_set_script_translations( self::EDITOR_HANDLE, 'imagina-player', PATH . 'languages' );
	}

	/**
	 * The addresses the preview iframe loads, with a cache-busting version.
	 *
	 * The block preview and the settings screen both build an iframe by hand and
	 * point it at the real front-end files, so they miss everything WordPress
	 * does for an enqueued asset — including `?ver=`. Without it the browser is
	 * entitled to keep serving whatever it cached the first time, and it does:
	 * after an update the editor went on drawing a video with a stylesheet that
	 * predated video, so the picture had no shape and the controls fell out from
	 * under it. Nothing was wrong with the page; it was months old.
	 *
	 * @return array<string, string>
	 */
	public static function preview_assets(): array {
		$version = self::asset_meta( 'frontend' )['version'];

		return array(
			'frontendCss' => add_query_arg( array( 'ver' => $version ), URL . 'build/style-frontend.css' ),
			'frontendJs'  => add_query_arg( array( 'ver' => $version ), URL . 'build/frontend.js' ),
			// Not built by webpack, so it has no hash of its own; the plugin
			// version is enough, since it only changes when the plugin does.
			'frameCss'    => add_query_arg( array( 'ver' => VERSION ), URL . 'assets/preview-frame.css' ),
			/*
			 * The previews build their own runtime object by hand and had this
			 * as an empty string, so the player inside them asked for
			 * `/peaks` relative to the site root and got a 404 on every editor
			 * load. Nothing broke — a stored waveform reaches the preview in the
			 * markup — but it is a failed request in everyone's console, and the
			 * fallback it was meant to be could never work.
			 */
			'restUrl'     => esc_url_raw( rest_url( Rest\PeaksController::REST_NAMESPACE ) ),
			/*
			 * The player loads its video chrome, provider shell and layers on
			 * demand, from beside its own script. Inside a preview its script
			 * is written into the frame as text, so "beside" would be the
			 * frame's own address — nowhere — and the pieces are asked for
			 * next to wp-admin instead. This says where they really are.
			 */
			'assetUrl'    => esc_url_raw( URL . 'build/' ),
			/*
			 * And the pieces themselves, so the preview can write them into
			 * the frame as well: a frame that requests nothing cannot be
			 * refused anything. All but the HLS library, which is half a
			 * megabyte for a stream a preview never plays.
			 */
			'frontendChunks' => self::preview_chunks( $version ),
		);
	}

	/**
	 * The on-demand pieces of the front-end bundle, as versioned addresses.
	 *
	 * @return string[]
	 */
	public static function preview_chunks( string $version ): array {
		$urls = array();

		foreach ( glob( PATH . 'build/imagina-*.js' ) ?: array() as $file ) {
			$name = basename( $file );

			if ( 'imagina-hls.js' === $name ) {
				continue;
			}

			$urls[] = add_query_arg( array( 'ver' => $version ), URL . 'build/' . $name );
		}

		sort( $urls );

		return $urls;
	}

	/**
	 * Enqueue the front-end bundle, once, for a page that renders a player.
	 */
	public static function enqueue_frontend(): void {
		if ( self::$frontend_enqueued ) {
			return;
		}

		self::$frontend_enqueued = true;

		wp_enqueue_script( self::FRONTEND_HANDLE );

		$advanced = Settings::advanced();

		if ( ! empty( $advanced['load_frontend_css'] ) ) {
			wp_enqueue_style( self::FRONTEND_HANDLE );
		}

		/*
		 * With the HTML-significant characters escaped as JSON escapes. Nothing
		 * in this payload is written by a visitor today, but it is printed
		 * inside a <script> element, and a translated string that happened to
		 * contain "</script>" would end the element early. Cheap insurance
		 * against a future field being less careful than the present ones.
		 */
		self::attach_runtime( true );

		$custom = trim( (string) ( $advanced['custom_css'] ?? '' ) );

		if ( '' !== $custom ) {
			wp_add_inline_style( self::FRONTEND_HANDLE, wp_strip_all_tags( $custom ) );
		}
	}

	/**
	 * Put `window.imaginaPlayer` in front of the script, once.
	 *
	 * @param bool $force Attach even if the script is not enqueued yet — for
	 *                    `enqueue_frontend()`, which is about to enqueue it.
	 */
	public static function attach_runtime( bool $force = false ): void {
		if ( self::$runtime_attached ) {
			return;
		}

		if ( true !== $force && ! wp_script_is( self::FRONTEND_HANDLE, 'enqueued' ) ) {
			return;
		}

		self::$runtime_attached = true;

		wp_add_inline_script(
			self::FRONTEND_HANDLE,
			'window.imaginaPlayer = ' . wp_json_encode(
				self::runtime_data(),
				JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
			) . ';',
			'before'
		);
	}

	/**
	 * Data shared by every player on the page.
	 *
	 * @return array<string, mixed>
	 */
	public static function runtime_data(): array {
		$advanced = Settings::advanced();
		$peaks    = Settings::peaks_settings();

		return array(
			'restUrl'         => esc_url_raw( rest_url( Rest\PeaksController::REST_NAMESPACE ) ),
			/*
			 * So a request from a logged-in visitor is made as that visitor. A
			 * cookie-authenticated REST call without this header is treated as
			 * anonymous, which for protected media bound to a user meant the
			 * refreshed link was minted for nobody and refused. Only logged-in
			 * pages, since those are the ones the nonce is for and the ones a
			 * page cache does not hold.
			 */
			// The player loads its video chrome on demand. Webpack would work
			// the location out from the script's own URL, but that throws
			// outright when an optimisation plugin inlines the bundle — so the
			// side that actually knows the answer gives it.
			'assetUrl'        => esc_url_raw( URL . 'build/' ),
			'lazyInit'        => ! empty( $advanced['lazy_init'] ),
			/*
			 * Only for a logged-in visitor. A nonce in HTML that a page cache
			 * serves to everyone is a stale nonce, and an anonymous request is
			 * treated as anonymous with or without one — so it is left out of
			 * the pages that get cached, and put in for the visitors it is for.
			 */
			'nonce'           => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
			'maxComputeBytes' => (int) ( $peaks['max_client_bytes'] ?? 25 * 1024 * 1024 ),
			'i18n'            => array(
				'play'   => __( 'Play', 'imagina-player' ),
				'pause'  => __( 'Pause', 'imagina-player' ),
				'mute'   => __( 'Mute', 'imagina-player' ),
				'unmute' => __( 'Unmute', 'imagina-player' ),
				'captionsOff' => __( 'Off', 'imagina-player' ),
				'qualityAuto' => __( 'Auto', 'imagina-player' ),
				'audioTrack' => __( 'Audio', 'imagina-player' ),
				'clipShare' => __( 'Share a clip', 'imagina-player' ),
				'clipStart' => __( 'Start', 'imagina-player' ),
				'clipEnd' => __( 'End', 'imagina-player' ),
				'clipNow' => __( 'Now', 'imagina-player' ),
				'clipCopy' => __( 'Copy clip link', 'imagina-player' ),
				'clipCopied' => __( 'Clip link copied', 'imagina-player' ),
				'clipInvalid' => __( 'The end has to come after the start.', 'imagina-player' ),
				'clipEnded' => __( 'End of the clip', 'imagina-player' ),
				'clipReplay' => __( 'Replay clip', 'imagina-player' ),
				'clipContinue' => __( 'Keep watching', 'imagina-player' ),
				'layerFailed' => __( 'That could not be sent. Please try again.', 'imagina-player' ),
				'searchPlaceholder' => __( 'Search what is said', 'imagina-player' ),
				'searchEmpty' => __( 'The subtitles for this video have not loaded yet.', 'imagina-player' ),
				'searchNone' => __( 'Nothing found.', 'imagina-player' ),
				'speed' => __( 'Speed', 'imagina-player' ),
				'speedNormal' => __( 'Normal', 'imagina-player' ),
				'back' => __( 'Back', 'imagina-player' ),
				/* translators: 1: lessons watched, 2: lessons in the course. */
				'courseProgress' => __( '%1$d of %2$d watched', 'imagina-player' ),
				'courseWatched' => __( 'Watched', 'imagina-player' ),
				'courseLocked' => __( 'Finish the one before to open this', 'imagina-player' ),
				'sleepTimer' => __( 'Sleep timer', 'imagina-player' ),
				'sleepEnd' => __( 'End of this one', 'imagina-player' ),
				/* translators: %d: minutes */
				'sleepLeft' => __( '%d min left', 'imagina-player' ),
				/* translators: %d: minutes */
				'sleepMinutes' => __( '%d minutes', 'imagina-player' ),
				'bookmarkAdd' => __( 'Bookmark this moment', 'imagina-player' ),
				/* translators: %s: a time such as 12:40 */
				'bookmarkAdded' => __( 'Bookmarked at %s', 'imagina-player' ),
				'bookmarks' => __( 'Bookmarks', 'imagina-player' ),
				'bookmarksClear' => __( 'Clear bookmarks', 'imagina-player' ),
				'copyLink' => __( 'Copy link to this moment', 'imagina-player' ),
				'linkCopied' => __( 'Link copied', 'imagina-player' ),
				/* translators: %s: a time such as 12:40 */
				'resumeFrom' => __( 'Resume from %s', 'imagina-player' ),
				'startOver' => __( 'Start over', 'imagina-player' ),
				'dismiss' => __( 'Dismiss', 'imagina-player' ),
			),
		);
	}

	/**
	 * Read the dependency manifest webpack writes next to each bundle.
	 *
	 * @return array{dependencies: array<int, string>, version: string}
	 */
	private static function asset_meta( string $entry ): array {
		$file = PATH . 'build/' . $entry . '.asset.php';

		if ( is_readable( $file ) ) {
			$meta = require $file;

			if ( is_array( $meta ) ) {
				return array(
					'dependencies' => isset( $meta['dependencies'] ) && is_array( $meta['dependencies'] ) ? $meta['dependencies'] : array(),
					'version'      => isset( $meta['version'] ) ? (string) $meta['version'] : VERSION,
				);
			}
		}

		return array(
			'dependencies' => array(),
			'version'      => VERSION,
		);
	}
}
