<?php
/**
 * Plugin bootstrapper: owns the service list and the activation lifecycle.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer;

use ImaginaPlayer\Admin\Dashboard;
use ImaginaPlayer\Blocks\BlockRegistrar;
use ImaginaPlayer\Peaks\PeaksRepository;
use ImaginaPlayer\Integrations\Elementor\Integration as ElementorIntegration;
use ImaginaPlayer\Protection\Integration as ProtectionIntegration;
use ImaginaPlayer\Protection\StreamServer;
use ImaginaPlayer\Leads\LeadRepository;
use ImaginaPlayer\Rest\CaptionController;
use ImaginaPlayer\Rest\LeadController;
use ImaginaPlayer\Rest\PeaksController;
use ImaginaPlayer\Rest\SettingsController;
use ImaginaPlayer\Rest\StreamController;
use ImaginaPlayer\Shortcodes\PlayerShortcode;
use ImaginaPlayer\Shortcodes\TimeShortcode;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static ?self $instance = null;

	/**
	 * Booted services, keyed by short name so integrations can reach them
	 * through the `imagina_player_service` filter.
	 *
	 * @var array<string, object>
	 */
	private array $services = array();

	private bool $booted = false;

	private function __construct() {}

	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function boot(): void {
		if ( $this->booted ) {
			return;
		}

		$this->booted = true;

		$this->services = array(
			'assets'      => new Assets(),
			'peaks'       => new PeaksRepository(),
			'rest'        => new PeaksController(),
			'captions'    => new CaptionController(),
			'leads'       => new LeadController(),
			'integrations' => new Rest\IntegrationsController(),
			'delivery'    => new Leads\Delivery(),
			'transcriber' => new Media\Transcriber(),
			'transcribe'  => new Rest\TranscriptionController(),
			'progress'    => new Rest\ProgressController(),
			'stream'      => new StreamServer(),
			'streamRest'  => new StreamController(),
			'settingsApi' => new SettingsController(),
			'protection'  => new ProtectionIntegration(),
			'blocks'      => new BlockRegistrar(),
			'patterns'    => new Blocks\Patterns(),
			'clips'       => new Share\ClipShare(),
			'stats'       => new Stats\Stats(),
			'shortcodes'  => new PlayerShortcode(),
			'timestamps'  => new TimeShortcode(),
			'dashboard'   => new Dashboard(),
			'elementor'   => new ElementorIntegration(),
		);

		\ImaginaPlayer\Media\Providers\VimeoThumbnail::hooks();

		foreach ( $this->services as $service ) {
			if ( method_exists( $service, 'hooks' ) ) {
				$service->hooks();
			}
		}

		/*
		 * On init rather than plugins_loaded, because seeding the settings
		 * translates the default preset's label, and WordPress 6.7 warns about
		 * translating before init. Priority 1, so the tables exist before
		 * anything registered at the default priority — REST routes included —
		 * could want them.
		 */
		add_action( 'init', array( $this, 'maybe_upgrade' ), 1 );
		add_action( 'init', array( $this, 'load_translations' ) );

		/**
		 * Fires once every Imagina Player service has registered its hooks.
		 *
		 * @param Plugin $plugin The plugin instance.
		 */
		do_action( 'imagina_player_booted', $this );
	}

	/**
	 * Point WordPress at the translations this plugin carries.
	 *
	 * Without this the `.mo` files in `/languages` are never opened. WordPress
	 * loads a text domain by itself only from `wp-content/languages/plugins`,
	 * which is where translations from translate.wordpress.org land — a plugin
	 * shipping its own has to say where they are. The Spanish was complete and
	 * compiled for a while before anybody noticed the interface was still in
	 * English, because nothing errors: `__()` simply hands back what it was
	 * given.
	 *
	 * On `init` rather than `plugins_loaded`, which is what WordPress 6.7
	 * asks for — the locale is not settled before then.
	 */
	public function load_translations(): void {
		load_plugin_textdomain(
			'imagina-player',
			false,
			dirname( plugin_basename( FILE ) ) . '/languages'
		);
	}

	/**
	 * Fetch a booted service.
	 */
	public function service( string $name ): ?object {
		return $this->services[ $name ] ?? null;
	}

	/**
	 * Catch up a site whose stored version is behind the code.
	 *
	 * The activation hook does not fire for a plugin copied into place, updated
	 * over FTP or deployed by git, which is exactly how this one reaches most of
	 * the sites that will run it.
	 */
	public function maybe_upgrade(): void {
		/*
		 * One autoloaded option, read from the options already in memory.
		 *
		 * There were three markers — plugin version, peaks table version,
		 * leads table version — each written with autoload off and each read
		 * by its own plugins_loaded hook. A non-autoloaded option that exists
		 * is in neither `alloptions` nor `notoptions`, so without a persistent
		 * object cache that was three SELECTs on every request the site served,
		 * front and back, to answer a question whose answer never changes
		 * between updates.
		 */
		if ( self::current_marker() === (string) get_option( self::MARKER_OPTION, '' ) ) {
			return;
		}

		if ( false === get_option( Settings::OPTION_KEY ) ) {
			add_option( Settings::OPTION_KEY, Settings::defaults() );
		}

		/*
		 * The tables as well, which is the entire reason this method exists and
		 * was the one thing it did not do.
		 *
		 * A column was added to the waveforms table in 1.31.0 and nothing ever
		 * ran the migration for a site updated by uploading the plugin — which
		 * is how this one reaches nearly every site. So the code asked for a
		 * column that was not there: every read failed, every write failed, and
		 * a waveform measured in the editor was never stored. The editor looked
		 * right because it draws what it just measured; the front end asked for
		 * it, got a 404, and downloaded fifty megabytes to work it out again on
		 * every single page view.
		 *
		 * Each of these checks a stored version and returns immediately when
		 * there is nothing to do, so this costs an option read on the one
		 * request after an update and nothing at all after that.
		 */
		PeaksRepository::install_table();
		LeadRepository::install_table();
		Stats\StatsRepository::install_table();

		update_option( 'imagina_player_version', VERSION, false );
		update_option( self::MARKER_OPTION, self::current_marker(), true );
	}

	/** Where the "everything is up to date" marker lives. Autoloaded. */
	public const MARKER_OPTION = 'imagina_player_schema';

	/**
	 * Plugin and both schema versions in one string, so a change to any of
	 * them runs the upgrade once and the comparison is one autoloaded read.
	 */
	private static function current_marker(): string {
		return VERSION . '|' . PeaksRepository::DB_VERSION . '|' . LeadRepository::DB_VERSION . '|' . Stats\StatsRepository::DB_VERSION;
	}

	public static function on_activation(): void {
		if ( false === get_option( Settings::OPTION_KEY ) ) {
			add_option( Settings::OPTION_KEY, Settings::defaults() );
		}

		update_option( 'imagina_player_version', VERSION, false );

		PeaksRepository::install_table();
		LeadRepository::install_table();
		Stats\StatsRepository::install_table();

		// Front-end assets are versioned by plugin version; flush page caches that key on rewrite rules.
		flush_rewrite_rules();
	}

	public static function on_deactivation(): void {
		flush_rewrite_rules();
	}
}
