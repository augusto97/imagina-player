import{aB as c}from"./admin.js?ver=1.4.0";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};
