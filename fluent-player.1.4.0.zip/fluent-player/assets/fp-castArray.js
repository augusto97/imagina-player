import{aV as a}from"./admin.js?ver=1.4.0";function e(){if(!arguments.length)return[];var r=arguments[0];return a(r)?r:[r]}export{e as c};
