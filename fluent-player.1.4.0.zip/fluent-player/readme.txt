=== FluentPlayer – Video Player With Forms & Lead Capture ===
Contributors: techjewel,wpmanageninja,adreastrian
Tags: audio, video player, video, vimeo, youtube
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Get a video player for WordPress that captures leads and collects emails on play.

== Description ==

= Video Player For WordPress Built For Playback and Dynamic Interaction =

**FluentPlayer** is a fast, **native WordPress video & audio player** that does more than embed a file. A viewer can fill out a form or subscribe without leaving the video, because FluentPlayer is built inside the same **Fluent ecosystem** as Fluent Forms, FluentCRM, and FluentCommunity.

[youtube https://www.youtube.com/watch?v=wA5sO4DhoF0]

[Live Demo](https://fluentplayer.com/demo) | [User Guide](https://docs.fluentplayer.com/) | [Features](https://fluentplayer.com/features/) | [Get Support](https://wpmanageninja.com/support-tickets/) | [Official Fluent Community](https://community.wpmanageninja.com/portal/space/)

From a simple self-hosted video to a lesson with a sign-up form or a lead capture overlay, FluentPlayer can meet virtually all your video needs.

== Powerful Features Available in the Free Version ==

* Self-hosted video, YouTube, Vimeo, and audio playback
* Native Fluent Forms layer for in-video forms
* Email capture layer
* Player presets: Default, Modern, Simple, Minimal, Standard, Floating
* Picture-in-Picture (HTML5)
* Inline mobile playback
* Autoplay
* Speed control
* Video chapters
* Language switching
* Load strategy performance control
* Aspect ratio control
* Custom branding (logo, brand color, control bar color)
* Custom thumbnail image (Poster Image)
* Title overlay
* Shortcodes for classic editor and page builders
* Native Gutenberg block

== Features Available in the Pro Version ==

* Video analytics (views, watch time, completion rate, audience retention, device and location breakdown)
* CTA banners, hotspots, ad layers, and shortcode layers
* Conditional rules for layers
* Timed Content
* Custom Subtitles
* YouTube Subtitle Import
* Video playlists with layout and appearance customization
* Media tagging
* Customizable player presets
* Text and button overlays
* Remember Playback Position
* BunnyCDN Stream, BunnyCDN Storage, Mux, external URLs, and HLS streaming
* AJAX compatibility

== Built for Speed ==

FluentPlayer is optimized to load fast and stay out of the way of your page speed. The Load Strategy setting controls when the player script loads, so a video below the fold does not block your first paint. This matters more than it sounds: a slow-loading video player drags down every page it sits on.

== Interactive Layers ==

Every interactive element in FluentPlayer is a layer you place at a specific point in the video, not a fixed page element. The free version includes a Fluent Forms layer and an email capture layer. Pro adds CTA banners, hotspots, ad layers, and shortcode layers, each with its own display rules: show a layer once a viewer reaches a timestamp, hide it after a set duration. This keeps every prompt relevant to what is happening on screen instead of interrupting the video at a generic moment.

== Native Fluent Forms Layer (Free) ==

FluentPlayer's biggest difference from other video players is the form layer. Instead of sending a viewer to a separate page to subscribe, register, or pay, the form appears directly inside the player at a moment you choose.

Because Fluent Forms supports payment fields, the same in-video layer can take a payment. A viewer can buy a course, pay for a webinar seat, or complete a paid registration without ever leaving the video. The submission flows straight into FluentCRM, where it can trigger an automation.

== Native FluentCRM Integration (Free) ==

FluentCRM and FluentPlayer are both built by WPManageNinja, and that shared origin is what makes this integration different from a standard plugin connection. When a viewer fills out a capture form in a video, their details are sent directly to FluentCRM in real time in preferred lists or tags with no third-party bridge, no manual import, and no sync delay.

For businesses running contact management inside WordPress, this keeps the entire pipeline in one place. The video, the capture form, and the CRM all operate from the same core, which means every lead the content generates is immediately available to act on.

== Timed Content (Pro) ==

Timed Content is unique to FluentPlayer. It renders a WordPress block region below the player that changes as the video plays. You set a time range, and the content for that range appears in sync. Any WordPress block works there, including a Fluent Forms form, a button, or a text block timed to a specific moment in the video.

== Play Any Video Source ==

**Available in the Free Version**

* Self-hosted video from your media library
* YouTube
* Vimeo
* Audio files

**Available in the Pro Version**

* BunnyCDN Stream
* BunnyCDN Storage
* Mux
* HLS Streaming

== Player Presets and Custom Branding ==

Choose from the built-in presets: Default, Modern, Simple, Minimal, Standard, and Floating. Set your logo, brand color, and control bar color, choose a poster image, and add a title overlay, all in the free version. Pro adds a new Ambient preset, fully customizable presets, text and button overlays, and a Remember Playback Position option that resumes a long video where the viewer left off.

== Video Playlists (Pro) ==

Group videos into a playlist with a standard or grid layout, then style the color, border, typography, and box shadow to match your site. Media tagging keeps a large video library organized as it grows.

== Video Analytics (Pro) ==

See what your viewers actually do, not just that a video played. The Pro analytics dashboard shows views, unique viewers, average watch time, and completion rate per video, plus an audience retention graph that shows the exact second viewers drop off. You also get new versus returning viewers, top videos, top users, device distribution, and location breakdown, all stored in your own WordPress database.

== Block Editor and Shortcode Support ==

Add the FluentPlayer block in the WordPress block editor, pick your source, and publish. No code. For the classic editor and page builders, every player also generates a shortcode.

== FluentCommunity Integration (Free) ==

FluentCommunity is part of the same WPManageNinja product suite as FluentPlayer, so the connection goes deeper than a typical third-party integration. Video embeds natively inside community spaces with full player functionality intact, and members watch content, follow learning paths, and access gated material without ever leaving the community.

For membership businesses and course creators building on WordPress, this means video content and community run as one system instead of two platforms patched together. Members who never get pulled out of the environment are more likely to stay engaged, return, and complete what they started.

== Conditional Rules for Layers (Pro) ==

Show the right layer to the right viewer. Conditional rules let you decide who sees a layer instead of showing the same form or offer to everyone. Each layer has its own Conditions panel where you build rules with a simple Field, Operator, and Value setup, the same logic you know from Fluent Forms. Match any rule or all of them.

You can show or hide a layer based on:

* Whether the viewer is logged in
* Whether the viewer is a FluentCRM contact
* Whether the viewer has a specific FluentCRM tag
* Whether the viewer is in a specific FluentCRM list
* Whether the viewer has already submitted their email
* A URL query parameter, matched by key and value
* Whether a layer has already been seen
* Whether a layer has been completed

A first-time visitor sees the email capture form, while a known FluentCRM contact skips it and gets a course offer instead. A viewer who arrives from a campaign link gets a layer matched to that campaign, and a viewer who already submitted their email never sees the same form twice.

== Integrations and Add-ons Available in the Free Version ==

* <a href="https://wordpress.org/plugins/fluentform" target="_blank">Fluent Forms</a> for in-video forms, including registration fields
* <a href="https://wordpress.org/plugins/fluent-crm" target="_blank">FluentCRM</a> to send captured contacts straight into your CRM and trigger automations
* <a href="https://wordpress.org/plugins/fluent-community" target="_blank">FluentCommunity</a> for course, community and membership videos

== Integrations Available in the Pro Version ==

* Mailchimp
* Webhooks
* Google Analytics
* BunnyCDN
* Mux

== Why a Self-Hosted WordPress Video Player? ==

Hosted video services charge a monthly fee, cap your bandwidth, and keep your viewer data on their platform. FluentPlayer keeps the video, the player, and the interaction on your own domain and in your own database. You own the data, you control the experience, and there is no per-view or per-seat cost.

== Check Out the Documentation ==

FluentPlayer has step-by-step documentation. Some essential pages are listed below:

<ul>
	<li><a href="https://docs.fluentplayer.com/introduction" target="_blank">Getting Started With FluentPlayer</a></li>
	<li><a href="https://docs.fluentplayer.com/email-capture/" target="_blank">Adding a Email Capture Overlay to a Video</a></li>
	<li><a href="https://docs.fluentplayer.com/cta-and-action-bar" target="_blank">How to add a CTA & Action Bar</a></li>
	<li><a href="https://docs.fluentplayer.com/display-embed" target="_blank">Dispaley & Embed Overview</a></li>
	<li><a href="https://docs.fluentplayer.com/customize" target="_blank">How to Customize your Player</a></li>
</ul>

== Other Plugins by the Fluent Team ==

<ul>
	<li><a href="https://wordpress.org/plugins/fluentform/" target="_blank">Fluent Forms – Drag & Drop Form Builder for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-crm/" target="_blank">FluentCRM – Email Marketing, Newsletter, and Automation Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-community/" target="_blank">FluentCommunity – Full-Fledged Social Network, Community, and LMS</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-booking" target="_blank">FluentBooking – The Ultimate WordPress Scheduling Plugin</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-boards/" target="_blank">FluentBoards – Project and Task Management, Kanban Board, and Team Collaboration</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-support/" target="_blank">Fluent Support – WordPress Helpdesk and Customer Support Ticket Plugin</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-smtp/" target="_blank">FluentSMTP – The Most Advanced SMTP, SES Plugin for WordPress</a></li>
	<li><a href="https://wordpress.org/plugins/fluent-cart/" target="_blank">FluentCart – A New Era of eCommerce With WordPress</a></li>
<li><a href="https://wordpress.org/plugins/fluent-affiliate/" target="_blank">FluentAffiliate – Affiliate Program Management Suite, Affiliates Manager</a></li>
</ul>

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/fluentplayer` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress.
1. Use the `FluentPlayer` -> `Settings` screen to configure the plugin.
1. Add a video using the FluentPlayer block in the block editor, or the shortcode in the classic editor.

== Frequently Asked Questions ==

= Is FluentPlayer free? =

Yes. The free version includes the player, multiple presets, self-hosted, YouTube, Vimeo, and audio sources, Picture-in-Picture, video chapters, custom branding, email capture, and a native Fluent Forms layer. Pro adds BunnyCDN and Mux hosting, playlists, Timed Content, subtitles, more interactive layers, and video analytics.

= Can I capture leads or collect emails from my videos? =

Yes, in the free version. A native Fluent Forms layer and an email capture field appear over the video at a time you set. Captured contacts can sync to FluentCRM and start an automation.

= What video sources does FluentPlayer support? =

Self-hosted video, YouTube, Vimeo, and audio in the free version. BunnyCDN Stream, BunnyCDN Storage, Mux, external URLs, and HLS streaming in Pro.

= Will FluentPlayer slow down my website? =

No. The Load Strategy setting controls when the player loads, so you can defer videos below the fold and keep your initial page render fast.

= Does FluentPlayer work with the block editor and page builders? =

Yes. FluentPlayer provides a native Gutenberg block, and every player also generates a shortcode for the classic editor and page builders.

= Does FluentPlayer support subtitles and multiple languages? =

Pro supports subtitles. Language switching for the player interface is in the free version.

= Can I migrate my videos from another player plugin? =

Yes. FluentPlayer includes a one-click migration that imports your existing videos so you do not rebuild them by hand.

= I want to report a bug, where do I report it? =

You can get support from our official support thread at <a href="https://wpmanageninja.com/support-tickets/">wpmanageninja.com/support-tickets</a>.

== Screenshots ==

1. The Media library — every self-hosted, YouTube, Vimeo, BunnyCDN, and Mux video in one searchable, sortable table.
2. The Playlists library, listing every playlist with sortable columns and visibility controls.
3. A grid-layout video playlist with custom branding applied.
4. Player presets — reusable player configurations you can apply across your videos.
5. Building a custom preset with full control over the player controls and behavior.
6. The custom branding panel — colors, logo, and watermark applied to the player.
7. Chapter markers added to the video timeline for quick navigation.
8. A Fluent Forms layer with a registration field shown over a video mid-play.
9. The analytics dashboard with per-video engagement and play metrics.
10. The integration settings showing native Fluent Forms, FluentCRM, and FluentCommunity connections.

== Development ==

FluentPlayer Source code, issue tracker, and contributions: https://github.com/WPManageNinja/fluent-player

== Changelog ==

= 1.4.0 (Date: August 26, 2026) =
* Feature: Vimeo provider — privacy mode, quality and playback-speed menus, and chapters
* Feature: Single Playback settings — starting one player pauses or keep playing every other player on the page (on by default)
* Feature: Deferred third-party embeds — YouTube and Vimeo players do not initialize the provider or send tracking requests until they're released, via the fluent_player/defer_player filter (for cookie-consent and privacy workflows)
* Feature: Muted Preview autoplay mode — the video autoplays muted loops with no analytics, layers, or resume running
* Improvement: Presto Player migration now maps Muted Autoplay Preview settings
* Improvement: Compatible with WordPress 7.1 — removed the deprecated block-editor control usage that logged warnings on every editor loaded
* Improvement: The block editor and media picker no longer run one database query per private media item
* Improvement: Public media pages can be switched off with the fluent_player/media_pages_enabled filter
* Improvement: Autoplay with sound recovers muted when the browser blocks it, instead of freezing on the first frame
* Security: Tightened permission checks and stripped credentials from block editor and player output
* Fix: Resume position is saved on pause, tab switch, and single-page-app teardown, so progress is no longer lost
* Fix: The same media placed twice on a page now renders two working players instead of one
* Fix: YouTube branding no longer appears over the block editor preview, and portrait Shorts no longer zoom
* Fix: Vimeo qualities the video cannot actually deliver are removed from the menu instead of silently failing
* Fix: FluentCommunity lesson pages regain full player behavior, including analytics
* Fix: Block editor styles are scoped so they no longer leak into core WordPress admin UI
* Fix: The media and playlist list tables keep their pagination controls after choosing a large page size, and remember your page and page size

= 1.3.1 (Date: July 28, 2026) =
* Improvement: Player assets are cache-busted after a plugin update, so browsers load the new version instead of a stale one
* Fix: Playback resumes where you left off for fluent community
* Fix: The Bunny Stream CDN token is forwarded to editor preview segments, so protected media preview correctly in the editor
* Fix: Fluent Player shortcodes now render inside the Breakdance builder canvas
* Fix: YouTube and Vimeo embeds keep their referrer
* Fix: The Divi and Elementor builder media and playlist pickers work again, and wp-admin typography issue in builder canvas

= 1.3.0 (Date: July 22, 2026) =
* Feature: Add any media by pasting a URL — the provider is detected automatically, and same-site upload URLs resolve to their library attachment
* Feature: Configurable media shortcode — playback-override attributes and an optional dynamic source (id is no longer required)
* Feature: Elementor widgets for the player and playlist, with full block-parity player settings
* Feature: Divi 5 Visual Builder modules for the player and playlist
* Feature: Audio playback support for CDN media providers
* Feature: Editors can now author media, layers, and presets (previously admin-only); adjustable via the fluent_player/authoring_capability filter
* Feature: FluentCRM integration — watched milestones and layer interactions are tracked and logged to the contact timeline
* Feature: Private media now play wherever they are embedded (pages, courses) while their standalone page returns 404 and stays out of sitemaps and search — so course videos are never publicly exposed
* Feature: Media created from a FluentCommunity lesson defaults to Private, so it never gets a public standalone page
* Improvement: Unconfigured Pro sources collapse behind a More sources toggle, and disconnected providers link to their setup
* Improvement: YouTube posters are served as WebP for faster loading
* Improvement: The block editor player preview is lazy-loaded
* Improvement: A branded loading backdrop covers the block editor's white boot phase
* Improvement: Cmd/Ctrl+S saves settings, and a keyboard shortcut creates new media from the admin pages
* Improvement: Locked providers are announced to assistive technology
* Improvement: The block editor media and playlist pickers are now searchable and load results in pages, so libraries beyond the first 20 items are reachable
* Improvement: FluentCRM timeline events and layer pickers now show block-editor labels (form title, provider name), and the media picker lists newest first
* Fix: Chapter files with umlauts and other non-ASCII characters render correctly in the block preview
* Fix: Audio players show all controls without scrolling
* Fix: Per-video audio normalization is saved reliably
* Fix: Overlay layers (forms, CTAs) no longer fail to appear on sites that load animation libraries such as GSAP
* Fix: Editing a media from a page or lesson where it is embedded no longer changes the media's visibility
* Fix: The Modern preset's mobile control bar no longer crowds the seek bar
* Fix: The Elementor and Divi builders no longer show a blank canvas for the timed-content and playlist blocks
* Fix: Portrait (9:16) YouTube Shorts fill the frame instead of being letterboxed
* Fix: Page-builder panel colors apply on the front end, and the Divi media module is selectable in the builder

= 1.2.0 (Date: July 8, 2026) =
* Improvement: Resume playback can now be set per video, overriding the preset
* Fix: The frontend language switcher button is now clickable
* Fix: The selected hotspot icon stays visible in the picker preview
* Fix: The admin top-nav dropdown is no longer hidden behind the WordPress admin bar
* Fix: The media-select search icon no longer overlaps the input text

= 1.1.0 (Date: July 6, 2026) =
* Feature: Use a FluentPlayer video as a FluentCommunity lesson's feature media
* Improvement: The YouTube paused cover button now uses your brand color and hides YouTube's default play button
* Improvement: Refined the player vignette overlay
* Improvement: Hide in-video form layers when a video plays inside a FluentCommunity lesson
* Fix: Players now re-initialize correctly when switching lessons in FluentCommunity
* Fix: The loading overlay no longer blocks clicks before the player is ready
* Fix: YouTube subscribe button styling now survives aggressive theme CSS

= 1.0.9 (Date: June 29, 2026) =
* Feature: Customize the confirmation message shown after someone submits the email-capture form
* Feature: Set a custom color and background for the play button
* Feature: FluentCRM Double optin email support
* Feature: Bulk actions in the media list — trash, restore, and change the status of multiple items at once
* Improvement: Honor WordPress's built-in password protection on the player — protected videos and audio now unlock right on the page
* Improvement: Honor WordPress's native scheduling for media — set a future publish date and see a clear Scheduled status and time
* Improvement: Cleaner, more compact media list and a thumbnail with the media type shown in the title
* Improvement: Refined, more compact media editor — unified setting cards
* Improvement: Show or hide columns in the media list to fit the table to what you need
* Improvement: Redesigned player right-click menu with item icons and a refreshed look
* Improvement: Spot overlapping timed content at a glance and edit each item inline
* Improvement: Clearer permanent-delete confirmation so media isn't removed by mistake
* Improvement: Faster-loading admin dashboard
* Security: Hardened the player's styling output against injection
* Fix: The video preview now shows while you scrub in the layer, overlay, and chapter editors
* Fix: On-screen layers such as email capture now correctly hold keyboard focus
* Fix: Audio tracks in a mixed playlist now play in the audio player
* Fix: The playlist player now fills the available width and its menu toggle works reliably
* Fix: YouTube playback and lesson settings now work correctly inside FluentCommunity
* Fix: Restored the YouTube and Analytics toggles on the settings page
* Fix: Reliability and rate-limiting improvements for the FluentCRM double opt-in flow
* Fix: The Default Aspect Ratio option now displays correctly in settings
* Fix: Renamed "Poster Image" to "Thumbnail" in the media block for clarity

= 1.0.8 (Date: June 22, 2026) =
* Maintenance: Internal improvements, compatibility, and stability updates

= 1.0.7 (Date: June 22, 2026) =
* Feature: Migrate media, per-video color, thumbnails, YouTube no-cookie settings, and email submissions from Presto Player
* Feature: Update Playlist flow for the playlist block
* Feature: Back button in the media editor header
* Feature: Unsaved changes guard on the settings page
* Improvement: All Media and Settings quick links in the plugins row
* Improvement: Skeleton loaders across the settings and analytics pages
* Improvement: Sortable columns and refined visibility controls in the media and playlist tables
* Improvement: Accessibility pass across the admin — accessible names, keyboard navigation, and AA contrast
* Improvement: Throttle player time-update handlers to reduce per-frame work and improve smoothness
* Fix: Let the assigned preset control resume-playback
* Fix: Make YouTube Privacy-Enhanced Mode actually toggle the embed and poster hosts
* Fix: Load the timed-content frontend script once across all render paths
* Fix: Pro-gate the Google Analytics gtag enqueue
* Fix: Honor |fallback on contact smartcodes when no CRM contact is present
* Fix: Neutralize spreadsheet formula injection in email exports

== Upgrade Notice ==
