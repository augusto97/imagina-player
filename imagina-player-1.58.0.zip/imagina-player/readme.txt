=== Imagina Player ===
Contributors: imagina
Tags: audio, waveform, player, podcast, music
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.58.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, accessible waveform audio player for WordPress, built for the block editor.

== Description ==

Imagina Player renders an audio player with a real waveform, a Gutenberg block, and
reusable presets so a whole site can be restyled from one screen.

It is deliberately small. The front-end bundle is under 9 KB gzipped with no
runtime dependencies — no jQuery, no player framework — and a page only loads it
when it actually contains a player.

**Waveforms without the wait.** Peaks are computed once and cached: on the server
with ffmpeg when the host provides it, otherwise by the first visitor's browser,
whose result is posted back so nobody else repeats the work. Peaks are stored as
one byte per bar, so a 400-bar waveform costs about half a kilobyte.

**Presets.** A preset bundles skin, colours and which controls are visible. Blocks
reference a preset and may override single values, so changing the house style is
one edit rather than one edit per post.

**Accessible and resilient.** The seek bar is a real ARIA slider with keyboard
support, every control is a real button, and the player is server-rendered around
a native `<audio controls>` element — if the script fails to load, the audio still
plays.

**Video, including YouTube and Vimeo.** Paste the address of a video and it plays
in this player, with your own controls, your own colours and your own calls to
action rather than the provider's chrome. Nothing is requested from them until a
visitor presses play, so a video nobody watches costs the page nothing.

**One block, every product's own file.** A block can take its file from a
custom field of the post it is shown on — an ACF or JetEngine field, or plain
post meta — so a product template built once shows each product's own video,
and a custom post type's single view plays each entry's own recording.

**Elementor too.** The audio player, the video player and the playlist are
Elementor widgets as well, in their own category, with the same choices the
blocks offer and the same renderer behind them. A file from the library, an
address, or a custom field of the post — with Elementor's dynamic tags where
they apply.

= Blocks, widgets and shortcodes =

* Blocks: **Imagina Audio Player**, **Imagina Video Player**, **Imagina Playlist**, with patterns and variations ready to insert
* Elementor widgets: the same three, under the **Imagina Player** category (Elementor 3.5 or newer)
* Shortcode: `[imagina_player src="https://example.com/track.mp3" artist="…" title="…"]`
* Shortcode, reading the file from a custom field of the current post: `[imagina_player field="video_url"]`
* Timestamp button, in the text around a player: `[imagina_time at="1:35"]The second question[/imagina_time]`
* Link to a moment: `https://example.com/interview/?t=95`, with `&player=intro` naming a block by its HTML anchor

== Frequently Asked Questions ==

= Can a button in the text jump to a moment in the video? =

Yes. Write `[imagina_time at="1:35"]The second question[/imagina_time]` where the
button should go; a click takes the player to 1:35 and starts it. The time can
be `95`, `1:35`, `1:02:03` or `1m35s`, and a shortcode with no text shows the
time itself — write that one as `[imagina_time at="1:35" /]`, closed with the
slash, so WordPress does not pair it with the closing tag of the next button.
On a page with more than one player, give the block an **HTML anchor** (in its
Advanced panel) and name it: `player="intro"`. Otherwise the first player on
the page is meant.

The same works from a link: an address ending in `?t=95` or `#t=1m35s` opens
the player at that second, paused, and `&player=intro` says which one. The
gear on a video's bar has **Copy link to this moment** for exactly this.

= Can I put text, an image or a form over the video? =

Yes. In the block's **Overlays and calls to action** panel, add an overlay and
pick its kind: text in a corner, an image (a logo, a still), a hotspot — a
spot on the picture that shows a label and can link somewhere — or a
shortcode, which shows whatever another plugin prints: a form, a button, a
countdown. Each appears at a moment and can go away at another, and none of
them stops playback. The call to action and the email gate still do.

= Can the video show its transcript? =

Yes, when it carries subtitles. Turn on **Transcript under the picture** in the
block's Controls panel, or for the whole site in Settings → Video. A closed
panel under the video opens to every line with its time; the line being said
is marked and kept in view, pressing a line jumps there, and the box above
narrows the list to a word. YouTube and Vimeo keep their subtitles inside
their frame, so this is for videos this site serves.

= Can I make a playlist of videos? =

Yes: the **Imagina Playlist** block takes videos as well as audio, and three
of its layouts are made for them — the list beside the picture, a rail of
thumbnails under it, or a slider of cards with arrows. Keep a list to one
kind: files this site serves, or videos from one provider. A YouTube video in
a list of files still works as a link, but it cannot take the place of a file
in the same player.

= Can I use a YouTube or Vimeo video? =

Yes. Paste the address into the Video block. It plays inside this player with your
own controls and your own calls to action, and the provider's still image is used
as the poster. Nothing is loaded from YouTube or Vimeo until a visitor presses
play — until then the page holds a picture, so there is no third-party request and
no cookie for a visitor who never watches.

A video hosted by them is not a file on your site, so the download protection does
not apply to it. Their subtitles are drawn inside their frame, in their style, but
this player's subtitles button turns them on and off and picks the language, so a
viewer can reach them with the provider's own interface hidden. Playback speed is
controlled from this player too. Picture quality is not: YouTube retired that
control from its API in 2019, for every player.

= Can the file come from a custom field, for a product template? =

Yes. Give each product a custom field — with ACF, JetEngine or any other way of
adding post meta — holding the video's address (a YouTube or Vimeo link, an MP4,
an HLS stream) or the file's media library ID. Place one video block in the
product template, open Dynamic source in its sidebar and type the field's key.
Each product page then shows that product's own video; a product whose field
is empty shows nothing there, unless the block is also given a file of its
own, which is then the default. The same works for the audio block, for any
post type, and in the shortcode as `field="…"`.

The field is read from the post the block is shown on, at the moment it is
shown. A key starting with an underscore is hidden meta and is never read.

= Does it work with Elementor? =

Yes. With Elementor active, the widget panel has an **Imagina Player** category
holding the audio player, the video player and the playlist. Each takes a file
from the media library, an address — a YouTube or Vimeo link, an MP4, an HLS
stream — or a custom field of the post the page shows, and offers the preset,
the skin, every control as a three-way choice, subtitles, chapters and calls to
action. Text fields accept Elementor's dynamic tags. The widgets are rendered
by the same code as the blocks, so a player on an Elementor page is the same
player, and the front end loads the same small bundle. Elementor 3.5 or newer.

= Does it need ffmpeg? =

No. ffmpeg makes waveforms appear instantly on first view; without it the first
visitor's browser computes the waveform once and the site caches it.

= Can I use audio hosted somewhere else? =

Yes. Any HTTPS URL works, including files served from a streaming provider or CDN.
Waveforms for external URLs are cached in the plugin's own table, keyed by URL.

= Who can play a protected file? =

Anyone who is shown the player. Protection keeps a file from being linked to or
downloaded by its address — links expire within minutes and cannot be passed
around — but it does not decide who may watch. For members only, turn on
**Require a logged-in user** in Settings → Protection, or decide per visitor with
the `imagina_player_can_stream` filter. The self-check in the same screen says
which of these is in force. To decide per player, see the next question.

= Can a player play only for customers or members? =

Yes. Every block and widget has **Who can play it**: anyone signed in, certain
roles, people who bought a WooCommerce product, members of a WooCommerce
Memberships plan or a MemberPress membership, or students of a LearnDash course.
Everybody else sees the poster and the title with your message and a button —
to the product or the course by default — and nothing of the file: no address,
no subtitles, no download. Whoever can edit the post always sees the player.
Anything else can decide through the `imagina_player_can_view` filter.

= Can the video show who is watching it? =

Yes, for paid lessons: **Viewer's name over the picture** in Settings → Video,
or per block, draws the name or the email of the person signed in, faintly, and
moves it every few seconds. A screen recording passed around then carries the
name of whoever made it. Only that person's own name is shown, only when they
are signed in; picture-in-picture is turned off with it. It deters; it does not
lock anything.

= Can a playlist be a course? =

Yes: turn on **This list is a course** in the playlist's Course panel. Each
lesson gets a tick once it has been watched, the list says how many are done,
and coming back carries on with the lesson that was playing, where it stopped.
For a student who is signed in, the progress is kept with their account and
follows them to another device. **One lesson at a time** keeps a lesson shut
until the one before has been watched; it guides students, it does not protect
the files — use **Who can play it** for that.

= Can I share just part of a video or an episode? =

Yes: **Share a clip** in the video's settings menu, or in the audio player's
"more" menu. Choose where it starts and ends and copy the link; whoever opens
it sees the page at the start of the clip, and the player stops at its end.
Shared on a social network or in a chat, the link shows a card with the clip's
title and picture, and sites that read oEmbed show the player itself.

= Can captured emails go to Mailchimp or my CRM? =

Yes. Under Imagina Player → Integrations, switch on Mailchimp, Brevo,
MailerLite, FluentCRM or a webhook — the last for Zapier, Make, n8n or your own
code. Every address is kept on your site first and then sent in the background,
and tried again if a service is down, so nobody's address is lost and nobody
waits for it. "Test the connection" checks each one.

= Can it make the subtitles for me? =

From a transcript, yes: paste it in the video block's Subtitles panel and it
becomes a subtitle file in your media library. With times at the start of its
lines they are used; without them, the text is spread over the video. To have
them written from the sound itself, set up a transcription service under
Imagina Player → Integrations — OpenAI's Whisper, Groq or your own Whisper
server — and use "Transcribe automatically". Chapters can be pasted as they
appear in a YouTube description.

= Does it count plays? =

Yes, under Imagina Player → Statistics: plays, time watched, how much of each
video or episode was watched, where viewers stopped, and which overlays they
pressed, for every player and page, with a CSV download. It is counted on your
own site, and only as totals: no cookie is set and nothing that identifies a
viewer is kept.

= Can it be just a play button, for a radio station? =

Yes. Choose the **Play button only** skin, in the block's Appearance panel or
in a preset, and paste the station's stream address. The page shows one
button that plays and pauses, in a small, medium or large size; nothing is
loaded until it is pressed, and resuming a live stream rejoins the broadcast
where it is now.

= Is there a sleep timer? =

Yes, in the audio player's **More** menu, the three dots beside the volume,
together with bookmarks and a link to the moment playing. The timer fades the
sound out after 15, 30, 45 or 60 minutes, or stops at the end of what is
playing. The speed a listener picks is remembered on every player of the site.

= Can a video offer other qualities or languages? =

Yes. In the video block's **Qualities and languages** panel, add the same video
in other sizes, and viewers switch between them with the quality button. Add an
audio file as long as the video for each other language, and viewers pick it
under **Audio** in the settings menu; it plays in step with the picture. An HLS
stream offers its own qualities and languages by itself.

= Are there ready-made layouts? =

Yes: the **Imagina Player** pattern category has a podcast episode, a lesson
with its transcript, a silent video header and a course, and the inserter
offers the blocks already set up as a podcast episode, a short clip, a lesson,
a silent loop, a course or a video series.

= Can I stop people downloading my audio? =

Mark a file as protected and it moves out of the public uploads folder, served
only through a signed link that expires. That stops the URL being copied, shared
or hotlinked, and it can require a login or defer to your membership plugin. It
cannot stop someone who is allowed to listen from recording what they hear —
nothing short of DRM can, and this plugin is honest about that.

= Does it support video? =

Yes. There is a Video block in the inserter and a Video section in the settings,
with a poster, fullscreen, subtitles in VTT or SRT, chapters, HLS, and the same
download protection the audio player has.

== Changelog ==

= 1.58.0 =
A new skin: a play button and nothing else, for a radio station.

* New: the **Play button only** skin. One button that plays and pauses — no
  bar, no times, no volume, no cover — for a radio station, or a sound a page
  plays without a player on show. Small, medium or large, at the start, the
  middle or the end of its column, in the block's Appearance panel, in
  Elementor, or in a shortcode: `[imagina_player src="https://radio.example.com/live"
  skin="button" button_size="large" button_align="center"]`. A screen reader
  hears what it plays, and the pointer is shown its title.
* New: a **station picks up where the broadcast is**. A live stream paused
  and resumed is asked for again, at the live edge, rather than played on
  from the minutes the browser had kept — or failing on a connection the
  station had closed. A file, on any skin, still carries on from where it
  stopped.
* New: while a stream connects — which can take a few seconds — a ring turns
  round the play button of any audio player until the sound starts, so it is
  not pressed again (which would stop it).
* Changed: the button-only skin asks for nothing until it is pressed, so a
  page with a station on it does not open a connection, or count a listener,
  for every visitor.
* Changed: in the block editor, a station's address with no file name —
  `:8000/live`, `/stream` — is not reported as something the player cannot
  play on the button-only skin, and the offer to measure a waveform is made
  only on a skin that draws one.
* Fixed: a preview in the block editor could grow but never shrink back,
  so a short player sat in a box a hundred and fifty pixels tall.

= 1.57.1 =
* Fixed: on a phone, a video paused part-way with subtitles on had the play
  disc in the middle sitting on top of the line being read — which is what
  people pause for. On a small picture, with subtitles on, the disc now steps
  aside once the video has started; the bar's play button is right there and
  a tap on the picture still plays it. A larger picture, with room for both,
  keeps the disc.

= 1.57.0 =
A visual audit of every player, list, overlay and screen, in a browser at a
desktop's width and a phone's, on a light page and a dark one.

* Fixed: **Compact** and **Pill** had two dark time badges laid over the ends
  of their line, which on a desktop left about ten pixels of bar between them.
  The times now sit either side of the line, the line takes the room between
  — and the pointer aims at the line it sees.
* Fixed: a **waveform stayed the width it was first measured**: turning a
  phone, widening a window or floating the player along the foot of the page
  left it half the width of its player. It now follows the player, and the
  floating one stops short of its close button.
* Fixed: on a phone the **Card** skin kept its desktop cover beside a title
  cut to "Episo…" — the rule meant to shrink it had never won. The cover is
  smaller there, and on a phone every audio title takes up to two lines
  rather than one cut short.
* Fixed: with every control switched on, a title was squeezed to "Episodio
  12: C…". It keeps room to be read and the controls take a line of their
  own.
* Changed: a **call to action's button** is filled, in the light one of the
  accent and its label colour, rather than an outline on the near-black
  panel — the email gate's button and a locked video's offer too. "Sign in",
  when it is the only way through, is a button rather than a footnote.
* Fixed: a **course's progress** sat in a narrow column beside the video in
  the layout with the lessons beside it; it runs across the top.
* Changed: the **slider's** arrow at an end it cannot go past is hidden rather
  than faded over the first card, and the **playing card** in a grid, rail or
  slider is ringed on its picture rather than boxed in with its title.
* Fixed: **subtitles on a phone** were eight or nine pixels high, a twentieth
  of the picture's height; each size now has a floor.
* Fixed: a **caption over the picture** took the size of a call to action's
  headline, a third of the height of a small video.
* Fixed: the **Stacked** video bar showed its title cut to "Clase 3:…" on a
  picture the width of a blog column; it shows it where there is room.
* Changed: the unplayed part of a plain progress bar is visible on white.
* Changed: in the block editor, a few settings stood flush against the label
  below them, and the video block had two panels called "Advanced" — its own
  is now **File download**.

= 1.56.0 =
A new feature: how players are watched, counted on the site itself.

* New: **Statistics**, under Imagina Player → Statistics. For every player on
  a published page: its plays, the time watched, the average share of it
  watched, how many watched it to the end (nine tenths of its length), and how
  many times each overlay was pressed — over the last 7, 30, 90 or 365 days,
  with the plays per day drawn as a chart. **Details** on a row draws how many
  were still watching at each point of the video or episode, says when half had
  stopped, and lists the overlays by the names the block gives them, with
  their presses per play. **Download as CSV** gives the period as a
  spreadsheet.
* Counts, not people: a row is a player, a page and a day. No address, cookie
  or account is kept with the counts, so there is nothing personal to keep,
  export or erase. The limit on reports below remembers a network for ten
  minutes, by a hash of the first part of its address, never the address.
  Days older than the period set under Counting — 400 days to begin with — are
  deleted once a day, and counting can be switched off there. Uninstalling the
  plugin removes the statistics with everything else.
* How it arrives: a player loads the counter, 2.5 KB, on its first play, and
  sends one small report when the page is closed or hidden, when a playlist
  moves to another track, when the media ends, and every five minutes of
  watching. Plays in the block editor, on the settings screen and in
  Elementor's or the Customizer's preview are not counted.
* Security: a report carries a token the page was drawn with, for that player
  on that page, so a script cannot invent players or pages to count; what a
  report says is held to what it could mean — a play is one play, time watched
  no more than the file could have played — and one network can send 300
  reports in ten minutes. Only administrators can read the statistics.
* Changed: the core bundle is 8.7 KB gzipped, down from 8.9, with the
  counter's hook in it. The console's explanations of why a waveform could not
  be measured in the browser moved to the chunk that measures, which is the
  only one that needs them.
* Fixed: on a phone, the tables under Emails and Statistics widened the whole
  settings screen by about two hundred pixels. The hidden labels in their
  header escaped the box that scrolls.
* Changed: the strings for all of this translated into Spanish.

= 1.55.0 =
A new feature: subtitles and chapters made without leaving the block.

* New: **subtitles from a transcript**, in the video block's Subtitles panel.
  Paste a transcript and the block makes a WebVTT file, saves it to the media
  library and lists it. Lines that start with their time ("1:23 …",
  "[00:01:23] …", as YouTube, Descript or Otter export them) are placed at it;
  a transcript without times is spread over the length of the video and said
  to be approximate; SRT or WebVTT pasted whole is kept as it is. Long lines
  are cut into cues of two lines at most, at a sentence or a word.
* New: **automatic transcription**, optional. Under Imagina Player →
  Integrations, set up any service that answers OpenAI's transcription API —
  OpenAI's Whisper, Groq, or a Whisper server of your own — and the block
  offers "Transcribe automatically". The sound is taken out of the file with
  ffmpeg when the server has it (an hour in about fourteen megabytes), sent in
  the background, and the subtitles that come back are saved to the library
  beside the video and listed in the block. The editor can be left while it
  works; a job that dies is reported rather than waited for.
* New: **chapters pasted** as a YouTube description writes them ("0:00
  Introduction", "Second part 1:30"), or read from a chapters file in the
  library.
* Changed: the strings for all of this translated into Spanish.

= 1.54.0 =
A new feature: captured emails sent on to the services a site already uses.

* New: **Integrations**, under Imagina Player → Integrations. Every address an
  email gate captures is still kept in this site's own table first; then it is
  sent, in the background, to each service switched on: **Mailchimp** (added or
  updated in an audience, with double opt-in if wanted, and tagged with the
  gate's list name), **Brevo** and **MailerLite** (into the lists or groups
  given), **FluentCRM** on the same site (with its lists, tags and double
  opt-in), and a **webhook** for Zapier, Make, n8n or anything that takes a
  POST — JSON, signed with an HMAC of the body when a secret is set. A service
  that does not answer is tried again three times, over two and a half hours.
  Each card has "Test the connection", which checks the account without
  sending anybody's address, and shows the last result.
* Security: the keys are kept in an option of their own, never sent back to
  the settings screen — only their last four characters — and the screen and
  its test are for administrators only. The webhook cannot reach an address
  inside the server's own network. Everything is removed on uninstall.
* Changed: the strings for all of this translated into Spanish.

= 1.53.0 =
A new feature, clips you can share, and two fixes found on a newer browser
and server.

* New: **Share a clip**, in the video's settings menu and the audio player's
  "more" menu. Choose a start and an end — "Now" takes the second playing — and
  copy a link that opens the page at the start and stops at the end, saying so
  and offering the clip again or the rest. The link is the page's own address
  with `t` and `end` (`?t=95&end=130`, or `t=95,130` as a media fragment), with
  `player` naming the block by its HTML anchor; dragging outside the clip lets
  it go.
* New: **a card for a shared clip or moment.** Its link carries Open Graph and
  Twitter tags naming the clip with its picture, for Facebook, X, LinkedIn and
  WhatsApp — left to an SEO plugin when one is writing the page's own — and an
  oEmbed endpoint, for WordPress, Slack, Discord and Notion, that answers with
  the player in a frame: a page with nothing on it but that player, starting at
  the clip. A player behind "Who can play it" is offered as a link, never in a
  frame; a draft or a post behind a password gets nothing.
* Fixed: a signed HLS stream — its credentials in the address — did not play in
  a browser that plays streams by itself, which now includes Chrome: its own
  player asked for every segment without the credentials. Such a stream is
  played by hls.js wherever it can run, and the page no longer starts fetching
  it before the script takes over.
* Fixed: an ffmpeg path typed in the settings was silently replaced by another
  ffmpeg when the server had one in the usual place, so a mistyped path was
  never reported. The path given is the one used, as the settings say.
* Changed: the strings for all of this translated into Spanish.

= 1.52.0 =
Two new features: a video in other qualities and other languages, and block
patterns and variations.

* New: **Qualities and languages**, on the video block and widget. Add the same
  video in other sizes and viewers pick one under the quality button, carrying
  on from the same second; the choice is remembered on every video of the site,
  a stream's own renditions included. Add an audio file as long as the video —
  a dubbing — and it is offered as **Audio** in the settings menu, played in
  step with the picture in place of its own sound: it follows play, pause,
  seeks and speed, is put back when it drifts, and the picture waits for it
  while it loads. The volume and mute controls go on working on whichever
  sound is playing. A soundtrack that cannot be kept with the picture, on a
  server that cannot seek in the file, is put away rather than left out of
  step. An HLS stream with several languages offers them in the same menu,
  through hls.js or Safari's own player. Files from the library are signed
  like the main one when protected, and refreshed the same way when their link
  runs out. In the shortcode, `sources`, `quality_label`, `audio_tracks` and
  `audio_label`, the lists as JSON.
* New: **Block patterns** in an Imagina Player category: a podcast episode with
  the earlier ones, a lesson with its transcript, a silent video header, and a
  course with its lessons.
* New: **Block variations** in the inserter: Podcast episode and Short clip for
  audio, Lesson and Silent loop for video, Course and Video series for the
  playlist.
* Fixed: the dot that marks the chosen item in the video's menus took the
  accent colour and vanished on the dark menu with a dark accent.
* Changed: the strings for all of this translated into Spanish.

= 1.51.0 =
Two new features: a playlist that is a course, and a "more" menu on the audio
player.

* New: **Course**, on the playlist block and widget. Each lesson is marked once
  nine tenths of it has played, the list says how many are done with a bar and
  a "Start over" button, and coming back loads the lesson that was playing,
  where it stopped. A visitor's progress is kept in their browser; a student
  who is signed in has it kept with their account too, so it follows them to
  another device and to another page carrying the same list. **One lesson at a
  time** opens a lesson only once the one before has been watched — a guide
  for the student, not a protection, which is what **Who can play it** is
  for. Progress goes to a REST route open only to people signed in, is written
  only to their own account, and is removed when the plugin is uninstalled.
* New: **More** on the audio player, the three dots beside the volume (on by
  default; a preset or a block can turn it off). A sleep timer of 15 to 60
  minutes that fades the sound out rather than cutting it, or that stops at the
  end of the file playing, even one set to loop; bookmarks a listener puts in a
  file, kept in their browser and listed to jump back to; and a link to the
  moment playing.
* New: the speed a listener picks is remembered across the site, on every
  player that shows the speed control.
* Changed: the strings for all of this translated into Spanish.

= 1.50.0 =
Two new features: who can play a player, and the viewer's own name over the
picture.

* New: **Who can play it**, on every block and Elementor widget and as
  shortcode attributes (`access_rule`, `access_ids`, `access_message`,
  `access_button`, `access_url`). A player can play for everyone, anyone signed
  in, certain roles, people who bought a WooCommerce product, members of a
  WooCommerce Memberships plan or a MemberPress membership, or students of a
  LearnDash course. Everybody else sees the poster and the title, a message
  that suits the rule, a button — to the product or the course by default — and
  a sign-in link when they are not signed in. Nothing of the file reaches the
  page: no address, no subtitles, no download, no configuration for the
  script. A playlist under a rule keeps its titles and loses its links.
  Whoever can edit the post always sees the player; anything else can decide
  through the `imagina_player_can_view` filter. A page where a player opened
  for somebody in particular is kept out of page caches.
* New: **Viewer's name over the picture**, in Settings → Video and per block
  or widget: the name, the email or both of the person signed in, drawn
  faintly over a video and moved every few seconds, so a screen recording of
  a paid lesson carries the name of whoever made it. Only their own name, only
  when signed in; picture-in-picture is turned off with it, and the mark is
  put back if something removes it from the page. The text can be changed
  through the `imagina_player_viewer_mark` filter.
* Changed: block and widget settings for the two, translated into Spanish.

= 1.49.0 =
The block editor and the settings screen, from the editor audit.

* Fixed: "Site: on" and "Site: off" in the block's inspector were read from
  the factory's defaults, so a site that had turned the download button on
  was told it was off, and the preset the block had chosen was ignored. They
  now come from the block's own preset, and for a video from the site's video
  settings, which the video rows had never shown at all.
* Fixed: settings about behaviour offered "Show" and "Hide" — "Hide YouTube's
  interface: Show" meant hiding it. They say On and Off.
* Fixed: the video "Shape" showed 16:9 for a block that follows the site, and
  once changed could never go back. It has "Use site setting", naming the
  site's shape.
* New: a watermark can be set from the block and the Elementor widget — an
  image, a corner and an opacity. It was in the player and reachable only
  from a shortcode.
* Fixed: the editor's preview could never show subtitles, so its transcript
  was always empty and its subtitles button did nothing. Subtitle files of
  this site are written into the preview; one on another site is named in a
  note under it.
* Fixed: a video from YouTube or Vimeo offered search, the transcript and
  picture-in-picture, which cannot work there, and an MP4 offered to hide
  YouTube's interface. Each is shown only where it does something.
* Fixed: an overlay the site would leave out — a call to action with no
  address, a caption with no words, an image with no image — appeared in the
  list and never on the page. Each says what it needs, on the overlay.
* Changed: the audio block offers text, image and shortcode overlays as what
  they are beside audio, under the player, and no longer a spot to press on a
  picture it does not have. The email gate has a thank-you message, and
  "Can be closed" explains what it means for each kind.
* Changed: replacing a video's file says that the old subtitles, chapters,
  poster and storyboard are still there, with a button to clear them; a
  YouTube or Vimeo address drops subtitle files it cannot use. The video
  block's replace accepts only video.
* Changed: the playlist block keeps what was typed when tracks are edited in
  the media library, keeps addresses added by hand, adds new picks at the
  end, and takes the files' lengths. It has a preset, per-track artist and
  cover, tracks added by address, and a length for those.
* Changed: the editor's preview shows that it is loading, and says why it
  failed with a way to try again. It no longer reloads for a class name or an
  alignment.
* Changed: "Hide the controls after" is in seconds everywhere. The labels for
  the floating player and for remembering the position read the same in the
  block, the settings and Elementor. The poster's choices are named the same
  everywhere.
* Changed: the settings screen's Video panel puts every control under
  Controls, behaviour under Behaviour, and keeps "Keeping the file" for the
  download button. Saving says what the site changed — a path that is not a
  program, a number out of range, a colour that is not one — and why a save
  failed. A number field can be cleared to type a new number.
* Changed: deleting a preset asks first and says that its blocks will use the
  default. A default preset that went missing comes back in the brand colours.
* Changed: captured addresses are shown in the site's time zone; the export
  says its times are UTC.
* Fixed: block names, descriptions and keywords were never translatable; they
  are now, and translated into Spanish. The playlist block says what it does
  today, and all three blocks have an example in the inserter.
* Fixed: the focus ring of the inspector's On/Off segments was cut off.

= 1.48.0 =
The visual audit: how the player looks on a phone, on a dark theme, beside a
theme's own styles and right to left.

* Changed: a video's bar is one row. On a phone it holds play, the time, sound,
  subtitles, the gear and full screen; skip is a double tap on either side of
  the picture, and chapters, search, quality, picture-in-picture, speed and
  the download are in the gear, under their own names. On a wider player the
  volume slider, search, quality and picture-in-picture move into the gear
  only when the row runs out of room. The bar used to wrap into three ragged
  rows on a phone and cover the whole picture.
* Changed: a video's title and artist sit over the top of the picture, in a
  band that comes and goes with the controls. On the bar they shared a row
  with a dozen buttons and were cut to a word or two. The stacked skin, which
  draws nothing over the picture, keeps them on its bar.
* Changed: a video's time is text on the bar, "0:12 / 3:40", instead of two
  dark pills on the seek line that covered the playhead and the first and last
  chapter notches. Audio keeps the pills that ride its waveform.
* Changed: a click on the dark gradient above a video's bar goes through to
  the picture. On a phone that gradient covered nearly all of it.
* Fixed: on a phone, a tap on a playing video paused it, including the tap
  meant to bring the controls back. A tap now shows or hides the controls; a
  tap on the round button in the middle, shown with the controls, pauses.
* Fixed: a video started with a tap kept its controls up for as long as it
  played, and so did one whose button had been tapped at all: the controls
  only faded after the mouse had moved. They fade on a phone as on a computer.
* Fixed: menus were cut off by the picture on a phone, and the search panel
  came out nineteen pixels tall with its results out of reach. Menus hang
  from the bar, are never taller than the picture above it, and on a phone
  are a sheet across the picture. The speed list opened from the gear has a
  way back to the gear.
* Fixed: subtitles were drawn on top of the controls while they were showing.
  They are lifted by the bar's real height, and not at all under the stacked
  skin, whose bar is not on the picture.
* Fixed: on a dark theme the title, the transcript and the playlist were
  near-black on near-black, and the play button a dark disc on a dark page.
  The words now take the page's own text colour, and on a dark page the
  factory colours change to a light play button, a dark icon and a waveform
  that reads. Colours an author chose are never changed.
* Fixed: a video's played line, on the factory colours, was a dark slate on a
  dark bar and could hardly be seen. It takes the bar's own foreground.
* Fixed: a pale accent gave a white play icon on a pale disc and a white close
  button on a pale bar.
* Fixed: the card skin with a call to action, an email gate, an action bar or
  the transcript squeezed the controls into a column beside the cover; those
  go underneath, full width.
* Fixed: "Compact, one line" and "Pill" were three lines at every width. They
  are one line, and wrap the seek line underneath only on a phone.
* Fixed: a centred caption over the picture was held to half its width; a
  shortcode card was taller than a phone's picture and lost its close button;
  a hotspot's label was cut off at the edges, and opened above the picture for
  a spot near the top; captions along the bottom sat on the bar and stayed
  there after it faded, because the rule that moved them named a class the
  player never set.
* Fixed: the floating video card was 179 pixels wide at "bottom" on a phone,
  with its full-screen button cut off, and a different width in each corner.
  It is one width everywhere, never under fifteen rem, with play, sound, the
  seek line and full screen.
* Fixed: a theme's list numbers, indents and underlined links reached the
  playlist, and its filled buttons the slider's arrows and the timestamp
  buttons. A shortcode's own buttons and links inside an overlay are no
  longer flattened by the player's defences.
* Fixed: the transcript's search box had lost its border and padding to the
  same defences.
* Changed: a list's tracks are numbered, the one playing is marked with a play
  sign and a stronger tint, and a track without a cover gets a blank one, so
  the column stays aligned and the grid has no holes. The grid is two columns
  on a phone. A video without a still is a dark frame with a visible play sign.
* Changed: the "beside" playlist drops its scroll box once it has wrapped under
  the picture; the slider's arrows sit level with the middle of the pictures.
* Changed: forty-four-pixel touch targets on touch screens, without making any
  icon bigger; the speed is a chip; the "resume from" line steps aside while a
  menu or the chapter tip is up, and "Link copied" moves the big button aside
  on a small picture.
* Changed: right-to-left pages get the player's margins, alignment and the
  current-item marks on the right side; the seek line still runs left to
  right.
* Changed: printed pages show the poster or the waveform and the title, not the
  controls.
* Fixed: on a phone, a single mute button no longer gets a line of its own, and
  the brand mark stays on the line with the controls.

= 1.47.0 =
The security findings of the audit. None was a door anyone could walk
through unaided; each is closed.

* Security: a fresh link to a protected file was handed to anyone who asked
  with the file's number, so counting upwards found every protected file —
  including those of drafts and private posts. The player now trades in the
  link that expired, which only a page with the player on it could have
  given; a link from another site's page, a link for another person, or one
  older than two weeks gets nothing. Every refusal is the same answer, so it
  no longer says which numbers exist or which files are protected.
* Security: a protected file stops playing when its post is made private or
  unpublished, for anyone who may not read that post.
* Security: the media address redirected to any unprotected attachment's real
  address, including those of drafts and private posts. It answers "not
  found" for anything not in the vault.
* Security: the block editor's preview read the title, tags, cover and address
  of any file named in it, including other people's private files. It reads
  only files the author may read. A shortcode overlay is shown, not run, in the
  preview of an author who may not publish arbitrary markup.
* Security: the doorway that fetches other sites' files for measuring would
  fetch from this site's own host and from any address with no content type.
  It refuses this site, accepts a missing type only for an address that names a
  media file, connects to the address it checked rather than looking the name
  up again, and limits how often one person may use it.
* Security: email capture counted a network by its /64, so one household with
  IPv6 counted as hundreds; it counts a /48 now, adds a ceiling for the whole
  site, clears its counters daily, and takes a check of the site's own — a
  captcha, say — through the `imagina_player_lead_allowed` filter. Behind a
  proxy, `imagina_player_client_ip` can name the visitor's real address.
* Security: the protection self-check trusted any answer to its own address,
  without verifying the certificate. It verifies it now, and says so when the
  server cannot. It also says plainly when nothing limits who may play a
  protected file.
* Fixed: the "Download as CSV" link in Leads carried the nonce from when the
  screen opened, and after a while saved WordPress's refusal under the name of
  the export. It fetches the file when pressed.
* Removed: a third-party plugin archive that had been committed to the source
  repository. It was never part of the plugin's download.

= 1.46.0 =
This release fixes what an audit of the whole plugin found; the security
findings follow in 1.47.0.

* Fixed: the plugin says it runs on PHP 8.0 and used a PHP 8.1 feature in two
  classes, so on PHP 8.0 the first player on any page was a fatal error.
* Fixed: the "HTML anchor" of all three blocks was lost on saving, so
  timestamp buttons and `?player=` links could only name a block written by
  hand. An anchor also keeps accented letters, colons and dots now.
* Fixed: keys pressed on a video's scrub bar acted twice — a left arrow went
  back fifteen seconds, space played and paused at once and left the player
  showing an error. Space on the transcript's heading plays the video no
  longer; it opens the transcript.
* Fixed: on a phone a tap showed the controls and the end of the same tap
  hid them again. A tap now shows hidden controls and hides shown ones.
* Fixed: a player moved in the page by a page builder — tabs, accordions,
  sliders — was taken apart and never rebuilt.
* Fixed: a floating player never went back when the reader scrolled up to it,
  and left an empty gap behind when it was removed.
* Fixed: the remembered position was saved from the animation loop, which a
  browser stops in a background tab, so a listener who switched tabs came
  back to where they switched. It is saved on each new second, on pause and
  when the page is hidden or closed.
* Fixed: "Resume from" said one thing while the playhead was elsewhere when
  the block had a start time, and offered positions past the end of the file.
  A remembered position now wins over the start time, a link to a moment
  wins over both, and a position at the end is forgotten.
* Fixed: a browser refusing to autoplay, or a play interrupted by a pause, put
  the player in its error state.
* Fixed: remembered state — position, closed overlays, a playlist's last
  track — was keyed on things that change between page loads: a protected
  file's signed address and a playlist's random id. It is keyed on the track
  and the list now.
* Fixed: Vimeo addresses from a channel, group, showcase, album or On Demand
  were taken for audio files, and an unlisted video pasted from Vimeo's own
  embed code (`player.vimeo.com/video/…?h=…`) lost its hash and would not play.
* Fixed: a page with a Vimeo video waited for Vimeo while it was being built —
  up to ten seconds on a host that cannot reach it. The picture is fetched in
  the background now; the editor's preview still asks and explains.
* Fixed: the bar's menus could not be used from the keyboard. The arrows walk
  the list, Escape closes it and returns to its button, a second button swaps
  its own list in, and the search box closes like the others.
* Fixed: focus mode paused a video playing in picture-in-picture.
* Fixed: a protected HLS stream could not renew its signed address, and three
  short network drops over a long lecture ended it for good. Its quality menu
  could open and close in the same click.
* Fixed: the total time stayed "--:--" on a player enhanced after its file had
  loaded; YouTube's buffering spinner could stay on a paused video; YouTube's
  clock was polled four times a second while nothing played.
* Fixed: a double tap on a YouTube or Vimeo video before it was ready built
  two players in one box.
* Fixed: in a playlist, "loop" restarted the track while the list moved on to
  the next. The player's end setting now applies to the list: loop starts the
  list again, reset goes back to the first track.
* Fixed: a call to action part-way through that could not be closed covered
  the video for good; one before the end is always closable. An overlay set to
  appear at the start no longer takes focus as the page loads.
* Fixed: the slider's arrows did nothing on a right-to-left site, and moved by
  most of a width, leaving a card cut in half. They move by whole cards now,
  and right-to-left sites get their mirrored stylesheet.
* Fixed: the transcript's lines were announced as list items rather than
  buttons; it waited a fixed second for a slow subtitle file instead of for
  the file. It now marks the words found, says how many lines there are, and
  can stop following the video.
* Fixed: measuring a waveform in a visitor's browser could use most of a
  gigabyte of memory for a long file. It decodes in windows now, like the
  editor, and is only downloaded by the visitor who needs it.
* Fixed: `[imagina_player class="…"]` was ignored; `start_time="1:30"` was
  read as one second; `[imagina_time at="00:00"]` printed nothing; a playlist
  printed an hour and a quarter as "75:00"; a stream did not borrow the cover
  as its poster; an SRT given as `/wp-content/uploads/…` was refused; a
  block's class was applied twice; uninstalling on a network left every site
  but the main one behind; Elementor's transparent colours were dropped
  without a word, and its image, text and hotspot overlays appeared only at
  the end of the video.
* Changed: the floating player and the in-browser waveform measurement are
  chunks of their own, fetched only by players that use them.

= 1.45.0 =
* Added: three layouts for a playlist of videos, beside the list and the
  grid: **Video with the list beside it**, **Video with a rail of thumbnails
  under it** and **Video with a slider of cards under it**, with arrows once
  the cards overflow. Each item shows its picture — the one given, or the
  video's poster, a provider's still or an upload's cover — with its length
  on it and a play glyph, and the row scrolls to the one playing. In the
  block's Layout setting and in the Elementor widget.
* Added: a playlist switches videos without rebuilding the player. A file
  takes the place of a file, with its poster back up until it plays; a
  YouTube or Vimeo video takes the place of another from the same provider
  inside the provider's own frame. A YouTube item in a list of files, or the
  other way round, is left to its link, which opens it, rather than a click
  that does nothing.
* Fixed: an item's length was only shown when typed in; an upload's own
  length is now read from the library.
* Fixed: the close button of a text or shortcode overlay sat over its first
  words; it sits on the corner now.

= 1.44.0 =
* Added: four more kinds of overlay beside the call to action, the bar and
  the email gate. **Text over the picture** puts a caption in one of nine
  places; **Image over the picture** puts a logo or a still there, sized as
  a share of the picture; **Hotspot** is a pulsing spot at a point of the
  picture with a label on hover or press, and a link if wanted;
  **Shortcode** shows whatever another plugin's shortcode prints — a form, a
  button, a countdown — over the picture. All four appear at a moment and
  can leave at another, and none of them pauses playback. In the block's
  panel (now "Overlays and calls to action") and in the Elementor widgets.
* Added: a transcript under the picture. With **Transcript under the
  picture** on — in the video block's Controls, in Settings → Video, or in
  the Elementor widget — a video that carries subtitles gets a closed panel
  beneath it that opens to every line with its time, marks the line being
  said and keeps it in view, jumps to a line when pressed, and narrows to a
  word typed in its box, accents or not. Built from the subtitles the video
  already carries; nothing is fetched twice. Off by default.

= 1.43.0 =
* Added: timestamp buttons. `[imagina_time at="1:35"]The second question[/imagina_time]`
  writes a button into the text that takes the player to that moment and
  starts it. `player="intro"` names a block by its HTML anchor when a page
  has more than one; without it, the first player on the page is meant.
  The time can be written as `95`, `1:35`, `1:02:03` or `1m35s`, and the
  button reads the time itself when no text is given.
* Added: links to a moment. A page address ending in `?t=95` or `#t=1m35s`
  opens the player at that second, paused, and `&player=intro` says which
  one. The video gear offers **Copy link to this moment**, which writes such
  a link to the clipboard.
* Added: a speed list for video. The speed button now opens a list from
  0.5× to 2× with the current speed marked, instead of stepping through
  five speeds in turn; audio keeps its one-press button.
* Added: a gear on the video bar. It holds the speed list and the link to
  the current moment.
* Added: the scrub bar is cut into segments where each chapter begins, and
  moving the pointer along it names the chapter underneath and the time
  there.
* Added: a player that remembers where the viewer stopped now says so —
  "Resume from 12:40", with **Start over** beside it — rather than opening
  silently part way through. The chip leaves by itself once playback has
  carried on.
* Added: the Elementor video widget now offers **Keep playing in a corner
  while scrolling** and **Remember where the viewer left off**, as the
  video block's Playback panel already did.
* Fixed: the video block's own **Speed control** switch had no effect. The
  video bar took the speed flag from the audio preset, whose default is
  off, so the control was missing from most videos whatever the block said.
* Changed: the core bundle is 8.3 KB gzipped, up from 7.8. The half kilobyte
  is the glue that decides whether to fetch the links-to-a-moment, timestamp
  and resume-chip code, each of which is its own file and costs a page
  nothing until it uses it.
* Fixed: two YouTube or Vimeo videos on one site shared a single remembered
  position, because neither has a file address to remember it under. Each
  is now remembered under its own name.

= 1.42.1 =
* Fixed: a Vimeo video hidden from Vimeo.com, or allowed only on chosen
  sites, had no picture — the editor said "Vimeo answered, but without a
  picture", beside Vimeo's own player plainly showing one. Vimeo answers the
  usual endpoint for such a video with the player and nothing else. The
  picture is now asked for at a second door when the first gives none: the
  player's own configuration, which lists the stills it draws. Every request
  to Vimeo also names this site as the asker, which is how the player's own
  request is let in for a video restricted to chosen sites.

= 1.42.0 =
* Added: Elementor widgets. With Elementor active, an **Imagina Player**
  category in the widget panel holds the audio player, the video player and
  the playlist. Each takes a file from the media library, an address, or a
  custom field of the post the page shows; the audio and video widgets offer
  the preset, the skin, the accent colour and corner radius, every control as
  a three-way choice between the preset's answer, on and off, calls to
  action, and — for video — the aspect ratio, poster, subtitles, chapters and
  the YouTube and Vimeo interface switch. The playlist takes a list of tracks
  by file or address, a heading, a layout and a preset. Text and address
  fields accept Elementor's dynamic tags. Rendered by the same code as the
  blocks. Nothing is registered unless Elementor is active, and Elementor
  3.5 or newer is asked for.

Verified on a real Elementor 4.4 on WordPress 6.8: the three widgets register
in their category with their panels, a page built with all three renders all
three players with the front-end bundle enqueued, and a widget's switch set
to off reaches the rendered player. Every choice each widget offers is
checked, one by one, against what the renderer receives.

= 1.41.0 =
* Added: the subtitles button switches a YouTube or Vimeo video's own
  subtitles. Both providers draw theirs inside their frame and will not hand
  the text over, so this player cannot draw them with its own size and
  backing — but it can turn them on and off and pick the language, and with
  the provider's interface hidden that was the only thing missing: a video
  with subtitles nobody could turn on. The button appears once the video has
  started, which is when the provider's frame exists and can list its
  languages. The viewer's remembered language and the block's "subtitles on
  from the start" apply to them as to the player's own tracks; for YouTube
  the latter is also passed as YouTube's own switch, so they show from the
  first frame.
* Note on YouTube: the module that lists and sets subtitle tracks has been
  in YouTube's player API for years without being documented. Turning them
  on from the start is documented. Vimeo's calls are documented.
* Vimeo's API script is not loaded a second time when another plugin already
  loaded it.

Driven in Chromium against stand-ins for both APIs that record what they are
told: the button hidden before play and shown after, the menu listing off and
every language, each pick reaching the provider as the right call, the choice
remembered for the next video, and a viewer's earlier choice applied without
asking.

= 1.40.3 =
* Fixed: after 1.40.1 the editor's preview drew, but its console showed
  `ChunkLoadError` for `imagina-provider.js` asked for next to wp-admin. The
  player loads its video chrome, provider shell and layers on demand from
  beside its own script; written into the frame as text, "beside" was the
  frame's own address, and a host that refuses the frame's requests refused
  those too. The previews now tell the player where the pieces live and
  write every piece into the frame with the script — all but the HLS
  library, half a megabyte for a stream a preview never plays.
* Fixed: every video page view carried a request for a waveform, and a 404
  for it in the console. A video never draws one, yet the player was given
  the key to ask with. It is not any more; audio is unchanged.

Verified in the real block editor against a server that refuses the
plugin's files to cross-site requests: the video preview is enhanced, with
its chrome and provider shell, and nothing is asked for from inside the
frame. Verified in Chromium that a refused piece inlined this way runs.

= 1.40.2 =
* Hardening of the 1.40.1 change, which shipped with one test red. A file
  that never answers is given up after eight seconds and linked instead, so
  a slow host cannot hold the preview forever; an address that is missing is
  skipped rather than failed on; and the plugin's own bundle no longer spells
  the tags that a page inlining it would trip over. Install this one rather
  than 1.40.1.

= 1.40.1 =
* Fixed: on some hosts the editor's preview showed the browser's bare
  controls with no styling, and the console showed each of the plugin's own
  files refused with `ERR_BLOCKED_BY_RESPONSE.NotSameOrigin 403`. The preview
  runs in a sandboxed frame, so to the server its requests come from nowhere,
  and hotlink protection, a Cross-Origin-Resource-Policy header or a firewall
  rule on static files refuses them. The stylesheet and script are now
  fetched by the editor page itself, which is the site, and written into the
  frame as text, so the frame has nothing left to ask for. The settings
  screen's live preview had the same fault and the same fix. Where a file
  cannot be fetched at all it is linked as before.

Verified against a server that refuses the plugin's files to cross-site
requests, in a real Chromium: the old preview comes up unstyled on it and the
new one styled, and in the real block editor on such a server the video
stage takes its 16:9 height again.

= 1.40.0 =
* Added: a block can take its file from a custom field of the post it is
  shown on. Open Dynamic source in the block's sidebar and name the field —
  one made with ACF or JetEngine, or plain post meta — whose value is the
  file's address or its media library ID. One block in a WooCommerce product
  template then shows each product's own video; a custom post type's single
  view plays each entry's own recording. Where the field is empty, visitors
  see nothing, unless the block is also given a file of its own, which is
  then the default. The editor's preview shows the file of the post being
  edited, and in a template, which has no such field, says which field it
  will read. Also in the shortcode, as `field="video_url"`.
* A field plugin's every way of storing a file is understood: an address, an
  attachment ID as a number or as text, or an array carrying either. Hidden
  meta — any key starting with an underscore — is never read, so naming a key
  cannot print a token or a private address into a page.

Verified on a real WordPress 6.8: three posts sharing one block, one with a
YouTube address in the field, one with a media library ID, one with nothing —
the first two play their own file and the third shows visitors nothing.

= 1.39.1 =
* Fixed: in the block editor, a video was cut off at the top fifth — the
  preview kept its starting height, 150 pixels, whatever it held. The
  preview runs in a sandboxed frame, on purpose, and the same wall that
  keeps it away from the editor kept the editor from measuring it: the
  measuring code read a document it could not reach and measured nothing,
  on every site, from the first version. An audio player happened to fit.
  The frame now reports its own height to the editor, and again whenever
  its content changes size, including from inside the editor's canvas frame
  on a block theme. The settings screen's live preview had the same fault
  and the same fix.

Verified in the real block editor on WordPress 6.8: a 16:9 video block is
shown whole at the width of the canvas, and a Chromium test holds a real
sandboxed frame, proves its document is unreadable from outside, and checks
that its report arrives, follows a change in size, is heard from inside a
canvas frame, and is ignored when it comes from any other frame.

= 1.39.0 =
Reported: "the video's picture only works with YouTube — a Vimeo video does
not bring one." On a real WordPress with Vimeo answering, the same lookup
produced the picture; what was missing was any account of what Vimeo had said,
and a memory that kept a single failed attempt for an hour.

* The editor now says why a Vimeo video has no picture — "Vimeo answered 403:
  the video is private, or its owner has restricted where it may be embedded",
  or whatever the HTTP client reported, verbatim — and offers to ask again.
  Nothing ever said anything before: a private video, a host that cannot
  reach Vimeo and a plugin not trying all looked the same.
* Fixed: a failure to reach Vimeo — a timeout during one preview, Vimeo being
  down — was remembered for an hour, the same as a refusal. It is remembered
  for five minutes now, and a refusal for an hour, with "Ask Vimeo again"
  in the editor for an author who has just made the video public. A miss
  remembered by an earlier version is asked again rather than trusted.
* Fixed: the block preview asked for the right to manage options, so an
  author or editor whose role cannot got "The preview could not be loaded"
  on every block. It asks for the right to edit posts now.

Verified on a real WordPress 6.8, in the real block editor: a Vimeo block
whose host cannot reach Vimeo shows the notice with the client's own words
beside the poster field, and a mocked Vimeo answer produces the picture in
the rendered player.

= 1.38.0 =
The plugin was installed on a real WordPress 6.8 — not a stub — and every
claim of the 1.37.0 audit was exercised there: activation, the block editor's
saved markup, the front end in a real browser, the waveform round trip, the
protected vault through core's media endpoint and the signed stream, the
upgrade path, the lead limits and uninstall. Two things did not hold up.

* Fixed: a settings request that named one setting in a group turned off every
  switch in that group it did not name. A request carrying only the ffmpeg path
  switched off server generation and the browser fallback, and the front end
  stopped measuring waveforms; one carrying only the YouTube interface switch
  turned off privacy mode and every video control. The settings screen sends
  whole groups, so it never showed there — anything else talking to the
  endpoint saw it. A request now changes what it names and nothing else.
* Fixed: uninstall moved every protected file back and left the vault
  directory behind, empty but for its deny rules. It is removed once nothing
  but those rules is left in it; a file of any other kind keeps it.

Verified on that site, and left alone: a page without a player loads none of
the plugin's assets on block and classic themes alike; a stored waveform is
served from the site on the next view instead of being measured again; the
media endpoint no longer names the vault directory to anyone; the vault's
signed stream honours Range requests and refuses a tampered or missing token;
the sixth lead from one address in a day is refused; a site updated by
uploading the plugin gets the waveform table's missing column back on its next
request; and uninstall leaves no option, table, transient or moved file behind.

= 1.37.0 =
An audit of the whole plugin — security, correctness, performance — with every
finding verified against the code before it was acted on, and every fix checked
by putting the fault back.

Security:
* Fixed (high, on nginx and any server that ignores .htaccess): the protected
  vault's unguessable directory name was written into attachment metadata,
  which core publishes verbatim on its own media endpoint to anyone. It is no
  longer written, and is stripped on read for files protected by earlier
  versions.
* Fixed: a duration of "1e999" is numeric, becomes INF, and INF cannot be JSON
  encoded — so one anonymous request could make a track's waveform endpoint
  answer 500 for good. Clamped where every path writes through. The same shape
  in a captured lead's position.
* Fixed: the ffmpeg path setting accepted anything, was quoted for the shell in
  a way that leaves spaces alone, and was run — so an administrator could run
  an arbitrary command. Absolute path, path characters only, executable file.
* Fixed: the fetch-on-behalf doorway had no size limit while downloading and
  left its temporary file behind on five of its six exits. Bounded, and removed
  on every exit.
* Fixed: the lead endpoint was limited per email address only; a script rotating
  addresses filled the table without bound. A second limit per network.
* Fixed: the waveform read endpoint answered for any attachment id, confirming
  existence and length of private and protected media. It applies the same
  visibility rule as core's media endpoint now.
* Fixed: the settings-screen tools that list every file on the site and
  describe the server required only the ability to upload; they require
  administration now.
* Fixed: the storyboard address was the one address never sanitised; a
  subtitle path check accepted a sibling directory; the editor offered a link
  to whatever was pasted, javascript: included; the preview frames ran with the
  admin's origin; the inline runtime JSON did not escape HTML characters;
  forced regeneration ran ffmpeg on demand with no limit; the leads and preview
  routes read parameters they never declared.

Correctness:
* Fixed: the Video and Track-details panels never saved. The screen posted five
  groups of settings and had seven; edits to those two were silently reverted
  by the server's own copy. Everything is sent now.
* Fixed: "Hide YouTube's own interface" was never persisted either.
* Fixed: "Generate missing waveforms" searched posts for the wrong block name
  and the wrong playlist attribute, so it found nothing on any real site. The
  test fixtures had been written with the same wrong names. Both now come from
  the class that registers the blocks.
* Fixed: a hide-controls delay of zero, documented as "never", hid them on the
  first frame.
* Fixed: a preset with a video skin used by an audio block drew the wave skin
  with no waveform under it.
* Fixed: measuring a file again with the same result was reported as a server
  error, because "unchanged" and "failed" share a return value in core.
* Fixed: the visitor's browser resampled waveforms by the loudest value,
  undoing on narrow players the loudness measure introduced in 1.30.0.
* Fixed: uninstall left captured email addresses behind, and left every
  protected file inside a directory that denies access with nothing to serve
  it. Files are moved back first; everything is removed.
* Fixed: the "enabled" switch for protection gated nothing.
* Fixed: two subtitle cards bound to the same settings, one unable to show a
  size the other allowed.

Performance:
* Fixed: the stylesheet was declared as a block style, which classic themes
  load on every page of the site whether or not a player is on it.
* Fixed: three version markers, each written without autoload and each read on
  every request — three queries per page view, site-wide. One autoloaded
  marker, read from memory.
* Fixed: a player with no stored waveform probed for ffmpeg — a process spawn —
  on every page view, before checking the transient that said it had already
  asked this hour.
* Fixed: a playlist of N uploads cost 2N queries; primed in one.
* Fixed: players removed from the page were never released.
* Fixed: a "no waveform" answer carried no cache header, so a CDN could keep it
  after one was stored. The block preview sent a HEAD for files it had already
  decided not to download.

= 1.36.0 =
* Added: hide YouTube's own interface, so a video hosted there looks like every
  other video on the site. Three mechanisms, because no single one is enough.
  The frame receives no pointer events, so nothing of theirs appears on hover.
  The frame is made three times the height of the box and centred, so their
  bars — pinned to the player's edges, while the picture is fitted inside and
  centred — fall outside the crop while the picture still covers the box
  exactly, to the pixel, with none of it lost. And playback is stopped a
  fraction before the end, because the grid of suggested videos is drawn over
  the picture where no crop can reach it, and no parameter turns it off.
  On by default, and switchable per video and site-wide.
* Note: YouTube's terms for the embedded player ask that it is not obscured.
  The setting says so where the choice is made, rather than leaving it to be
  discovered.
* Testing: the crop is measured in a real browser against a stand-in built to
  the same geometry — bars at the player's edges, picture fitted and centred —
  with the same page measured twice, once with the crop and once without, so
  the "before" is a control rather than an assumption. It requires a hundred
  pixels of clearance rather than merely "outside the box", which any overscan
  satisfies. The stopping-before-the-end is driven through the real bundle with
  a stand-in for YouTube's API. All three were confirmed by turning them off.

= 1.35.0 =
* Fixed: "Generate missing waveforms" skipped most of what needed generating.
  It asked the media library for attachments with no stored waveform, which
  excluded two whole groups: a file measured by an older version has one, so it
  was skipped — and those are precisely the ones worth doing again — and a
  track played from an address rather than an upload has no row in the library
  at all. On a site whose audio lives on a media host it found nothing and
  reported success, which reads as "all done" when nothing was done. It now
  includes files measured an older way, and finds tracks played from addresses
  inside the posts that play them, playlists and nested blocks included.
* Fixed: and it could not have measured them anyway. Measuring a file that may
  be on another domain — try it directly, fall back to this site's own doorway
  — lived inside the editor's notice, so the settings screen fetched every file
  directly and failed on any host that does not allow another domain to read
  its files, which is most of them. One implementation now, used by both.
* Fixed: a waveform measured for an address from that screen was stored against
  attachment zero, which is nothing at all. The address goes with it now.
* Changed: the report lists every file that failed with its own reason, in the
  same words the editor uses. It used to be a count and the first failure's raw
  tag, which says neither which files were left nor what to do about them —
  and eleven failures rarely share one cause.

= 1.34.0 =
* Fixed: every string with a plural stayed in English, in an otherwise fully
  translated editor and settings screen, for as long as the translation
  generator has existed. A .mo file keys a plural as `msgid` + NUL +
  `msgid_plural`; the JSON that scripts read keys it by the msgid alone, with
  the forms in the value. The generator ran the two formats together and
  produced a key meaning "the singular, in the context of the plural", which
  nothing ever asks for. Singulars were unaffected, which is why it survived
  this long — it took a screenshot of one button in an otherwise Spanish panel.
* Changed: the offer to measure an existing waveform again is a button rather
  than a link. As a link it sat in a column of form controls looking like a
  caption for the field below it, and was easy to miss.
* Testing: the translation check no longer inspects the generated JSON — a test
  that reads a file and decides it looks right is written by the same
  understanding that produced the file. It now loads each catalogue into the
  actual `@wordpress/i18n` library the browser runs and asks it for the
  strings, singular and plural. Putting the old key format back fails it.

= 1.33.0 =
* Changed: the editor's waveform notice and source warning move into the block
  sidebar. They were drawn inside the block, above the player — and in the
  editor a block is a picture of the page, so anything drawn there reads as
  part of it. Somebody showing a client a post had to explain that "Measure
  this waveform again" was not going to appear on the finished site.
* Changed: the settings screen no longer warns about ffmpeg when nothing needs
  it. It used to say so in alarm colours on every visit to any site without
  ffmpeg, whether or not a single file was missing a waveform — telling people
  their server cannot do something they are not asking it to do, which reads as
  a fault. It now counts what is actually missing, says nothing when the answer
  is none, and when there is something to do says which button to press rather
  than what the server cannot do. The technical reason moves beside the ffmpeg
  path setting, where somebody wondering about it is already looking.
* Testing: a new check reads which components are drawn inside the block and
  which are in the sidebar, and requires the author-only ones to be in the
  sidebar; and requires the ffmpeg note to depend on a count and to be a note
  rather than a warning. Both were confirmed by putting the old behaviour back.

= 1.32.0 =
* Fixed: 1.31.0 added a column to the waveforms table and nothing ever created
  it. The routine that catches up a site whose stored version is behind the
  code — which exists precisely because most sites update by uploading the
  plugin rather than by activating it — did not touch the tables. So the code
  asked for a column that was not there: every read failed, every write failed,
  and it was invisible, because the editor draws the waveform it has just
  measured and looked perfectly correct while nothing reached the database.
  The visible symptom was on the front end, where every visitor downloaded the
  whole file to work the same waveform out again on every page view.
* Fixed: a write to the waveforms table that fails now rebuilds the table and
  tries once more, rather than reporting success it did not have.
* Fixed: the loading sheen slid a full width in each direction inside a box
  that clipped nothing, so while a waveform was being worked out a whole page
  width hung off the side and the horizontal scrollbar appeared, grew and shrank
  in time with it. Measured at 320 to 768 pixels across every skin.
* Changed: the file check reports a host that cuts the last few kilobytes off a
  range as "coped" rather than "FAILED", with what the client said kept beside
  it. The request does fail, measuring does cope, and a red line next to a
  waveform that works sends people hunting a problem they are already past.
* Testing: a new check reads the columns the code writes and reads out of the
  code, reads the columns the table declares out of the schema, and requires
  that they agree — and that the upgrade routine actually applies the schema.
  Both halves of the bug were confirmed by putting them back.

= 1.31.0 =
* Fixed: 1.30.0 said the editor would offer to measure an old waveform again.
  It could not. The waveforms table had no column to record how a waveform was
  measured, and the code that read a row filled that field in from the current
  constant — so every stored waveform claimed to have been measured whichever
  way was current, nothing was ever out of date, and the offer was unreachable.
  The column exists now, is written, and is read. Rows that predate it report
  the older measure, which is what they are.
* Fixed: and there was nowhere to ask. The notice vanished the moment every
  track had a waveform, so measuring was something the editor did to you when
  it judged a file lacking and never something you could request — which is no
  use at all when the file has a waveform and the waveform looks wrong. There
  is now a "Measure this waveform again" button whenever a track has one, and a
  separate notice for waveforms measured the older way.
* Fixed: the record cache key is built in one place instead of three. Three
  copies of a string that had to match, and nothing making them.
* Testing: the check that was supposed to cover this asked a question about an
  array built inside the test and never stored a waveform or read one back,
  which is why it passed while the feature did not exist. The test harness can
  now store and retrieve, and the test stores, reads back, and asks the editor's
  own endpoint what it would show. Both halves of the bug were confirmed by
  putting them back.

= 1.30.0 =
* Changed: a bar is now the loudness of its stretch of audio, not the loudest
  instant in it. On anything long the old measure saturates: four hundred bars
  across a fifty-three minute lesson is eight seconds of audio per bar, and the
  loudest instant in eight seconds of anybody talking is a syllable at full
  volume — every bar, all the way across. The numbers were right and the
  picture was a comb, close enough to decoration that it was reasonable to ask
  whether anything had been measured at all. Measured against a fixture that
  talks for a twentieth of one minute and the whole of the next, the old
  measure told those apart by 0.02 and this one by a factor of four.
* Changed: the same measure now in all three places a waveform is produced —
  the editor, the visitor's browser and the server's ffmpeg — so the same file
  draws the same picture wherever it was measured. The editor also scales its
  result to fill the height, which the other two always did and it never had.
* Changed: a waveform measured the old way is still drawn, and the editor now
  offers to measure it again, so nothing has to be deleted by hand first.
* Testing: a new test writes audio whose loudness is known second by second,
  measures it in a real browser with the shipped code, and checks every bar
  against what was written underneath it — including that the silent minutes
  read as zero and the blocks come back in the order they were recorded. Both
  changes were verified by putting the old measure back and watching it fail.

= 1.29.0 =
* Fixed: one dropped request threw away a download that was 99% finished. A
  fifty megabyte recording comes down in thirteen pieces, and there was no
  retry anywhere in the chain — so the thirteenth piece failing discarded the
  twelve that had arrived perfectly, and reported it as though the file could
  not be fetched at all. Pieces are now asked for up to three times. A refusal
  is not retried, because a refusal is an answer.
* Fixed: and if a piece never comes, everything but the last scrap of a file is
  still a waveform. Where at least 95% arrived, the waveform is drawn from what
  there is and the timeline is scaled so the track's length stays right. Below
  that it is still reported as a failure, because a confident picture of
  two-thirds of a recording is worse than saying so.
* Fixed: the reason a request failed was being read into a variable and thrown
  away. "This site could not reach the file's own server" covers a name that
  would not resolve, a certificate that would not verify, a timeout, and a
  connection reset at byte forty million — four different problems with four
  different fixes, and the HTTP client names which one every time. It now says
  which, in the client's own words, beside which piece it happened on.
* Fixed: the file check only ever asked for the first kilobyte, so it came back
  entirely green about a file whose measurement was failing on the last piece.
  The first kilobyte is the one request that is always cheap, always cached and
  always allowed. It now asks for the tail as well.
* Testing: the reported failure is reproduced end to end — a piece that fails
  twice and then works, a piece that never comes, and a piece missing from the
  middle, which must still refuse. Each of the three was checked by turning the
  fix back off.

= 1.28.0 =
* Fixed: a failure with a perfectly good explanation on it was reported as
  "the browser could not read it, which is usually a cross-origin refusal".
  That sentence is the last line of the code that turns a failure into words,
  reached when nothing else matched — and three separate failures reached it,
  each one arriving with a status, a step and a reason attached that were all
  thrown away on the way out. It is a convincing wrong answer, too: cross-origin
  refusals are real and common, so it sends people to look at the one place the
  problem is not.
* Fixed: a refused piece of a large file now says which piece and why. Large
  files come through in slices, and only the first slice ever read the reason
  the server gave; the rest reported the bare status, or nothing.
* Fixed: two failures had no words at all — this site being unable to open a
  temporary file to download into (a full disk, or an uploads folder it cannot
  write to), and a refusal whose reason was stripped before it got back. Both
  used to arrive as the cross-origin sentence.
* Changed: measuring a large file through this site now makes one request per
  slice instead of two. The extra request asked the media host what the file
  was before fetching a piece of it, which it can answer from the piece itself.
* Testing: the words are no longer written inside a React component where
  nothing could reach them. They are their own module, and the suite now reads
  every failure tag out of the two files that produce them — the browser-side
  measuring code and the server-side doorway — and asks the module what it would
  say about each one. A new `throw` with no words for it fails the suite. Which
  is the check that was missing all three times.

= 1.27.0 =
* Fixed: a successful ranged fetch was treated as a failure. A server answering
  a `Range` request correctly answers 206, and the check for whether the fetch
  had worked demanded exactly 200 — written before there were ranges and left
  alone when they were added. So from the moment large files started coming
  through in slices, every one of them was refused, and the site owner was told
  their media host had refused them with a 206. Which is a success code.
* Testing: the route is now exercised with a range on it, which is what would
  have caught this — and with the two requests it makes answering differently,
  which is the only way to reach the second of its two checks at all.

= 1.26.0 =
* Fixed: a file behind hotlink protection could not be measured. The site's own
  server fetched it without saying who was asking — no `Referer` at all — so a
  media host that allows the site's domain refused it, while the same file
  played perfectly in the browser, which does send one. The fetch now
  identifies the site it is made for and the plugin making it.
* Fixed: refusals were being thrown away in transit. A web server in front of
  PHP may treat a 5xx from its backend as the backend having failed and replace
  the whole response — reason header and body alike — with its own error page.
  LiteSpeed does. So every message that said exactly what had gone wrong
  arrived as a bare 502. Refusals are sent as 424 now, which no gateway
  rewrites.
* New: the file check runs the same request twice, once anonymously and once
  saying which site is asking, and reports both. That pair is what tells
  hotlink protection apart from every other reason for a refusal — and it
  reports what it identified itself as, so the address can be allow-listed.

= 1.25.0 =
* New: Settings → Imagina Player → Waveforms has a check that asks the server
  what happens when it goes for a file, and reports what it finds: the status
  the file's own host gives this server, whether that host will serve part of a
  file, how long each step took, and what PHP is actually permitted to do —
  including the live value of `disable_functions` and which SAPI is running,
  which is what settles an ffmpeg notice that will not go away. The report is
  plain text, selectable in one go, meant to be sent to whoever is helping.
* Changed: a gateway error no longer claims to know its cause. Every refusal
  this plugin makes says which step gave up, so an error carrying no reason did
  not come from this plugin — something between the browser and WordPress
  answered instead, and which of those it is cannot be told from the browser.
  The message says that and points at the check, rather than naming a setting
  it cannot see.

= 1.24.0 =
* Fixed: measuring a file hosted on another domain failed with a bare 502 once
  the file was big enough. The whole file came through this site in a single
  request — fetched to a temporary file and then read back and served, two full
  transfers inside one PHP request with no time limit raised — so where a host
  allows thirty seconds a large file never finished, PHP was killed, and the
  web server answered with its own 502. That 502 carries none of this plugin's
  reasons, which is why it said so little. A smaller file finished in time,
  which is why it looked arbitrary.
* Changed: the file now comes through in slices. The route serves byte ranges
  and the browser asks for a few megabytes at a time, so no single request can
  outlast an execution limit. It also asks for more time where the host allows
  it, which costs nothing and helps on a slow remote server.
* Changed: a file too large to fetch whole is no longer refused outright — the
  size limit now applies to what was actually asked for, so a very long
  recording can be measured a few megabytes at a time.
* Fixed: slices are only requested from this site. A `Range` header makes a
  cross-origin request non-simple and the browser asks permission first, which
  many media hosts refuse — asking would have broken the files that work in
  order to help the ones that do not.
* Fixed: a bare gateway error now says what it means, rather than repeating the
  status.
* Testing: the browser test now runs against a server that honours byte ranges
  and checks that a file stitched back together from a dozen slices measures
  identically to the same file fetched in one go — the failure mode of
  reassembly is an offset wrong by one, which still decodes and draws something
  else.

= 1.23.0 =
* Fixed: the route that measures a file hosted on another domain had never
  worked. It builds a URL by hand — what it produces has to be something an
  audio decoder can be pointed at — and that URL carries a REST nonce taken
  from `window.wpApiSettings`. The editor script never declared the dependency
  that puts that object on the page, so where nothing else happened to enqueue
  it the nonce was empty and WordPress refused the request. Nothing failed
  loudly; the file simply never got a waveform.
* Fixed: when that route did answer, it answered with a bare status. The file's
  own server refusing this site looked exactly like this site refusing the
  request, and those have completely different answers. It now says which
  happened, and passes on the status the remote server gave — a 403 from a
  bucket or a CDN is the whole answer, and it points at that service's hotlink
  protection rather than at anything here.
* Fixed: a file the browser is not allowed to read was reported as "too large
  to analyse in the browser", which sends somebody to the size settings for a
  permissions problem. The reasons are told apart now, and each has its own
  message.
* Fixed: both block previews built their runtime with an empty REST root, so
  the player inside them asked for `/peaks` against the site root and collected
  a 404 on every editor load — and the fallback that request was meant to be
  could never work.
* Fixed: a preview asks for no download at all, and that came out as "this file
  is too large" in the console for every file, whatever its size.
* Changed: the refusal reason travels in the body as well as a header, for
  sites where something in front of WordPress strips headers it does not
  recognise.
* Testing: the new checks run the route rather than reading it — a remote 403,
  an address that is not media, and an address on this machine — and confirm
  each comes back named.

= 1.22.0 =
* Fixed: long recordings never got a waveform. The editor's measurement handed
  the whole file to the browser's decoder at once, and a decoder expands a file
  at its own sample rate before resampling — so an hour of 44.1 kHz stereo is
  about a gigabyte of samples in flight, whatever rate was asked for. Files are
  now decoded a few megabytes at a time, each piece reduced and thrown away
  before the next is read, so how long a recording is stops mattering. A
  fifty-three minute file measures in a couple of seconds.
* Fixed: a failure said only "some files could not be measured here", which is
  not something anybody can act on. It now says which of the things that can go
  wrong actually did — the server refused the file, the download was cut short,
  the browser could not decode it, or it was a cross-origin refusal.
* Fixed: the download held the file twice at the moment it was largest, by
  collecting it in pieces and then copying them into one buffer.
* Testing: a new test builds a real fifty-three minute file, measures it in a
  real browser, and checks the shape of the result rather than only its size —
  and that no single decode covers more than a couple of minutes, which is the
  property the change is actually about. The same audio measured both ways has
  to give the same picture, so the pieces cannot quietly drift from the whole.

= 1.21.0 =
* Fixed: the action bar was invisible over a video. The overlay slot sat at
  `z-index: 6` while the control bar sat at 8, and the slot is its own stacking
  context — so nothing inside it could climb past the controls. A bar pinned to
  the bottom of the picture, which is the edge the controls occupy, was drawn
  underneath them: the headline came out behind the play button and the action
  button on top of the volume slider.
* Changed: the action bar now sits below the picture rather than on it, which
  is where Presto's and Fluent's do, and cannot collide with the controls at
  all. A call to action and an email gate still cover the picture, and now
  cover the controls with it, which is the point of something that stops
  playback.
* Fixed: nothing could appear before the visitor pressed play. The script only
  listened for `timeupdate`, which fires during playback — so "a bar that is
  simply there", which is what an action bar is in both of those players, could
  not be expressed. A layer set to the start is now up from the moment the page
  loads.
* Changed: adding an action bar sets it to appear at the start. Every new layer
  defaulted to 100%, so a bar added and left alone appeared only once the video
  had finished.
* New: a layer can be given an end as well as a beginning, so an offer can be a
  moment rather than a permanent fixture — Presto's overlays "appear at a
  specific time and disappear at another" and Fluent's say how long they stay,
  and this had no way to express either. Rewinding past it brings it back.
* Fixed: dismissing a call to action never stuck. The "already seen" note was
  filed under the player's DOM id, which is minted fresh on every render, so
  nothing was ever recognised on the next visit and the browser's storage
  filled with keys that could not match anything again.
* Fixed: the call to action's button was not visible as a button. Measured, its
  fill separated from the panel behind it at 1.43:1 with the factory accent —
  the label read perfectly and the shape did not. It has an edge now, and the
  site's accent is untouched.
* Fixed: the end-of-video call to action appeared and vanished in the same
  frame. "Rewind when it ends" is the default, so the player seeks back to zero
  exactly when a layer at 100% becomes due.
* Testing: a new browser test drives a player through a timeline it controls
  and asks what is on screen at each moment, checks that a click on the control
  row reaches the controls, and measures the button. It found a tenth problem
  while being written: the end time was in the schema, sanitised, rendered and
  read by the script, and did nothing, because the payload the page receives is
  rebuilt key by key and nobody had added it there.

= 1.20.0 =
* Fixed: the close button on a call to action was nearly invisible. The
  stylesheet's own defence against themes strips every button's background, and
  this one's had been restated for its hover state and not for the state it
  spends its life in — so on any real site it was a white glyph with nothing
  behind it, over whatever the video happened to be showing.
* Fixed: a theme's `p { margin: 1.5em 0; line-height: 2; font-size: 18px }` —
  one of the most ordinary things a theme says — reached the call to action's
  copy and nearly doubled the panel's height beside audio.
* Fixed: the email gate's field ignored a theme's padding in its width and
  ended up 43 pixels outside the player.
* Fixed: the spam honeypot sat at `left: -9999px`, which inside page content is
  an element ten thousand pixels to the left of the article. It is clipped in
  place now.
* Changed: the block's settings are reorganised. There were ten panels for a
  video, two of them called "Colours", with subtitle sizes filed under "Video"
  and a "Video" panel holding a corner radius, a poster, thirteen dropdowns and
  a second set of colours. There are now eight, each named for the question it
  answers — Media, Appearance, Controls, Playback, Subtitles, Chapters and
  previews, Calls to action, Advanced — with every setting in exactly one of
  them and only the first open.
* Changed: a setting that can inherit is a segmented control rather than a
  dropdown. Thirteen three-way dropdowns in a column cost a click each to read;
  the segments show all three answers at once, say what the site's own setting
  is, and mark the rows this block has changed.
* Changed: which controls a player shows and how it behaves are separate
  questions and were in the same list. Sticking to the corner, remembering the
  position and stopping when the video leaves the screen are in Playback;
  subtitles-on-from-the-start is with the subtitles.
* New: the preset preview can be looked at as a video. A preset's accent paints
  the play button over a picture, its corner radius rounds it, its button
  colour is on the bar — and the preview only ever drew audio.
* New: the Video settings have a live preview of their own, showing the
  settings as they stand on screen rather than as they were last saved.
* Testing: the hostile-theme test walks every element inside the player and
  compares it with and without a theme, which sounded exhaustive and was not —
  no case it rendered had a call to action on it, so the panel, its button, its
  form and its close button were never in the tree being walked. They are now,
  and they are what found all four fixes above.

= 1.19.0 =
* Fixed: rounding a video's corners drew a frame around it. The rounded shell
  is the audio player's card — asking for a radius on a row of controls means
  asking for the card they sit in, so it carries padding and a faint tint. On a
  video that padding became a pale ring and the tint became a border nobody
  asked for. A video already rounds the right thing: the picture itself.
* New: the colours of the playback controls. The buttons and the clock on the
  bar, and the played part of the seek bar with the volume knob beside it —
  site-wide and per block. Both were fixed in the stylesheet: the icons were
  white whatever colour the bar behind them was set to, so a pale control bar
  hid its own buttons; and the played line took the waveform's progress colour,
  an audio setting the video block does not show, so the one moving coloured
  thing on the picture could not be reached at all.
* New: left on Automatic, the buttons are worked out from the control bar the
  same way the accent's foreground is, so an existing site gets readable
  controls without touching anything.
* New: the audio player's small buttons — mute, skip, speed, download, and the
  volume rail — have a colour, on the preset and on the block. That was a fixed
  slate grey, which all but disappears on a dark page.
* Fixed: the play button in the control row printed a white icon on the accent
  without checking. The big play button over a video already worked that out;
  this one assumed.
* Fixed: the time chips kept a black pill on a pale control bar, so a correctly
  darkened clock was printed on black anyway.
* Testing: two browser tests. One measures the rendered boxes — is the picture
  flush with the shell, is anything painted behind it, is the curve there — and
  checks the audio card keeps the padding and tint the rule exists for. The
  other measures real contrast on the control bar for a dark bar, a pale bar and
  a hand-picked one, compositing each translucent colour over what is behind it
  first: the rail is thirty per cent of a colour, and reading it without its
  backdrop reported 1.29:1 for a pair that is plainly legible.

= 1.18.0 =
* New: the plugin speaks Spanish. 471 strings extracted into
  `languages/imagina-player.pot`, a complete `es_ES` translation, and the
  compiled `.mo` and per-bundle `.json` files, all shipped in the archive.
* Fixed: the plugin never called `load_plugin_textdomain`. WordPress opens a
  plugin's own `.mo` files only when it is told where they are, so a complete
  translation would have shipped and never been read — and nothing errors when
  that happens, `__()` simply hands back the English.
* Fixed: the release archive had no `languages/` folder at all, so even a
  correctly loaded text domain would have found nothing on an installed site.
* Fixed: every bundle was handed the whole catalogue, and the front-end bundle
  — which has no `__()` call in it, since its handful of strings come from PHP
  — was told to fetch one on every page view. Each catalogue now carries only
  the strings its own sources use, and the front end has no file to fetch.
* Fixed: the caption search's three strings were missing from the payload PHP
  sends the player, so that box would have stayed in English on a Spanish site.
* New: the corner radius can be set per block, not only on the preset.
* New: caption search — a box that finds the moment a word is said and jumps to
  it, reading the subtitles the video already carries. Accents and case fold,
  so *pagina* finds *página*, while `ñ` is left alone.
* Testing: `tests/test-translations.php` checks the template against the source,
  the translation against the template, the placeholders inside every translated
  string, the compiled catalogue byte for byte, which strings each bundle
  downloads, and then renders a real player with the catalogue loaded and reads
  the Spanish back out of the markup. The harness's translation stubs used to
  return their input unchanged, which meant no test could tell a loaded
  catalogue from an unloaded one; they now consult one when a test sets it.

= 1.17.0 =
* Fixed: chapters were never delivered on a real site. Their track is a `data:`
  URI, and WordPress's `esc_url()` only allows the protocols in
  `wp_allowed_protocols()` — which does not include `data` — so the attribute
  came out empty. No test noticed because the harness's own `esc_url()` was
  `htmlspecialchars` alone, which also let `javascript:` through. Both are
  fixed, and the honest one found the chapter bug within a minute.
* New: the control bar's colour and the subtitles' colour, size and backing,
  per block and site-wide. All four were hard-coded, so a player could carry a
  site's colours everywhere except the two places somebody looks at while a
  video is playing.
* New: every video control has its own answer — the play button over the
  picture, the title, the times, skip, volume, speed, subtitles, chapters,
  picture-in-picture, fullscreen. Half of these lived on the audio preset,
  which is why a video block showed a mixture of two lists and neither was
  complete. For a video the video settings are now the authority.
* New: stop when nobody is watching. Pauses when the tab goes to the background
  or the picture scrolls off the screen. It does not start again by itself.
* New: subtitles on from the first frame, for an audience that mostly watches
  with the sound off. A viewer who turns them off is remembered and this does
  not override that.
* New: a mark over the picture, with a corner and an opacity. It is not
  protection and is not offered as any — a screen recording keeps it and a crop
  removes it — but it makes a copy traceable.
* Fixed: an address that cannot be a mark now leaves no element at all, rather
  than an empty `<img>` every browser reports as broken.

= 1.16.0 =
* Fixed: the seek bar on a video could not be dragged. It was drawn correctly —
  the line paints at the right place and looks like a seek bar — but the element
  a pointer has to land on was zero pixels tall, because everything inside the
  scrubber is positioned absolutely and the video rule set the box to auto
  height. The video could not be scrubbed at all, and it looked like it should
  be. There is now a real hit area, a line that thickens under the pointer, and
  a test that presses every control of every skin at the point where it appears.
* New: video skins of their own — Theater (controls over the picture, fading
  out while it plays), Minimal (a line and little else), and Stacked (a solid
  bar under the picture that never covers it). Until now a video block was
  offered the seven audio skins, every one of which arranges a waveform and a
  row of transport buttons, so choosing one either did nothing or did something
  meaningless.
* Changed: a block offers only the skins that apply to what it is playing, and
  a skin saved for the other medium falls back instead of rendering wrongly —
  which is what happened when an audio file was replaced with a video.
* New: `docs/VIDEO-ROADMAP.md`, which lists what the video player still lacks
  next to Presto Player and Fluent Player, read from their source, and the
  order it is being done in.

= 1.15.0 =
* New: a video that follows the reader. Scroll away from one that is playing
  and it detaches into a small card in a corner, keeping its shape, with the
  controls on it and a button to send it away — which stays away. The switch
  for this existed before but did the audio version of it: a full-width bar
  across the foot of the window, which for a video is a whole picture lying
  across the bottom of the screen.
* Fixed: a player already off screen when playback started was never
  reconsidered, because an observer reports changes and nothing had changed.
  An autoplaying video below the fold, or a playlist carrying on to the next
  track, would play to nobody.
* New: stills on the seek bar. Point at the bar and the moment under the
  pointer appears above it. Give the block a WebVTT storyboard — what most
  video tools export — and nothing is downloaded until somebody actually drags
  the bar, so a reader who never scrubs pays nothing for it.
* New: the compressed size of the bundle and the stylesheet are now checked on
  every test run, alongside the source sizes. Those are the numbers a visitor
  pays and the ones the description claims.

= 1.14.0 =
* Fixed: autoplay, start muted and loop did nothing on a YouTube or Vimeo
  video. The renderer prints them as attributes on an `<audio>` or `<video>`
  element, and a provider video has neither — so all three were switches in the
  block wired to nothing at all. They are now passed to the provider when the
  frame is built, which is the only moment they can be set. Looping a single
  YouTube video also needs it handed a playlist of that one video, without
  which `loop` is quietly ignored.
* New: the Video panel in the block now has real settings — the play button
  over the picture, the fullscreen and picture-in-picture buttons, the speed
  control, how the poster fills its box, how long before the controls fade, and
  whether the browser download is blocked. These existed, but only site-wide:
  per-block overrides run off the preset, and the video settings are not in a
  preset, so there was no path from a block to them. Two videos in one post
  could not behave differently from each other.
* Changed: each of those is three-way — "use site setting", show, hide — rather
  than a switch, so a block left alone keeps following the site rather than
  freezing today's setting into itself.
* Changed: audio controls no longer appear on a video block. "Show thumbnail"
  did nothing, because a video's still is the poster and has its own field; the
  waveform and played-portion colours had nothing to draw; and "stick to the
  bottom while playing" did something worse than nothing — it pinned the whole
  picture across the foot of the window, which is an audio mini-player.
* New: turning on autoplay without muting now says so in the block. No browser
  starts a video with sound by itself, and a help line under a switch is not
  the same as being told this block is in exactly that state.
* Changed: preload is no longer offered for a provider video, where nothing is
  fetched until somebody presses play.

= 1.13.2 =
* Changed: the editor no longer prints anything into the block itself except a
  fault. The line saying a video came from YouTube sat inside the block, above
  the preview, where everything reads as the post about to be published — so it
  looked like content the visitor would see, and it was telling the author
  something they already knew. It now lives in the sidebar with the block's
  other settings. An address the player cannot play still says so in the block,
  because that will publish broken and the author has to see it.

= 1.13.1 =
* Fixed: on a site whose theme styles its own buttons — which is most of them —
  the play button over a video was painted in the theme's colour. It covers the
  whole picture on purpose so it can be clicked anywhere, and during playback
  only its circle and icon fade out, so what was left was a flat sheet of the
  theme's colour over the video. Round buttons became rounded squares, icons
  took the theme's text colour, and the download control took its link colour.
* New: the player now defends the properties a theme has any business setting
  on a button, an input, an anchor or a frame of its own. The site's typeface
  still flows in, as it should; nothing else does.
* New: the whole player is rendered twice on every test run — once inside a
  stylesheet built out of what themes really ship, once without it — and every
  element of the two is compared. Until now every browser test rendered into an
  empty page, which is why none of this was caught.
* Fixed: the block preview loaded the front-end stylesheet with no version, so
  after an update the browser went on serving whatever it had cached. On a site
  updated from an older release the editor drew a video with a stylesheet that
  predated video: the picture had no shape, the poster sat at its own size and
  the controls fell out underneath it.
* Changed: the "this is a YouTube video" notice in the editor is one quiet line
  instead of a banner three lines deep above every block.

= 1.13.0 =
* New: YouTube and Vimeo. Pasting a YouTube address into the Video block used to
  produce an audio player that showed nothing, played nothing and had no
  thumbnail — WordPress reports no file type for a web page, so the track was
  not a video and the renderer built a row of audio controls around an `<audio>`
  element pointed at youtube.com. Provider videos are now recognised, laid out
  as video, and driven through the provider's own API so the picture carries
  this player's controls rather than theirs.
* New: calls to action, chapters, the keyboard and the scrub bar all work on a
  provider video, because the player asks the provider where playback is instead
  of assuming there is an element to read it off.
* New: nothing is requested from YouTube or Vimeo until somebody presses play.
  The page holds their still image until then, so a video nobody watches costs a
  visitor no third-party request and no cookie. YouTube is loaded from its
  no-cookie domain by default, which is a new setting under Video.
* New: the block says what it made of the address you gave it, before you save —
  including when it cannot play it at all, which used to be silent.
* Fixed: pasting a video address into the *audio* block made it look for a
  waveform inside a web page.
* Changed: subtitles are no longer offered for a provider video. They are drawn
  inside the provider's frame and a file added here would never have appeared.

= 1.12.0 =
* Fixed: a call to action beside an audio player rendered as a full-width sheet
  of brand colour lying across the waveform and the title, with a button in
  almost exactly the colour of the sheet behind it. The layers were inside a
  wrapper positioned to cover the picture, which audio does not have.
* Changed: beside audio a call to action is now a strip attached under the
  controls — the offer on the left, the button on the right, on a dark surface
  with a hairline of the accent down its edge. Over a video it stays a sheet
  over the picture, with the copy held to a readable column.
* Fixed: button labels were always white. On a bright accent — this plugin's
  own cyan included — white on it reads at 2.2:1, which is unreadable. The
  foreground is now worked out from the accent's luminance.
* New: the layer layout is measured in a real browser on every test run: that
  it sits beside the player rather than on it, stays inside its width, is a
  strip rather than a slab, and that the button can be told apart from what is
  behind it.
* Fixed: two contrast checks in the test suite read colours with a regular
  expression, which reads `color(srgb 0 0.7 0.78)` as near-black and so passed
  anything painted with `color-mix()`. They now resolve colours properly.

= 1.11.0 =
* New: a Track details section. Where a title and an artist come from when you
  leave the block's fields empty — the file's own tags, the name it has in your
  library, or the file name itself. Some of this already happened; none of it
  could be changed or seen.
* New: the file name is used as a last resort. "2024-03-11_mi-conferencia.mp3"
  becomes "Mi conferencia" — the leading date is filing, not a title. It is the
  only thing a track pasted from a streaming provider has, since there are no
  tags to read.
* New: cover art embedded in an audio file is used as the thumbnail.
* Changed: the block's Title and Artist fields now show what the file would
  give them, in grey, instead of sitting empty next to a player that has a
  title. An empty box gave no reason to believe anything would fill it.

= 1.10.0 =
* New: tracks hosted somewhere else can have a waveform. Until now they could
  not, by any route: ffmpeg reads local files, the generate and store endpoints
  were keyed on a media library item, and the editor's notice ignored anything
  that was not one — so a track pasted from a streaming provider got a plain
  bar and no explanation.
* New: when a host does not allow this site to read its files — which is most
  of them — the measuring goes through this site instead. That doorway needs
  the right to add media, refuses anything but http and https, refuses private
  and internal addresses, caps the size, and only ever answers with media.

= 1.9.2 =
* Fixed: after generating a waveform in the editor, the preview kept showing
  the old plain bar — so the button looked as though it had done nothing. The
  waveform is stored against the file rather than the block, so nothing in the
  block changed to make the preview go and look again. It does now.
* New: the playlist block checks all of its tracks and offers to measure the
  ones that need it, in one go. That is the case that most needed it: several
  files arrive at once, and nobody wants to press a button somewhere else once
  per file.
* Changed: the notice asks the server directly rather than waiting for a
  preview, so it appears as soon as a file is chosen.

= 1.9.1 =
* Fixed: the block editor drew a waveform for tracks that did not have one. It
  was synthetic — a stand-in so the preview would not look like a flat bar —
  and the effect was that the editor told you your waveform worked while your
  site showed a plain bar. The preview now shows what the site will show, and
  says when a waveform is missing.
* Fixed: on a host without ffmpeg, a recording longer than the visitor size
  limit could never get a waveform at all, and nothing said why. You can now
  measure it in your own browser — from the block, or in bulk under Waveforms —
  which downloads the file once, there, and stores the result for every
  visitor. Nobody browsing your site downloads anything extra.

= 1.9.0 =
* New: a video block. The player has handled video since 1.6.0, but the only
  block was called "Imagina Audio Player" and said "upload an audio file", so
  anyone looking for video in the inserter found nothing — and reasonably
  concluded there was nothing to find. There is now an **Imagina Video Player**
  block, with its own icon and its own words.
* New: a Video section in the settings. Shape, poster behaviour, how long the
  controls stay up, which buttons appear, how subtitles look, and whether the
  browser's download button is taken away. All of it was hardcoded before.
* Fixed: the video panels in the block appeared only when the file name looked
  like a video. The video block is video whatever the file is called.
* Fixed: a block that sets no shape now follows the site setting rather than
  assuming widescreen.

= 1.8.0 =
* New: calls to action. Three kinds — a panel that stops playback, a bar that
  does not, and an email gate. They work on audio as well as video: a gate two
  thirds of the way through a podcast is the same feature.
* New: captured addresses are kept, listed under Emails, and downloadable as a
  CSV. Cells that a spreadsheet would run as a formula are neutralised on the
  way out.
* New: playlists, as a list or a grid of covers. Every track is a link to its
  own file, so clicking one plays it even before any script has run; the
  runtime catches the click and hands it to the player already on the page, so
  the volume and speed the listener chose survive.
* Each of these is downloaded only by pages that use it. A page with a plain
  player is unchanged, to the byte.

= 1.7.0 =
* New: subtitles. WebVTT and SubRip, several languages, a menu to switch
  between them, and the choice remembered across videos. SubRip files are
  converted for the browser automatically — browsers read WebVTT and nothing
  else, and telling people to go and find a converter is not a feature.
* New: chapters. Marks on the progress bar and a menu to jump between sections.
  Times can be written as 90, 1:30 or 0:01:30.
* New: HLS adaptive streaming, with a quality menu built from the stream
  itself. The streaming library is downloaded only for pages that have a
  stream, and only where the browser cannot play one on its own — Safari and
  iOS play it natively and pay nothing.
* New: on a protected stream, every segment is signed, not just the playlist.
  Signing only the playlist protects nothing: the segment addresses are listed
  inside it in plain text.
* Fixed: a stream (.m3u8) was rendered as an audio player, because WordPress
  reports no file type for a playlist.

= 1.6.0 =
* New: video. A player built around the picture rather than beside it —
  poster, play button in the middle, controls over the video that fade while
  it plays, full screen, picture-in-picture, keyboard shortcuts and touch
  gestures.
* New: the video chrome is downloaded only by pages that have a video on them.
  A page with nothing but audio players is unchanged, to the byte.
* New: video files are served with the browser's own download button and
  remote playback turned off, and the right-click menu taken away. This makes
  the file harder to take, not impossible — nothing short of DRM does that,
  and the protection that matters is still the vault and the expiring link.
* Fixed: the bundle would refuse to start if an optimisation plugin inlined it
  into the page.

= 1.5.1 =
* Fixed: the JavaScript linter could not run at all — a TypeScript version its
  plugins predate had been pulled in — so nothing had ever been linted. It runs
  clean now, and `npm test` runs the linters, the type checker and the test
  suite together so it cannot rot again unnoticed.
* Fixed: each toggle on the settings screen now names the control it belongs to
  outright, instead of relying on being wrapped around it.

= 1.5.0 =
* New: a protection self-check. It writes a decoy file into the protected
  folder, fetches it over real HTTP with no login, and reports what the server
  actually answered — which is the only way to catch the common failure where
  nginx never reads the .htaccess the plugin writes and every "protected" file
  sits in the open.
* New: the logo is chosen from the media library. It still accepts a pasted
  URL, since a logo often lives outside the library.
* Fixed: "ffmpeg was not found" was shown for three different problems with
  three different fixes — a host that forbids starting processes, a path typed
  in wrong, and nothing installed. Each now says which one it is.
* Fixed: saving a new ffmpeg path and re-reading its status happen in one
  request, and the status came from before the save.

= 1.4.0 =
* Fixed: the player overflowed its container on phones. Every skin was measured
  at 320, 360, 414 and 768 pixels with all controls on; the title now shrinks
  instead of pushing, and the controls take a line of their own on narrow
  screens.
* Changed: factory colours are neutral. A fresh install no longer arrives
  wearing the colours of somebody else's player; set yours once under Branding.
* Changed: the settings screen has its own identity, separate from whatever
  colour a client gives their player.

= 1.3.1 =
* Fixed: the block preview grew scrollbars and swallowed clicks and drags in the
  editor. The preview frame no longer scrolls, and it is inert — every click and
  drag belongs to the editor, as it should for something you only look at.

= 1.3.0 =
* Fixed: the block preview drew a hand-made copy of the player that had fallen
  behind the real one — the card, compact and pill skins all appeared as the
  plain stacked layout. It now renders the actual player, the same way the
  settings screen does.

= 1.2.4 =
* Fixed: the block's colour settings still sat behind an overflow menu and could
  not be collapsed. They are now an ordinary collapsible panel with a swatch, a
  hex field and a reset for each colour.

= 1.2.3 =
* Fixed: the block's appearance settings sat behind a "+" menu that hid them
  until you knew to look, and the waveform height is now a slider with a reset.

= 1.2.2 =
* Fixed: the preset background was a bare text field with no colour picker,
  because it also accepts "transparent". It is now an explicit choice between
  transparent and a colour, with the picker alongside.

= 1.2.1 =
* Fixed: the settings screen followed the browser's dark-mode preference, which
  turned that one screen dark while the rest of wp-admin stayed light and kept
  painting dark headings onto it. It now uses a single light palette, like the
  admin around it.

= 1.2.0 =
* Fixed: the settings screen's live preview showed "no audio file selected"
  instead of a player, and its headings inherited their colour from wp-admin
  instead of declaring it.
* New: Branding — site-wide default colours that a new preset starts from, plus
  an optional logo on every player.
* New: custom CSS, loaded after the player stylesheet on pages with a player.
* New per preset: a description, a corner radius, what happens when a track
  finishes (rewind, repeat or stop), and where a sticky player docks.

= 1.1.0 =
* New: a purpose-built settings screen replacing the WordPress options form —
  preset list, a Controls / Behaviour / Style editor, and a live preview that
  renders through the real player rather than an imitation of it.
* New: four more skins — mirrored waveform, card with cover, compact one-line,
  and pill — bringing the total to seven.
* New: the block picks a cover image and a download file from the media
  library instead of asking for a URL.
* New: "Generate missing waveforms" moved into the new screen, alongside the
  ffmpeg status and the browser size limit.

= 1.0.1 =
* Fixed: a file too long to analyse in the browser left the "analysing"
  highlight sweeping across the player for ever. The browser now checks the
  file size before committing, gives up after 30 seconds, and the highlight
  stops regardless.
* Fixed: a player with no waveform drew a row of stubby bars that read as a
  broken player. It now falls back to a plain seek bar.
* Added: "Generate missing waveforms" in Settings → Imagina Player, so long
  recordings get their waveform on the server without waiting for WP-Cron.
* Added: a size limit for browser-side analysis, 25 MB by default.
* Fixed: the volume slider is now styled explicitly, so themes that restyle
  range inputs cannot turn it into an unrecognisable box.

= 1.0.0 =
* First release.
* Waveform audio player: server-rendered around a native audio element, canvas
  waveform, keyboard-accessible seek bar, sticky player, remembered position.
* Gutenberg block and `[imagina_player]` shortcode sharing one attribute schema.
* Reusable presets, editable from Settings → Imagina Player.
* Waveform peaks generated by ffmpeg out of the request path, or by the first
  visitor's browser, and cached as one byte per bar.
* Protected media: signed expiring links with HTTP range support, optional login,
  user and network binding, X-Accel-Redirect / X-Sendfile delivery, and an
  `imagina_player_can_stream` filter for membership and course plugins.
