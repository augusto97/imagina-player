<?php
/**
 * The video player as an Elementor widget.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Integrations\Elementor;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use ImaginaPlayer\Player\Attributes;
use ImaginaPlayer\Render\PlayerRenderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class VideoWidget extends PlayerWidget {

	/** The three-way choices the video player offers, attribute => label. */
	public const SWITCHES = array(
		'videoBigPlay'       => 'Play button over the picture',
		'videoTitle'         => 'Title',
		'videoTime'          => 'Time',
		'videoVolume'        => 'Volume',
		'videoSkip'          => 'Skip back and forward',
		'videoSpeed'         => 'Speed',
		'videoCaptions'      => 'Subtitles',
		'videoChapters'      => 'Chapters',
		'videoSearch'        => 'Search what is said',
		'videoTranscript'    => 'Transcript under the picture',
		'videoPip'           => 'Picture in picture',
		'videoFullscreen'    => 'Full screen',
		'videoBlockDownload' => 'Block the browser download',
		'videoFocusMode'     => 'Focus mode',
		'videoCaptionsOn'    => 'Subtitles on from the start',
		'videoProviderBare'  => 'Hide YouTube’s and Vimeo’s own interface',
		'sticky'             => 'Keep playing in a corner while scrolling',
		'rememberPosition'   => 'Remember where the viewer left off',
	);

	public const RATIOS = array( '16:9', '4:3', '1:1', '9:16', '21:9' );

	public function get_name(): string {
		return 'imagina-video-player';
	}

	public function get_title(): string {
		return __( 'Imagina Video Player', 'imagina-player' );
	}

	public function get_icon(): string {
		return 'eicon-video-camera';
	}

	public function get_keywords(): array {
		return array( 'video', 'player', 'youtube', 'vimeo', 'hls', 'imagina' );
	}

	protected function register_controls(): void {
		$this->start_controls_section(
			'media_section',
			array( 'label' => __( 'Video', 'imagina-player' ) )
		);

		$this->source_controls( 'video', array( 'video' ) );

		$this->add_control(
			'poster',
			array(
				'label'       => __( 'Poster', 'imagina-player' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => array( 'image' ),
				'description' => __( 'Shown before play. Leave empty to use YouTube’s or Vimeo’s own picture.', 'imagina-player' ),
			)
		);

		$ratios = array( '' => __( 'Use site setting', 'imagina-player' ) );

		foreach ( self::RATIOS as $ratio ) {
			$ratios[ $ratio ] = $ratio;
		}

		$this->add_control(
			'aspect_ratio',
			array(
				'label'   => __( 'Aspect ratio', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $ratios,
			)
		);

		$this->add_control( 'autoplay', array( 'label' => __( 'Autoplay', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER, 'description' => __( 'Browsers allow it only when muted.', 'imagina-player' ) ) );
		$this->add_control( 'muted', array( 'label' => __( 'Start muted', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER ) );
		$this->add_control( 'loop', array( 'label' => __( 'Loop', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER ) );
		$this->add_control( 'start_time', array( 'label' => __( 'Start at (seconds)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'default' => '' ) );

		$this->end_controls_section();

		$this->appearance_controls( 'video' );

		$switches = array();

		foreach ( self::SWITCHES as $attribute => $label ) {
			$switches[ $attribute ] = self::label( $attribute, $label );
		}

		$this->tristate_controls( 'controls_section', __( 'Controls', 'imagina-player' ), $switches );

		$this->start_controls_section(
			'behaviour_section',
			array( 'label' => __( 'Behaviour', 'imagina-player' ) )
		);
		/*
		 * In seconds, as on the settings screen and in the block. The old
		 * control took milliseconds; it stays, hidden, so a page saved with
		 * it keeps its answer until somebody sets this one.
		 */
		$this->add_control( 'hide_after_seconds', array( 'label' => __( 'Hide the controls after (seconds)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 20, 'step' => 0.5, 'default' => '', 'description' => __( 'Empty uses the site setting; zero keeps them up.', 'imagina-player' ) ) );
		$this->add_control( 'hide_after', array( 'type' => Controls_Manager::HIDDEN, 'default' => '' ) );
		$this->add_control( 'skip_seconds', array( 'label' => __( 'Skip by (seconds)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 120, 'default' => '' ) );
		$this->add_control(
			'poster_fit',
			array(
				'label'   => __( 'Poster', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''        => __( 'Use site setting', 'imagina-player' ),
					'cover'   => __( 'Crop to fill', 'imagina-player' ),
					'contain' => __( 'Show all of it', 'imagina-player' ),
				),
			)
		);
		$this->add_control(
			'caption_size',
			array(
				'label'   => __( 'Subtitle size', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => __( 'Use site setting', 'imagina-player' ),
					'small'  => __( 'Small', 'imagina-player' ),
					'medium' => __( 'Medium', 'imagina-player' ),
					'large'  => __( 'Large', 'imagina-player' ),
					'xlarge' => __( 'Extra large', 'imagina-player' ),
				),
			)
		);
		$this->end_controls_section();

		/*
		 * A mark in a corner of the picture. The block and the shortcode had
		 * it; the widget did not.
		 */
		$this->start_controls_section(
			'watermark_section',
			array( 'label' => __( 'Watermark', 'imagina-player' ) )
		);
		$this->add_control(
			'watermark',
			array(
				'label'       => __( 'Image', 'imagina-player' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => array( 'image' ),
				'description' => __( 'A logo in a corner of the picture. It makes a copy traceable; it does not stop one being made.', 'imagina-player' ),
			)
		);
		$this->add_control(
			'watermark_position',
			array(
				'label'   => __( 'Corner', 'imagina-player' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'top-right',
				'options' => array(
					'top-left'     => __( 'Top left', 'imagina-player' ),
					'top-right'    => __( 'Top right', 'imagina-player' ),
					'bottom-left'  => __( 'Bottom left', 'imagina-player' ),
					'bottom-right' => __( 'Bottom right', 'imagina-player' ),
				),
			)
		);
		$this->add_control( 'watermark_opacity', array( 'label' => __( 'Opacity (%)', 'imagina-player' ), 'type' => Controls_Manager::NUMBER, 'min' => 5, 'max' => 100, 'step' => 5, 'default' => 55 ) );
		$this->add_control(
			'viewer_mark',
			array(
				'label'       => __( 'Viewer’s name over the picture', 'imagina-player' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''      => __( 'Use site setting', 'imagina-player' ),
					'off'   => __( 'Off', 'imagina-player' ),
					'name'  => __( 'Their name', 'imagina-player' ),
					'email' => __( 'Their email', 'imagina-player' ),
					'both'  => __( 'Their name and email', 'imagina-player' ),
				),
				'description' => __( 'Shown only to somebody signed in, and only their own, moving over the picture so a screen recording carries their name.', 'imagina-player' ),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'subtitles_section',
			array( 'label' => __( 'Subtitles', 'imagina-player' ) )
		);

		$tracks = new Repeater();
		$tracks->add_control( 'label', array( 'label' => __( 'Language name', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'Español' ) );
		$tracks->add_control( 'srclang', array( 'label' => __( 'Language code', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'es' ) );
		$tracks->add_control( 'src', array( 'label' => __( 'Subtitle file (.vtt or .srt)', 'imagina-player' ), 'type' => Controls_Manager::URL, 'options' => false, 'description' => __( 'Upload it to the media library and paste its address.', 'imagina-player' ) ) );
		$tracks->add_control( 'default', array( 'label' => __( 'On by default', 'imagina-player' ), 'type' => Controls_Manager::SWITCHER ) );

		$this->add_control(
			'tracks',
			array(
				'label'       => __( 'Subtitle tracks', 'imagina-player' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $tracks->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ label || srclang }}}',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'chapters_section',
			array( 'label' => __( 'Chapters', 'imagina-player' ) )
		);

		$chapters = new Repeater();
		$chapters->add_control( 'start', array( 'label' => __( 'Starts at', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => '1:30', 'description' => __( 'Minutes and seconds, or seconds.', 'imagina-player' ) ) );
		$chapters->add_control( 'title', array( 'label' => __( 'Title', 'imagina-player' ), 'type' => Controls_Manager::TEXT ) );

		$this->add_control(
			'chapters',
			array(
				'label'       => __( 'Chapters', 'imagina-player' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $chapters->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ start }}} {{{ title }}}',
			)
		);

		$this->end_controls_section();

		/*
		 * The same video in other sizes, and other soundtracks for it. A file
		 * from the library or an address, for each.
		 */
		$this->start_controls_section(
			'sources_section',
			array( 'label' => __( 'Qualities and languages', 'imagina-player' ) )
		);

		$this->add_control( 'quality_label', array( 'label' => __( 'Name of the main file', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'Original', 'imagina-player' ), 'description' => __( 'As it appears in the menu, such as 1080p.', 'imagina-player' ) ) );

		$sources = new Repeater();
		$sources->add_control( 'label', array( 'label' => __( 'Name in the menu', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => '720p' ) );
		$sources->add_control( 'file', array( 'label' => __( 'File', 'imagina-player' ), 'type' => Controls_Manager::MEDIA, 'media_types' => array( 'video' ) ) );
		$sources->add_control( 'url', array( 'label' => __( 'Or its address', 'imagina-player' ), 'type' => Controls_Manager::URL, 'options' => false ) );

		$this->add_control(
			'sources',
			array(
				'label'       => __( 'Other qualities', 'imagina-player' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $sources->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ label }}}',
			)
		);

		$this->add_control( 'audio_label', array( 'label' => __( 'Name of the video’s own sound', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'Original', 'imagina-player' ), 'separator' => 'before' ) );

		$dubs = new Repeater();
		$dubs->add_control( 'label', array( 'label' => __( 'Name in the menu', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'English', 'imagina-player' ) ) );
		$dubs->add_control( 'srclang', array( 'label' => __( 'Language code', 'imagina-player' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'en' ) );
		$dubs->add_control( 'file', array( 'label' => __( 'Audio file', 'imagina-player' ), 'type' => Controls_Manager::MEDIA, 'media_types' => array( 'audio' ) ) );
		$dubs->add_control( 'url', array( 'label' => __( 'Or its address', 'imagina-player' ), 'type' => Controls_Manager::URL, 'options' => false ) );

		$this->add_control(
			'audio_tracks',
			array(
				'label'       => __( 'Soundtracks', 'imagina-player' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $dubs->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ label || srclang }}}',
				'description' => __( 'An audio file as long as the video, played in step with the picture in place of its own sound.', 'imagina-player' ),
			)
		);

		$this->end_controls_section();

		$this->layer_controls();
		$this->access_controls();
	}

	private static function label( string $attribute, string $fallback ): string {
		switch ( $attribute ) {
			case 'videoBigPlay':
				return __( 'Play button over the picture', 'imagina-player' );
			case 'videoTitle':
				return __( 'Title', 'imagina-player' );
			case 'videoTime':
				return __( 'Time', 'imagina-player' );
			case 'videoVolume':
				return __( 'Volume', 'imagina-player' );
			case 'videoSkip':
				return __( 'Skip back and forward', 'imagina-player' );
			case 'videoSpeed':
				return __( 'Speed', 'imagina-player' );
			case 'videoCaptions':
				return __( 'Subtitles', 'imagina-player' );
			case 'videoChapters':
				return __( 'Chapters', 'imagina-player' );
			case 'videoSearch':
				return __( 'Search what is said', 'imagina-player' );
			case 'videoTranscript':
				return __( 'Transcript under the picture', 'imagina-player' );
			case 'videoPip':
				return __( 'Picture in picture', 'imagina-player' );
			case 'videoFullscreen':
				return __( 'Full screen', 'imagina-player' );
			case 'videoBlockDownload':
				return __( 'Block the browser download', 'imagina-player' );
			case 'sticky':
				return __( 'Keep playing in a corner while scrolling', 'imagina-player' );
			case 'rememberPosition':
				return __( 'Remember where the viewer left off', 'imagina-player' );
			case 'videoFocusMode':
				return __( 'Focus mode', 'imagina-player' );
			case 'videoCaptionsOn':
				return __( 'Subtitles on from the start', 'imagina-player' );
			case 'videoProviderBare':
				return __( 'Hide YouTube’s and Vimeo’s own interface', 'imagina-player' );
		}

		return $fallback;
	}

	public function attributes_from( array $settings ): array {
		$poster    = self::image_from( $settings['poster'] ?? null );
		$watermark = self::image_from( $settings['watermark'] ?? null );

		// Seconds when set, the old milliseconds otherwise.
		$seconds    = $settings['hide_after_seconds'] ?? '';
		$hide_after = '' === $seconds || null === $seconds
			? self::number_from( $settings['hide_after'] ?? '' )
			: (string) max( 0, (int) round( (float) $seconds * 1000 ) );

		return self::source_from( $settings ) + self::tristates_from( $settings, array_keys( self::SWITCHES ) ) + array(
			'title'            => (string) ( $settings['title'] ?? '' ),
			'poster'           => $poster['url'],
			'posterId'         => $poster['id'],
			'aspectRatio'      => (string) ( $settings['aspect_ratio'] ?? '' ),
			'autoplay'         => self::switch_from( $settings, 'autoplay' ),
			'muted'            => self::switch_from( $settings, 'muted' ),
			'loop'             => self::switch_from( $settings, 'loop' ),
			'startTime'        => (float) ( $settings['start_time'] ?? 0 ),
			'preset'           => (string) ( $settings['preset'] ?? 'default' ),
			'skin'             => (string) ( $settings['skin'] ?? '' ),
			'accent'           => (string) ( $settings['accent'] ?? '' ),
			'borderRadius'     => self::number_from( $settings['border_radius'] ?? '', 'px' ),
			'videoHideAfter'   => $hide_after,
			'skipSeconds'      => self::number_from( $settings['skip_seconds'] ?? '' ),
			'videoPosterFit'   => (string) ( $settings['poster_fit'] ?? '' ),
			'videoCaptionSize' => (string) ( $settings['caption_size'] ?? '' ),
			'tracks'           => self::tracks_from( $settings['tracks'] ?? array() ),
			'chapters'         => self::chapters_from( $settings['chapters'] ?? array() ),
			'sources'          => self::choices_from( $settings['sources'] ?? array() ),
			'qualityLabel'     => (string) ( $settings['quality_label'] ?? '' ),
			'audioTracks'      => self::choices_from( $settings['audio_tracks'] ?? array() ),
			'audioLabel'       => (string) ( $settings['audio_label'] ?? '' ),
			'layers'           => self::layers_from( $settings['layers'] ?? array() ),
			'watermark'         => $watermark['url'],
			'watermarkId'       => $watermark['id'],
			'watermarkPosition' => (string) ( $settings['watermark_position'] ?? 'top-right' ),
			'watermarkOpacity'  => max( 5, min( 100, (int) ( $settings['watermark_opacity'] ?? 55 ) ) ),
			'videoViewerMark'   => (string) ( $settings['viewer_mark'] ?? '' ),
		) + self::access_from( $settings );
	}

	/**
	 * @param mixed $rows
	 * @return array<int, array<string, mixed>>
	 */
	private static function tracks_from( $rows ): array {
		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$out[] = array(
				'src'     => self::url_from( $row['src'] ?? '' ),
				'srclang' => (string) ( $row['srclang'] ?? '' ),
				'label'   => (string) ( $row['label'] ?? '' ),
				'kind'    => 'subtitles',
				'default' => 'yes' === ( $row['default'] ?? '' ),
			);
		}

		return $out;
	}

	/**
	 * Qualities or soundtracks: the library's file when one was chosen, the
	 * typed address otherwise.
	 *
	 * @param mixed $rows
	 * @return array<int, array<string, mixed>>
	 */
	private static function choices_from( $rows ): array {
		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$file = self::image_from( $row['file'] ?? null );

			$out[] = array(
				'src'     => '' !== $file['url'] ? $file['url'] : self::url_from( $row['url'] ?? '' ),
				'id'      => '' !== $file['url'] ? $file['id'] : 0,
				'label'   => (string) ( $row['label'] ?? '' ),
				'srclang' => (string) ( $row['srclang'] ?? '' ),
			);
		}

		return $out;
	}

	/**
	 * @param mixed $rows
	 * @return array<int, array<string, mixed>>
	 */
	private static function chapters_from( $rows ): array {
		$out = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$out[] = array(
				'start' => (string) ( $row['start'] ?? '0' ),
				'title' => (string) ( $row['title'] ?? '' ),
			);
		}

		return $out;
	}

	public function markup( array $settings ): string {
		$html = ( new PlayerRenderer() )->render( $this->attributes_from( $settings ) );

		return '' === $html ? '' : '<div class="imgp-block imgp-block--elementor">' . $html . '</div>';
	}
}
