<?php
/**
 * Several tracks, one player.
 *
 * The player itself is the ordinary one — the same renderer, the same skins,
 * the same protection. What this adds is a list beside it and the ability to
 * change what is loaded without rebuilding anything, because a playlist that
 * re-created the player on every click would lose the volume the listener set,
 * the speed they chose and the element they had focused.
 *
 * The first track is rendered fully, server-side, so the page is a working
 * player before any JavaScript runs. Every other item is a link that happens to
 * do something better when it can.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Render;

use ImaginaPlayer\Media\Track;
use ImaginaPlayer\Peaks\PeaksRepository;
use ImaginaPlayer\Player\Access;
use ImaginaPlayer\Player\Attributes;
use ImaginaPlayer\Player\Config;
use ImaginaPlayer\Player\CourseProgress;
use ImaginaPlayer\Protection\Vault;
use ImaginaPlayer\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PlaylistRenderer {

	/**
	 * How the list sits against the player.
	 *
	 * `list` and `grid` are the audio shapes. The other three are for video:
	 * the list beside the picture, a rail of thumbnails under it, and a
	 * slider of larger cards with arrows.
	 */
	public const LAYOUTS = array( 'list', 'grid', 'side', 'rail', 'slider' );

	/** The layouts that run sideways and scroll. */
	public const HORIZONTAL = array( 'rail', 'slider' );

	private PlayerRenderer $player;

	private PeaksRepository $peaks;

	public function __construct( ?PlayerRenderer $player = null, ?PeaksRepository $peaks = null ) {
		$this->player = $player ?? new PlayerRenderer();
		$this->peaks  = $peaks ?? new PeaksRepository();
	}

	/**
	 * @param array<string, mixed> $atts Raw block attributes.
	 */
	public function render( array $atts ): string {
		$items = self::sanitize_items( (array) ( $atts['items'] ?? array() ) );

		if ( array() === $items ) {
			return '<div class="imgp imgp--empty"><p>'
				. esc_html__( 'Imagina Player: this playlist has no tracks yet.', 'imagina-player' )
				. '</p></div>';
		}

		$layout  = self::layout( (string) ( $atts['layout'] ?? 'list' ) );
		$heading = sanitize_text_field( (string) ( $atts['heading'] ?? '' ) );
		$id      = 'imgp-pl-' . wp_generate_password( 8, false, false );

		// Each item as the player would see it: a video's poster, a provider's
		// still, an upload's cover and length, resolved once here so the list
		// and the runtime agree.
		$items = array_map( array( $this, 'resolve' ), $items );

		// The first item is rendered as a real player. The rest are data the
		// runtime swaps in — but they are also links, so they work without it.
		$first = $items[0];

		/*
		 * The same rule as a single player, for the whole list. Locked, the
		 * player draws its offer and the list keeps its titles but not one
		 * address: every item was a link to its file.
		 */
		$access = array_intersect_key(
			Attributes::sanitize( $atts ),
			array_flip( array( 'accessRule', 'accessIds', 'accessMessage', 'accessButton', 'accessUrl' ) )
		);
		$locked = ! Access::allows( $access );

		/*
		 * A course: each lesson is marked once it has been watched, the list
		 * says how far through it is, and coming back carries on where it
		 * stopped — on this device from the browser, on any other from the
		 * student's account. Optionally one lesson at a time.
		 */
		$course     = ! $locked && ! empty( $atts['course'] );
		$course_key = CourseProgress::key( (string) ( $atts['courseKey'] ?? '' ) );
		$course_key = '' === $course_key ? self::stable_key( $items ) : $course_key;
		$sequential = $course && ! empty( $atts['courseSequential'] );
		$progress   = $course ? CourseProgress::get( (int) get_current_user_id(), $course_key ) : null;
		$watched    = array_flip( (array) ( $progress['w'] ?? array() ) );
		$item_keys  = array_map( static fn( array $item ): string => substr( md5( (string) $item['stableKey'] ), 0, 12 ), $items );

		// The first lesson not yet watched: the furthest a student may go.
		$frontier = count( $items );

		foreach ( $item_keys as $index => $item_key ) {
			if ( ! isset( $watched[ $item_key ] ) ) {
				$frontier = $index;
				break;
			}
		}

		// Progress drawn for one person is not a page for the next one.
		if ( $course && is_user_logged_in() ) {
			Access::do_not_cache();
		}

		$player = $this->player->render(
			array(
				'src'          => $first['src'],
				'attachmentId' => $first['id'],
				'title'        => $first['title'],
				'artist'       => $first['artist'],
				'thumbnail'    => $first['thumbnail'],
				'poster'       => $first['poster'],
				'preset'       => (string) ( $atts['preset'] ?? Settings::DEFAULT_PRESET ),
			)
			// A course remembers where each lesson stopped, whatever its
			// preset says.
			+ ( $course ? array( 'rememberPosition' => 'yes' ) : array() )
			+ $access
		);

		$tracks     = array_map( array( $this, 'client_track' ), $items );
		$horizontal = in_array( $layout, self::HORIZONTAL, true );

		/*
		 * The list is outside the player, so the player's colours never
		 * reached it: the highlight on the current track was drawn from an
		 * accent that was not defined there, and came out as nothing at all.
		 */
		$style = Config::style_attribute(
			Config::shared_variables(
				Config::resolve( Attributes::sanitize( array( 'preset' => (string) ( $atts['preset'] ?? Settings::DEFAULT_PRESET ) ) ) )
			)
		);

		ob_start();
		?>
		<div
			class="imgp-playlist imgp-playlist--<?php echo esc_attr( $layout ); ?><?php echo $locked ? ' imgp-playlist--locked' : ''; ?><?php echo $course ? ' imgp-playlist--course' : ''; ?>"
			id="<?php echo esc_attr( $id ); ?>"
			<?php if ( ! $locked ) : ?>
				data-imagina-playlist="<?php echo esc_attr( (string) wp_json_encode( $tracks ) ); ?>"
				data-imagina-playlist-key="<?php echo esc_attr( self::stable_key( $items ) ); ?>"
			<?php endif; ?>
			<?php if ( '' !== $style ) : ?>
				style="<?php echo esc_attr( $style ); ?>"
			<?php endif; ?>
			<?php if ( $course ) : ?>
				data-imagina-course="<?php echo esc_attr( (string) wp_json_encode( array( 'key' => $course_key, 'items' => $item_keys, 'sequential' => $sequential, 'sync' => is_user_logged_in(), 'state' => $progress ) ) ); ?>"
			<?php endif; ?>
		>
			<?php if ( '' !== $heading ) : ?>
				<h3 class="imgp-playlist__heading"><?php echo esc_html( $heading ); ?></h3>
			<?php endif; ?>

			<?php if ( $course ) : ?>
				<?php $done = count( array_intersect( $item_keys, array_keys( $watched ) ) ); ?>
				<div class="imgp-playlist__progress">
					<span class="imgp-playlist__progress-text">
						<?php
						echo esc_html(
							sprintf(
								/* translators: 1: lessons watched, 2: lessons in the course. */
								__( '%1$d of %2$d watched', 'imagina-player' ),
								$done,
								count( $items )
							)
						);
						?>
					</span>
					<span class="imgp-playlist__progress-bar" aria-hidden="true"><span style="width:<?php echo esc_attr( (string) ( count( $items ) ? round( 100 * $done / count( $items ) ) : 0 ) ); ?>%"></span></span>
					<button type="button" class="imgp-playlist__restart"<?php echo 0 === $done ? ' hidden' : ''; ?>><?php esc_html_e( 'Start over', 'imagina-player' ); ?></button>
				</div>
			<?php endif; ?>

			<div class="imgp-playlist__player">
				<?php echo $player; // phpcs:ignore WordPress.Security.EscapeOutput -- rendered by PlayerRenderer, which escapes. ?>
			</div>

			<?php if ( 'slider' === $layout ) : ?>
				<?php
				/*
				 * Arrows for the slider, hidden until the script knows the
				 * cards overflow; a row that fits needs no arrows, and the
				 * row scrolls by hand either way. In a strip with the row,
				 * so they sit over its ends rather than the picture's.
				 */
				?>
				<div class="imgp-playlist__strip">
				<button type="button" class="imgp-playlist__nav imgp-playlist__nav--prev" aria-label="<?php esc_attr_e( 'Previous', 'imagina-player' ); ?>" hidden><?php echo Icons::get( 'back-arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG. ?></button>
				<button type="button" class="imgp-playlist__nav imgp-playlist__nav--next" aria-label="<?php esc_attr_e( 'Next', 'imagina-player' ); ?>" hidden><?php echo Icons::get( 'forward-arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG. ?></button>
			<?php endif; ?>

			<ol class="imgp-playlist__items">
				<?php foreach ( $items as $index => $item ) : ?>
					<?php
					$is_watched = $course && isset( $watched[ $item_keys[ $index ] ] );
					$is_shut    = $sequential && $index > $frontier;
					?>
					<li class="imgp-playlist__item<?php echo 0 === $index ? ' is-current' : ''; ?><?php echo $is_watched ? ' is-watched' : ''; ?><?php echo $is_shut ? ' is-locked' : ''; ?>"<?php echo $course ? ' data-key="' . esc_attr( $item_keys[ $index ] ) . '"' : ''; ?>>
						<?php
						/*
						 * A link to the file, not a button. Without JavaScript it
						 * plays the track — which is what a person clicking a track
						 * in a list is asking for. With it, the click is caught and
						 * the current player takes over instead.
						 */
						$time = $item['duration'] > 0
							? '<span class="imgp-playlist__time">' . esc_html( self::clock( $item['duration'] ) ) . '</span>'
							: '';
						?>
						<?php if ( $locked ) : ?>
							<span class="imgp-playlist__link is-locked">
						<?php else : ?>
							<a class="imgp-playlist__link" href="<?php echo esc_url( $item['src'] ); ?>" data-index="<?php echo esc_attr( (string) $index ); ?>">
						<?php endif; ?>
							<?php
							/*
							 * Always a cover, a blank one when the item has no
							 * picture. Without it an item with no cover sat flush
							 * against the edge in a column of indented ones, and
							 * left a hole in a grid.
							 */
							?>
							<span class="imgp-playlist__cover<?php echo '' === $item['thumbnail'] ? ' imgp-playlist__cover--blank' : ''; ?><?php echo $item['video'] ? ' imgp-playlist__cover--video' : ''; ?>">
								<?php if ( '' !== $item['thumbnail'] ) : ?>
									<img class="imgp-playlist__art" src="<?php echo esc_url( $item['thumbnail'] ); ?>" alt="" loading="lazy" decoding="async" width="64" height="64" />
								<?php endif; ?>
								<?php if ( $horizontal ) : ?>
									<?php echo $time; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above. ?>
								<?php endif; ?>
							</span>

							<span class="imgp-playlist__text">
								<span class="imgp-playlist__title"><?php echo esc_html( $item['title'] ); ?></span>
								<?php if ( '' !== $item['artist'] ) : ?>
									<span class="imgp-playlist__artist"><?php echo esc_html( $item['artist'] ); ?></span>
								<?php endif; ?>
							</span>

							<?php if ( ! $horizontal ) : ?>
								<?php echo $time; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped above. ?>
							<?php endif; ?>

							<?php if ( $course ) : ?>
								<span class="imgp-playlist__check" aria-hidden="true"></span>
								<span class="imgp-playlist__status imgp__sr"><?php echo $is_watched ? esc_html__( 'Watched', 'imagina-player' ) : ''; ?></span>
							<?php endif; ?>
						<?php echo $locked ? '</span>' : '</a>'; ?>
					</li>
				<?php endforeach; ?>
			</ol>
			<?php if ( 'slider' === $layout ) : ?>
				</div>
			<?php endif; ?>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * What the runtime needs to swap a track in.
	 *
	 * Peaks travel with the item when the server already has them measured: the
	 * alternative is a request per track as the listener clicks through an
	 * album, and the whole waveform pipeline exists to avoid exactly that.
	 *
	 * @param array<string, mixed> $item Sanitised item.
	 * @return array<string, mixed>
	 */
	private function client_track( array $item ): array {
		$key    = (string) $item['peaksKey'];
		$record = '' === $key ? null : $this->peaks->get( $key );

		$track = array(
			'layerKey'    => substr( md5( (string) $item['stableKey'] ), 0, 12 ),
			'src'         => $item['src'],
			'title'       => $item['title'],
			'artist'      => $item['artist'],
			'thumbnail'   => $item['thumbnail'],
			'poster'      => $item['poster'],
			'duration'    => $item['duration'],
			'peaksKey'    => $key,
			'peaks'       => is_array( $record ) ? (string) $record['peaks'] : '',
			'protectedId' => Vault::is_protected( $item['id'] ) ? $item['id'] : 0,
		);

		// A provider's video is switched through the provider's own player,
		// which needs its name for the video rather than an address.
		if ( '' !== $item['provider'] ) {
			$track['provider']     = $item['provider'];
			$track['providerId']   = $item['providerId'];
			$track['providerHash'] = $item['providerHash'];
		}

		return $track;
	}

	/**
	 * An item as the player would see it.
	 *
	 * A video item wants a picture in the list whether or not the author gave
	 * it one: the poster a provider serves, or the cover an upload carries.
	 * An upload also knows its own length. The player resolves all of this
	 * for the one it shows; the list needs it for every item.
	 *
	 * @param array<string, mixed> $item Sanitised item.
	 * @return array<string, mixed>
	 */
	private function resolve( array $item ): array {
		$track = Track::from_attributes(
			array(
				'src'          => $item['src'],
				'attachmentId' => $item['id'],
				'title'        => $item['title'],
				'thumbnail'    => $item['thumbnail'],
			)
		);

		$duration = $item['duration'];

		if ( $duration <= 0 && $item['id'] > 0 && function_exists( 'wp_get_attachment_metadata' ) ) {
			$meta     = (array) ( wp_get_attachment_metadata( $item['id'] ) ?: array() );
			$duration = max( 0.0, (float) ( $meta['length'] ?? 0 ) );
		}

		return array_merge(
			$item,
			array(
				'video'        => $track->is_video(),
				'poster'       => $track->poster,
				'provider'     => $track->is_provider() && null !== $track->provider ? $track->provider->name : '',
				'providerId'   => null !== $track->provider ? $track->provider->id : '',
				'providerHash' => null !== $track->provider ? $track->provider->hash : '',
				'peaksKey'     => $track->peaks_key(),
				'stableKey'    => $track->stable_key(),
				// A picture for the list: the author's, else the poster or cover.
				'thumbnail'    => '' !== $item['thumbnail'] ? $item['thumbnail'] : ( '' !== $track->poster ? $track->poster : $track->thumbnail ),
				'duration'     => $duration,
			)
		);
	}

	/**
	 * A name for this list that survives a page load.
	 *
	 * The last track a listener played is remembered against it. The DOM id
	 * is minted fresh on every render, so keyed on that the memory never
	 * matched anything; the tracks themselves do not change between loads.
	 *
	 * @param array<int, array<string, mixed>> $items Resolved items.
	 */
	public static function stable_key( array $items ): string {
		$names = array_map(
			static fn( array $item ): string => (int) ( $item['id'] ?? 0 ) > 0
				? 'att_' . (int) $item['id']
				: (string) ( function_exists( 'remove_query_arg' ) ? remove_query_arg( array( 'imgpt', 'imagina_media' ), (string) $item['src'] ) : $item['src'] ),
			$items
		);

		return substr( md5( implode( '|', $names ) ), 0, 12 );
	}

	/**
	 * One of the layouts, or the list.
	 */
	public static function layout( string $layout ): string {
		return in_array( $layout, self::LAYOUTS, true ) ? $layout : 'list';
	}

	/**
	 * @param array<int, mixed> $items Raw items.
	 * @return array<int, array{id: int, src: string, title: string, artist: string, thumbnail: string, duration: float}>
	 */
	public static function sanitize_items( array $items ): array {
		$clean = array();

		/*
		 * Every attachment in one round trip, before the loop asks about them
		 * one at a time. wp_get_attachment_url() loads the post and its meta on
		 * first sight, which for a playlist of N uploads was 2N queries; primed,
		 * it is two whatever N is.
		 */
		$ids = array();

		foreach ( $items as $item ) {
			if ( is_array( $item ) && (int) ( $item['id'] ?? 0 ) > 0 ) {
				$ids[] = (int) $item['id'];
			}
		}

		if ( array() !== $ids && function_exists( '_prime_post_caches' ) ) {
			_prime_post_caches( array_values( array_unique( $ids ) ), false, true );
		}

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$id  = (int) ( $item['id'] ?? 0 );
			$src = Attributes::sanitize_media_url( (string) ( $item['src'] ?? '' ) );

			// An attachment's current URL wins, for the same reason it does on a
			// single player: a file moved into the vault answers on a signed URL
			// now, and the one saved in the block would bypass it or 404.
			if ( $id > 0 ) {
				$current = wp_get_attachment_url( $id );

				if ( $current ) {
					$src = (string) $current;
				}
			}

			if ( '' === $src ) {
				continue;
			}

			$clean[] = array(
				'id'        => $id,
				'src'       => $src,
				'title'     => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
				'artist'    => sanitize_text_field( (string) ( $item['artist'] ?? '' ) ),
				'thumbnail' => Attributes::sanitize_media_url( (string) ( $item['thumbnail'] ?? '' ) ),
				'duration'  => max( 0.0, (float) ( $item['duration'] ?? 0 ) ),
			);
		}

		return $clean;
	}

	private static function clock( float $seconds ): string {
		$whole   = (int) round( $seconds );
		$hours   = intdiv( $whole, 3600 );
		$minutes = intdiv( $whole % 3600, 60 );

		// A lecture of an hour and a quarter reads `1:15:00`, as it does on the
		// player itself — not `75:00`.
		return $hours > 0
			? sprintf( '%d:%02d:%02d', $hours, $minutes, $whole % 60 )
			: sprintf( '%d:%02d', $minutes, $whole % 60 );
	}
}
