<?php
/**
 * Settings API behind the admin interface.
 *
 * The screen is a React application rather than a WordPress options form, so it
 * reads and writes through here. The preview endpoint returns markup produced by
 * the real renderer: what the settings screen shows is literally what the front
 * end will output, not a hand-maintained imitation of it.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Rest;

use ImaginaPlayer\Media\Provider;
use ImaginaPlayer\Media\Providers\VimeoThumbnail;
use ImaginaPlayer\Media\Track;
use ImaginaPlayer\Peaks\PeaksGenerator;
use ImaginaPlayer\Peaks\PeaksRepository;
use ImaginaPlayer\Player\Attributes;
use ImaginaPlayer\Player\Skins;
use ImaginaPlayer\Protection\SelfCheck;
use ImaginaPlayer\Protection\Vault;
use ImaginaPlayer\Render\PlayerRenderer;
use ImaginaPlayer\Settings;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SettingsController {

	public function hooks(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		$can_manage = static fn(): bool => current_user_can( 'manage_options' );
		$can_edit   = static fn(): bool => current_user_can( 'edit_posts' );

		register_rest_route(
			PeaksController::REST_NAMESPACE,
			'/settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => $can_manage,
				),
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_settings' ),
					'permission_callback' => $can_manage,
				),
			)
		);

		// A write method on purpose: it puts a file on disk and makes outbound
		// requests, so it should not be reachable by a link somebody follows.
		register_rest_route(
			PeaksController::REST_NAMESPACE,
			'/protection/self-check',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'self_check' ),
				'permission_callback' => $can_manage,
			)
		);

		/*
		 * Ask Vimeo again for a video's picture, forgetting what was remembered.
		 * A write method: it makes an outbound request.
		 */
		register_rest_route(
			PeaksController::REST_NAMESPACE,
			'/provider/poster',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'retry_poster' ),
				'permission_callback' => $can_edit,
				'args'                => array(
					'src' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		/*
		 * Open to anyone who can edit a post, not only administrators: this is
		 * what the block shows while it is being edited, and an author whose
		 * role cannot manage options was getting "The preview could not be
		 * loaded" on every block.
		 */
		register_rest_route(
			PeaksController::REST_NAMESPACE,
			'/preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'preview' ),
				'permission_callback' => $can_edit,
				'args'                => array(
					'preset'     => array(
						'type' => 'object',
					),
					'attributes' => array(
						'type' => 'object',
					),
					// The post the block is being edited in, for a block that
					// takes its file from that post's custom field.
					'postId'     => array(
						'type'    => 'integer',
						'minimum' => 0,
					),
					/*
					 * Which medium the settings screen wants to look at. A
					 * preset carries the accent, the corner radius, the button
					 * colour and a skin, and every one of those is visible on a
					 * video — but the preview only ever rendered audio, so the
					 * half of the plugin most people came for could not be seen
					 * before publishing it.
					 */
					'medium'     => array(
						'type' => 'string',
						'enum' => array( 'audio', 'video' ),
					),
					/*
					 * Unsaved video settings, so the Video section can show
					 * what a change looks like before it is saved — the same
					 * courtesy the preset editor has always had.
					 */
					'video'      => array(
						'type' => 'object',
					),
					'title'      => array( 'type' => 'string', 'maxLength' => 200 ),
					'artist'     => array( 'type' => 'string', 'maxLength' => 200 ),
				),
			)
		);
	}

	public function self_check(): WP_REST_Response {
		return new WP_REST_Response( SelfCheck::run(), 200 );
	}

	public function get_settings(): WP_REST_Response {
		return new WP_REST_Response( $this->payload(), 200 );
	}

	public function update_settings( WP_REST_Request $request ): WP_REST_Response {
		$incoming = $request->get_json_params();
		$settings = Settings::all();

		if ( isset( $incoming['presets'] ) && is_array( $incoming['presets'] ) ) {
			$presets = array();

			foreach ( $incoming['presets'] as $key => $preset ) {
				$key = sanitize_key( (string) $key );

				if ( '' === $key || ! is_array( $preset ) ) {
					continue;
				}

				$presets[ $key ] = Settings::sanitize_preset( $preset );
			}

			// The default preset is what every unconfigured block falls back to;
			// losing it would leave those blocks with nothing to resolve.
			if ( ! isset( $presets[ Settings::DEFAULT_PRESET ] ) ) {
				$presets[ Settings::DEFAULT_PRESET ] = Settings::preset_defaults();
			}

			$settings['presets'] = $presets;
		}

		if ( isset( $incoming['peaks'] ) && is_array( $incoming['peaks'] ) ) {
			$peaks = self::with_current( $incoming['peaks'], self::peaks_as_sent( $settings['peaks'] ) );

			$settings['peaks']['resolution']        = max( 32, min( 2000, (int) ( $peaks['resolution'] ?? 400 ) ) );
			$settings['peaks']['server_generation'] = ! empty( $peaks['server_generation'] );
			$settings['peaks']['client_fallback']   = ! empty( $peaks['client_fallback'] );
			$settings['peaks']['ffmpeg_path']       = Settings::sanitize_binary_path( (string) ( $peaks['ffmpeg_path'] ?? '' ) );
			$settings['peaks']['max_client_bytes']  = max( 1, min( 200, (int) ( $peaks['max_client_mb'] ?? 25 ) ) ) * MB_IN_BYTES;
		}

		if ( isset( $incoming['metadata'] ) && is_array( $incoming['metadata'] ) ) {
			$metadata = self::with_current( $incoming['metadata'], $settings['metadata'] );

			$settings['metadata']['title_from']    = in_array( $metadata['title_from'] ?? '', array( 'auto', 'tags', 'post', 'file', 'none' ), true )
				? (string) $metadata['title_from']
				: 'auto';
			$settings['metadata']['artist_from']   = in_array( $metadata['artist_from'] ?? '', array( 'auto', 'tags', 'none' ), true )
				? (string) $metadata['artist_from']
				: 'auto';
			$settings['metadata']['from_filename'] = ! empty( $metadata['from_filename'] );
			$settings['metadata']['use_cover']     = ! empty( $metadata['use_cover'] );
		}

		if ( isset( $incoming['video'] ) && is_array( $incoming['video'] ) ) {
			$video = self::with_current( $incoming['video'], $settings['video'] );

			$settings['video']['ratio']           = Attributes::sanitize_ratio( (string) ( $video['ratio'] ?? '16:9' ) );
			// Zero is a real answer here — "never hide them" — so it is clamped
			// rather than treated as unset.
			$settings['video']['hide_after']      = max( 0, min( 20000, (int) ( $video['hide_after'] ?? 2600 ) ) );
			$settings['video']['show_pip']        = ! empty( $video['show_pip'] );
			$settings['video']['show_fullscreen'] = ! empty( $video['show_fullscreen'] );
			$settings['video']['show_speed']      = ! empty( $video['show_speed'] );
			$settings['video']['big_play']        = ! empty( $video['big_play'] );
			$settings['video']['block_download']  = ! empty( $video['block_download'] );
			$settings['video']['poster_fit']      = 'contain' === ( $video['poster_fit'] ?? '' ) ? 'contain' : 'cover';
			$settings['video']['caption_size']    = in_array( $video['caption_size'] ?? '', array( 'small', 'medium', 'large', 'xlarge' ), true )
				? (string) $video['caption_size']
				: 'medium';
			$settings['video']['caption_bg']      = in_array( $video['caption_bg'] ?? '', array( 'solid', 'shadow', 'none' ), true )
				? (string) $video['caption_bg']
				: 'solid';
			$settings['video']['provider_privacy'] = ! empty( $video['provider_privacy'] );

			foreach ( array( 'show_captions', 'show_chapters', 'show_search', 'show_transcript', 'show_skip', 'show_time', 'show_volume', 'show_title', 'focus_mode', 'captions_on', 'provider_bare' ) as $flag ) {
				$settings['video'][ $flag ] = ! empty( $video[ $flag ] );
			}

			$settings['video']['chrome_color']    = Settings::sanitize_color( (string) ( $video['chrome_color'] ?? '' ), '#000000' );
			$settings['video']['caption_color']   = Settings::sanitize_color( (string) ( $video['caption_color'] ?? '' ), '#ffffff' );

			/*
			 * `auto` is a value in its own right for these two — the icons
			 * follow the bar, the played line follows the accent — so it has to
			 * survive the sanitiser rather than be turned into a colour here.
			 */
			foreach ( array( 'control_color', 'progress_color' ) as $key ) {
				$value = (string) ( $video[ $key ] ?? 'auto' );

				$settings['video'][ $key ] = 'auto' === $value
					? 'auto'
					: Settings::sanitize_color( $value, 'auto' );
			}
		}

		if ( isset( $incoming['protection'] ) && is_array( $incoming['protection'] ) ) {
			$protection = self::with_current( $incoming['protection'], $settings['protection'] );

			$settings['protection']['enabled']       = ! empty( $protection['enabled'] );
			$settings['protection']['require_login'] = ! empty( $protection['require_login'] );
			$settings['protection']['bind_to_user']  = ! empty( $protection['bind_to_user'] );
			$settings['protection']['bind_to_ip']    = ! empty( $protection['bind_to_ip'] );
			$settings['protection']['ttl']           = max( HOUR_IN_SECONDS, min( WEEK_IN_SECONDS, (int) ( $protection['ttl'] ?? DAY_IN_SECONDS ) ) );
			$settings['protection']['delivery']      = in_array( $protection['delivery'] ?? 'php', array( 'php', 'xaccel', 'xsendfile' ), true )
				? (string) $protection['delivery']
				: 'php';
			$settings['protection']['xaccel_prefix'] = '/' . trim( sanitize_text_field( (string) ( $protection['xaccel_prefix'] ?? '' ) ), '/' ) . '/';

			if ( $settings['protection']['enabled'] ) {
				Vault::ensure();
			}
		}

		if ( isset( $incoming['advanced'] ) && is_array( $incoming['advanced'] ) ) {
			$advanced = self::with_current( $incoming['advanced'], $settings['advanced'] );

			$settings['advanced']['load_frontend_css'] = ! empty( $advanced['load_frontend_css'] );
			$settings['advanced']['lazy_init']         = ! empty( $advanced['lazy_init'] );
			// Stripped of tags, not of CSS: this is a stylesheet, and an admin who
			// can reach this screen can already edit theme files.
			$settings['advanced']['custom_css']        = wp_strip_all_tags( (string) ( $advanced['custom_css'] ?? '' ) );
		}

		if ( isset( $incoming['branding'] ) && is_array( $incoming['branding'] ) ) {
			$current  = $settings['branding'];
			$branding = self::with_current( $incoming['branding'], $current );

			foreach ( array( 'accent', 'wave_color', 'text_color', 'meta_color', 'control_color' ) as $key ) {
				$settings['branding'][ $key ] = Settings::sanitize_color(
					(string) ( $branding[ $key ] ?? '' ),
					(string) $current[ $key ]
				);
			}

			$settings['branding']['logo']        = esc_url_raw( (string) ( $branding['logo'] ?? '' ), array( 'http', 'https' ) );
			$settings['branding']['logo_link']   = esc_url_raw( (string) ( $branding['logo_link'] ?? '' ), array( 'http', 'https' ) );
			$settings['branding']['logo_height'] = max( 8, min( 80, (int) ( $branding['logo_height'] ?? 20 ) ) );
		}

		Settings::update( $settings );

		return new WP_REST_Response( $this->payload(), 200 );
	}

	/**
	 * A group as the request sent it, laid over the group as it is stored.
	 *
	 * Every switch below is read as `! empty( $group['flag'] )`, which makes
	 * "not mentioned" and "off" the same thing. The settings screen sends
	 * every group whole, so it never noticed — but the endpoint is public to
	 * anything holding an administrator's cookie, and a request that named
	 * one switch in a group turned off every other switch in that group. A
	 * request that mentions a key changes that key; a key it does not mention
	 * keeps the value it had.
	 *
	 * @param array<string, mixed> $incoming What the request carried.
	 * @param array<string, mixed> $current  The group as stored, in the shape
	 *                                       the request would send it.
	 * @return array<string, mixed>
	 */
	private static function with_current( array $incoming, array $current ): array {
		return array_merge( $current, $incoming );
	}

	/**
	 * The waveform group in the shape the interface sends it — megabytes, not
	 * bytes — so a partial request can be laid over it.
	 *
	 * @param array<string, mixed> $stored The group as stored.
	 * @return array<string, mixed>
	 */
	private static function peaks_as_sent( array $stored ): array {
		$stored['max_client_mb'] = (int) round( (int) ( $stored['max_client_bytes'] ?? 0 ) / MB_IN_BYTES );

		return $stored;
	}

	/**
	 * Why a video has no picture, when the reason is Vimeo's.
	 */
	private static function poster_reason( Track $track ): string {
		if ( '' !== $track->poster || ! $track->is_provider() || 'vimeo' !== $track->provider->name ) {
			return '';
		}

		// Already asked while the track was built, so this reads what was
		// remembered and makes no second request.
		return VimeoThumbnail::status( $track->provider )['why'];
	}

	/**
	 * Forget what Vimeo said about a video and ask again.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	public function retry_poster( WP_REST_Request $request ) {
		$provider = Provider::detect( Attributes::sanitize_media_url( (string) $request->get_param( 'src' ) ) );

		if ( 'vimeo' !== $provider->name ) {
			return new WP_Error(
				'imagina_player_not_vimeo',
				__( 'Only a Vimeo video has a picture that must be asked for.', 'imagina-player' ),
				array( 'status' => 400 )
			);
		}

		VimeoThumbnail::forget( $provider );

		return new WP_REST_Response( VimeoThumbnail::status( $provider ), 200 );
	}

	/**
	 * Render a player with a candidate preset, without saving anything.
	 */
	public function preview( WP_REST_Request $request ): WP_REST_Response {
		$attributes = $request->get_param( 'attributes' );

		// Two callers, two shapes. The block sends its own attributes and wants to
		// see exactly what it will publish; the settings screen sends a candidate
		// preset that is not saved anywhere yet.
		if ( is_array( $attributes ) ) {
			/*
			 * Only a post the author may edit: the block reads a custom field
			 * of it, and naming somebody else's post here must not read theirs.
			 */
			$post_id = (int) $request->get_param( 'postId' );

			if ( $post_id > 0 && ! current_user_can( 'edit_post', $post_id ) ) {
				$post_id = 0;
			}

			// A block previewing a real file gets that file's real waveform. It
			// used to get the demo one, which told the author their waveform was
			// working when it was not — they only found out on the front end.
			return $this->preview_response( $attributes, null, false, $post_id );
		}

		if ( 'video' === $request->get_param( 'medium' ) ) {
			/*
			 * A file that does not exist, exactly like the audio demo: the
			 * player is built from the attributes and the poster, and nothing
			 * here ever plays. What matters is that it is the real renderer, so
			 * the preview cannot drift away from the thing it previews.
			 */
			$video = $request->get_param( 'video' );

			$override = null;

			if ( is_array( $video ) ) {
				$candidate = Settings::video();

				foreach ( $video as $key => $value ) {
					if ( array_key_exists( $key, $candidate ) ) {
						$candidate[ $key ] = $value;
					}
				}

				$override = static fn(): array => $candidate;
				add_filter( 'imagina_player_video_settings', $override, 99 );
			}

			$response = $this->preview_response(
				array(
					'src'         => home_url( '/imagina-player-preview.mp4' ),
					'title'       => (string) ( $request->get_param( 'title' ) ?: __( 'Your video title', 'imagina-player' ) ),
					'poster'      => \ImaginaPlayer\URL . 'assets/preview-poster.svg',
					'aspectRatio' => '16:9',
				),
				Settings::sanitize_preset( (array) $request->get_param( 'preset' ) )
			);

			if ( null !== $override ) {
				remove_filter( 'imagina_player_video_settings', $override, 99 );
			}

			return $response;
		}

		return $this->preview_response(
			array(
				'src'       => home_url( '/imagina-player-preview.mp3' ),
				'title'     => (string) ( $request->get_param( 'title' ) ?: __( 'Your track title', 'imagina-player' ) ),
				'artist'    => (string) ( $request->get_param( 'artist' ) ?: __( 'Artist name', 'imagina-player' ) ),
				'thumbnail' => \ImaginaPlayer\URL . 'assets/preview-cover.svg',
			),
			Settings::sanitize_preset( (array) $request->get_param( 'preset' ) )
		);
	}

	/**
	 * Render through the real renderer, optionally forcing a candidate preset.
	 *
	 * @param array<string, mixed>      $attributes Player attributes.
	 * @param array<string, mixed>|null $preset     Preset to force, or null to resolve normally.
	 */
	private function preview_response( array $attributes, ?array $preset, bool $demo = true, int $post_id = 0 ): WP_REST_Response {
		// A duration the player can lay a scrubber over. Without it the preview
		// shows `--:--` and the elapsed badge has nowhere to sit. Only for the
		// settings screen, whose "track" is a file that does not exist.
		$fake_duration = static function ( array $config ): array {
			if ( empty( $config['duration'] ) ) {
				$config['duration'] = 214.0;
			}

			return $config;
		};

		$override = null;

		if ( null !== $preset ) {
			$override = static fn(): array => $preset;
			add_filter( 'imagina_player_resolved_config', $override, 99 );
		}

		if ( $demo ) {
			add_filter( 'imagina_player_client_config', $fake_duration, 99 );
		}

		$renderer = new PlayerRenderer();
		$html     = $renderer->render( $attributes, $post_id );

		if ( null !== $override ) {
			remove_filter( 'imagina_player_resolved_config', $override, 99 );
		}

		if ( $demo ) {
			remove_filter( 'imagina_player_client_config', $fake_duration, 99 );

			return new WP_REST_Response(
				array(
					'html'  => $html,
					'peaks' => self::demo_peaks(),
					'real'  => false,
				),
				200
			);
		}

		// The real thing, or nothing. An empty string is what the editor needs
		// in order to say "this track has no waveform yet" rather than draw one
		// that does not exist.
		$track  = Track::from_attributes( PlayerRenderer::resolve( $attributes, $post_id ) );
		$key    = $track->peaks_key();
		$record = '' === $key ? null : ( new PeaksRepository() )->get( $key );

		return new WP_REST_Response(
			array(
				'html'         => $html,
				'peaks'        => is_array( $record ) ? (string) $record['peaks'] : '',
				'real'         => true,
				'hasPeaks'     => is_array( $record ),
				'attachmentId' => $track->attachment_id,
				// What the block will show if its own fields are left empty, so
				// the editor can put it in the field as a placeholder rather
				// than showing a blank box beside a filled-in player.
				'resolved'     => array(
					'title'     => $track->title,
					'artist'    => $track->artist,
					'thumbnail' => $track->thumbnail,
					// The picture behind a video, and — for one Vimeo would not
					// hand over — why, so the editor can say so rather than
					// show a black rectangle that reads as "does not work".
					'poster'       => $track->poster,
					'posterReason' => self::poster_reason( $track ),
				),
			),
			200
		);
	}

	/**
	 * A synthetic waveform for the preview, so it looks like audio without
	 * needing a real file to analyse.
	 */
	public static function demo_peaks(): string {
		$peaks = array();

		for ( $i = 0; $i < 400; $i++ ) {
			$peaks[] = min(
				1.0,
				max(
					0.12,
					0.55
					+ sin( $i * 0.35 ) * 0.25
					+ sin( $i * 1.7 ) * 0.2
					+ sin( $i * 0.11 ) * 0.3
				)
			);
		}

		return PeaksRepository::encode( $peaks );
	}

	/**
	 * Everything the interface needs in one response.
	 *
	 * @return array<string, mixed>
	 */
	private function payload(): array {
		$settings = Settings::all();
		$peaks    = $settings['peaks'];

		return array(
			'presets'    => $settings['presets'],
			'peaks'      => array(
				'resolution'        => (int) $peaks['resolution'],
				'server_generation' => (bool) $peaks['server_generation'],
				'client_fallback'   => (bool) $peaks['client_fallback'],
				'ffmpeg_path'       => (string) $peaks['ffmpeg_path'],
				'max_client_mb'     => (int) round( (int) $peaks['max_client_bytes'] / MB_IN_BYTES ),
			),
			'protection' => $settings['protection'],
			'advanced'   => $settings['advanced'],
			'branding'   => $settings['branding'],
			'schema'     => array(
				'presetDefaults' => Settings::preset_from_branding(),
				'skins'          => Skins::all(),
				'skinNotes'      => Skins::descriptions(),
				'defaultPreset'  => Settings::DEFAULT_PRESET,
			),
			'video'      => Settings::video(),
			'metadata'   => Settings::metadata(),
			'system'     => array(
				'ffmpeg'        => PeaksGenerator::is_available(),
				'ffmpegBinary'  => PeaksGenerator::binary(),
				'ffmpegState'   => PeaksGenerator::diagnosis()['state'],
				'vaultDir'      => Vault::base_dir(),
				'vaultName'     => Vault::directory_name(),
				'htaccess'      => Vault::server_honours_htaccess(),
				'version'       => \ImaginaPlayer\VERSION,
			),
		);
	}
}
