<?php
/**
 * Block registration.
 *
 * Attribute definitions are generated from the PHP schema and injected at
 * registration time rather than duplicated into `block.json`. The editor picks
 * them up through WordPress's server-side block definitions, so the schema stays
 * in one place.
 *
 * @package ImaginaPlayer
 */

declare( strict_types = 1 );

namespace ImaginaPlayer\Blocks;

use ImaginaPlayer\Assets;
use ImaginaPlayer\Player\Attributes;
use ImaginaPlayer\Render\PlayerRenderer;
use ImaginaPlayer\Render\PlaylistRenderer;
use ImaginaPlayer\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BlockRegistrar {

	public const BLOCK_NAME = 'imagina/audio-player';

	public const VIDEO_BLOCK = 'imagina/video-player';

	public const PLAYLIST_BLOCK = 'imagina/playlist';

	/**
	 * What every block name above begins with, for code that looks for any of
	 * them in post content. Named here so it cannot be typed differently
	 * somewhere else — which it was.
	 */
	public const NAMESPACE_PREFIX = 'imagina/';

	/** The attribute a playlist keeps its tracks in. */
	public const PLAYLIST_ITEMS = 'items';

	public function hooks(): void {
		add_action( 'init', array( $this, 'register' ), 20 );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_data' ) );
	}

	public function register(): void {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		register_block_type(
			\ImaginaPlayer\PATH . 'blocks/audio',
			array(
				'attributes'      => self::block_attributes(),
				'render_callback' => array( $this, 'render' ),
			)
		);

		/*
		 * A block of its own rather than a mode of the audio one. The audio
		 * block always handled a video file, but it is called "Imagina Audio
		 * Player", carries an audio icon and says "upload an audio file" — so
		 * somebody looking for video in the inserter found nothing, and
		 * reasonably concluded there was nothing to find.
		 */
		register_block_type(
			\ImaginaPlayer\PATH . 'blocks/video',
			array(
				'attributes'      => self::block_attributes(),
				'render_callback' => array( $this, 'render' ),
			)
		);

		register_block_type(
			\ImaginaPlayer\PATH . 'blocks/playlist',
			array(
				'attributes'      => array(
					'items'     => array(
						'type'    => 'array',
						'default' => array(),
						'items'   => array( 'type' => 'object' ),
					),
					'layout'    => array(
						'type'    => 'string',
						'default' => 'list',
					),
					'heading'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'preset'    => array(
						'type'    => 'string',
						'default' => Settings::DEFAULT_PRESET,
					),
					'className' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'render_callback' => array( $this, 'render_playlist' ),
			)
		);
	}

	/**
	 * @param array<string, mixed> $attributes Block attributes.
	 */
	public function render_playlist( array $attributes, string $content = '', mixed $block = null ): string {
		$renderer = new PlaylistRenderer();
		$html     = $renderer->render( $attributes );

		if ( '' === $html ) {
			return '';
		}

		$wrapper = get_block_wrapper_attributes( array( 'class' => 'imgp-block' ) );

		return sprintf( '<div %s>%s</div>', $wrapper, $html );
	}

	/**
	 * Translate the PHP attribute schema into block attribute definitions.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function block_attributes(): array {
		$attributes = array();

		foreach ( Attributes::schema() as $name => $definition ) {
			$attributes[ $name ] = match ( $definition['type'] ) {
				'int', 'float' => array(
					'type'    => 'number',
					'default' => $definition['default'],
				),
				'bool'         => array(
					'type'    => 'boolean',
					'default' => (bool) $definition['default'],
				),
				'array'        => array(
					'type'    => 'array',
					'default' => array(),
					'items'   => array( 'type' => 'object' ),
				),
				default        => array(
					'type'    => 'string',
					'default' => (string) $definition['default'],
				),
			};
		}

		return $attributes;
	}

	/**
	 * @param array<string, mixed> $attributes Block attributes.
	 */
	public function render( array $attributes, string $content = '', mixed $block = null ): string {
		$renderer = new PlayerRenderer();
		$html     = $renderer->render( $attributes );

		if ( '' === $html ) {
			return '';
		}

		$wrapper = get_block_wrapper_attributes( array( 'class' => 'imgp-block' ) );

		return sprintf( '<div %s>%s</div>', $wrapper, $html );
	}

	/**
	 * Hand the editor the preset list and the override schema so its inspector
	 * can be generated instead of hand-maintained.
	 */
	public function enqueue_editor_data(): void {
		$presets = array();

		foreach ( Settings::presets() as $key => $preset ) {
			$presets[] = array(
				'value' => $key,
				'label' => (string) $preset['label'],
			);
		}

		wp_add_inline_script(
			Assets::EDITOR_HANDLE,
			'window.imaginaPlayerEditor = ' . wp_json_encode(
				array(
					'presets'     => $presets,
					'skins'       => Settings::skins(),
					// Separately, because a skin belongs to a medium: the seven
					// above all arrange a waveform and a row of transport
					// buttons, which is not what a video needs.
					'videoSkins'  => \ImaginaPlayer\Player\Skins::video(),
					'overrides'   => Attributes::override_map(),
					'presetShape' => Settings::preset_defaults(),
					'settingsUrl' => esc_url_raw( admin_url( 'admin.php?page=imagina-player' ) ),
				) + Assets::preview_assets()
			) . ';',
			'before'
		);
	}
}
