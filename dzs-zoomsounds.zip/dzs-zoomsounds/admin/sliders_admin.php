<?php


// -- in action init
$dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery = null;


add_action('dzsap_sliders_edit_form_fields', 'dzsap_sliders_admin_add_feature_group_field', 10, 10);

add_filter('dzsap_sliders_row_actions', 'dzsap_sliders_admin_duplicate_post_link', 10, 2);
add_action('admin_action_dzsap_duplicate_slider_term', 'dzsap_action_dzsap_duplicate_slider_term', 10, 2);


add_action('admin_init', 'dzsap_sliders_admin_init', 1000);

/**
 * rms_ plugin acts up with the order
 * @param $targetQuery
 */
function dzsap_slidersAdmin_fixHackConfictsForOrder($targetQuery) {

  global $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery;

  if (isset($targetQuery->query_vars) && $targetQuery->query_vars['post_type'] === DZSAP_REGISTER_POST_TYPE_NAME) {
    $targetQuery->query_vars['meta_query'] = $dzsap_slidersAdmin_fixHackConfictsForOrder_metaQuery;
  }
}




function dzsap_sliders_admin_init() {

  global $dzsap, $pagenow;
  $taxonomyName = DZSAP_TAXONOMY_NAME_SLIDERS;

  if (isset($_GET['taxonomy']) && $_GET['taxonomy'] === DZSAP_TAXONOMY_NAME_SLIDERS && isset($_GET['post_type']) && $_GET['post_type'] === DZSAP_REGISTER_POST_TYPE_NAME) {

    add_action('pre_get_posts', 'dzsap_slidersAdmin_fixHackConfictsForOrder', 1000);
  }


  if ((isset($_REQUEST['action']) && 'dzsap_duplicate_slider_term' == $_REQUEST['action'])) {

    if (!(isset($_GET['term_id']) || isset($_POST['term_id']))) {
      wp_die("no term_id set");
    }


    /*
     * get the original post id
     */
    $term_id = (isset($_GET['term_id']) ? absint($_GET['term_id']) : absint($_POST['term_id']));

    $term_meta = get_option("taxonomy_$term_id");

    /*
    $current_user = wp_get_current_user();
    $new_post_author = $current_user->ID;



     * Nonce verification
     */
    if (isset($_GET['duplicate-nonce-for-term-id-' . $term_id]) && wp_verify_nonce($_GET['duplicate-nonce-for-term-id-' . $term_id], 'duplicate-nonce-for-term-id-' . $term_id)) {


      $argsForImport = array(
        'post_type' => DZSAP_REGISTER_POST_TYPE_NAME,
        'tax_query' => array(
          array(
            'taxonomy' => DZSAP_TAXONOMY_NAME_SLIDERS,
            'field' => 'id',
            'terms' => $term_id
          )
        ),
      );
      $query = new WP_Query($argsForImport);


      $reference_term = get_term($term_id, $taxonomyName);


      $reference_term_name = $reference_term->name;
      $reference_term_slug = $reference_term->slug;






      $new_term_name = $reference_term_name . ' ' . esc_html("Copy", DZSAP_ID);
      $new_term_slug = $reference_term_slug . '-copy';
      $original_slug_name = $reference_term_slug . '-copy';


      $ind = 1;
      $breaker = 100;
      while (1) {

        $term = term_exists($new_term_slug, $taxonomyName);
        if ($term !== 0 && $term !== null) {

          $ind++;
          $new_term_slug = $original_slug_name . '-' . $ind;
        } else {
          break;
        }

        $breaker--;

        if ($breaker < 0) {
          break;
        }
      }


      $new_term = wp_insert_term(
        $new_term_name, // the term
        $taxonomyName, // the taxonomy
        array(

          'slug' => $new_term_slug,
        )
      );


      foreach ($query->posts as $po) {


        $dzsap->ajax_functions->duplicate_post($po->ID, array(
          'new_term_slug' => $new_term_slug,
          'call_from' => 'default',
          'new_tax' => $taxonomyName,
        ));


      }




      $new_term_id = $new_term['term_id'];


      update_option("taxonomy_$new_term_id", $term_meta);
      wp_redirect(admin_url('term.php?taxonomy=' . $taxonomyName . '&tag_ID=' . $new_term_id . '&post_type=dzsap_items'));

      exit;



    } else {
      $aux = ('invalid nonce for term_id' . $term_id . 'duplicate-nonce-for-term-id-' . $term_id);

      $aux .= print_rr($_SESSION);

      $aux .= ' searched nonce - ' . $_GET['duplicate-nonce-for-term-id-' . $term_id];
      $aux .= ' searched nonce verify - ' . wp_verify_nonce($_GET['duplicate-nonce-for-term-id-' . $term_id], 'duplicate-nonce-for-term-id-' . $term_id);


      wp_die($aux);
    }
  }


  // -- export
  if ((isset($_REQUEST['action']) && 'dzsap_export_slider_term' == $_REQUEST['action'])) {


    /*
     * get the original post id
     */
    $term_id = (isset($_GET['term_id']) ? absint($_GET['term_id']) : absint($_POST['term_id']));


    $arr_export = $dzsap->classAdmin->playlist_export($term_id, array(
      'download_export' => true
    ));
    echo json_encode($arr_export);
    die();


    exit;

  }


  // -- import

  if (isset($_POST['action']) && $_POST['action'] == 'dzsap_import_slider') {

    if (isset($_FILES['dzsap_import_slider_file'])) {

      $file_arr = $_FILES['dzsap_import_slider_file'];

      $file_cont = file_get_contents($file_arr['tmp_name'], true);


      $type = 'none';


      try {
        $sliderObj = json_decode($file_cont, true);

        error_log('content - ' . print_rr($sliderObj, true));

        if ($sliderObj && is_array($sliderObj)) {

          $type = 'json';
        } else {
          $sliderObj = unserialize($file_cont);


          error_log('content - ' . print_rr($sliderObj, true));
          $type = 'serial';
        }

        if (is_array($sliderObj)) {
          if ($type == 'json') {


            $reference_term_name = $sliderObj['original_term_name'];
            $reference_term_slug = $sliderObj['original_term_slug'];




            $original_name = $reference_term_name;
            $original_slug = $reference_term_slug;


            $new_term_slug = $reference_term_slug;
            $new_term_name = $reference_term_name;


            $ind = 1;
            $breaker = 100;


            $term = term_exists($new_term_name, $taxonomyName);
            if ($term !== 0 && $term !== null) {


              $new_term_name = $original_name . '-' . $ind;
              $new_term_slug = $original_slug . '-' . $ind;
              $ind++;


              while (1) {

                $term = term_exists($new_term_name, $taxonomyName);
                if ($term !== 0 && $term !== null) {

                  $new_term_name = $original_name . '-' . $ind;
                  $new_term_slug = $original_slug . '-' . $ind;
                  $ind++;
                } else {
                  break;
                }

                $breaker--;

                if ($breaker < 0) {
                  break;
                }
              }

            } else {


            }


            $new_term = wp_insert_term(
              $new_term_name, // the term
              $taxonomyName, // the taxonomy
              array(

                'slug' => $new_term_slug,
              )
            );


            $new_term_id = '';
            if (is_array($new_term)) {

              $new_term_id = $new_term['term_id'];
            } else {
              error_log(' .. the name is ' . $new_term_name);
              error_log(print_r($new_term, true));
            }


            $term_meta = array_merge(array(), $sliderObj['term_meta']);

            unset($term_meta['items']);

            update_option("taxonomy_$new_term_id", $term_meta);


            foreach ($sliderObj['items'] as $po) {

              $argsForImport = array_merge(array(), $po);

              $argsForImport['term'] = $new_term_slug;
              $argsForImport['taxonomy'] = $taxonomyName;

              $argsForImport['call_from'] = 'sliders_admin import slider_file';
              $dzsap->ajax_functions->import_demo_insert_post_complete($argsForImport);


            }






          }


          // -- legacy
          if ($type == 'serial') {


            include_once(DZSAP_BASE_PATH.'inc/php/legacy/sliders-admin-init--legacy.php');
          }
        }
      } catch
      (Exception $err) {
        print_rr($err);
      }
    }
  }
}


function dzsap_action_dzsap_duplicate_slider_term() {


}

function dzsap_sliders_admin_duplicate_post_link($actions, $term) {


  if (current_user_can('edit_posts')) {


    // Create an nonce, and add it as a query var in a link to perform an action.
    $nonce = wp_create_nonce('duplicate-nonce-for-term-id-' . $term->term_id);

    $actions['duplicate'] = '<a href="' . admin_url('edit-tags.php?taxonomy=dzsap_sliders&post_type=dzsap_items&action=dzsap_duplicate_slider_term&term_id=' . $term->term_id) . '&duplicate-nonce-for-term-id-' . ($term->term_id) . '=' . $nonce . '" title="Duplicate this item" rel="permalink">' . esc_html("Duplicate", DZSAP_ID) . '</a>';
  }


  $actions['export'] = '<a href="' . admin_url('edit-tags.php?taxonomy=dzsap_sliders&post_type=dzsap_items&action=dzsap_export_slider_term&term_id=' . $term->term_id) . '" title="Duplicate this item" rel="permalink">' . esc_html("Export", DZSAP_ID) . '</a>';


  return $actions;
}


function dzsap_sliders_admin() {

  $dzsapSlidersAdmin = new SlidersAdmin(array(
    'target_taxonomy' => DZSAP_TAXONOMY_NAME_SLIDERS,
    'target_post_type' => DZSAP_REGISTER_POST_TYPE_NAME,
  ));
  $dzsapSlidersAdmin->render_sliders();
}


function dzsap_sliders_admin_add_feature_group_field($term) {




  global $dzsap;





  $dzsap->options_slider = include DZSAP_BASE_PATH . 'configs/playlist-options.php';


  $dzsap->options_slider_categories_lng = array(
    'appearence' => esc_html__("Appearance", DZSAP_ID),
    'menu' => esc_html__("Menu", DZSAP_ID),
    'autoplay' => esc_html__("Play Options", DZSAP_ID),
    'counters' => esc_html__("Counters", DZSAP_ID),
  );





  $i23 = 0;
  foreach ($dzsap->mainitems_configs as $vpconfig) {



    $aux = array(
      'label' => $vpconfig['settings']['id'],
      'value' => $vpconfig['settings']['id'],
    );




    foreach ($dzsap->options_slider as $lab => $so) {

      if ($so['name'] == 'vpconfig') {




        array_push($dzsap->options_slider[$lab]['options'], $aux);

        break;
      }
    }


    $i23++;
  }


  dzsap_sliders_admin_parse_options($term, 'main');


}

function dzsap_sliders_admin_parse_options($term, $cat = 'main') {

  global $dzsap;
  $indtem = 0;


  $t_id = $term->term_id;

  // retrieve the existing value(s) for this meta field. This returns an array
  $term_meta = get_option("taxonomy_$t_id");




  // -- we need real location, not insert-id

  $struct_uploader = '<div class="dzs-wordpress-uploader ">
<a href="#" class="button-secondary">' . esc_html__('Upload', DZSAP_ID) . '</a>
</div>';

  foreach ($dzsap->options_slider as $sliderOption) {






    if ($cat == 'main') {

      if (isset($sliderOption['category']) == false || (isset($sliderOption['category']) && $sliderOption['category'] == 'main')) {

      } else {
        continue;
      }
    } else {

      if ((isset($sliderOption['category']) && $sliderOption['category'] == $cat)) {

      } else {
        continue;
      }
    }
    if (!isset($sliderOption['title'])) {
      continue;
    }
    if ($indtem % 2 === 0) {



    }


    if (isset($sliderOption['choices'])) {
      $sliderOption['options'] = $sliderOption['choices'];
    }

    if (isset($sliderOption['sidenote'])) {
      $sliderOption['description'] = $sliderOption['sidenote'];
    }
    ?>
    <tr class="form-field" <?php


    if (isset($sliderOption['dependency'])) {

      echo ' data-dependency=\'' . json_encode($sliderOption['dependency']) . '\'';
    }

    ?>>
      <th scope="row" valign="top"><label
          for="term_meta[<?php echo $sliderOption['name']; ?>]"><?php echo $sliderOption['title']; ?></label></th>
      <td class="<?php
      if ($sliderOption['type'] == 'media-upload') {
        echo 'setting-upload';
      }
      ?>">


        <?php
        // -- main options

        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'color') {
          echo '<div class="uploader-three-floats">';
        }

        if ($sliderOption['type'] == 'media-upload') {
          echo '<span class="uploader-preview"></span>';
        }
        ?>



        <?php
        $lab = 'term_meta[' . $sliderOption['name'] . ']';

        $val = '';

        if (isset($term_meta[$sliderOption['name']])) {

          $val = esc_attr($term_meta[$sliderOption['name']]) ? esc_attr($term_meta[$sliderOption['name']]) : '';
        }

        $class = 'setting-field medium';


        if ($sliderOption['type'] == 'media-upload') {
          $class .= ' uploader-target';
        }

        if ($sliderOption['type'] == 'color') {
          $class .= ' wp-color-picker-init';
        }
        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'text' || $sliderOption['type'] == 'input' || $sliderOption['type'] == 'color') {


          if ($sliderOption['type'] == 'color') {
            $class .= ' with_colorpicker';
          }

          echo DZSHelpers::generate_input_text($lab, array(
            'class' => $class,
            'seekval' => $val,
            'id' => $lab,
          ));

        }


        if ($sliderOption['type'] == 'select') {




          $class .= ' dzs-style-me skin-beige';

          if (isset($sliderOption['select_type'])) {
            $class .= ' ' . $sliderOption['select_type'];
          }
          if (isset($sliderOption['extra_classes'])) {
            $class .= ' ' . $sliderOption['extra_classes'];
          }
          $class .= ' dzs-dependency-field';
          echo DZSHelpers::generate_select($lab, array(
            'class' => $class,
            'options' => $sliderOption['options'],
            'seekval' => $val,
            'id' => $lab,
          ));


          if (isset($sliderOption['select_type']) && $sliderOption['select_type'] == 'opener-listbuttons') {

            echo '<ul class="dzs-style-me-feeder">';

            foreach ($sliderOption['choices_html'] as $oim_html) {

              echo '<li>';
              echo $oim_html;
              echo '</li>';
            }

            echo '</ul>';


          }
        }

        if ($sliderOption['type'] == 'color') {



          echo '<div class="picker-con"><div class="the-icon"></div><div class="picker"></div></div>';
        }


        // -- media upload
        if ($sliderOption['type'] == 'media-upload') {

          echo '<div class="dzs-wordpress-uploader here-uploader ">
<a href="#" class="button-secondary';


          if (isset($sliderOption['upload_btn_extra_classes']) && $sliderOption['upload_btn_extra_classes']) {
            echo ' ' . $sliderOption['upload_btn_extra_classes'];
          }


          echo '">' . esc_html__('Upload', DZSAP_ID) . '</a>
</div>';

        }
        ?>
        <?php


        if ($sliderOption['type'] == 'media-upload' || $sliderOption['type'] == 'color') {
          echo '</div><!-- end uploader three floats -->';
        }

        $description = '';
        if (isset($sliderOption['description'])) {
          $description = $sliderOption['description'];
        }

        if ($description) {
          ?>
          <p class="description"><?php echo $description; ?></p>
          <?php


        }
        ?>
      </td>
    </tr>
    <?php

    $indtem++;
  }

}
