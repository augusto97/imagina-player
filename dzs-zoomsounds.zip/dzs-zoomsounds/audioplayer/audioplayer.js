/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "../source/audioplayer/configs/_constants.js":
/*!***************************************************!*\
  !*** ../source/audioplayer/configs/_constants.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConstantsDzsAp": () => (/* binding */ ConstantsDzsAp),
/* harmony export */   "DEBUG_STYLE_PLAY_FUNCTIONS": () => (/* binding */ DEBUG_STYLE_PLAY_FUNCTIONS),
/* harmony export */   "DZSAP_AJAX_ACTION_LIKE": () => (/* binding */ DZSAP_AJAX_ACTION_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_AJAX_LIKE": () => (/* binding */ DZSAP_CLASS_NAME_AJAX_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_FEED_EMBED_CODE": () => (/* binding */ DZSAP_CLASS_NAME_FEED_EMBED_CODE),
/* harmony export */   "DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS": () => (/* binding */ DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOOTER_PLAYER": () => (/* binding */ DZSAP_PLAYER_CLASS_FOOTER_PLAYER),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW": () => (/* binding */ DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW),
/* harmony export */   "DZSAP_PLAYER_CLASS_LOADED": () => (/* binding */ DZSAP_PLAYER_CLASS_LOADED),
/* harmony export */   "DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED": () => (/* binding */ DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_KEYBOARD": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_KEYBOARD),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS),
/* harmony export */   "DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT": () => (/* binding */ DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT),
/* harmony export */   "DZSAP_VIEW_SONG_CHANGER_CLASS": () => (/* binding */ DZSAP_VIEW_SONG_CHANGER_CLASS),
/* harmony export */   "WAVESURFER_MAX_TIMEOUT": () => (/* binding */ WAVESURFER_MAX_TIMEOUT)
/* harmony export */ });
const DEBUG_STYLE_PLAY_FUNCTIONS = 'background-color: #daffda; color: #222222;';
const WAVESURFER_MAX_TIMEOUT = 20000;

const ConstantsDzsAp = {
  PLAYLIST_TRANSITION_DURATION: 300,
  'DEBUG_STYLE_1': 'background-color: #aaa022; color: #222222;',
  'DEBUG_STYLE_2': 'background-color: #7c3b8e; color: #ffffff;',
  'DEBUG_STYLE_3': 'background-color: #3a696b; color: #eeeeee;',
  'DEBUG_STYLE_ERROR': 'background-color: #3a696b; color: #eeeeee;',
  URL_WAVESURFER_HELPER_BACKUP: 'https://zoomthe.me/assets/dzsap-wave-generate.js',
  WAVESURFER_MAX_TIMEOUT,
  DEBUG_STYLE_PLAY_FUNCTIONS,
  URL_JQUERY: 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js',
  ERRORED_OUT_CLASS: 'errored-out',
  ERRORED_OUT_MAX_ATTEMPTS: 5
}

const DZSAP_PLAYER_CLASS_FOOTER_PLAYER = 'dzsap_footer';
const DZSAP_PLAYER_CLASS_LOADED = 'dzsap-loaded';
const DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW = 'audioplayer-loaded';
const DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom';
const DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom-placeholder';
const DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED = 'fake';
const DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS = 'last';
const DZSAP_CLASS_NAME_AJAX_LIKE = 'btn-like';
const DZSAP_CLASS_NAME_FEED_EMBED_CODE = 'feed-dzsap--embed-code';

const DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS = '#dzsap-main-settings';
const DZSAP_SCRIPT_SELECTOR_KEYBOARD = '#dzsap-keyboard-controls';
const DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT = 500;
const DZSAP_AJAX_ACTION_LIKE = 'dzsap_submit_like';
const DZSAP_VIEW_SONG_CHANGER_CLASS = 'audioplayer-song-changer';


/***/ }),

/***/ "../source/audioplayer/configs/_settingsPlayer.js":
/*!********************************************************!*\
  !*** ../source/audioplayer/configs/_settingsPlayer.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "defaultPlayerOptions": () => (/* binding */ defaultPlayerOptions)
/* harmony export */ });
const defaultPlayerOptions = {
  design_skin: 'skin-default',  // -- the skin of the player - can be set from the html as well,autoplay: 'off' // -- autoplay the track ( only works is cue is set to "on"
  call_from: 'default', // -- call from a specific api
  autoplay_on_scrub_click: 'off',  // -- autoplay the track ( only works is cue is set to "on"
  cueMedia: 'on', // -- this chooses wheter "on" or not "off" a part .. what part is decided by the preload_method below
  preload_method: 'metadata',  // -- "none" or "metadata" or "auto" ( whole track )
  loop: 'off',  // -- loop the track
  pause_method: 'pause',  // -- loop the track
  // -- extra HTML
  settings_extrahtml: '',  // -- some extra html - can be rates, plays, likes
  settings_extrahtml_before_play_pause: '',  // -- some extra html that you may want before play button
  settings_extrahtml_after_play_pause: '',  // -- some extra html that you may want after play button

  settings_trigger_resize: '0',  // -- check the player dimensions every x milli seconds
  design_thumbh: "default",  // -- thumbnail size
  extra_classes_player: '',
  disable_volume: 'default',
  disable_scrub: 'default',
  disable_timer: 'default', // -- disable timer display
  disable_player_navigation: 'off',
  scrub_show_scrub_time: 'on',
  player_navigation: 'default',  // -- auto decide if we need player navigation
  type: 'audio'
  , enable_embed_button: 'off' // -- enable the embed button
  , embed_code: '' // -- embed code
  , skinwave_dynamicwaves: 'off' // -- dynamic scale based on volume for no spectrum wave
  , soundcloud_apikey: '',  // -- set the sound cloud api key
  skinwave_enableSpectrum: 'off', // -- off or on
  skinwave_place_thumb_after_volume: 'off', // -- place the thumbnail after volume button
  skinwave_place_metaartist_after_volume: 'off', // -- place metaartist after volume button
  php_retriever: 'soundcloudretriever.php', // -- the soundcloud php file used to render soundcloud files,
  skinwave_mode: 'normal',  // -- "normal" or "small" or "alternate"
  skinwave_wave_mode: 'canvas',  // -- "normal" or "canvas" or "line"
  skinwave_wave_mode_canvas_mode: 'normal',  // -- "normal" or "reflecto"
  skinwave_wave_mode_canvas_normalize: 'on' // -- normalize wave to look more natural

  // -- wave settings
  , skinwave_wave_mode_canvas_waves_number: '3' // -- the number of waves in the canvas ( "1" pixel waves, "2" 2 pixel width waves, "3" 3 pixel width waves, "anything more then 3" means number of waves in the container, for example 100 means 100 waves in 1000px container if the container is 1000px width )
  , skinwave_wave_mode_canvas_waves_padding: '1' // -- padding between waves ( "1" 1 pixel between < - > "0" no reflection )
  , skinwave_wave_mode_canvas_reflection_size: '0.25',  // -- the reflection size ( "1" full size < - > "0" no reflection )
  wavesurfer_pcm_length: '200',  // -- define the precision of the wave generation; higher is more precise, but occupies more space

  pcm_data_try_to_generate: 'on',  // -- try to find out the pcm data and sent it via ajax ( maybe send it via php_handler
  pcm_data_try_to_generate_wait_for_real_pcm: 'on',  // -- if set to on, the fake pcm data will not be generated
  pcm_notice: 'off',  // -- show a notice for pcm
  notice_no_media: 'on',  // -- show a notice for when the media errors out

  sampleTimesMode: 'realPrevivew', // -- "realPreview" or "pseudoPreview"
  mobile_delete: "off",  // -- delete the whole player on mobile, useful for unwanted footer players in mobile
  footer_btn_playlist: "off",  // -- construct inner player playlist
  mobile_disable_fakeplayer: "off",  // -- disable feeding to other players on mobile
  skinwave_comments_displayontime: 'on', // -- display the comment when the scrub header is over it
  skinwave_comments_allow_post_if_not_logged_in: 'on', // -- allow posting in comments section if not looged in, to be logged in, skinwave_comments_account must be an account id

  skinwave_comments_links_to: '',  // -- clicking the comments bar will lead to this link ( optional )
  skinwave_comments_enable: 'off',  // -- enable the comments, publisher.php must be in the same folder as this html
  skinwave_comments_mode_outer_selector: '',  // -- the outer selector if it has one
  skinwave_comments_playerid: '',

  skinwave_timer_static: 'off',  // -- Timer indicators are static
  default_volume: 'default',  // -- number / set the default volume 0-1 or "last" for the last known volume
  volume_from_gallery: '',// -- the volume set from the gallery item select, leave blank if the player is not called from the gallery
  design_menu_show_player_state_button: 'off', // -- show a button that allows to hide or show the menu
  playfrom: 'off',  // -- off or specific number of settings or set to "last"
  design_animateplaypause: 'default'
  , embedded: 'off',  // // -- if embedded in a iframe
  embedded_iframe_id: '', // // -- if embedded in a iframe, specify the iframe id here
  google_analytics_send_play_event: 'off' // -- send the play event to google analytics, you need to have google analytics script already on your page
  , fakeplayer: null // -- if this is a fake player, it will feed
  , failsafe_repair_media_element: '' // -- some scripts might effect the media element used by zoomsounds, this is how we replace the media element in a certain time
  , action_audio_play: null // -- set a outer play function ( for example for tracking your analytics )
  , action_audio_play2: null // -- set a outer play function ( for example for tracking your analytics )
  , action_audio_pause: null, // -- set a outer play function ( for example for tracking your analytics )
  action_audio_end: null,  // -- set a outer ended function ( for example for tracking your analytics )
  action_audio_comment: null,  // -- set a outer commented function ( for example for tracking your analytics )
  action_received_time_total: null // -- event triggers at receiving time total
  , action_audio_change_media: null,  // -- set a outer on change track function
  action_audio_loaded_metadata: null,  // -- set a outer commented function ( for example for tracking your analytics )
  action_video_contor_60secs: null,  // -- fire every 30s
  type_audio_stop_buffer_on_unfocus: 'off',  // -- if set to on, when the audio player goes out of focus, it will unbuffer the file so that it will not load anymore, useful if you want to stop buffer on large files


  settings_exclude_from_list: 'off',  // -- a audioplayer list is formed at runtime so that when
  design_wave_color_bg: '222222',  // -- waveform background color..  000000,ffffff gradient is allowed
  design_wave_color_progress: 'ea8c52', // -- waveform progress color


  skin_minimal_button_size: '100',
  gallery_gapless_play: 'off', // -- play without pause
  preview_on_hover: 'off',  // -- on mouseenter autoplay the track
  controls_external_scrubbar: '',  // -- on mouseenter autoplay the track
  parentgallery: null, // -- the parent gallery of the player
  scrubbar_type: 'auto', // -- "wave" or "spectrum" or "bar"
  scrubbar_type_wave__has_reveal_animation: 'off',

  settings_php_handler: '', // -- the path of the publisher.php file, this is used to handle comments, likes etc. - can be "wpdefault"
};

// settings_extrahtml -- for plays use <div class="dzsap-counter counter-hits"><i class="fa fa-play"></i><span class="the-number">{{get_plays}}</span></div>


/***/ }),

/***/ "../source/audioplayer/js_common/_dzs_helpers.js":
/*!*******************************************************!*\
  !*** ../source/audioplayer/js_common/_dzs_helpers.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decode_json": () => (/* binding */ decode_json),
/* harmony export */   "dzsap_jQueryInit": () => (/* binding */ dzsap_jQueryInit),
/* harmony export */   "getBaseUrl": () => (/* binding */ getBaseUrl),
/* harmony export */   "getRelativeX": () => (/* binding */ getRelativeX),
/* harmony export */   "isInt": () => (/* binding */ isInt),
/* harmony export */   "isValid": () => (/* binding */ isValid),
/* harmony export */   "loadScriptIfItDoesNotExist": () => (/* binding */ loadScriptIfItDoesNotExist),
/* harmony export */   "sanitizeToCssPx": () => (/* binding */ sanitizeToCssPx),
/* harmony export */   "setupTooltip": () => (/* binding */ setupTooltip),
/* harmony export */   "simpleStringify": () => (/* binding */ simpleStringify),
/* harmony export */   "string_curateClassName": () => (/* binding */ string_curateClassName)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const decode_json = function (arg) {
  var fout = {};

  if (arg) {

    try {

      fout = JSON.parse(arg);
    } catch (err) {

      return null;
    }
  }

  return fout;
}
async function dzsap_jQueryInit(callback, reject) {

  return new Promise((resolve, reject) => {

    if (window.jQuery) {
      resolve('jQuery loaded');
    } else {
      const script = document.createElement('script');
      script.onload = function () {
        if (window.jQuery) {
          resolve('jQuery loaded');
        } else {
          reject('error loading');
        }
      };
      script.src = _configs_constants__WEBPACK_IMPORTED_MODULE_0__.ConstantsDzsAp.URL_JQUERY;

      document.head.appendChild(script);
    }

    setTimeout(() => {
      reject('error loading');
    }, 15000);
  })
}
/**
 *
 * @param {string} arg
 * @return {string}
 */
function string_curateClassName(arg){

  arg = arg.replace('feed-dzsap', '');
  arg = arg.replace('feed-dzsap--extra-html', '');
  return arg;
}


function simpleStringify (object){
  if (object && typeof object === 'object') {
    object = copyWithoutCircularReferences([object], object);
  }
  return JSON.stringify(object);

  function copyWithoutCircularReferences(references, object) {
    const cleanObject = {};
    Object.keys(object).forEach(function(key) {
      var value = object[key];
      if (value && typeof value === 'object') {
        if (references.indexOf(value) < 0) {
          references.push(value);
          cleanObject[key] = copyWithoutCircularReferences(references, value);
          references.pop();
        } else {
          cleanObject[key] = '###_Circular_###';
        }
      } else if (typeof value !== 'function') {
        cleanObject[key] = value;
      }
    });
    return cleanObject;
  }
}

const loadScriptIfItDoesNotExist = (scriptSrc, checkForVar) => {
  return new Promise((resolve, reject) => {
    if (checkForVar) {
      resolve('loadfromvar');
      return;
    }

    var script = document.createElement('script');
    script.onload = function () {
      resolve('loadfromload');
    };
    script.onerror = function () {
      reject();
    };
    script.src = scriptSrc;

    document.head.appendChild(script);
  })
}


const getBaseUrl = (baseUrlVar, scriptName) => {
  if (window[baseUrlVar]) {
    return window[baseUrlVar];
  }

  let scripts = document.getElementsByTagName("script");
  for (var scriptKey in scripts) {
    if (scripts[scriptKey] && scripts[scriptKey].src && String(scripts[scriptKey].src).indexOf(scriptName) > -1) {
      break;
    }
  }
  var baseUrl_arr = String(scripts[scriptKey].src).split('/');
  baseUrl_arr.splice(-1, 1);
  const result = string_addTrailingSlash(baseUrl_arr.join('/'));
  window[baseUrlVar] = result+'/';
  return result;
}

function string_addTrailingSlash(url){
  var lastChar = url.substr(-1); // Selects the last character
  if (lastChar != '/') {         // If the last character is not a slash
    url = url + '/';            // Append a slash to it.
  }
  return url;
}
const sanitizeToCssPx = (arg) => {

  if (String(arg).indexOf('%') > -1 || String(arg).indexOf('em') > -1 || String(arg).indexOf('px') > -1 || String(arg).indexOf('auto') > -1) {
    return arg;
  }
  return arg + 'px';
}


const setupTooltip = (args) => {

  var mainArgs = Object.assign({
    tooltipInnerHTML: '',
    tooltipIndicatorText: '',
    tooltipConClass: '',
  }, args)

  return `<div class="dzstooltip-con ${mainArgs.tooltipConClass}"><span class="dzstooltip main-tooltip   talign-end arrow-bottom style-rounded color-dark-light  dims-set transition-slidedown " style="width: 280px;"><span class="dzstooltip--inner">${mainArgs.tooltipInnerHTML}</span> </span></span><span class="tooltip-indicator">${mainArgs.tooltipIndicatorText}</span></div>`;
}


const isInt = function (n) {
  return typeof n == 'number' && Math.round(n) % 1 == 0;
}

const isValid = function (n) {
  return typeof n != 'undefined' && n != '';
}


function getRelativeX (mouseX, $el_) {
  if (jQuery) {
    return mouseX - jQuery($el_).offset().left;
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_ajax.js":
/*!**************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_ajax.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ajax_submit_download": () => (/* binding */ ajax_submit_download),
/* harmony export */   "ajax_submit_like": () => (/* binding */ ajax_submit_like),
/* harmony export */   "ajax_submit_total_time": () => (/* binding */ ajax_submit_total_time),
/* harmony export */   "ajax_submit_views": () => (/* binding */ ajax_submit_views)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");




const ajax_submit_views = function (argp) {


  var selfClass = this;
  var $ = jQuery;
  var data = {
    action: 'dzsap_submit_views',
    postdata: 1,
    playerid: selfClass.the_player_id,
    currip: selfClass.currIp,
    playerSource: selfClass.data_source
  };



  if (selfClass.cthis.attr('data-playerid-for-views')) {
    data.playerid = selfClass.cthis.attr('data-playerid-for-views');
  }


  if (data.playerid == '') {
    data.playerid = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzs_clean_string)(selfClass.data_source);
  }


  // -- submit view
  if (selfClass.urlToAjaxHandler) {
    $.ajax({
      type: "POST",
      url: selfClass.urlToAjaxHandler,
      data: data,
      success: function (response) {

        // -- increase number of hits
        let auxnr = selfClass.cthis.find('.counter-hits .the-number').html();
        auxnr = parseInt(auxnr, 10);
        if (selfClass.increment_views != 2) {
          auxnr++;
        }
        if (response) {
          if ((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.decode_json)(response)) {
            auxnr = (0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.decode_json)(response)['number'];
          }
        }

        selfClass.cthis.find('.counter-hits .the-number').html(auxnr);

        selfClass.ajax_view_submitted = 'on';
      },
      error: function (arg) {


        var auxlikes = selfClass.cthis.find('.counter-hits .the-number').html();
        auxlikes = parseInt(auxlikes, 10);
        auxlikes++;
        selfClass.cthis.find('.counter-hits .the-number').html(auxlikes);

        selfClass.ajax_view_submitted = 'on';
      }
    });
    selfClass.ajax_view_submitted = 'on';
  }

}

const ajax_submit_like = function (argp) {
  var selfClass = this;
  var $ = jQuery;

  //only handles ajax call + result
  var mainarg = argp;
  var data = {
    action: _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_AJAX_ACTION_LIKE,
    postdata: mainarg,
    playerid: selfClass.the_player_id,
    playerSource: selfClass.data_source
  };


  selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_CLASS_NAME_AJAX_LIKE}`).addClass('disabled');

  if (selfClass.urlToAjaxHandler || selfClass.cthis.hasClass('is-preview')) {

    $.ajax({
      type: "POST",
      url: selfClass.urlToAjaxHandler,
      data: data,
      success: function (response) {


        selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_CLASS_NAME_AJAX_LIKE}`).addClass('active');
        selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_CLASS_NAME_AJAX_LIKE}`).removeClass('disabled');
        var auxlikes = selfClass.cthis.find('.counter-likes .the-number').html();
        auxlikes = parseInt(auxlikes, 10);
        auxlikes++;
        selfClass.cthis.find('.counter-likes .the-number').html(auxlikes);
      },
      error: function (arg) {


        selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_CLASS_NAME_AJAX_LIKE}`).addClass('active');
        selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_CLASS_NAME_AJAX_LIKE}`).removeClass('disabled');
        var auxlikes = selfClass.cthis.find('.counter-likes .the-number').html();
        auxlikes = parseInt(auxlikes, 10);
        auxlikes++;
        selfClass.cthis.find('.counter-likes .the-number').html(auxlikes);
      }
    });
  }
}





const ajax_submit_total_time = function (selfClass) {

  const isTheNeedToSendTotalTime = () => {

    return !selfClass.cthis.attr('data-sample_time_total') || (selfClass.cthis.attr('data-sample_time_total') && selfClass.timeModel.getActualTotalTime() && selfClass.timeModel.getActualTotalTime() != selfClass.cthis.attr('data-sample_time_total') && !selfClass.cthis.attr('data-sample_time_end'));
  }

  if (!selfClass.isSentCacheTotalTime) {
    if (isTheNeedToSendTotalTime()) {
      if (window.dzsap_settings && window.dzsap_settings.action_received_time_total) {
        selfClass.timeModel.refreshTimes();
        window['dzsap_functions'][window.dzsap_settings.action_received_time_total](selfClass.timeModel.getActualTotalTime(), selfClass.cthis);
      }
    }
    selfClass.isSentCacheTotalTime = true;
  }
}


const ajax_submit_download = function (argp) {
  //only handles ajax call + result
  var mainarg = argp;
  var selfClass = this;
  var data = {
    action: 'dzsap_submit_download',
    postdata: mainarg,
    playerid: selfClass.the_player_id
  };

  if (selfClass.starrating_alreadyrated > -1) {
    return;
  }

  if (selfClass.urlToAjaxHandler) {

    jQuery.ajax({
      type: "POST",
      url: selfClass.urlToAjaxHandler,
      data: data,
      success: function (response) {


      },
      error: function (arg) {


      }
    });
  }
};



/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_helpers.js":
/*!*****************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_helpers.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "add_query_arg": () => (/* binding */ add_query_arg),
/* harmony export */   "assignHelperFunctionsToJquery": () => (/* binding */ assignHelperFunctionsToJquery),
/* harmony export */   "assignPcmData": () => (/* binding */ assignPcmData),
/* harmony export */   "can_canvas": () => (/* binding */ can_canvas),
/* harmony export */   "can_history_api": () => (/* binding */ can_history_api),
/* harmony export */   "convertPluginOptionsToFinalOptions": () => (/* binding */ convertPluginOptionsToFinalOptions),
/* harmony export */   "dzs_clean_string": () => (/* binding */ dzs_clean_string),
/* harmony export */   "dzsapInitjQueryRegisters": () => (/* binding */ dzsapInitjQueryRegisters),
/* harmony export */   "dzsap_generate_keyboard_tooltip": () => (/* binding */ dzsap_generate_keyboard_tooltip),
/* harmony export */   "dzsap_is_mobile": () => (/* binding */ dzsap_is_mobile),
/* harmony export */   "dzsap_singleton_ready_calls": () => (/* binding */ dzsap_singleton_ready_calls),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "generateFakeArrayForPcm": () => (/* binding */ generateFakeArrayForPcm),
/* harmony export */   "get_query_arg": () => (/* binding */ get_query_arg),
/* harmony export */   "hexToRgb": () => (/* binding */ hexToRgb),
/* harmony export */   "htmlEncode": () => (/* binding */ htmlEncode),
/* harmony export */   "is_android": () => (/* binding */ is_android),
/* harmony export */   "is_android_good": () => (/* binding */ is_android_good),
/* harmony export */   "is_ios": () => (/* binding */ is_ios),
/* harmony export */   "is_safari": () => (/* binding */ is_safari),
/* harmony export */   "jQueryAuxBindings": () => (/* binding */ jQueryAuxBindings),
/* harmony export */   "playerFunctions": () => (/* binding */ playerFunctions),
/* harmony export */   "playerRegisterWindowFunctions": () => (/* binding */ playerRegisterWindowFunctions),
/* harmony export */   "player_checkIfWeShouldShowAComment": () => (/* binding */ player_checkIfWeShouldShowAComment),
/* harmony export */   "player_delete": () => (/* binding */ player_delete),
/* harmony export */   "player_determineStickToBottomContainer": () => (/* binding */ player_determineStickToBottomContainer),
/* harmony export */   "player_getPlayFromTime": () => (/* binding */ player_getPlayFromTime),
/* harmony export */   "player_identifySource": () => (/* binding */ player_identifySource),
/* harmony export */   "player_identifyTypes": () => (/* binding */ player_identifyTypes),
/* harmony export */   "player_isGoingToSetupMediaNow": () => (/* binding */ player_isGoingToSetupMediaNow),
/* harmony export */   "player_radio_isNameUpdatable": () => (/* binding */ player_radio_isNameUpdatable),
/* harmony export */   "player_reinit_findIfPcmNeedsGenerating": () => (/* binding */ player_reinit_findIfPcmNeedsGenerating),
/* harmony export */   "player_service_getSourceProtection": () => (/* binding */ player_service_getSourceProtection),
/* harmony export */   "player_stickToBottomContainerDetermineClasses": () => (/* binding */ player_stickToBottomContainerDetermineClasses),
/* harmony export */   "player_stopOtherPlayers": () => (/* binding */ player_stopOtherPlayers),
/* harmony export */   "player_syncPlayers_buildList": () => (/* binding */ player_syncPlayers_buildList),
/* harmony export */   "player_syncPlayers_gotoItem": () => (/* binding */ player_syncPlayers_gotoItem),
/* harmony export */   "player_view_addMetaLoaded": () => (/* binding */ player_view_addMetaLoaded),
/* harmony export */   "registerTextWidth": () => (/* binding */ registerTextWidth),
/* harmony export */   "sanitizeObjectForChangeMediaArgs": () => (/* binding */ sanitizeObjectForChangeMediaArgs),
/* harmony export */   "sanitizeToHexColor": () => (/* binding */ sanitizeToHexColor),
/* harmony export */   "sanitizeToIntFromPointTime": () => (/* binding */ sanitizeToIntFromPointTime),
/* harmony export */   "select_all": () => (/* binding */ select_all),
/* harmony export */   "string_jsonConvertToArray": () => (/* binding */ string_jsonConvertToArray),
/* harmony export */   "utils_sanitizeToColor": () => (/* binding */ utils_sanitizeToColor),
/* harmony export */   "view_player_globalDetermineSyncPlayersIndex": () => (/* binding */ view_player_globalDetermineSyncPlayersIndex),
/* harmony export */   "view_player_playMiscEffects": () => (/* binding */ view_player_playMiscEffects),
/* harmony export */   "waitForScriptToBeAvailableThenExecute": () => (/* binding */ waitForScriptToBeAvailableThenExecute)
/* harmony export */ });
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./player/_player_keyboard */ "../source/audioplayer/jsinc/player/_player_keyboard.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");





function formatTime(arg) {

  var s = Math.round(arg);
  var m = 0;
  var h = 0;
  if (s > 0) {
    while (s > 3599 && s < 3000000 && isFinite(s)) {
      h++;
      s -= 3600;
    }
    while (s > 59 && s < 3000000 && isFinite(s)) {
      m++;
      s -= 60;
    }
    if (h) {

      return String((h < 10 ? "0" : "") + h + ":" + String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s));
    }
    return String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s);
  } else {
    return "00:00";
  }
}

function can_history_api() {
  return !!(window.history && history.pushState);
}

function dzs_clean_string(arg) {

  if (arg) {

    arg = arg.replace(/[^A-Za-z0-9\-]/g, '');

    arg = arg.replace(/\./g, '');
    return arg;
  }

  return '';


}


function get_query_arg(purl, key) {
  if (purl) {

    if (String(purl).indexOf(key + '=') > -1) {

      var regexS = "[?&]" + key + "=.+";
      var regex = new RegExp(regexS);
      var regtest = regex.exec(purl);


      if (regtest != null) {
        var splitterS = regtest[0];
        if (splitterS.indexOf('&') > -1) {
          var aux = splitterS.split('&');
          splitterS = aux[1];
        }

        var splitter = splitterS.split('=');


        return splitter[1];

      }

    }

  } else {
  }
}

function add_query_arg(purl, key, value) {

  key = encodeURIComponent(key);
  value = encodeURIComponent(value);

  if (!(purl)) {
    purl = '';
  }
  var s = purl;
  var pair = key + "=" + value;

  var r = new RegExp("(&|\\?)" + key + "=[^\&]*");

  s = s.replace(r, "$1" + pair);

  if (s.indexOf(key + '=') > -1) {


  } else {
    if (s.indexOf('?') > -1) {
      s += '&' + pair;
    } else {
      s += '?' + pair;
    }
  }


  if (value === 'NaN') {
    var regex_attr = new RegExp('[\?|\&]' + key + '=' + value);
    s = s.replace(regex_attr, '');


    if (s.indexOf('?') === -1 && s.indexOf('&') > -1) {
      s = s.replace('&', '?');
    }
  }

  return s;
}


function dzsap_is_mobile() {


  return is_ios() || is_android();
}

function is_ios() {

  return ((navigator.platform.indexOf("iPhone") !== -1) || (navigator.platform.indexOf("iPod") !== -1) || (navigator.platform.indexOf("iPad") !== -1));
}


function can_canvas() {

  var oCanvas = document.createElement("canvas");
  return !!oCanvas.getContext("2d");

}

function is_safari() {
  return Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
}


function is_android() {
  var ua = navigator.userAgent.toLowerCase();

  return (ua.indexOf("android") > -1);
}

function select_all(el) {
  if (typeof window.getSelection !== "undefined" && typeof document.createRange !== "undefined") {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  } else if (typeof document.selection !== "undefined" && typeof document.body.createTextRange !== "undefined") {
    var textRange = document.body.createTextRange();
    textRange.moveToElementText(el);
    textRange.select();
  }
}

function is_android_good() {


}

function htmlEncode(arg) {
  return jQuery('<div/>').text(arg).html();
}

function dzsap_generate_keyboard_tooltip(keyboard_controls, lab) {


  let structureDzsTooltipCommentAfterSubmit = '<span class="dzstooltip color-dark-light talign-start transition-slidein arrow-bottom style-default" style="width: auto;  white-space:nowrap;"><span class="dzstooltip--inner">' + 'Shortcut' + ': ' + keyboard_controls[lab] + '</span></span>';

  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('32', 'space');
  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('27', 'escape');

  return structureDzsTooltipCommentAfterSubmit;


}


/**
 *
 * @param hex
 * @param {number|null} targetAlpha 0-1
 * @returns {string}
 */
function hexToRgb(hex, targetAlpha = null) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  var str = '';
  if (result) {
    result = {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    };


    var alpha = 1;

    if (targetAlpha !== null) {
      alpha = targetAlpha;
    }


    str = 'rgba(' + result.r + ',' + result.g + ',' + result.b + ',' + alpha + ')';
  }


  return str;


}

function assignHelperFunctionsToJquery($) {


  Math.easeIn = function (t, b, c, d) {
    return -c * (t /= d) * (t - 2) + b;
  };


  /**
   *
   * @param {string} argfind
   * @param {string} arg
   * @returns {string}
   */
  const checkIfHasClass = (argfind, arg) => {

    if (!argfind) {
      var regex = new RegExp('class="(.*?)"');
      var auxarr = regex.exec(arg);


      if (auxarr && auxarr[1]) {
        argfind = '.' + auxarr[1];
      }
    }

    return argfind;
  }
  $.fn.prependOnce = function (arg, argfind) {
    var _t = $(this)


    argfind = checkIfHasClass(argfind, arg);


    if (_t.children(argfind).length < 1) {
      _t.prepend(arg);
      return true;
    }
    return false;
  };
  $.fn.appendOnce = function (arg, argfind) {
    var _t = $(this)

    argfind = checkIfHasClass(argfind, arg);

    if (_t.children(argfind).length < 1) {
      _t.append(arg);
      return true;
    }
    return false;
  };
};


function registerTextWidth($) {

  $.fn.textWidth = function () {
    var _t = jQuery(this);
    var html_org = _t.html();
    if (_t[0].nodeName === 'INPUT') {
      html_org = _t.val();
    }
    var html_calcS = '<span class="forcalc">' + html_org + '</span>';
    jQuery('body').append(html_calcS);
    var _lastspan = jQuery('span.forcalc').last();

    _lastspan.css({
      'font-size': _t.css('font-size'),
      'font-family': _t.css('font-family')
    })
    var width = _lastspan.width();

    _lastspan.remove();
    return width;
  };
}

function player_checkIfWeShouldShowAComment(selfClass, real_time_curr, real_time_total) {

  var $ = jQuery;
  var timer_curr_perc = Math.round((real_time_curr / real_time_total) * 100) / 100;
  if (selfClass.audioType === 'fake') {
    timer_curr_perc = Math.round((selfClass.timeCurrent / selfClass.timeTotal) * 100) / 100;
  }
  if (selfClass._commentsHolder) {
    selfClass._commentsHolder.children().each(function () {
      var _t = $(this);
      if (_t.hasClass('dzstooltip-con')) {
        var _t_posx = _t.offset().left - selfClass._commentsHolder.offset().left;


        var aux = Math.round((parseFloat(_t_posx) / selfClass._commentsHolder.outerWidth()) * 100) / 100;


        if (aux) {

          if (Math.abs(aux - timer_curr_perc) < 0.02) {
            selfClass._commentsHolder.find('.dzstooltip').removeClass('active');
            _t.find('.dzstooltip').addClass('active');
          } else {
            _t.find('.dzstooltip').removeClass('active');
          }
        }
      }
    })
  }
}


function sanitizeObjectForChangeMediaArgs(_sourceForChange) {

  var changeMediaArgs = {};
  var _feed_fakePlayer = _sourceForChange;

  var lab = '';

  if (_sourceForChange.data('original-settings')) {
    return _sourceForChange.data('original-settings');
  }


  changeMediaArgs.source = null;
  if (_feed_fakePlayer.attr('data-source')) {
    changeMediaArgs.source = _feed_fakePlayer.attr('data-source')
  } else {

    if (_feed_fakePlayer.attr('href')) {
      changeMediaArgs.source = _feed_fakePlayer.attr('href');
    }
  }

  if (_feed_fakePlayer.attr('data-pcm')) {
    changeMediaArgs.pcm = _feed_fakePlayer.attr('data-pcm');
  }


  lab = 'thumb';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }

  lab = 'playerid';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }
  lab = 'type';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }


  if (_feed_fakePlayer.attr('data-thumb_link')) {
    changeMediaArgs.thumb_link = _sourceForChange.attr('data-thumb_link');
  }


  if (_sourceForChange.find('.meta-artist').length > 0 || _sourceForChange.find('.meta-artist-con').length > 0) {

    changeMediaArgs.artist = _sourceForChange.find('.the-artist').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.the-name').eq(0).html();
  }


  if (_sourceForChange.attr('data-thumb_for_parent')) {
    changeMediaArgs.thumb = _sourceForChange.attr('data-thumb_for_parent');
  }


  if (_sourceForChange.find('.feed-song-name').length > 0 || _sourceForChange.find('.feed-artist-name').length > 0) {
    changeMediaArgs.artist = _sourceForChange.find('.feed-artist-name').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.feed-song-name').eq(0).html();
  }


  return changeMediaArgs;
}


function utils_sanitizeToColor(colorString) {
  if (colorString.indexOf('#') === -1 && colorString.indexOf('rgb') === -1 && colorString.indexOf('hsl') === -1) {
    return '#' + colorString;
  }
  return colorString;
}

function dzsapInitjQueryRegisters() {
}

function player_radio_isNameUpdatable(selfClass, radio_update_song_name, targetKey) {

  if (selfClass._metaArtistCon.find(targetKey).length && selfClass._metaArtistCon.find(targetKey).eq(0).text().length > 0) {

    if (selfClass._metaArtistCon.find(targetKey).eq(0).html().indexOf('{{update}}') > -1) {
      return true;
    }
  }


  return false;
}

function playerRegisterWindowFunctions() {


  window['dzsap_functions'] = {};
  window['dzsap_functions']['send_total_time'] = function (argtime, argcthis) {


    if (argtime && argtime !== Infinity) {
      const data = {
        action: 'dzsap_send_total_time_for_track',
        id_track: argcthis.attr('data-playerid'),
        postdata: Math.ceil(argtime)
      };
      jQuery.post(window.dzsap_ajaxurl, data, function (response) {
      });
    }

  }


  window.dzs_open_social_link = function (arg, argthis) {
    var leftPosition, topPosition;
    var w = 500, h = 500;

    leftPosition = (window.screen.width / 2) - ((w / 2) + 10);

    topPosition = (window.screen.height / 2) - ((h / 2) + 50);
    var windowFeatures = "status=no,height=" + h + ",width=" + w + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";


    arg = arg.replace('{{replacewithcurrurl}}', encodeURIComponent(window.location.href));

    if (argthis && argthis.attr) {
      arg = arg.replace(/{{replacewithdataurl}}/g, argthis.attr('data-url'));
    }

    const locationHref = window.location.href;


    const auxa = locationHref.split('?');

    let cid = '';
    let cid_gallery = '';


    if (argthis) {

    } else {
      if (window.dzsap_currplayer_from_share) {

        argthis = window.dzsap_currplayer_from_share;
      }
    }


    if (argthis) {

      const $ = jQuery;

      if ($(argthis).hasClass('audioplayer')) {
        cid = $(argthis).parent().children().index(argthis);
        cid_gallery = $(argthis).parent().parent().parent().attr('id');
      } else {
        if (jQuery(argthis).parent().parent().attr('data-menu-index')) {

          cid = jQuery(argthis).parent().parent().attr('data-menu-index');
        }
        if (jQuery(argthis).parent().parent().attr('data-gallery-id')) {

          cid_gallery = jQuery(argthis).parent().parent().attr('data-gallery-id');
        }
      }

    }


    var shareurl = encodeURIComponent(auxa[0] + '?fromsharer=on&audiogallery_startitem_' + cid_gallery + '=' + cid + '');
    arg = arg.replace('{{shareurl}}', shareurl);


    window.open(arg, "sharer", windowFeatures);
  }


  window.dzsap_wp_send_contor_60_secs = function (argcthis, argtitle) {

    var data = {
      video_title: argtitle

      , video_analytics_id: argcthis.attr('data-playerid')
      , curr_user: window.dzsap_curr_user
    };
    var theajaxurl = 'index.php?action=ajax_dzsap_submit_contor_60_secs';

    if (window.dzsap_settings.dzsap_site_url) {

      theajaxurl = dzsap_settings.dzsap_site_url + theajaxurl;
    }


    jQuery.ajax({
      type: "POST",
      url: theajaxurl,
      data: data,
      success: function (response) {


      },
      error: function (arg) {

      }
    });
  }


  window.dzsap_init_multisharer = function () {


  }


}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function assignPcmData(selfClass) {

  selfClass.pcmSource = string_jsonConvertToArray(selfClass.cthis.attr('data-pcm'));
  if (selfClass.initOptions.skinwave_enableSpectrum === 'on') {
    var pcmSourceLen = selfClass.pcmSource.length;
    var desiredSize = 256;

    for (var i = 0; i < pcmSourceLen; i++) {
      if (i > desiredSize) {
        continue;
      }
      selfClass.pcmSource[i] = selfClass.pcmSource[i * pcmSourceLen / desiredSize] * desiredSize;
    }
    selfClass.pcmSource.splice(desiredSize, pcmSourceLen - desiredSize); // removes 3rd element of array
  }
}

function string_jsonConvertToArray(ar_str) {
  let waves = [];
  if (typeof (ar_str) == 'object') {
    waves = ar_str;
  } else {
    try {
      waves = JSON.parse(ar_str);
    } catch (err) {

    }
  }

  return waves;
}

/**
 * should be called only once on init
 */
function dzsap_singleton_ready_calls() {

  window.dzsap_singleton_ready_calls_is_called = true;


  let $feed_dzsapMainSettings = null;
  const $feed_dzsapMainSettingsAll = document.querySelectorAll('.dzsap-main-settings');
  if ($feed_dzsapMainSettingsAll.length) {
    $feed_dzsapMainSettings = $feed_dzsapMainSettingsAll[$feed_dzsapMainSettingsAll.length - 1];
  }
  if ($feed_dzsapMainSettings) {
    window.dzsap_settings = JSON.parse($feed_dzsapMainSettings.innerHTML);
    window.ajaxurl = window.dzsap_settings.ajax_url;
    window.dzsap_curr_user = window.dzsap_settings.dzsap_curr_user;
  }


  jQuery('body').append('<style class="dzsap--style"></style>');


  window.dzsap__style = jQuery('.dzsap--style');


  jQuery('audio.zoomsounds-from-audio').each(function () {
    var _t = jQuery(this);
    _t.after('<div class="audioplayer-tobe auto-init skin-silver" data-source="' + _t.attr('src') + '"></div>');
    _t.remove();
  })

  jQuery(document).on('focus.dzsap', 'input', function () {
    window.dzsap_currplayer_focused = null;
  })

  registerTextWidth(jQuery);

  (0,_player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__.dzsap_keyboardSetup)();
}

function jQueryAuxBindings($) {


  function handleClick_onGlobalZoomSoundsButton(e) {
    const $t = $(this);


    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if ($t.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS)) {
      const _c = $($t.attr('data-fakeplayer')).eq(0);


      if (_c && _c.get(0) && _c.get(0).api_change_media) {
        _c.get(0).api_change_media($t, {
          'feeder_type': 'button'
          , 'call_from': 'changed ' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS
        });
      }

      return false;
    }


  }


  $(document).off('click.dzsap_metas')
  $(document).on('click.dzsap_metas', '.' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS, handleClick_onGlobalZoomSoundsButton)


}


/**
 * for .zoomsounds-wrapper-bg-center
 * @param selfClass
 */
function view_player_playMiscEffects(selfClass) {

  selfClass.$conPlayPause.addClass('playing');

  if (selfClass.cthis.parent().hasClass('zoomsounds-wrapper-bg-center')) {
    selfClass.cthis.parent().addClass('is-playing');
  }
}


function view_player_globalDetermineSyncPlayersIndex(selfClass) {

  if (selfClass._sourcePlayer === null && window.dzsap_syncList_players) {
    window.dzsap_syncList_players.forEach(($syncPlayer, index) => {
      if (selfClass.cthis.attr('data-playerid') == $syncPlayer.attr('data-playerid')) {
        window.dzsap_syncList_index = index;
      }
    })
  }
}


function player_view_addMetaLoaded(selfClass) {

  selfClass.cthis.addClass('meta-loaded');
  selfClass.cthis.removeClass('meta-fake');
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
    selfClass._sourcePlayer.removeClass('meta-fake');
  }
  if (selfClass.$totalTime) {

    selfClass.timeModel.refreshTimes();
    selfClass.$totalTime.html(formatTime(selfClass.timeModel.getVisualTotalTime()));
  }
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
  }
}


function htmlEntities(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function waitForScriptToBeAvailableThenExecute(verifyVar, callbackFn) {

  new Promise((resolve, reject) => {

    let checkInterval = 0;

    function checkIfVarExists() {
      if (verifyVar) {
        clearInterval(checkInterval);
        resolve('var exists');
      }
    }

    checkIfVarExists()
    checkInterval = setInterval(checkIfVarExists, 300);
    setTimeout(() => {
      reject('timeout');
    }, 5000);

  }).then((resolve => {
    callbackFn(resolve);
  })).catch((err) => {
  })
}


function player_reinit_findIfPcmNeedsGenerating(selfClass) {
  const o = selfClass.initOptions;

  if (selfClass.cthis.attr('data-pcm')) {
    selfClass.hasInitialPcmData = true;
  }

  if (!selfClass.hasInitialPcmData && o.skinwave_wave_mode === 'canvas' && (o.design_skin === 'skin-wave' || selfClass.cthis.attr('data-fakeplayer'))) {
    selfClass.isPcmRequiredToGenerate = true;
  }


  if (o.scrubbar_type === 'wave') {
    if (o.is_inited_from_playlist) {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (o.scrubbar_type_wave__has_reveal_animation === 'on') {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (selfClass.isPcmRequiredToGenerate) {
      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
  }
}


function playerFunctions(selfClass, functionType) {
  var o = selfClass.initOptions;

  if (functionType === 'detectIds') {


    if (o.skinwave_comments_playerid === '') {
      if (typeof (selfClass.cthis.attr('id')) !== 'undefined') {
        selfClass.the_player_id = selfClass.cthis.attr('id');
      }
    }


    if (selfClass.the_player_id == '') {

      if (selfClass.cthis.attr('data-computed-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-computed-playerid');
      }
      if (selfClass.cthis.attr('data-real-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-real-playerid');
      }
    }
    selfClass.uniqueId = selfClass.the_player_id;

    if (typeof selfClass.uniqueId === 'string') {
      selfClass.uniqueId = selfClass.uniqueId.replace('ap', '');
    }
    selfClass.identifier_pcm = selfClass.uniqueId;


    if (selfClass.uniqueId === '') {
      o.skinwave_comments_enable = 'off';
    }

  }
}

function player_delete(selfClass) {

  var _con = null;
  if (selfClass.cthis.parent().parent().hasClass('dzsap-sticktobottom')) {
    _con = selfClass.cthis.parent().parent();
  }
  if (_con) {
    if (_con.prev().hasClass("dzsap-sticktobottom-placeholder")) {
      _con.prev().remove();
    }
    _con.remove();
  }
  selfClass.cthis.remove();
  return false;
}


function sanitizeToHexColor(hexcolor) {
  if (hexcolor.indexOf('#') === -1) {
    hexcolor = '#' + hexcolor;
  }
  return hexcolor;
}

function player_identifySource(selfClass) {

  selfClass.data_source = selfClass.cthis.attr('data-source') || '';
}

function player_identifyTypes(selfClass) {


  var o = selfClass.initOptions;
  const cthis = selfClass.cthis;
  if (cthis.attr('data-type') === 'youtube') {
    o.type = 'youtube';
    selfClass.audioType = 'youtube';
  }
  if (cthis.attr('data-type') === 'soundcloud') {
    o.type = 'soundcloud';
    selfClass.audioType = 'soundcloud';

    o.skinwave_enableSpectrum = 'off';
    cthis.removeClass('skin-wave-is-spectrum');
  }
  if (cthis.attr('data-type') === 'mediafile') {
    o.type = 'audio';
    selfClass.audioType = 'audio';
  }

  if (cthis.attr('data-type') === 'shoutcast') {
    o.type = 'shoutcast';
    selfClass.audioType = 'audio';
    o.disable_timer = 'on';
    o.skinwave_enableSpectrum = 'off';

    if (!cthis.attr('data-streamtype')) {

      selfClass.audioTypeSelfHosted_streamType = 'shoutcast';
    }


    if (o.design_skin === 'skin-default') {
      o.disable_scrub = 'on';
    }

  }


  if (selfClass.audioType === 'audio' || selfClass.audioType === 'normal' || selfClass.audioType === '') {
    selfClass.audioType = 'selfHosted';
  }


  if (String(selfClass.data_source).indexOf('https://soundcloud.com/') > -1) {
    selfClass.audioType = 'soundcloud';
  }
}


function player_getPlayFromTime(selfClass) {

  selfClass.playFrom = selfClass.initOptions.playfrom;

  if ((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__.isValid)(selfClass.cthis.attr('data-playfrom'))) {
    selfClass.playFrom = selfClass.cthis.attr('data-playfrom');
  }

  if (isNaN(parseInt(selfClass.playFrom, 10)) === false) {
    selfClass.playFrom = parseInt(selfClass.playFrom, 10);
  }


  if (selfClass.playFrom === 'off' || selfClass.playFrom === '') {
    if (get_query_arg(window.location.href, 'audio_time')) {
      selfClass.playFrom = sanitizeToIntFromPointTime(get_query_arg(window.location.href, 'audio_time'));
    }
  }

  if (selfClass.timeModel.sampleTimeStart) {
    if (selfClass.playFrom < selfClass.timeModel.sampleTimeStart) {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
    if (typeof selfClass.playFrom === 'string') {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
  }
}


function sanitizeToIntFromPointTime(arg) {


  arg = String(arg).replace('%3A', ':');
  arg = String(arg).replace('#', '');

  if (arg && String(arg).indexOf(':') > -1) {

    var arr = /(\d.*):(\d.*)/g.exec(arg);


    var m = parseInt(arr[1], 10);
    var s = parseInt(arr[2], 10);


    return (m * 60) + s;
  } else {
    return Number(arg);
  }
}


/**
 * called in player init()
 * @param {DzsAudioPlayer} selfClass
 */
function player_determineStickToBottomContainer(selfClass) {

  let $conTest = selfClass.cthis.parent();


  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;

  }
  $conTest = selfClass.cthis.parent().parent();
  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;
  }
}


/**
 *
 * todo: maybe move
 * @param {DzsAudioPlayer} selfClass
 */
function player_stickToBottomContainerDetermineClasses(selfClass) {

  if (selfClass.$stickToBottomContainer) {
    if (selfClass.cthis.hasClass('theme-dark')) {
      selfClass.$stickToBottomContainer.addClass('theme-dark');
    }

    setTimeout(function () {

      selfClass.$stickToBottomContainer.addClass('inited');
    }, 500)


  }

}

function player_service_getSourceProtection(selfClass) {

  return new Promise((resolve, reject) => {

    jQuery.ajax({
      type: "POST",
      url: selfClass.data_source,
      data: {},
      success: function (response) {
        resolve(response);
      },
      error: function (err) {
        reject(err);
      }
    });
  })
}

function player_isGoingToSetupMediaNow(selfClass) {
  return selfClass.audioTypeSelfHosted_streamType !== 'icecast' && selfClass.audioType !== 'youtube';
}


function player_stopOtherPlayers(dzsap_list, selfClass) {

  let i = 0;
  for (i = 0; i < dzsap_list.length; i++) {

    if (dzsap_list[i].get(0) && dzsap_list[i].get(0).api_pause_media && (dzsap_list[i].get(0) != selfClass.cthis.get(0))) {


      if (dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') && dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') === 'on') {
        dzsap_list[i].get(0).api_destroy_for_rebuffer();
      } else {
        dzsap_list[i].get(0).api_pause_media({
          'audioapi_setlasttime': false
        });
      }
    }
  }
}


function player_syncPlayers_gotoItem(selfClass, targetIncrement) {
  if (window.dzsap_settings.syncPlayers_autoplayEnabled) {

    for (let keySyncPlayer in window.dzsap_syncList_players) {
      let $playerInSyncList = selfClass.cthis;

      if (selfClass._sourcePlayer) {
        $playerInSyncList = selfClass._sourcePlayer;
      }


      if (window.dzsap_syncList_players[keySyncPlayer].get(0) === $playerInSyncList.get(0)) {

        keySyncPlayer = parseInt(keySyncPlayer, 10);
        let targetIndex = window.dzsap_syncList_index + targetIncrement;
        if (targetIndex >= 0 && targetIndex < window.dzsap_syncList_players.length) {
          const $currentSyncPlayer_ = window.dzsap_syncList_players[targetIndex].get(0);


          if ($currentSyncPlayer_ && $currentSyncPlayer_.api_play_media) {
            setTimeout(function () {
              $currentSyncPlayer_.api_play_media({
                'called_from': 'api_sync_players_prev'
              });
            }, 200);

          }
        }
      }
    }
  }

}

function player_syncPlayers_buildList() {

  if (!window.syncPlayers_isDzsapListBuilt) {

    window.dzsap_syncList_players = [];

    window.syncPlayers_isDzsapListBuilt = true;

    jQuery('.audioplayer.is-single-player,.audioplayer-tobe.is-single-player').each(function () {
      const _t23 = jQuery(this);


      if (_t23.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_FOOTER_PLAYER)) {
        return;
      }


      if (_t23.attr('data-do-not-include-in-list') !== 'on') {
        window.dzsap_syncList_players.push(_t23);
      }
    })


    clearTimeout(window.syncPlayers_buildTimeout);

    window.syncPlayers_buildTimeout = setTimeout(function () {
      window.syncPlayers_isDzsapListBuilt = false;
    }, 500);

  }

}


function convertPluginOptionsToFinalOptions(elThis, defaultOptions, argOptions = null, searchedAttr = 'data-options', $es) {

  var finalOptions = null;
  var tempOptions = {};
  var isSetFromJson = false;

  if ($es === undefined) {
    $es = jQuery;
  }


  var $elThis = $es(elThis);

  const isArgOptionsDefinedViaJs = Boolean(argOptions && typeof argOptions === 'object' && Object.keys(argOptions).length);


  if (isArgOptionsDefinedViaJs) {
    tempOptions = argOptions;
  } else {
    if ($elThis.attr(searchedAttr)) {
      try {
        tempOptions = JSON.parse($elThis.attr(searchedAttr));
        isSetFromJson = true;
      } catch (err) {
        console.log('err - ',err);

      }
    }
    if (!isSetFromJson) {
      if (typeof $elThis.attr(searchedAttr) != 'undefined' && $elThis.attr('data-options') != '') {
        let aux = $elThis.attr(searchedAttr);
        aux = 'var aux_opts = ' + aux;
        eval(aux);
        tempOptions = Object.assign({}, argOptions);
      }
    }
  }
  finalOptions = Object.assign(defaultOptions, tempOptions);

  return finalOptions;
}

function generateFakeArrayForPcm() {


  var maxlen = 256;

  var arr = [];

  for (let it1 = 0; it1 < maxlen; it1++) {
    arr[it1] = Math.random() * 100;

  }

  return arr;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_misc.js":
/*!**************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_misc.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "retrieve_soundcloud_url": () => (/* binding */ retrieve_soundcloud_url)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");



function retrieve_soundcloud_url(selfClass, pargs) {


  var o = selfClass.initOptions;

  if (o.soundcloud_apikey == '') {
    alert('soundcloud api key not defined, read docs!');
  }
  var aux = 'https://api.' + 'soundcloud.com' + '/resolve?url=' + selfClass.data_source + '&format=json&consumer_key=' + o.soundcloud_apikey;



  aux = encodeURIComponent(aux);


  var soundcloud_retriever = o.php_retriever + '?scurl=' + aux;


  jQuery.ajax({
    type: "GET",
    url: soundcloud_retriever
    , data: {}
    , async: true
    , dataType: 'text'
    , error: function (err, q, t) {

    }
    , success: function (response) {


      var data = [];


      let newSource = '';
      try {
        data = JSON.parse(response);

        selfClass.audioType = 'selfHosted';


        if (data == '') {
          selfClass.cthis.addClass(_configs_constants__WEBPACK_IMPORTED_MODULE_0__.ConstantsDzsAp.ERRORED_OUT_CLASS);
          selfClass.cthis.append('<div class="feedback-text">soundcloud track does not seem to serve via api</div>');
        }



        selfClass.original_real_mp3 = selfClass.cthis.attr('data-source');
        if (data.stream_url) {

          newSource = data.stream_url + '?consumer_key=' + o.soundcloud_apikey + '&origin=localhost';
          selfClass.cthis.attr('data-source', newSource);


          if (selfClass.$feed_fakeButton) {
            selfClass.$feed_fakeButton.attr('data-source', newSource);
          }
          if (selfClass._sourcePlayer) {
            selfClass._sourcePlayer.attr('data-source', newSource);
          }
        } else {

          selfClass.cthis.addClass(_configs_constants__WEBPACK_IMPORTED_MODULE_0__.ConstantsDzsAp.ERRORED_OUT_CLASS);
          selfClass.cthis.append('<div class="feedback-text ">this soundcloud track does not allow streaming  </div>');
        }
        selfClass.data_source = newSource;


        if (selfClass.cthis.attr('data-pcm')) {
          selfClass.isAlreadyHasRealPcm = true;
        }
        if (o.design_skin == 'skin-wave') {
          if (o.skinwave_wave_mode == 'canvas') {
            if (selfClass.isAlreadyHasRealPcm == false) {
              if ((o.pcm_data_try_to_generate == 'on' && o.pcm_data_try_to_generate_wait_for_real_pcm == 'on') == false) {
                window.scrubModeWave__initGenerateWaveData(selfClass, {
                  'call_from': 'soundcloud init(), pcm not real..'
                });
              }
            }
          }
        }

        selfClass.setup_media({
          'called_from': 'change_media'
        });


        setTimeout(function () {


          if (selfClass.isPlayPromised) {
            selfClass.play_media({
              'call_from': 'change_media'
            })
            selfClass.isPlayPromised = false;
          }
        }, 300);
      } catch (err) {
        console.log('soduncloud parse error -', response, ' - ', soundcloud_retriever);
      }
    }
  });

}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_svgs.js":
/*!**************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_svgs.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pausebtn_svg": () => (/* binding */ pausebtn_svg),
/* harmony export */   "playbtn_svg": () => (/* binding */ playbtn_svg),
/* harmony export */   "svg_embed_btn": () => (/* binding */ svg_embed_btn),
/* harmony export */   "svg_menu_state": () => (/* binding */ svg_menu_state),
/* harmony export */   "svg_next_btn": () => (/* binding */ svg_next_btn),
/* harmony export */   "svg_prev_btn": () => (/* binding */ svg_prev_btn),
/* harmony export */   "svg_share_icon": () => (/* binding */ svg_share_icon)
/* harmony export */ });



const playbtn_svg = '<svg class="svg-icon" version="1.2" baseProfile="tiny" id="Layer_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="30px" viewBox="0 0 25 30" xml:space="preserve"> <path d="M24.156,13.195L2.406,0.25C2.141,0.094,1.867,0,1.555,0C0.703,0,0.008,0.703,0.008,1.562H0v26.875h0.008 C0.008,29.297,0.703,30,1.555,30c0.32,0,0.586-0.109,0.875-0.266l21.727-12.93C24.672,16.375,25,15.727,25,15 S24.672,13.633,24.156,13.195z"/> </svg>';
const pausebtn_svg = '<svg class="svg-icon" version="1.1" id="Layer_3" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="12px" height="13px" viewBox="0 0 13.415 16.333" enable-background="new 0 0 13.415 16.333" xml:space="preserve"> <path fill="#D2D6DB" d="M4.868,14.59c0,0.549-0.591,0.997-1.322,0.997H2.2c-0.731,0-1.322-0.448-1.322-0.997V1.618 c0-0.55,0.592-0.997,1.322-0.997h1.346c0.731,0,1.322,0.447,1.322,0.997V14.59z"/> <path fill="#D2D6DB" d="M12.118,14.59c0,0.549-0.593,0.997-1.324,0.997H9.448c-0.729,0-1.322-0.448-1.322-0.997V1.619 c0-0.55,0.593-0.997,1.322-0.997h1.346c0.731,0,1.324,0.447,1.324,0.997V14.59z"/> </svg>';





const svg_share_icon = '<svg class="svg-icon" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 511.626 511.627" style="enable-background:new 0 0 511.626 511.627;" xml:space="preserve"> <g> <path d="M506.206,179.012L360.025,32.834c-3.617-3.617-7.898-5.426-12.847-5.426s-9.233,1.809-12.847,5.426 c-3.617,3.619-5.428,7.902-5.428,12.85v73.089h-63.953c-135.716,0-218.984,38.354-249.823,115.06C5.042,259.335,0,291.03,0,328.907 c0,31.594,12.087,74.514,36.259,128.762c0.57,1.335,1.566,3.614,2.996,6.849c1.429,3.233,2.712,6.088,3.854,8.565 c1.146,2.471,2.384,4.565,3.715,6.276c2.282,3.237,4.948,4.859,7.994,4.859c2.855,0,5.092-0.951,6.711-2.854 c1.615-1.902,2.424-4.284,2.424-7.132c0-1.718-0.238-4.236-0.715-7.569c-0.476-3.333-0.715-5.564-0.715-6.708 c-0.953-12.938-1.429-24.653-1.429-35.114c0-19.223,1.668-36.449,4.996-51.675c3.333-15.229,7.948-28.407,13.85-39.543 c5.901-11.14,13.512-20.745,22.841-28.835c9.325-8.09,19.364-14.702,30.118-19.842c10.756-5.141,23.413-9.186,37.974-12.135 c14.56-2.95,29.215-4.997,43.968-6.14s31.455-1.711,50.109-1.711h63.953v73.091c0,4.948,1.807,9.232,5.421,12.847 c3.62,3.613,7.901,5.424,12.847,5.424c4.948,0,9.232-1.811,12.854-5.424l146.178-146.183c3.617-3.617,5.424-7.898,5.424-12.847 C511.626,186.92,509.82,182.636,506.206,179.012z" fill="#696969"/> </g></svg> ';





const svg_prev_btn = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="14px" height="14px" viewBox="0 0 12.5 12.817" enable-background="new 0 0 12.5 12.817" xml:space="preserve"> <g> <g> <g> <path fill="#D2D6DB" d="M2.581,7.375c-0.744-0.462-1.413-0.94-1.486-1.061C1.021,6.194,1.867,5.586,2.632,5.158l2.35-1.313 c0.765-0.427,1.505-0.782,1.646-0.789s0.257,1.03,0.257,1.905V7.87c0,0.876-0.051,1.692-0.112,1.817 C6.711,9.81,5.776,9.361,5.032,8.898L2.581,7.375z"/> </g> </g> </g> <g> <g> <g> <path fill="#D2D6DB" d="M6.307,7.57C5.413,7.014,4.61,6.441,4.521,6.295C4.432,6.15,5.447,5.42,6.366,4.906l2.82-1.577 c0.919-0.513,1.809-0.939,1.979-0.947s0.309,1.236,0.309,2.288v3.493c0,1.053-0.061,2.033-0.135,2.182S10.144,9.955,9.25,9.4 L6.307,7.57z"/> </g> </g> </g> </svg>';
const svg_next_btn = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="14px" height="14px" viewBox="0 0 12.5 12.817" enable-background="new 0 0 12.5 12.817" xml:space="preserve"> <g> <g> <g> <path fill="#D2D6DB" d="M9.874,5.443c0.744,0.462,1.414,0.939,1.486,1.06c0.074,0.121-0.771,0.729-1.535,1.156L7.482,8.967 C6.719,9.394,5.978,9.75,5.837,9.756C5.696,9.761,5.581,8.726,5.581,7.851V4.952c0-0.875,0.05-1.693,0.112-1.816 c0.062-0.124,0.995,0.326,1.739,0.788L9.874,5.443z"/> </g> </g> </g> <g> <g> <g> <path fill="#D2D6DB" d="M6.155,5.248c0.893,0.556,1.696,1.129,1.786,1.274c0.088,0.145-0.928,0.875-1.847,1.389l-2.811,1.57 c-0.918,0.514-1.808,0.939-1.978,0.947c-0.169,0.008-0.308-1.234-0.308-2.287V4.66c0-1.052,0.061-2.034,0.135-2.182 s1.195,0.391,2.089,0.947L6.155,5.248z"/> </g> </g> </g> </svg>';





const svg_menu_state = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="13.25px" height="13.915px" viewBox="0 0 13.25 13.915" enable-background="new 0 0 13.25 13.915" xml:space="preserve"> <path d="M1.327,4.346c-0.058,0-0.104-0.052-0.104-0.115V2.222c0-0.063,0.046-0.115,0.104-0.115H11.58 c0.059,0,0.105,0.052,0.105,0.115v2.009c0,0.063-0.046,0.115-0.105,0.115H1.327z"/> <path d="M1.351,8.177c-0.058,0-0.104-0.051-0.104-0.115V6.054c0-0.064,0.046-0.115,0.104-0.115h10.252 c0.058,0,0.105,0.051,0.105,0.115v2.009c0,0.063-0.047,0.115-0.105,0.115H1.351z"/> <path d="M1.351,12.182c-0.058,0-0.104-0.05-0.104-0.115v-2.009c0-0.064,0.046-0.115,0.104-0.115h10.252 c0.058,0,0.105,0.051,0.105,0.115v2.009c0,0.064-0.047,0.115-0.105,0.115H1.351z"/> </svg>';
const svg_embed_btn = '<svg class="svg-icon" version="1.2" baseProfile="tiny" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 15 15" xml:space="preserve"> <g id="Layer_1"> <polygon fill="#E6E7E8" points="1.221,7.067 0.494,5.422 4.963,1.12 5.69,2.767 "/> <polygon fill="#E6E7E8" points="0.5,5.358 1.657,4.263 3.944,10.578 2.787,11.676 "/> <polygon fill="#E6E7E8" points="13.588,9.597 14.887,8.34 12.268,2.672 10.969,3.93 "/> <polygon fill="#E6E7E8" points="14.903,8.278 14.22,6.829 9.714,11.837 10.397,13.287 "/> </g> <g id="Layer_2"> <rect x="6.416" y="1.713" transform="matrix(0.9663 0.2575 -0.2575 0.9663 2.1699 -1.6329)" fill="#E6E7E8" width="1.805" height="11.509"/> </g> </svg>';






/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_time_model.js":
/*!********************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_time_model.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayerTime": () => (/* binding */ PlayerTime)
/* harmony export */ });
/* harmony import */ var _media_media_functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./media/_media_functions */ "../source/audioplayer/jsinc/media/_media_functions.js");


/**
 * @property actualTotalTime
 */
class PlayerTime {

  /**
   *
   * @param {DzsAudioPlayer} selfClass
   */
  constructor(selfClass) {

    this.timeCurrent = 0;
    this.timeTotal = 0;
    this.sampleTimeStart = null;
    this.sampleTimeEnd = null;
    this.sampleTimeTotal = null;

    this.referenceMediaCurrentTime = 0;
    this.referenceMediaTotalTime = 0;

    this.visualCurrentTime = null;
    this.visualTotalTime = null;

    this.actualTotalTime = null;


    this.dzsapInstance = selfClass;
    this.init();
  }

  init() {


  }

  initObjects() {

    var selfClass = this.dzsapInstance;
    var timeInstance = this;


    // -- set current time
    selfClass.cthis.get(0).api_set_timeVisualCurrent = function (arg) {
      timeInstance.visualCurrentTime = arg;


    }
    selfClass.cthis.get(0).api_get_time_total = function () {

      return timeInstance.getVisualTotalTime();
    }
    selfClass.cthis.get(0).api_get_time_curr = function () {
      return timeInstance.getVisualCurrentTime();
    };

    // -- set total time
    selfClass.cthis.get(0).api_set_timeVisualTotal = function (arg) {


      timeInstance.visualTotalTime = arg;
      timeInstance.refreshTimes();


    };
  }


  /**
   * called from enterFrame and other places
   */
  refreshTimes() {

    const getCurrentTime = () => {
      if (false) {} else {

        // -- normal
        if (selfClass.$mediaNode_) {
          if (selfClass._actualPlayer === null) {
            return selfClass.$mediaNode_.currentTime;
          }
        }
      }

    }

    var selfClass = this.dzsapInstance;


    // -- trying to get current time

    if ((selfClass.audioType === 'selfHosted' || (selfClass.audioType === 'fake' && selfClass._actualPlayer))) {
      if (selfClass.audioTypeSelfHosted_streamType === '') {


        if (selfClass.$mediaNode_ && (0,_media_media_functions__WEBPACK_IMPORTED_MODULE_0__.isValidTotalTime)(selfClass.$mediaNode_.duration)) {
          this.referenceMediaTotalTime = selfClass.$mediaNode_.duration;
        }

        this.referenceMediaCurrentTime = getCurrentTime();



        if (selfClass.playFrom === 'last' && selfClass.playFrom_ready) {
          if (typeof Storage !== 'undefined') {
            localStorage['dzsap_' + selfClass.the_player_id + '_lastpos'] = selfClass.timeCurrent;
          }
        }


      }


    }



    if ((selfClass.audioType === 'youtube')) {

      if(selfClass.$mediaNode_ && selfClass.$mediaNode_.getDuration){
        this.referenceMediaCurrentTime = selfClass.$mediaNode_.getCurrentTime();
        this.referenceMediaTotalTime = selfClass.$mediaNode_.getDuration();
      }

    }

    if (selfClass._sourcePlayer && selfClass._sourcePlayer.get(0)) {


      if (selfClass._sourcePlayer.get(0).api_get_time_curr) {
        if (isNaN(selfClass._sourcePlayer.get(0).api_get_time_total()) || selfClass._sourcePlayer.get(0).api_get_time_total() === '' || selfClass._sourcePlayer.get(0).api_get_time_total() < 1) {
          selfClass._sourcePlayer.get(0).api_set_timeVisualTotal(this.getVisualTotalTime());
        }
      }
    }


    // -- setting real times ( if actual player is not there )
    if (selfClass._actualPlayer === null && this.referenceMediaCurrentTime > -1) {
      selfClass.timeCurrent = this.referenceMediaCurrentTime;
    }

    if (selfClass._actualPlayer === null && this.referenceMediaTotalTime > -1) {
      selfClass.timeTotal = this.referenceMediaTotalTime;
    }


    if (this.sampleTimeStart) {
      if (this.sampleTimeEnd) {
        if (selfClass.timeCurrent > this.sampleTimeEnd) {
          var args = {
            'call_from': 'time_curr>sample_time_end'
          }
          selfClass.handle_end(args);

          selfClass.isMediaEnded = true;

          clearTimeout(selfClass.inter_isEnded);
          selfClass.inter_isEnded = setTimeout(function () {

            selfClass.isMediaEnded = false;
          }, 1000);
        }
      }
    }
  }

  /**
   * call on every playing frame
   */
  processCurrentFrame() {

    var selfClass = this.dzsapInstance;
    if (selfClass._sourcePlayer) {
      if (selfClass._sourcePlayer.get(0)) {
        if (selfClass._sourcePlayer.get(0).api_get_time_curr) {
          selfClass._sourcePlayer.get(0).api_set_timeVisualCurrent(selfClass.timeCurrent);
        }
      }


      if (selfClass._sourcePlayer.get(0) && selfClass._sourcePlayer.get(0).api_seek_to_visual) {
        var temp_time_curr = selfClass.timeCurrent;
        // TODO: to be continued


        selfClass._sourcePlayer.get(0).api_seek_to_visual(temp_time_curr / selfClass.timeTotal);
      } else {
      }

    }


    // -- check end track
    if (selfClass.isSafeToChangeTrack && this.timeTotal > 1 && this.timeCurrent >= this.timeTotal - 0.07) {
      var args = {
        'call_from': 'selfClass.timeTotal > 0 && selfClass.timeCurrent >= selfClass.timeTotal - 0.07 ... '
      }

      if (!selfClass._actualPlayer) {

        selfClass.handle_end(args);
        selfClass.isMediaEnded = true;


        clearTimeout(selfClass.inter_isEnded);
        selfClass.inter_isEnded = setTimeout(function () {
          selfClass.isMediaEnded = false;
        }, 1000);
      }
    }

  }

  getVisualCurrentTime() {

    var selfClass = this.dzsapInstance;


    if (selfClass._actualPlayer === null && this.referenceMediaCurrentTime > -1) {
      return this.referenceMediaCurrentTime;
    }


    if (this.visualCurrentTime) {
      return this.visualCurrentTime;
    }


    if (selfClass.playFrom) {
      return selfClass.playFrom;
    }

    // todo: offsetVisual


    return 0;
  }

  getActualTotalTime() {
    return this.actualTotalTime;
  }

  /**
   *
   * @returns {null|number}
   */
  getVisualTotalTime() {
    var selfClass = this.dzsapInstance;


    if (this.sampleTimeTotal) {
      return this.sampleTimeTotal;
    }


    if (selfClass._actualPlayer === null) {
      if (this.referenceMediaTotalTime > -1) {
        return this.referenceMediaTotalTime;
      }
    } else {
      // -- has footer player

      if (this.visualTotalTime) {
        return this.visualTotalTime;
      }
      //-- last resort
      if (this.referenceMediaTotalTime > -1) {
        return this.referenceMediaTotalTime;
      }
    }


    return 0;
  }

  /**
   * compare target scrub time with sample times
   * @param targetTime
   * @returns {*}
   */
  getActualTargetTime(targetTime) {
    if (this.sampleTimeStart) {
      if (targetTime < this.sampleTimeStart) {
        targetTime = this.sampleTimeStart;
      }
      if (targetTime > this.sampleTimeEnd) {
        targetTime = this.sampleTimeEnd;
      }
    }

    return targetTime;
  }

  getSampleTimesFromDom($targetPlayer = null) {
    var selfClass = this.dzsapInstance;

    selfClass.sample_time_start = 0;
    selfClass.sample_time_total = 0;
    selfClass.sample_time_start = 0;
    selfClass.pseudo_sample_time_end = 0;


    if ($targetPlayer === null) {
      $targetPlayer = selfClass.cthis;
    }


    if ($targetPlayer.attr('data-sample_time_start')) {
      this.sampleTimeStart = Number($targetPlayer.attr('data-sample_time_start'));
    }
    if ($targetPlayer.attr('data-sample_time_end')) {
      this.sampleTimeEnd = Number($targetPlayer.attr('data-sample_time_end'));
    }
    if ($targetPlayer.attr('data-sample_time_total')) {
      this.sampleTimeTotal = Number($targetPlayer.attr('data-sample_time_total'));
    }


    // -- *side-effect: send to selfClass
    selfClass.sample_perc_start = selfClass.sample_time_start / selfClass.sample_time_total;
    selfClass.sample_perc_end = selfClass.sample_time_end / selfClass.sample_time_total;


    selfClass.isSample = !!((this.sampleTimeTotal && this.sampleTimeStart) || (this.sampleTimeStart && this.sampleTimeEnd));

  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/components/_structure.js":
/*!************************************************************!*\
  !*** ../source/audioplayer/jsinc/components/_structure.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "setup_structure": () => (/* binding */ setup_structure),
/* harmony export */   "setup_structure_extras": () => (/* binding */ setup_structure_extras)
/* harmony export */ });
/* harmony import */ var _extra_functionality_extraHtmlFunctions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../extra-functionality/_extraHtmlFunctions */ "../source/audioplayer/jsinc/extra-functionality/_extraHtmlFunctions.js");
/* harmony import */ var _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_dzsap_svgs */ "../source/audioplayer/jsinc/_dzsap_svgs.js");
/* harmony import */ var _view_player_view_playerStructure__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../view/player/_view_playerStructure */ "../source/audioplayer/jsinc/view/player/_view_playerStructure.js");
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");






/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param o
 */
function setup_structure_extras(selfClass, o) {


  if (o.design_skin === 'skin-wave' && selfClass.skinwave_mode === 'bigwavo') {
    selfClass._audioplayerInner.after(selfClass._scrubbar);

    if (selfClass.cthis.find('.feed-description')) {
      selfClass.$conControls.after(selfClass.cthis.find('.feed-description').eq(0));
      selfClass.$conControls.next().removeClass('feed-description').addClass('song-desc');
    }
  }


  selfClass.radio_isGoingToUpdateSongName = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.player_radio_isNameUpdatable)(selfClass, selfClass.radio_isGoingToUpdateSongName, '.the-songname');
  selfClass.radio_isGoingToUpdateArtistName = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.player_radio_isNameUpdatable)(selfClass, selfClass.radio_isGoingToUpdateArtistName, '.the-artist');


  if (o.disable_scrub === 'on') {
    selfClass.cthis.addClass('disable-scrubbar');
  }


  const struct_embedButtonWithTooltip = `<div class="btn-embed-code-con dzstooltip-con "><div class="btn-embed-code player-but "> <div class="the-icon-bg"></div>${_dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.svg_embed_btn}</div><span class="dzstooltip   transition-slidein arrow-bottom talign-end style-rounded color-dark-light " style="width: 350px; "><span class="dzstooltip--inner"><span class="embed-code--text"></span></span></span></div>`;

  if (selfClass.feedEmbedCode !== '') {
    (0,_extra_functionality_extraHtmlFunctions__WEBPACK_IMPORTED_MODULE_0__.feedEmbedFunctionality)(selfClass, jQuery, struct_embedButtonWithTooltip)
  }

  if (o.footer_btn_playlist === 'on') {
    if (selfClass._apControlsRight.find('.btn-footer-playlist').length === 0) {
      (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.waitForScriptToBeAvailableThenExecute)(window.dzsap_inner_playlist_is_loaded, () => {

        selfClass.classFunctionalityInnerPlaylist = new DzsapInnerPlaylist(selfClass);
        selfClass.classFunctionalityInnerPlaylist.init();
      })

    }

  }


  setTimeout(function () {

    if (selfClass.cthis.find('.extra-html').length) {
      (0,_extra_functionality_extraHtmlFunctions__WEBPACK_IMPORTED_MODULE_0__.extraHtmlBottomFunctionality)(selfClass);
    }
  }, 100);

  setTimeout(function () {
    if (selfClass.cthis.html().indexOf('dzsap-multisharer-but') > -1) {
      selfClass.isMultiSharer = true;
      selfClass.check_multisharer();
    }
  }, 1002);


  if (selfClass.cthis.find('.afterplayer').length > 0) {

    selfClass.cthis.append(selfClass.cthis.find('.afterplayer'));
  }

}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function structure_generatePlayPauseString(selfClass) {

  const o = selfClass.initOptions;

  let structConPlayPause = '';
  if (o.settings_extrahtml_before_play_pause) {
    structConPlayPause += o.settings_extrahtml_before_play_pause;


  }


  structConPlayPause += '<div class="con-playpause-con">';

  structConPlayPause = addExtraHtmlInPlace(selfClass, '.feed-dzsap-before-playpause', '') + structConPlayPause;

  structConPlayPause += '<div class="con-playpause';

  if (selfClass.keyboard_controls.show_tooltips === 'on') {
    structConPlayPause += ' dzstooltip-con';
  }

  structConPlayPause += '">';
  if (selfClass.keyboard_controls.show_tooltips === 'on') {
    structConPlayPause += (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.dzsap_generate_keyboard_tooltip)(selfClass.keyboard_controls, 'pause_play');
  }


  structConPlayPause += '<div class="playbtn player-but" aria-controls="' + selfClass.uniqueId + '-audio"><div class="the-icon-bg"></div><div class="dzsap-play-icon">';


  structConPlayPause += _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.playbtn_svg;


  structConPlayPause += `</div><div class="media-load--preloader"><img alt="preloader" class="" src="${window.dzsap_base_url}parts/assets/view-preloader.svg"/></div>`;
  structConPlayPause += '</div>'; // -- end playbtn


  structConPlayPause += '<div class="pausebtn player-but"';


  structConPlayPause += '><div class="the-icon-bg"></div><div class="pause-icon">';


  structConPlayPause += _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.pausebtn_svg;


  structConPlayPause += '</div>';// -- end pause-icon
  structConPlayPause += '</div>'; // -- end pausebtn


  structConPlayPause += '';


  structConPlayPause += '</div>';

  // -- todo: check if correct one
  if (selfClass.cthis.find('.feed-dzsap-after-playpause').length) {
    structConPlayPause += addExtraHtmlInPlace(selfClass, '.feed-dzsap-after-playpause', '');
  }

  structConPlayPause += '</div>';


  return structConPlayPause;
}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function setup_structure__setup_wrapper_image(selfClass) {

  var img = new Image();


  if (selfClass.cthis.hasClass('zoomsounds-no-wrapper') === false) {

    img.onload = function () {


      selfClass.cthis.css('background-image', 'url(' + this.src + ')');

      setTimeout(function () {

        selfClass.cthis.find('.zoomsounds-bg').addClass('loaded');


        if (selfClass.cthis.hasClass('zoomsounds-wrapper-bg-bellow')) {

          selfClass.cthis.css('padding-top', 200);
        }
      }, 100);
    }

    img.src = selfClass.cthis.attr('data-wrapper-image');
  }

}

/**
 * setup player structure , called from init
 * @param {DzsAudioPlayer} selfClass
 * @param pargs
 * @returns {boolean}
 */
const setup_structure = function (selfClass, pargs) {


  // -- setup structure here
  var $ = jQuery;
  var o = selfClass.initOptions;


  var margs = {
    'setup_inner_player': true
    , 'setup_media': true
    , 'setup_otherstructure': true
    , 'call_from': "default"


  }


  if (pargs) {
    margs = $.extend(margs, pargs);
  }


  if (margs.call_from === 'reconstruct') {
    if (selfClass._metaArtistCon) {


    }


    selfClass._metaArtistCon = null;
    if (selfClass.cthis.hasClass('skin-wave')) {
      o.design_skin = 'skin-wave';
    }
    if (selfClass.cthis.hasClass('skin-silver')) {
      o.design_skin = 'skin-silver';
    }
  }


  var structure_str_apControls = '<div class="ap-controls';

  if (o.design_skin === 'skin-default') {
    structure_str_apControls += ' dzsap-color_inverse_ui_fill';
  }
  structure_str_apControls += '"></div>'

  if (margs.setup_inner_player) {
    selfClass.cthis.appendOnce('<div class="audioplayer-inner"></div>');
    selfClass._audioplayerInner = selfClass.cthis.children('.audioplayer-inner');
  }


  // -- end setup inner


  if (!margs.setup_otherstructure) {
    return false;
  }


  if (selfClass.cthis.attr('data-wrapper-image')) {
    setup_structure__setup_wrapper_image(selfClass);
  }


  var structure_str_scrubbar = '<div class="scrubbar">';
  var aux_str_con_controls = '';

  var aux_str_time = '';


  structure_str_scrubbar += '<div class="scrub-bg"></div><div class="scrub-buffer"></div>';

  structure_str_scrubbar += '<div class="scrub-prog';

  if (o.scrubbar_type !== 'wave') {
    structure_str_scrubbar += ' dzsap-color_brand_bg';
  }

  structure_str_scrubbar += '"></div><div class="scrubBox"></div><div class="scrubBox-prog"></div><div class="scrubBox-hover"></div>';
  aux_str_time = '<div class="total-time">00:00</div><div class="curr-time">00:00</div>';


  if (selfClass.sample_perc_start) {

    structure_str_scrubbar += '<div class="sample-block-start" style="width: ' + (selfClass.sample_perc_start * 100) + '%"></div>'
  }
  if (selfClass.sample_perc_end) {

    structure_str_scrubbar += '<div class="sample-block-end" style="left: ' + (selfClass.sample_perc_end * 100) + '%; width: ' + (100 - (selfClass.sample_perc_end * 100)) + '%"></div>'
  }

  structure_str_scrubbar += '</div>'; // -- end scrubbar


  if (o.controls_external_scrubbar) {
    structure_str_scrubbar = '';
  }


  var struct_con_playpause = '';

  struct_con_playpause += structure_generatePlayPauseString(selfClass);


  aux_str_con_controls += '<div class="con-controls"><div class="the-bg"></div>' + struct_con_playpause;


  if (selfClass.extraHtmlAreas.controlsLeft) {
    aux_str_con_controls += selfClass.extraHtmlAreas.controlsLeft;
  }


  if (o.design_skin === 'skin-pro') {
    aux_str_con_controls += '<div class="con-controls--right">';
    aux_str_con_controls += '</div>';
  }


  var aux_str_con_volume = '<div class="controls-volume"><div class="volumeicon"></div><div class="volume_static"></div><div class="volume_active"></div><div class="volume_cut"></div></div>';
  if (o.disable_volume === 'on') {
    aux_str_con_volume = '';
  }


  if (o.design_skin === 'skin-default' || o.design_skin === 'skin-wave') {

    aux_str_con_controls += '<div class="ap-controls-right">';
    if (o.disable_volume !== 'on') {
      aux_str_con_controls += '<div class="controls-volume"><div class="volumeicon"></div><div class="volume_static"></div><div class="volume_active"></div><div class="volume_cut"></div></div>';
    }


    aux_str_con_controls += '</div>';


  }

  aux_str_con_controls += '</div>'; // -- end con-controls


/// -- end STR


  if (o.design_skin === 'skin-wave' && selfClass.skinwave_mode === 'small') {
    aux_str_con_controls = '<div class="the-bg"></div><div class="ap-controls-left">' + struct_con_playpause + '</div>' + structure_str_scrubbar + '<div class="ap-controls-right">' + aux_str_con_volume + '<div class="extrahtml-in-float-right for-skin-wave-small">' + selfClass.extraHtmlAreas.controlsRight + '</div></div>';


  } else {


    // -- other skins

    if (o.design_skin === 'skin-aria' || o.design_skin === 'skin-silver' || o.design_skin === 'skin-redlights' || o.design_skin === 'skin-steel') {


      let playbtnSvg = _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.playbtn_svg;
      let pausebtnSvg = _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.pausebtn_svg;
      if (o.design_skin === 'skin-steel') {
        playbtnSvg = '';
        pausebtnSvg = '';
      }

      aux_str_con_controls = '<div class="the-bg"></div><div class="ap-controls-left">';


      if (o.design_skin === 'skin-silver') {

        aux_str_con_controls += struct_con_playpause;
      } else {


        aux_str_con_controls += '<div class="con-playpause';

        if (selfClass.keyboard_controls.show_tooltips === 'on') {
          aux_str_con_controls += ' dzstooltip-con';
        }

        aux_str_con_controls += '">';


        if (selfClass.keyboard_controls.show_tooltips === 'on') {
          aux_str_con_controls += (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.dzsap_generate_keyboard_tooltip)(selfClass.keyboard_controls, 'pause_play');
        }


        aux_str_con_controls += '<div class="playbtn player-but playbtn-not-skin-silver"><div class="dzsap-play-icon">' + playbtnSvg + '</div></div><div class="pausebtn player-but" ';


        aux_str_con_controls += '><div class="pause-icon">' + pausebtnSvg + '</div></div></div>'; // -- enc con-playpause

      }


      // todo: check
      // addExtraHtmlInPlace(selfClass, '.feed-dzsap-after-playpause', struct_con_playpause);


      aux_str_con_controls += '</div>';


      if (selfClass.extraHtmlAreas.controlsRight) {
        aux_str_con_controls += '<div class="controls-right">' + selfClass.extraHtmlAreas.controlsRight + '</div>';


        if (o.design_skin === 'skin-redlights') {


          if (o.parentgallery && o.parentgallery.get(0).api_skin_redlights_give_controls_right_to_all) {
            o.parentgallery.get(0).api_skin_redlights_give_controls_right_to_all();
          }
        }
      }


      aux_str_con_controls += '<div class="ap-controls-right">';

      if (o.design_skin === 'skin-silver') {

        aux_str_con_controls += '<div class="controls-volume controls-volume-vertical"><div class="volumeicon"></div><div class="volume-holder"><div class="volume_static"></div><div class="volume_active"></div><div class="volume_cut"></div></div></div>';


        aux_str_con_controls += '</div>' + structure_str_scrubbar;
      } else {


        if (o.design_skin === 'skin-redlights') {

          if (o.disable_volume != 'on') {
            aux_str_con_controls += '<div class="controls-volume"><div class="volumeicon"></div><div class="volume_static"></div><div class="volume_active"></div><div class="volume_cut"></div></div>';
          }
        }

        aux_str_con_controls += structure_str_scrubbar;


        if (o.disable_timer != 'on') {
          aux_str_con_controls += '<div class="total-time">00:00</div>';
        }
      }


      if (o.design_skin === 'skin-silver') {

      } else {
        aux_str_con_controls += '</div>';
      }


    }


  }


// -- end strings
// --------------

  if (margs.setup_media) {
    selfClass._audioplayerInner.append('<div class="the-media"></div>');
    selfClass.$theMedia = selfClass._audioplayerInner.children('.the-media').eq(0);
  }
  if (o.design_skin !== 'skin-customcontrols') {
    selfClass._audioplayerInner.append(structure_str_apControls);
  }

  selfClass._apControls = selfClass._audioplayerInner.children('.ap-controls').eq(0);
  selfClass._apControls.append(aux_str_con_controls);


  if (selfClass.cthis.hasClass('skin-wave-mode-alternate')) {
    if (selfClass.cthis.find('.scrubbar').length === 0) {
      selfClass._apControls.append(structure_str_scrubbar);
    }
  } else {
    if (selfClass.cthis.find('.scrubbar').length === 0) {
      selfClass._apControls.prepend(structure_str_scrubbar);
    }
  }


  selfClass._apControlsRight = null;

  if (selfClass._apControls.find('.ap-controls-right').length > 0) {
    selfClass._apControlsRight = selfClass.cthis.find('.ap-controls-right');
  }
  if (selfClass._apControls.find('.ap-controls-left').length > 0) {
    selfClass._apControlsLeft = selfClass._apControls.find('.ap-controls-left').eq(0);
  }


  if (o.design_skin === 'skin-pro') {
    selfClass._apControlsRight = selfClass.cthis.find('.con-controls--right').eq(0)
  }


// -- Todo: if we have footer, playlist btn we can place it in ap-controls-right


  addExtraHtmlInPlace(selfClass, '.feed-dzsap--custom-controls', null, selfClass._audioplayerInner);
  addExtraHtmlInPlace(selfClass, '.feed-dzsap-after-con-controls', null, selfClass._apControls);


  if (o.controls_external_scrubbar) {
    selfClass._scrubbar = $(o.controls_external_scrubbar).children('.scrubbar').eq(0);
  } else {
    selfClass._scrubbar = selfClass._apControls.find('.scrubbar').eq(0);
  }

  if (selfClass._scrubbar.length === 0) {
    selfClass.initOptions.scrubbar_type = 'none';
  }


  selfClass.$$scrubbProg = selfClass._scrubbar.find('.scrub-prog').get(0);


  selfClass.$conControls = selfClass._apControls.children('.con-controls');
  selfClass.$conPlayPause = selfClass.cthis.find('.con-playpause').eq(0);
  selfClass._conPlayPauseCon = selfClass.cthis.find('.con-playpause-con').eq(0);
  selfClass.$controlsVolume = selfClass.cthis.find('.controls-volume').eq(0);


  (_view_player_view_playerStructure__WEBPACK_IMPORTED_MODULE_2__.player_constructArtistAndSongCon.bind(selfClass))(margs);


  selfClass._scrubbar.addClass('scrubbar-inited');
  if (o.scrubbar_type === 'wave' && o.disable_timer != 'on') {
    // -- no sense in adding time if external
    if (o.controls_external_scrubbar === '') {
      selfClass._scrubbar.append(aux_str_time);
    }
  }


  if (o.design_skin != 'skin-wave' && o.disable_timer != 'on') {
    // aux_str_con_controls += '<div class="curr-time">00:00</div><div class="total-time">00:00</div>';

    // -- all skins
    selfClass._apControls.append(aux_str_time);
  }


// -- end structure


// -- start assocations
  if (o.disable_timer != 'on') {
    selfClass.$currTime = selfClass.cthis.find('.curr-time').eq(0);
    selfClass.$totalTime = selfClass.cthis.find('.total-time').eq(0);

    if (o.design_skin === 'skin-steel') {
      if (selfClass.$currTime.length === 0) {
        selfClass.$totalTime.before('<div class="curr-time">00:00</div> <span class="separator-slash">/</span> ');


        selfClass.$currTime = selfClass.$totalTime.prev().prev();

      }
    }


  }


  if (Number(o.sample_time_total) > 0) {

    selfClass.timeTotal = Number(o.sample_time_total);


    if (selfClass.$totalTime) {


      selfClass.$totalTime.html((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_3__.formatTime)(selfClass.time_total_for_visual));
    }


  }


  selfClass.setupStructure_thumbnailCon();


  if (o.design_skin === 'skin-wave' && o.parentgallery && typeof (o.parentgallery) != 'undefined' && o.design_menu_show_player_state_button === 'on') {
    if (o.design_skin === 'skin-wave') {
      if (selfClass._apControlsRight) {

        selfClass._apControlsRight.appendOnce('<div class="btn-menu-state player-but"> <div class="the-icon-bg"></div> ' + _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.svg_menu_state + '    </div></div>');
      } else {
      }
    } else {
      selfClass._audioplayerInner.appendOnce('<div class="btn-menu-state"></div>');
    }
  }

  if (o.skinwave_place_metaartist_after_volume === 'on') {

    selfClass.$controlsVolume.before(selfClass._metaArtistCon);
  }


  if (o.skinwave_place_thumb_after_volume === 'on') {

    selfClass.$controlsVolume.before(selfClass.cthis.find('.the-thumb-con'));
  }


  if (o.design_skin === 'skin-wave') {


    // -- structure setup

    selfClass.setup_structure_scrub();


    if (o.skinwave_timer_static === 'on') {
      if (selfClass.$currTime) {
        selfClass.$currTime.addClass('static');
      }
      if (selfClass.$totalTime) {
        selfClass.$totalTime.addClass('static');
      }
    }


    selfClass._apControls.css({
      //'height': design_thumbh
    })


    if (o.skinwave_wave_mode === 'canvas') {

      setTimeout(function () {
        selfClass.cthis.addClass('scrubbar-loaded');
        selfClass._scrubbar.parent().addClass('scrubbar-loaded');


      }, 700); // -- tbc

    }

  }
// --- END skin-wave


  selfClass.check_multisharer();

  if (selfClass.cthis.hasClass('skin-minimal')) {
    // -- here is skin-minimal

    selfClass.cthis.find('.the-bg').before('<div class="skin-minimal-bg skin-minimal--outer-bg"></div><div class="skin-minimal-bg skin-minimal--inner-bg-under dzsap-color_brand_bg"></div><div class="skin-minimal-bg skin-minimal--inner-bg"></div><div class="skin-minimal-bg skin-minimal--inner-inner-bg dzsap-color_brand_bg"></div>')
    selfClass.cthis.find('.the-bg').append('<canvas width="100" height="100" class="playbtn-canvas"/>')
    selfClass.skin_minimal_canvasplay = selfClass.cthis.find('.playbtn-canvas').eq(0).get(0);

    if (selfClass.$conPlayPause) {

      selfClass.$conPlayPause.children('.playbtn').append(_dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.playbtn_svg);
      selfClass.$conPlayPause.children('.pausebtn').append(_dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.pausebtn_svg);
    }

    setTimeout(function () {
      selfClass.isCanvasFirstDrawn = false;
    }, 200);
  }


  if (selfClass.cthis.hasClass('skin-minion')) {
    if (selfClass.cthis.find('.menu-description').length > 0) {

      selfClass.$conPlayPause.addClass('with-tooltip');
      selfClass.$conPlayPause.prepend('<span class="dzstooltip" style="left:-7px;">' + selfClass.cthis.find('.menu-description').html() + '</span>');
      selfClass.$conPlayPause.children('span').eq(0).css('width', selfClass.$conPlayPause.children('span').eq(0).textWidth() + 10);
    }
  }


  if (o.player_navigation === 'default') {

    if (o.parentgallery) {

      o.player_navigation = 'on';
    }


    if (o.parentgallery && o.parentgallery.hasClass('mode-showall')) {
      o.player_navigation = 'off';
    }
  }

  if (o.disable_player_navigation === 'on') {

    o.player_navigation = 'off';
  }

  if (o.player_navigation === 'default') {

    o.player_navigation = 'off';
  }


  if (o.player_navigation === 'on') {

    var prev_btn_str = '<div class="prev-btn player-but"><div class="the-icon-bg"></div>' + _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.svg_prev_btn + ' </div>';

    var next_btn_str = '<div class="next-btn player-but"><div class="the-icon-bg"></div>' + _dzsap_svgs__WEBPACK_IMPORTED_MODULE_1__.svg_next_btn + '  </div>';


    var auxs = prev_btn_str + next_btn_str;


    // -- create player navigation here
    if ((o.design_skin === 'skin-wave' && selfClass.skinwave_mode === 'small') || o.design_skin === 'skin-aria') {


      selfClass.$conPlayPause.before(prev_btn_str)
      selfClass.$conPlayPause.after(next_btn_str)


    } else {
      if (o.design_skin === 'skin-wave') {


        if (o.player_navigation === 'on') {

          selfClass._conPlayPauseCon.prependOnce(prev_btn_str, '.prev-btn');
          selfClass._conPlayPauseCon.appendOnce(next_btn_str, '.next-btn');
        }

      } else if (o.design_skin === 'skin-steel') {

        selfClass._apControlsLeft.prependOnce(prev_btn_str, '.prev-btn');

        if (selfClass._apControlsLeft.children('.the-thumb-con').length > 0) {


          if (selfClass._apControlsLeft.children('.the-thumb-con').eq(0).length > 0) {
            if (selfClass._apControlsLeft.children('.the-thumb-con').eq(0).prev().hasClass('next-btn') === false) {
              selfClass._apControlsLeft.children('.the-thumb-con').eq(0).before(next_btn_str);
            }
          }

        } else {

          selfClass._apControlsLeft.appendOnce(next_btn_str, '.next-btn');
        }
      } else {

        selfClass._audioplayerInner.appendOnce(auxs, '.prev-btn');
      }
    }

  }


  if (selfClass.cthis.hasClass('skinvariation-wave-bigtitles')) {
    if (selfClass.cthis.find('.controls-volume').length && selfClass._metaArtistCon.find('.controls-volume').length === 0) {
      selfClass._metaArtistCon.append('<br>');
      selfClass._metaArtistCon.append(selfClass.cthis.find('.controls-volume'));
    }

  }

  if (selfClass.cthis.hasClass('skinvariation-wave-righter')) {

    selfClass._apControls.appendOnce('<div class="playbuttons-con"></div>');
    var _c = selfClass.cthis.find('.playbuttons-con').eq(0);
    _c.append(selfClass.cthis.find('.con-playpause-con'));

  }


  if (o.design_skin === 'skin-pro') {

    selfClass._apControlsRight.append(selfClass.$currTime);
    selfClass._apControlsRight.append(selfClass.$totalTime);
  }


  if (o.design_skin === 'skin-silver') {
    selfClass._scrubbar.after(selfClass._apControlsRight);
    selfClass._apControlsLeft.prepend(selfClass._metaArtistCon);
    selfClass._apControlsLeft.append(selfClass.$currTime);
    selfClass._apControlsRight.append(selfClass.$totalTime);


  }


  if (o.design_skin === 'skin-redlights') {
    selfClass._apControlsRight.append('<div class="ap-controls-right--top"></div>');
    selfClass._apControlsRight.append('<div class="ap-controls-right--bottom"></div>');
    selfClass._apControlsRight.find('.ap-controls-right--top').append(selfClass._apControlsRight.find('.meta-artist-con'));
    selfClass._apControlsRight.find('.ap-controls-right--top').append(selfClass._apControlsRight.find('.controls-volume'));
    selfClass._apControlsRight.find('.ap-controls-right--bottom').append(selfClass._apControlsRight.find('.scrubbar'));
  }


  if (margs.call_from === 'reconstruct') {
    if (selfClass.cthis.hasClass('skin-silver')) {
      selfClass._apControlsLeft.append(selfClass.cthis.find('.con-playpause'));
    }
  }


  if (selfClass.isMultiSharer) {
    selfClass.check_multisharer();
  }

  selfClass.setup_structure_sanitizers();
  setup_structure_extras(selfClass, o);


  selfClass.cthis.addClass('structure-setuped');


  if (selfClass.extraHtmlAreas.afterArtist) {
    selfClass._metaArtistCon.find('.the-artist').append(selfClass.extraHtmlAreas.afterArtist);
  }


  if (selfClass.extraHtmlAreas.bottom !== '') {
    selfClass.cthis.append('<div class="extra-html">' + selfClass.extraHtmlAreas.bottom + '</div>');
  }


  var settings_extrahtml_in_float_right_str = '';


  if (String(selfClass.extraHtmlAreas.controlsRight).indexOf('dzsap-multisharer-but') > -1) {
    selfClass.isMultiSharer = true;
  }

  if (o.design_skin === 'skin-wave' && selfClass.skinwave_mode === 'small') {

  } else {

    settings_extrahtml_in_float_right_str += '<div class="extrahtml-in-float-right from-setup_structure from-js-setup_structure">' + selfClass.extraHtmlAreas.controlsRight + '</div>';
  }


  if (settings_extrahtml_in_float_right_str) {
    if (o.design_skin === 'skin-wave' || o.design_skin === 'skin-default') {

      selfClass.cthis.find('.ap-controls-right').eq(0).append(settings_extrahtml_in_float_right_str);

    }
    if (o.design_skin === 'skin-pro') {

      selfClass.cthis.find('.con-controls--right').eq(0).append(settings_extrahtml_in_float_right_str);

    }
  }


}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param {string} feedSelector
 * @param {string|null} addToString
 * @param $appendElement
 * @returns {null|string|any}
 */
function addExtraHtmlInPlace(selfClass, feedSelector, addToString = null, $appendElement = null) {

  if (selfClass.cthis.find(feedSelector).length) {
    if (addToString !== null) {

      addToString += selfClass.cthis.find(feedSelector).eq(0).html();
    }

    if ($appendElement !== null) {

      $appendElement.append(selfClass.cthis.find(feedSelector).eq(0).html())
      return $appendElement;
    }
    selfClass.cthis.find(feedSelector).remove();
    if (addToString !== null) {

      return addToString;
    }
  }


  if (typeof addToString == 'string') {
    return addToString;
  }

  return null;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/extra-functionality/_extraHtmlFunctions.js":
/*!******************************************************************************!*\
  !*** ../source/audioplayer/jsinc/extra-functionality/_extraHtmlFunctions.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "extraHtmlBottomFunctionality": () => (/* binding */ extraHtmlBottomFunctionality),
/* harmony export */   "feedEmbedFunctionality": () => (/* binding */ feedEmbedFunctionality)
/* harmony export */ });
/* harmony import */ var _dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_ajax */ "../source/audioplayer/jsinc/_dzsap_ajax.js");
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");



function extraHtmlBottomFunctionality(selfClass    ){


  var o = selfClass.initOptions;





    if (selfClass.increment_views === 1) {
      (_dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__.ajax_submit_views.bind(selfClass))();
      selfClass.increment_views = 2;
    }



  if (selfClass.index_extrahtml_toloads === 0) {


    selfClass.cthis.find('.extra-html').addClass('active');
  }
  setTimeout(function () {
    selfClass.cthis.find('.extra-html').addClass('active');
    if (selfClass.cthis.find('.float-left').length === 0) {
      selfClass.cthis.find('.extra-html').append(selfClass.cthis.find('.extra-html-extra'));
    } else {
      selfClass.cthis.find('.extra-html .float-left').append(selfClass.cthis.find('.extra-html-extra'));
    }


    var _c = selfClass.cthis.find('.extra-html-extra').children().eq(0);

    selfClass.cthis.find('.extra-html-extra').children().unwrap();







  }, 2000);
}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param $
 * @param struct_embedButtonWithTooltip
 */
function feedEmbedFunctionality(selfClass,$, struct_embedButtonWithTooltip){

  var o = selfClass.initOptions;

  if (o.design_skin === 'skin-wave') {

    if (o.enable_embed_button === 'on') {
      if (selfClass._apControlsRight) {

        selfClass._apControlsRight.appendOnce(struct_embedButtonWithTooltip);
        selfClass.$embedButton = selfClass._apControlsRight.find('.btn-embed-code-con').eq(0);
        selfClass.$embedButton.find('.btn-embed-code').addClass('player-but');
      }
    }

  } else {
    if (o.enable_embed_button === 'on') {
      selfClass._audioplayerInner.appendOnce(struct_embedButtonWithTooltip);
      selfClass.$embedButton = selfClass._audioplayerInner.find('.btn-embed-code-con').eq(0);
    }
  }
  if (selfClass.$embedButton) {

    selfClass.$embedButton.find('.embed-code--text').html(selfClass.feedEmbedCode);
  }


  selfClass.cthis.on('click', '.btn-embed-code-con, .btn-embed', function () {
    var _t = $(this);


    (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_1__.select_all)(_t.find('.dzstooltip').get(0));
    document.execCommand('copy');
  })
  selfClass.cthis.on('click', '.copy-embed-code-btn', function () {
    var _t = $(this);

    (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_1__.select_all)(_t.parent().parent().find('.dzstooltip--inner > span').get(0));

    document.execCommand('copy');
    setTimeout(function () {
      (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_1__.select_all)(_t.get(0));
    }, 100)
  })
}


/***/ }),

/***/ "../source/audioplayer/jsinc/helper-classes/_ClassMetaParts.js":
/*!*********************************************************************!*\
  !*** ../source/audioplayer/jsinc/helper-classes/_ClassMetaParts.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_ClassMetaParts": () => (/* binding */ _ClassMetaParts)
/* harmony export */ });


class _ClassMetaParts{
  constructor(selfClass) {
    this.selfClass = selfClass;
  }

  set_extraHtmlFloatRight(extraHtml){


    this.selfClass.cthis.find('.extrahtml-in-float-right').eq(0).html(extraHtml);
  }

}


/***/ }),

/***/ "../source/audioplayer/jsinc/media/_media_functions.js":
/*!*************************************************************!*\
  !*** ../source/audioplayer/jsinc/media/_media_functions.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "buildAudioElementHtml": () => (/* binding */ buildAudioElementHtml),
/* harmony export */   "destroy_cmedia": () => (/* binding */ destroy_cmedia),
/* harmony export */   "destroy_media": () => (/* binding */ destroy_media),
/* harmony export */   "isValidTotalTime": () => (/* binding */ isValidTotalTime),
/* harmony export */   "makeMediaPreloadInTheFuture": () => (/* binding */ makeMediaPreloadInTheFuture),
/* harmony export */   "mediaSetup": () => (/* binding */ mediaSetup),
/* harmony export */   "media_handleEventEnd": () => (/* binding */ media_handleEventEnd),
/* harmony export */   "media_pause": () => (/* binding */ media_pause),
/* harmony export */   "media_removeMediaInside": () => (/* binding */ media_removeMediaInside),
/* harmony export */   "media_tryToPlay": () => (/* binding */ media_tryToPlay),
/* harmony export */   "repairMediaElement": () => (/* binding */ repairMediaElement),
/* harmony export */   "setupMediaElement": () => (/* binding */ setupMediaElement),
/* harmony export */   "setupMediaListeners": () => (/* binding */ setupMediaListeners)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _player_player_volume__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../player/_player_volume */ "../source/audioplayer/jsinc/player/_player_volume.js");
/* harmony import */ var _player_player_scrubModeWave_spectrum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../player/_player_scrubModeWave_spectrum */ "../source/audioplayer/jsinc/player/_player_scrubModeWave_spectrum.js");






/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param callbackFn
 * @param errorFn
 */
const media_tryToPlay = function (selfClass, callbackFn, errorFn) {
  async function async_media_tryToPlay() {
    function tryToPlay(resolve, reject) {
      if (selfClass.cthis.attr('data-original-type')) {
        // -- then this player is feeding
      } else {

        if (selfClass.$mediaNode_) {
          if (selfClass.$mediaNode_.play) {

            // -- no audioCtx_buffer

            if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() && selfClass.spectrum_audioContext !== null && typeof selfClass.spectrum_audioContext == 'object') {
              // todo: ios not playing nice.. with audio context

              selfClass.spectrum_audioContextBufferSource = selfClass.spectrum_audioContext.createBufferSource();
              selfClass.spectrum_audioContextBufferSource.buffer = selfClass.spectrum_audioContext_buffer;
              selfClass.spectrum_audioContextBufferSource.connect(selfClass.spectrum_audioContext.destination);

              selfClass.spectrum_audioContextBufferSource.start(0, selfClass.lastTimeInSeconds);
              resolve({
                'resolve_type': 'playing_context'
              })
            } else {

              selfClass.cthis.addClass('zoomsounds-player--media--is-loading');

              try {

                selfClass.$mediaNode_.play().then(r => {
                  resolve({
                    'resolve_type': 'started_playing'
                  })
                }).catch(err => {
                  reject({
                    'error_type': 'did not want to play',
                    'error_message': err
                  });
                }).finally(() => {

                  selfClass.cthis.removeClass('zoomsounds-player--media--is-loading');
                });
              } catch (e) {
                selfClass.$mediaNode_.play();
                resolve({
                  'resolve_type': 'started_playing'
                })
              }

            }
          } else {
            if (selfClass._actualPlayer == null) {
              selfClass.isPlayPromised = true;
            }

          }
        } else {
          if (selfClass._actualPlayer == null) {
            selfClass.isPlayPromised = true;
          }
        }


      }

    }

    return new Promise((resolve, reject) => {

      tryToPlay(resolve, reject);

    })
  }

  async_media_tryToPlay().then((r) => {
    callbackFn(r);
  }).catch((err) => {
    errorFn(err);
  })

}


/**
 *
 * @param {DzsApPlaylist | null} $parentPlaylistForSource
 * @param {DzsAudioPlayer} selfClass
 * @returns {string}
 */
const getAutoplayNextMethod = ($parentPlaylistForSource, selfClass) => {

  let autoplayNextMethod = 'default';

  // -- if it's part of a playlist
  if ($parentPlaylistForSource) {
    if ($parentPlaylistForSource.initOptions.autoplayNext === 'on') {
      autoplayNextMethod = 'nextInSourcePlayist';
    }
  }

  if (autoplayNextMethod === 'default') {
    const tryGetAutoPlayMethod = () => {
      if (window.dzsap_syncList_players && window.dzsap_syncList_players.length > 0) {
        if (selfClass.cthis.hasClass('is-single-player') || (selfClass._sourcePlayer && selfClass._sourcePlayer.hasClass('is-single-player'))) {
          // -- called on handle end
          return  'syncPlayerNext';
        }
      }
      if (selfClass._sourcePlayer && (selfClass._sourcePlayer.hasClass('is-single-player') || selfClass._sourcePlayer.hasClass('feeded-whole-playlist'))) {
        return 'handleEndForSourcePlayer';
      }

      return 'nothingAfter';
    }
    autoplayNextMethod = tryGetAutoPlayMethod();
  }

  return autoplayNextMethod;
}



/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param {object} pargs
 * @param {boolean} media_isLoopActive
 * @param {function} seek_to
 * @param {function} play_media
 * @param {function} pause_media
 * @param {object} o
 * @param {function} syncPlayers_gotoNext
 * @param {function} action_audio_end
 * @returns {void}
 */
const media_handleEventEnd = (selfClass, pargs, media_isLoopActive, seek_to, play_media, pause_media, o, syncPlayers_gotoNext, action_audio_end) => {


  var margs = {
    'called_from': 'default'
  }


  if (pargs) {
    margs = Object.assign(margs, pargs);
  }
  if (selfClass.isMediaEnded) {
    return;
  }

  selfClass.isMediaEnded = true;

  selfClass.inter_isEnded = setTimeout(function () {
    selfClass.isMediaEnded = false;
  }, 1000);


  if (selfClass._sourcePlayer) {

    media_isLoopActive = selfClass._sourcePlayer.get(0).api_get_media_isLoopActive();
  }
  if (selfClass._actualPlayer && margs.call_from !== 'fake_player') {
    // -- lets leave fake player handle handle_end
    return;
  }


  seek_to(0, {
    'call_from': 'handle_end'
  });

  if (media_isLoopActive) {
    play_media({
      'called_from': 'track_end'
    });
    return;
  } else {
    pause_media();
  }

  if (o.parentgallery) {
    o.parentgallery.get(0).api_gallery_handle_end();
  }



  let $parentPlaylistForSource = null;
  if (selfClass._sourcePlayer && selfClass._sourcePlayer.get(0) && selfClass._sourcePlayer.get(0).SelfInstance && selfClass._sourcePlayer.get(0).SelfInstance.$parentPlaylist) {
    // -- called on handle end
    $parentPlaylistForSource = selfClass._sourcePlayer.get(0).SelfInstance.$parentPlaylist.get(0).SelfPlaylist;

  }

  const autoplayNextMethod = getAutoplayNextMethod($parentPlaylistForSource, selfClass);



  // -- decided autoplayNextMethod

  if (autoplayNextMethod === 'nextInSourcePlayist') {

    if ($parentPlaylistForSource && $parentPlaylistForSource.argThis) {
      $parentPlaylistForSource.argThis.api_gallery_handle_end();
    }
  }
  if (autoplayNextMethod === 'syncPlayerNext') {
    setTimeout(function () {
      syncPlayers_gotoNext(selfClass);
    }, 100);
  }

  if (autoplayNextMethod === 'handleEndForSourcePlayer') {
    setTimeout(function () {
      selfClass._sourcePlayer.get(0).api_handle_end({
        'call_from': 'handle_end() fake_player'
      });
    }, 200);
  }

  if (action_audio_end) {
    setTimeout(function () {
      let args = {};
      action_audio_end(selfClass.cthis, args);
    }, 200);
  }
}

const media_removeMediaInside = (selfClass) => {

  selfClass.$theMedia.children().remove();
  selfClass.$mediaNode_ = null;
}

const setupMediaElement = (selfClass, stringAudioElementHtml = '', stringAudioTagSource = '') => {


  media_removeMediaInside(selfClass);

  if (stringAudioTagSource) {
    if (selfClass.$mediaNode_) {

      jQuery(selfClass.$mediaNode_).append(stringAudioTagSource);
      if (selfClass.$mediaNode_.load) {
        selfClass.$mediaNode_.load();
      }

    } else {
      setupMediaElement(selfClass, stringAudioElementHtml);
      return false;
    }
  } else {
    selfClass.$theMedia.append(stringAudioElementHtml);
  }
  selfClass.$mediaNode_ = (selfClass.$theMedia.children('audio').get(0));


}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function destroy_cmedia(selfClass) {
  // -- destroy cmedia
  const $ = selfClass.$;

  $(selfClass.$mediaNode_).remove();
  selfClass.$mediaNode_ = null;
  selfClass.isSetupedMedia = false;
  selfClass.isPlayerLoaded = false;
}

function destroy_media(selfClass, pause_media) {
  const o = selfClass.initOptions;
  pause_media();


  if (selfClass.$mediaNode_) {

    if (selfClass.$mediaNode_.children) {

    }

    if (o.type === 'audio') {
      selfClass.$mediaNode_.innerHTML = '';
      selfClass.$mediaNode_.load();
    }
  }

  if (selfClass.$theMedia) {

    selfClass.$theMedia.children().remove();
    selfClass.$mediaNode_ = null;
    selfClass.isPlayerLoaded = false;
  }

  destroy_cmedia(selfClass);

}

const setupMediaListeners = function (selfClass, setupMediaAttrs, action_initLoaded, volume_lastVolume, volume_setVolume) {

  let attempt_reload = 0;


  if (typeof (selfClass.$mediaNode_) !== "undefined" && selfClass.$mediaNode_) {
    selfClass.$mediaNode_.addEventListener('error', handleAudioError, true);
    selfClass.$mediaNode_.addEventListener('loadedmetadata', handleMediaMetaLoaded, true);
    if (selfClass.$mediaNode_.nodeName === 'AUDIO') {
      selfClass.$mediaNode_.addEventListener('ended', media_handleEnd);
    }
  }


  function media_handleEnd(pargs) {
    selfClass.handle_end(pargs);
  }

  function handleAudioError(e) {

    const $audioElement_ = this;

    var noSourcesLoaded = ($audioElement_.networkState === HTMLMediaElement.NETWORK_NO_SOURCE);
    if (noSourcesLoaded && (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzsap_is_mobile)() === false) {
      if (selfClass.cthis.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.ERRORED_OUT_CLASS) === false) {

        if (attempt_reload < _configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.ERRORED_OUT_MAX_ATTEMPTS) {
          setTimeout(function (earg) {
            if (selfClass.$mediaNode_) {
              selfClass.$mediaNode_.src = '';
            }


            setTimeout(function () {
              if (selfClass.$mediaNode_) {
                selfClass.$mediaNode_.src = selfClass.data_source;
                selfClass.$mediaNode_.load();
              }
            }, 1000)
          }, 1000, e)
          attempt_reload++;
        } else {

          // -- IT FAILED LOADING

          if (selfClass.initOptions.notice_no_media === 'on') {
            selfClass.cthis.addClass(_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.ERRORED_OUT_CLASS);
            var txt = 'error - file does not exist...';
            if (e.target.error) {
              txt = e.target.error.message;
            }
            selfClass.cthis.append((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_2__.setupTooltip)({
              tooltipConClass: ' feedback-tooltip-con',
              tooltipIndicatorText: '<span class="player-but"><span class="the-icon-bg" style="background-color: #912c2c"></span><span class="svg-icon dzsap-color-ui-inverse" >&#x2139;</span></span>',
              tooltipInnerHTML: 'cannot load - ( ' + selfClass.data_source + ' ) - error: ' + txt,
            }));
          }
        }
      }
    }
  }


  function handleMediaMetaLoaded(e) {


    (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_view_addMetaLoaded)(selfClass);

    /** @type {HTMLAudioElement} */
    const $audio_ = e.currentTarget;

    if (isValidTotalTime($audio_.duration)) {
      selfClass.timeModel.actualTotalTime = Math.ceil($audio_.duration);
    }
    selfClass.service_checkIfWeShouldUpdateTotalTime();


    if (setupMediaAttrs.called_from === 'change_media') {

      action_initLoaded({
        'call_from': 'force_reload_change_media'
      })
    }

    if (setupMediaAttrs.called_from === 'change_media' || selfClass._sourcePlayer) {
      if (volume_lastVolume) {
        setTimeout(() => {
          volume_setVolume(selfClass, volume_lastVolume, {
            call_from: "change_media"
          });
        }, 50);
      }
    }

    if (selfClass._sourcePlayer) {
      if (isValidTotalTime($audio_.duration)) {
        selfClass._sourcePlayer.get(0).api_set_timeVisualTotal($audio_.duration)

      }
    }


    selfClass.view_drawCurrentTime();
  }

}


const buildAudioElementHtml = function (selfClass, type_normal_stream_type, calledFrom) {

  var stringAudioTagOpen = '';
  var stringAudioTagSource = '';
  var stringAudioTagClose = '';
  var o = selfClass.initOptions;


  if (selfClass.data_source) {
    if (selfClass.data_source.indexOf('get_track_source') > -1) {
      o.preload_method = 'none';
    }
  }

  stringAudioTagOpen += '<audio';
  stringAudioTagOpen += ' id="' + selfClass.uniqueId + '-audio"';
  stringAudioTagOpen += ' preload="' + o.preload_method + '"';
  if (o.skinwave_enableSpectrum === 'on') {
    stringAudioTagOpen += ' crossOrigin="anonymous"';

  }

  if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()) {
    if (calledFrom === 'change_media') {
      stringAudioTagOpen += ' autoplay';
    }
  }

  stringAudioTagOpen += '>';
  stringAudioTagSource = '';


  if (selfClass.data_source) {

    if (!selfClass.data_source && type_normal_stream_type !== 'icecast') {
      selfClass.data_source = selfClass.cthis.attr('data-source');
    }


    if (selfClass.data_source !== 'fake') {
      stringAudioTagSource += '<source src="' + selfClass.data_source + '" type="audio/mpeg">';
      if (selfClass.cthis.attr('data-sourceogg') !== undefined) {
        stringAudioTagSource += '<source src="' + selfClass.cthis.attr('data-sourceogg') + '" type="audio/ogg">';
      }
    } else {
      selfClass.cthis.addClass('meta-loaded meta-fake');
    }
  }
  stringAudioTagClose += '</audio>';


  return {
    stringAudioElementHtml: stringAudioTagOpen + stringAudioTagSource + stringAudioTagClose,
    stringAudioTagSource
  };

}

const makeMediaPreloadInTheFuture = function (selfClass, stringAudioElementHtml) {

  setTimeout(function () {
    if (selfClass.$mediaNode_) {
      jQuery(selfClass.$mediaNode_).attr('preload', 'metadata');
    }
  }, (Number(window.dzsap_player_index) * 10000));
}
const repairMediaElement = function (selfClass, stringAudioElementHtml) {

  var o = selfClass.initOptions;
  setTimeout(function () {

    if (selfClass.$theMedia.children().eq(0).get(0) && selfClass.$theMedia.children().eq(0).get(0).nodeName === "AUDIO") {

      return false;
    }
    selfClass.$theMedia.html('');
    selfClass.$mediaNode_ = null;
    selfClass.$theMedia.append(stringAudioElementHtml);

    var isWasPlaying = selfClass.isPlayerPlaying;

    selfClass.pause_media();
    selfClass.$mediaNode_ = (selfClass.$theMedia.children('audio').get(0));


    if (isWasPlaying) {
      setTimeout(function () {

        selfClass.play_media({
          'called_from': 'aux_was_playing'
        });
      }, 20);
    }
  }, o.failsafe_repair_media_element);

  o.failsafe_repair_media_element = '';
}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param callbackFn
 */
const media_pause = function (selfClass, callbackFn) {

  var $ = selfClass.$;


  if (selfClass.audioType === 'youtube') {


    if (selfClass.$mediaNode_ && selfClass.$mediaNode_.pauseVideo) {
      selfClass.$mediaNode_.pauseVideo();
    }
  }
  if (selfClass.audioType === 'selfHosted') {

    if (false) {} else {
      if (selfClass.$mediaNode_) {

        if (selfClass.initOptions.pause_method == 'stop') {

          selfClass.$mediaNode_.pause();
          selfClass.$mediaNode_.src = '';


          selfClass.destroy_cmedia();
          $(selfClass.$mediaNode_).remove();
          selfClass.$mediaNode_ = null;
        } else {

          if (selfClass.$mediaNode_.pause) {
            selfClass.$mediaNode_.pause();
          }
        }
      }

    }


  }

  callbackFn();

}

const isValidTotalTime = (duration) => {
  return Boolean(duration && duration !== Infinity);
}


const mediaSetupElement = (setupMediaAttrs, selfClass, stringAudioElement, stringAudioElementHtml) => {

  const stringAudioTagSource = stringAudioElement.stringAudioTagSource;
  if (setupMediaAttrs.called_from === 'change_media' || setupMediaAttrs.called_from === 'nonce generated') {

    if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() || (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()) {

      // -- we append only the source to mobile devices as we need the thing to autoplay without user action
      setupMediaElement(selfClass, stringAudioElementHtml, stringAudioTagSource);

    } else {
      // -- normal desktop
      if (!(setupMediaAttrs.called_from === 'nonce generated' && selfClass._actualPlayer)) {

        setupMediaElement(selfClass, stringAudioElementHtml);
      }
    }
    // -- end change media
  } else {
    setupMediaElement(selfClass, stringAudioElementHtml);

  }
}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param {object} pargs
 * @param init_loaded
 * @param pause_media
 * @param init_checkIfReady
 * @param handleClick_playPause
 * @returns {void}
 */
const mediaSetup = (selfClass, pargs, init_loaded, pause_media, init_checkIfReady, handleClick_playPause) => {
  var stringAudioElementHtml = '';

  var setupMediaAttrs = {

    'do_not_autoplay': false,
    'called_from': 'default',
    'newSource': '',
  };

  var $ = jQuery;
  var o = selfClass.initOptions;
  var cthis = selfClass.cthis;

  if (pargs) {
    setupMediaAttrs = $.extend(setupMediaAttrs, pargs);
  }

  if (selfClass.cthis && selfClass.cthis.attr('data-pcm')) {
    (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.assignPcmData)(selfClass);
  }

  // -- these types should not exist
  if (selfClass.audioType === 'icecast' || selfClass.audioType === 'shoutcast') {
    selfClass.audioType = 'selfHosted';
  }

  if (o.cueMedia === 'off') {
    if (selfClass.ajax_view_submitted === 'auto') {
      // -- why is view submitted ?
      selfClass.increment_views = 1;
      selfClass.ajax_view_submitted = 'off';
    }
  }

  if (selfClass.isPlayerLoaded) {
    return;
  }
  if (cthis.attr('data-original-type') === 'youtube') {
    return;
  }


  if (selfClass.audioType === 'youtube') {
    dzsap_youtube_setupMedia(selfClass, setupMediaAttrs);
  }
  // -- END youtube


  if (setupMediaAttrs.newSource) {
    selfClass.data_source = setupMediaAttrs.newSource;
  }

  if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()) {
    o.preload_method = 'metadata';
  }

  const stringAudioElement = buildAudioElementHtml(selfClass, selfClass.audioTypeSelfHosted_streamType, 'setup_media');
  stringAudioElementHtml = stringAudioElement.stringAudioElementHtml;

  if (selfClass.audioType === 'selfHosted' || selfClass.audioType === 'soundcloud') {

    mediaSetupElement(setupMediaAttrs, selfClass, stringAudioElement, stringAudioElementHtml);

    if (selfClass.$mediaNode_ && selfClass.$mediaNode_.addEventListener && selfClass.cthis.attr('data-source') !== 'fake') {
      setupMediaListeners(selfClass, setupMediaAttrs, init_loaded, selfClass.volume_lastVolume, _player_player_volume__WEBPACK_IMPORTED_MODULE_3__.volume_setVolume)
    }

  }

  selfClass.cthis.addClass('media-setuped');


  if (setupMediaAttrs.called_from === 'change_media') {
    return;
  }

  if (selfClass.audioType !== 'youtube') {
    if (selfClass.cthis.attr('data-source') === 'fake') {
      if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() || (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()) {
        init_loaded(setupMediaAttrs);
      }
    } else {
      if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()) {

        setTimeout(function () {
          init_loaded(setupMediaAttrs);
        }, 1000);


      } else {

        // -- check_ready() will fire init_loaded()
        selfClass.inter_checkReady = setInterval(function () {
          init_checkIfReady(setupMediaAttrs);
        }, 50);
      }

    }


    if (o.preload_method === 'none') {
      makeMediaPreloadInTheFuture(selfClass);
    }


    if (o.design_skin === 'skin-customcontrols' || o.design_skin === 'skin-customhtml') {
      cthis.find('.custom-play-btn,.custom-pause-btn').off('click');
      cthis.find('.custom-play-btn,.custom-pause-btn').on('click', handleClick_playPause);
    }

    if (o.failsafe_repair_media_element) {
      repairMediaElement(selfClass, stringAudioElementHtml);

    }
  }

  if (o.skinwave_enableSpectrum === 'on') {
    (0,_player_player_scrubModeWave_spectrum__WEBPACK_IMPORTED_MODULE_4__.player_initSpectrumOnUserAction)(selfClass);
  }

  selfClass.isSetupedMedia = true;
}



/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player-one-time-setups.js":
/*!*********************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player-one-time-setups.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dzsap_oneTimeSetups": () => (/* binding */ dzsap_oneTimeSetups)
/* harmony export */ });
const dzsap_oneTimeSetups = ()=>{

  if(!window.dzsap_skinFunctions_handleResize){
    window.dzsap_skinFunctions_handleResize = {};
  }

  window.dzsap_generate_list_for_sync_players = function (pargs) {
    var $ = jQuery;

    var margs = {
      'force_regenerate': false

    };

    if (pargs) {
      margs = $.extend(margs, pargs);
    }
    window.dzsap_syncList_players = [];


    if ((window.dzsap_settings.syncPlayers_buildList === 'on') || margs.force_regenerate) {

      jQuery('.audioplayer,.audioplayer-tobe').each(function () {
        var _t2 = jQuery(this);
        if (_t2.attr('data-do-not-include-in-list') !== 'on') {
          if (_t2.attr('data-type') !== 'fake' || _t2.attr('data-fakeplayer')) {
            window.dzsap_syncList_players.push(_t2);
          }
        }
      })


    }
  }


  jQuery(document).off('click.dzsap_global');
  jQuery(document).on('click.dzsap_global', '.dzsap-btn-info', function () {

    var _t = jQuery(this);
    if (_t.hasClass('dzsap-btn-info')) {

      _t.find('.dzstooltip').toggleClass('active');
      return;
    }

  })
  jQuery(document).on('mouseover.dzsap_global', '.dzsap-btn-info', function () {

    var _t = jQuery(this);
    if (_t.hasClass('dzsap-btn-info')) {

      if (window.innerWidth < 500) {

        if (_t.offset().left < (window.innerWidth / 2)) {
          _t.find('.dzstooltip').removeClass('talign-end').addClass('talign-start');
        }
      } else {
        _t.find('.dzstooltip').addClass('talign-end').removeClass('talign-start');
      }
    }

  });
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_commentsSelector.js":
/*!**********************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_commentsSelector.js ***!
  \**********************************************************************/
/***/ (() => {




/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_config.js":
/*!************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_config.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "configureAudioPlayerOptionsInitial": () => (/* binding */ configureAudioPlayerOptionsInitial),
/* harmony export */   "player_adjustIdentifiers": () => (/* binding */ player_adjustIdentifiers),
/* harmony export */   "player_detect_skinwave_mode": () => (/* binding */ player_detect_skinwave_mode),
/* harmony export */   "player_determineActualPlayer": () => (/* binding */ player_determineActualPlayer),
/* harmony export */   "player_determineHtmlAreas": () => (/* binding */ player_determineHtmlAreas),
/* harmony export */   "player_viewApplySkinWaveModes": () => (/* binding */ player_viewApplySkinWaveModes)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _dzsap_svgs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../_dzsap_svgs */ "../source/audioplayer/jsinc/_dzsap_svgs.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");





/**
 *
 * @param {jQuery} cthis
 * @param {object} o
 * @param {DzsAudioPlayer} selfClass
 */
function configureAudioPlayerOptionsInitial(cthis, o, selfClass) {


  selfClass.cthis.addClass('preload-method-' + o.preload_method);

  o.wavesurfer_pcm_length = Number(o.wavesurfer_pcm_length);


  o.settings_trigger_resize = parseInt(o.settings_trigger_resize, 10);

  if((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzsap_is_mobile)()){
    o.preview_on_hover = 'off';
  }

  if (isNaN(parseInt(o.design_thumbh, 10)) === false) {
    o.design_thumbh = parseInt(o.design_thumbh, 10);
  }

  if (o.skinwave_wave_mode === '') {
    o.skinwave_wave_mode = 'canvas';
  }
  if (o.skinwave_enableSpectrum === 'on') {
    o.skinwave_wave_mode = 'canvas';
  }
  if (o.skinwave_wave_mode_canvas_normalize === '') {
    o.skinwave_wave_mode_canvas_normalize = 'on';
  }
  if (o.skinwave_wave_mode_canvas_waves_number === '' || isNaN(Number(o.skinwave_wave_mode_canvas_waves_number))) {
    o.skinwave_wave_mode_canvas_waves_number = 3;
  }


  if (o.autoplay === 'on' && o.cue === 'on') {
    o.preload_method = 'auto';
  }

  cthis.addClass(o.extra_classes_player)

  if (o.design_skin === '') {
    o.design_skin = 'skin-default';
  }


  if (selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_3__.DZSAP_CLASS_NAME_FEED_EMBED_CODE}`).length) {

    selfClass.feedEmbedCode = selfClass.cthis.find(`.${_configs_constants__WEBPACK_IMPORTED_MODULE_3__.DZSAP_CLASS_NAME_FEED_EMBED_CODE}`).eq(0).html();
  } else {
    if (o.embed_code !== '') {
      selfClass.feedEmbedCode = o.embed_code;
    }
  }

  if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()) {

    if (selfClass.initOptions.skinwave_enableSpectrum === 'on') {
      selfClass.initOptions.skinwave_enableSpectrum = 'off';
    }

  }

  const skin_regex = / skin-/g;


  if (skin_regex.test(cthis.attr('class'))) {

  } else {

    cthis.addClass(o.design_skin);
  }


  if (cthis.hasClass('skin-default')) {
    o.design_skin = 'skin-default';
  }
  if (cthis.hasClass('skin-wave')) {
    o.design_skin = 'skin-wave';
  }
  if (cthis.hasClass('skin-justthumbandbutton')) {
    o.design_skin = 'skin-justthumbandbutton';
  }
  if (cthis.hasClass('skin-pro')) {
    o.design_skin = 'skin-pro';
  }
  if (cthis.hasClass('skin-aria')) {
    o.design_skin = 'skin-aria';
  }
  if (cthis.hasClass('skin-silver')) {
    o.design_skin = 'skin-silver';
  }
  if (cthis.hasClass('skin-redlights')) {
    o.design_skin = 'skin-redlights';
  }
  if (cthis.hasClass('skin-steel')) {
    o.design_skin = 'skin-steel';
  }
  if (cthis.hasClass('skin-customcontrols')) {
    o.design_skin = 'skin-customcontrols';
  }


  if (o.design_skin === 'skin-wave') {
    if (o.scrubbar_type === 'auto') {
      o.scrubbar_type = 'wave';
    }
  }
  if (o.scrubbar_type === 'auto') {
    o.scrubbar_type = 'bar';
  }

  if (o.settings_php_handler === 'wpdefault') {
    o.settings_php_handler = window.ajaxurl;
  }
  if (o.action_received_time_total === 'wpdefault') {
    o.action_received_time_total = window.dzsap_send_total_time;
  }
  if (o.action_video_contor_60secs === 'wpdefault') {
    o.action_video_contor_60secs = window.action_video_contor_60secs;
  }


  if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() || (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()) {
    o.autoplay = 'off';
    o.disable_volume = 'on';
    if (o.cueMedia === 'off') {
      o.cueMedia = 'on';
    }
    o.cueMedia = 'on';
  }

  if (cthis.attr('data-viewsubmitted') === 'on') {
    selfClass.ajax_view_submitted = 'on';


  }
  if (cthis.attr('data-userstarrating')) {
    selfClass.starrating_alreadyrated = Number(cthis.attr('data-userstarrating'));
  }

  if (cthis.attr('data-loop') === 'on') {
    selfClass.initOptions.loop = 'on';
  }


  if (cthis.hasClass('skin-minimal')) {
    o.design_skin = 'skin-minimal';
    if (o.disable_volume === 'default') {
      o.disable_volume = 'on';
    }

    if (o.disable_scrub === 'default') {
      o.disable_scrub = 'on';
    }
    o.disable_timer = 'on';
  }
  if (cthis.hasClass('skin-minion')) {
    o.design_skin = 'skin-minion';
    if (o.disable_volume === 'default') {
      o.disable_volume = 'on';
    }

    if (o.disable_scrub === 'default') {
      o.disable_scrub = 'on';
    }

    o.disable_timer = 'on';
  }


  if (o.design_color_bg) {
    o.design_wave_color_bg = o.design_color_bg;
  }


  if (o.design_color_highlight) {
    o.design_wave_color_progress = o.design_color_highlight;
  }


  if (o.design_skin === 'skin-justthumbandbutton') {
    if (o.design_thumbh === 'default') {
      o.design_thumbh = '';

    }
    o.disable_timer = 'on';
    o.disable_volume = 'on';

    if (o.design_animateplaypause === 'default') {
      o.design_animateplaypause = 'on';
    }
  }
  if (o.design_skin === 'skin-redlights') {
    o.disable_timer = 'on';
    o.disable_volume = 'off';
    if (o.design_animateplaypause === 'default') {
      o.design_animateplaypause = 'on';
    }

  }
  if (o.design_skin === 'skin-steel') {
    if (o.disable_timer === 'default') {

      o.disable_timer = 'off';
    }
    o.disable_volume = 'on';
    if (o.design_animateplaypause === 'default') {
      o.design_animateplaypause = 'on';
    }


    if (o.disable_scrub === 'default') {
      o.disable_scrub = 'on';
    }

  }
  if (o.design_skin === 'skin-customcontrols') {
    if (o.disable_timer === 'default') {

      o.disable_timer = 'on';
    }
    o.disable_volume = 'on';
    if (o.design_animateplaypause === 'default') {
      o.design_animateplaypause = 'on';
    }


    if (o.disable_scrub === 'default') {
      o.disable_scrub = 'on';
    }

  }

  if (o.skinwave_wave_mode_canvas_mode === 'reflecto') {
    o.skinwave_wave_mode_canvas_reflection_size = 0.5;


  }

  if (o.skinwave_wave_mode_canvas_mode === 'reflecto') {
    o.skinwave_wave_mode_canvas_reflection_size = 0.5;

  }


  if (o.embed_code === '') {
    if (cthis.find('div.feed-embed-code').length > 0) {
      o.embed_code = cthis.find('div.feed-embed-code').eq(0).html();
    }
  }

  if (o.design_animateplaypause === 'default') {
    o.design_animateplaypause = 'off';
  }

  if (o.design_animateplaypause === 'on') {
    cthis.addClass('design-animateplaypause');
  }

  if (window.dzsap_settings) {
    if (window.dzsap_settings.ajax_url) {
      if (!o.settings_php_handler) {

        o.settings_php_handler = window.dzsap_settings.ajax_url;
      }
    }
  }

  if (o.settings_php_handler) {
    selfClass.urlToAjaxHandler = o.settings_php_handler;
  } else {
    if (window.dzsap_settings && window.dzsap_settings.php_handler) {

      selfClass.urlToAjaxHandler = window.dzsap_settings.php_handler;
    }
  }


  (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_reinit_findIfPcmNeedsGenerating)(selfClass);

}

function player_detect_skinwave_mode() {

  const selfClass = this;


  selfClass.skinwave_mode = selfClass.initOptions.skinwave_mode;

  if (selfClass.cthis.hasClass('skin-wave-mode-small')) {
    selfClass.skinwave_mode = 'small'
  }
  if (selfClass.cthis.hasClass('skin-wave-mode-alternate')) {
    selfClass.skinwave_mode = 'alternate'
  }
  if (selfClass.cthis.hasClass('skin-wave-mode-bigwavo')) {
    selfClass.skinwave_mode = 'bigwavo'
  }
}



function player_viewApplySkinWaveModes(selfClass) {


  var o = selfClass.initOptions;

  selfClass.cthis.removeClass('skin-wave-mode-normal');

  if (o.design_skin === 'skin-wave') {
    selfClass.cthis.addClass('skin-wave-mode-' + selfClass.skinwave_mode);


    selfClass.cthis.addClass('skin-wave-wave-mode-' + o.skinwave_wave_mode);
    if (o.skinwave_enableSpectrum === 'on') {
      selfClass.cthis.addClass('skin-wave-is-spectrum');
    }
    selfClass.cthis.addClass('skin-wave-wave-mode-canvas-mode-' + o.skinwave_wave_mode_canvas_mode);
  }


}

function player_determineHtmlAreas(selfClass) {

  var o = selfClass.initOptions;


  let extraHtmlBottom = '';
  let extraHtmlControlsLeft = '';
  let extraHtmlControlsRight = '';


  if (selfClass.cthis.children('.feed-dzsap--extra-html').length > 0 && o.settings_extrahtml === '') {
    selfClass.cthis.children('.feed-dzsap--extra-html').each(function () {

      let newExtraHtmlSectionClassName = (0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.string_curateClassName)(this.className);
      extraHtmlBottom += `<section class="dzsap-extra-html--section-bottom ${newExtraHtmlSectionClassName}">${this.innerHTML}</section>`;
    })
    selfClass.cthis.children('.feed-dzsap--extra-html').remove();
  } else {
    if (o.settings_extrahtml) {
      extraHtmlBottom = o.settings_extrahtml;
    }
  }


  if (selfClass.cthis.children('.feed-dzsap--extra-html-in-controls-left').length > 0) {
    extraHtmlControlsLeft = selfClass.cthis.children('.feed-dzsap--extra-html-in-controls-left').eq(0).html();
  }
  if (selfClass.cthis.children('.feed-dzsap--extra-html-in-controls-right').length > 0) {
    extraHtmlControlsRight = selfClass.cthis.children('.feed-dzsap--extra-html-in-controls-right').eq(0).html();
  }
  if (selfClass.cthis.children('.feed-dzsap--extra-html-bottom').length > 0) {
    extraHtmlBottom = selfClass.cthis.children('.feed-dzsap--extra-html-bottom').eq(0).html();
  }


  selfClass.extraHtmlAreas.controlsLeft = extraHtmlControlsLeft;
  selfClass.extraHtmlAreas.controlsRight = extraHtmlControlsRight;
  selfClass.extraHtmlAreas.bottom = extraHtmlBottom;


  if (selfClass.extraHtmlAreas.controlsRight) {
    selfClass.extraHtmlAreas.controlsRight = String(selfClass.extraHtmlAreas.controlsRight).replace(/{{svg_share_icon}}/g, _dzsap_svgs__WEBPACK_IMPORTED_MODULE_2__.svg_share_icon);
  }


  for (var key in selfClass.extraHtmlAreas) {

    selfClass.extraHtmlAreas[key] = String(selfClass.extraHtmlAreas[key]).replace('{{heart_svg}}', '\t&hearts;');
    selfClass.extraHtmlAreas[key] = String(selfClass.extraHtmlAreas[key]).replace('{{embed_code}}', selfClass.feedEmbedCode);
  }
}


function player_determineActualPlayer(selfClass) {

  var $ = jQuery;
  var $fakePlayer = $(selfClass.cthis.attr('data-fakeplayer'));


  if ($fakePlayer.length === 0) {
    $fakePlayer = $(String(selfClass.cthis.attr('data-fakeplayer')).replace('#', '.'));
    if ($fakePlayer.length) {
      selfClass._actualPlayer = $(String(selfClass.cthis.attr('data-fakeplayer')).replace('#', '.'));
      selfClass.cthis.attr('data-fakeplayer', String(selfClass.cthis.attr('data-fakeplayer')).replace('#', '.'));
    }
  }

  if ($fakePlayer.length === 0) {
    selfClass.cthis.attr('data-fakeplayer', '');
  } else {
    selfClass.cthis.addClass('player-is-feeding is-source-player-for-actual-player');
    if (selfClass.cthis.attr('data-type')) {
      selfClass._actualPlayer = $(selfClass.cthis.attr('data-fakeplayer')).eq(0);
      selfClass._actualPlayer.addClass('player-is-feeded');
      selfClass.actualDataTypeOfMedia = selfClass.cthis.attr('data-type');
      selfClass.cthis.attr('data-original-type', selfClass.actualDataTypeOfMedia);
    }
  }
}


function player_adjustIdentifiers(selfClass) {

  selfClass.identifier_pcm = selfClass.the_player_id;


  var _feed_obj = null;

  if (selfClass.$feed_fakeButton) {
    _feed_obj = selfClass.$feed_fakeButton;
  } else {
    if (selfClass._sourcePlayer) {
      _feed_obj = selfClass._sourcePlayer;
    } else {
      _feed_obj = null;
    }
  }


  if (selfClass.identifier_pcm === 'dzs_footer') {
    selfClass.identifier_pcm = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzs_clean_string)(selfClass.cthis.attr('data-source'));
  }

  if (_feed_obj) {
    if (_feed_obj.attr('data-playerid')) {
      selfClass.identifier_pcm = _feed_obj.attr('data-playerid');
    } else {
      if (_feed_obj.attr('data-source')) {
        selfClass.identifier_pcm = _feed_obj.attr('data-source');
      }
    }
  }

  if (typeof selfClass.identifier_pcm === 'string') {
    selfClass.identifier_pcm = selfClass.identifier_pcm.replace('ap', '');
  }

}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_feederFunctions.js":
/*!*********************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_feederFunctions.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_actualPlayerPause": () => (/* binding */ player_actualPlayerPause),
/* harmony export */   "player_actualPlayerPlay": () => (/* binding */ player_actualPlayerPlay),
/* harmony export */   "player_feederSeekTo": () => (/* binding */ player_feederSeekTo),
/* harmony export */   "player_sourcePlayerPauseVisual": () => (/* binding */ player_sourcePlayerPauseVisual),
/* harmony export */   "player_sourcePlayerPlayVisual": () => (/* binding */ player_sourcePlayerPlayVisual)
/* harmony export */ });
/* harmony import */ var _dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_ajax */ "../source/audioplayer/jsinc/_dzsap_ajax.js");



function player_sourcePlayerPauseVisual(selfClass){
  if (selfClass._sourcePlayer.get(0) && selfClass._sourcePlayer.get(0).api_pause_media_visual) {
    selfClass._sourcePlayer.get(0).api_pause_media_visual({
      'call_from': 'pause_media in child player'
    });
  }
}
function player_sourcePlayerPlayVisual(selfClass){
  if (selfClass._sourcePlayer.get(0) && selfClass._sourcePlayer.get(0).api_play_media_visual) {
    selfClass._sourcePlayer.get(0).api_play_media_visual({
      'api_report_play_media': false
    });
  }
}
function player_actualPlayerPlay(selfClass, margs, seek_to){

  const cthis = selfClass.cthis;
  const o = selfClass.initOptions;

  const output = {
    itShouldReturn : false
  }
  // -- the actual player is the footer player

  let args = {
    type: selfClass.actualDataTypeOfMedia,
    fakeplayer_is_feeder: 'on',
    call_from: 'play_media_audioplayer'
  }

  try {
    if (margs.called_from === 'click_playpause') {
      // -- let us reset up the playlist


      if (o.parentgallery) {
        o.parentgallery.get(0).api_regenerate_sync_players_with_this_playlist();
        selfClass._actualPlayer.get(0).api_regenerate_playerlist_inner();
      }

    }

    if (selfClass._actualPlayer && selfClass._actualPlayer.length && selfClass._actualPlayer.data('feeding-from') !== cthis.get(0)) {

      args.called_from = 'play_media from player 22 ' + cthis.attr('data-source') + ' < -  ' + 'old call from - ' + margs.called_from;

      if (selfClass._actualPlayer.get(0).api_change_media) {
        selfClass._actualPlayer.get(0).api_change_media(cthis, args);
      }

      if (!cthis.hasClass('first-played')) {
        if (cthis.data('promise-to-play-footer-player-from')) {
          seek_to(cthis.data('promise-to-play-footer-player-from'));
          setTimeout(function () {
            cthis.data('promise-to-play-footer-player-from', '');
          }, 1000);
        }
      }

    }
    setTimeout(function () {
      if (selfClass._actualPlayer.get(0) && selfClass._actualPlayer.get(0).api_play_media) {
        selfClass._actualPlayer.get(0).api_play_media({
          'called_from': '[feed_to_feeder]'
        });
      }
    }, 100);


    if (selfClass.ajax_view_submitted === 'off') {
      (_dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__.ajax_submit_views.bind(selfClass))();
    }

    output.itShouldReturn = true;


  } catch (err) {
    console.log('no fake player..', err);
  }

  return output;
}
function player_actualPlayerPause(selfClass){

  const cthis = selfClass.cthis;


  let args = {
    type: selfClass.actualDataTypeOfMedia,
    fakeplayer_is_feeder: 'on'
  }
  if (selfClass._actualPlayer && selfClass._actualPlayer.length && selfClass._actualPlayer.data('feeding-from') !== cthis.get(0)) {
    args.called_from = 'pause_media from player ' + cthis.attr('data-source');
    selfClass._actualPlayer.get(0).api_change_media(cthis, args);
  }
  setTimeout(function () {
    if (selfClass._actualPlayer.get(0) && selfClass._actualPlayer.get(0).api_pause_media) {
      selfClass._actualPlayer.get(0).api_pause_media();
    }
  }, 100);
}
function player_feederSeekTo(selfClass, margs, targetTimeMediaScrub){

  const cthis = selfClass.cthis;

  let args = {
    type: selfClass.actualDataTypeOfMedia,
    fakeplayer_is_feeder: 'on'
  }
  if (selfClass._actualPlayer.length && selfClass._actualPlayer.data('feeding-from') !== cthis.get(0)) {
    // -- the actualPlayer is not rendering this feed player
    if (margs.call_from !== 'handle_end' && margs.call_from !== 'from_playfrom' && margs.call_from !== 'last_pos' && margs.call_from !== 'playlist_seek_from_0') {
      // -- if it is not user action, ( handle_end or anything else )
      args.called_from = 'seek_to from player source->' + (cthis.attr('data-source')) + ' < -  ' + 'old call from - ' + margs.call_from;
      if (selfClass._actualPlayer.get(0).api_change_media) {
        selfClass._actualPlayer.get(0).api_change_media(cthis, args);
      } else {
        console.log('not inited ? ', selfClass._actualPlayer);
      }
    } else {
      // -- NORMAL call

      cthis.data('promise-to-play-footer-player-from', targetTimeMediaScrub);
    }
  }


  setTimeout(function () {

    if (selfClass._actualPlayer.get(0) && selfClass._actualPlayer.get(0).api_pause_media) {
      if (margs.call_from !== 'from_playfrom' && margs.call_from !== 'last_pos') {
        selfClass._actualPlayer.get(0).api_seek_to(targetTimeMediaScrub, {
          'call_from': 'from_feeder_to_feed'
        });
      }
    }
  }, 50);
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_keyboard.js":
/*!**************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_keyboard.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dzsap_generate_keyboard_controls": () => (/* binding */ dzsap_generate_keyboard_controls),
/* harmony export */   "dzsap_keyboardSetup": () => (/* binding */ dzsap_keyboardSetup),
/* harmony export */   "handle_keypresses": () => (/* binding */ handle_keypresses)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const dzsap_generate_keyboard_controls = function () {
  let keyboard_controls = {
    'play_trigger_step_back': 'off'
    , 'step_back_amount': '5'
    , 'step_back': '37'
    , 'step_forward': '39'
    , 'sync_players_goto_next': ''
    , 'sync_players_goto_prev': ''
    , 'pause_play': '32'
    , 'show_tooltips': 'off'
  }


  const $keyboardControlsInfo = jQuery(_configs_constants__WEBPACK_IMPORTED_MODULE_0__.DZSAP_SCRIPT_SELECTOR_KEYBOARD);
  if ($keyboardControlsInfo.length) {
    window.dzsap_keyboard_controls = JSON.parse($keyboardControlsInfo.html());
  }

  if (window.dzsap_keyboard_controls) {
    keyboard_controls = jQuery.extend(keyboard_controls, window.dzsap_keyboard_controls);
  }

  keyboard_controls.step_back_amount = Number(keyboard_controls.step_back_amount);


  return keyboard_controls;
};


function handle_keypresses(e) {

  if (window.dzsap_isTextFieldFocused) {
    return;
  }


  function isKeyPressed(checkKeyCode) {
    let isKeyPressed = false;
    if (checkKeyCode.indexOf('ctrl+') > -1) {
      if (e.ctrlKey) {
        checkKeyCode = checkKeyCode.replace('ctrl+', '');
        if (e.keyCode === Number(checkKeyCode)) {
          isKeyPressed = true;
        }
      }
    } else {
      if (e.keyCode === Number(checkKeyCode)) {
        isKeyPressed = true;
      }
    }
    return isKeyPressed;
  }

  var $ = jQuery;

  const keyboard_controls = $.extend({}, dzsap_generate_keyboard_controls());


  if (dzsap_currplayer_focused && dzsap_currplayer_focused.api_pause_media) {

    if (isKeyPressed(keyboard_controls.pause_play)) {
      if (!$(dzsap_currplayer_focused).hasClass('comments-writer-active')) {
        if ($(dzsap_currplayer_focused).hasClass('is-playing')) {
          dzsap_currplayer_focused.api_pause_media();
        } else {
          dzsap_currplayer_focused.api_play_media();
        }

        if (window.dzsap_mouseover) {
          e.preventDefault();
          return false;
        }
      }
    }

    if (isKeyPressed(keyboard_controls.step_back)) {
      dzsap_currplayer_focused.api_step_back(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.step_forward)) {
      dzsap_currplayer_focused.api_step_forward(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.sync_players_goto_next)) {
      dzsap_currplayer_focused.api_sync_players_goto_next();
    }


    if (isKeyPressed(keyboard_controls.sync_players_goto_prev)) {
      dzsap_currplayer_focused.api_sync_players_goto_prev();
    }


  }
}


/**
 * called in singleton
 */
const dzsap_keyboardSetup = () => {

  let $ = jQuery;

  window.dzsap_isTextFieldFocused = false;

  $(document).off('keydown.dzsapkeyup');
  $(document).on('keydown.dzsapkeyup', handle_keypresses);


  $(document).on('focus blur', 'textarea,input', function (e) {

    if (e.type == 'focusin' || e.type == 'focus') {

      window.dzsap_isTextFieldFocused = true;
    }
    if (e.type == 'focusout' || e.type == 'blur') {

      window.dzsap_isTextFieldFocused = false;
    }
  });


  $(document).on('keydown blur', '.zoomsounds-search-field', function (e) {
    const _t = $(e.currentTarget);

    setTimeout(function () {

      if (_t) {
        let $audioGallery = $('.audiogallery').eq(0);
        if (_t.attr('data-target')) {
          $audioGallery = $(_t.attr('data-target'));
        }
        if ($audioGallery.get(0) && $audioGallery.get(0).api_filter) {
          $audioGallery.get(0).api_filter('title', _t.val());
        }
      }
    }, 100);

  });
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_menuState.js":
/*!***************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_menuState.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_menuStateSetup": () => (/* binding */ player_menuStateSetup)
/* harmony export */ });
const player_menuStateSetup = (cthis,o) => {

  cthis.find('.btn-menu-state').eq(0).on('click', handleClickMenuState);


  function handleClickMenuState(e) {
    if (o.parentgallery && typeof (o.parentgallery.get(0)) !== "undefined") {
      o.parentgallery.get(0).api_toggle_menu_state();
    }
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_nextPrevButtons.js":
/*!*********************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_nextPrevButtons.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_nextPrevButtonsSetup": () => (/* binding */ player_nextPrevButtonsSetup),
/* harmony export */   "syncPlayers_gotoItem": () => (/* binding */ syncPlayers_gotoItem),
/* harmony export */   "syncPlayers_gotoNext": () => (/* binding */ syncPlayers_gotoNext),
/* harmony export */   "syncPlayers_gotoPrev": () => (/* binding */ syncPlayers_gotoPrev)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");


const player_nextPrevButtonsSetup = (selfClass, cthis, o) => {

  cthis.on('click', '.prev-btn,.next-btn', handle_mouse);


  function handle_mouse(e) {
    let _target;
    const $t = jQuery(this);

    if (e.type === 'click') {
      if ($t.hasClass('prev-btn')) {
        handleClick_prevBtn();
      }
      if ($t.hasClass('next-btn')) {
        handleClick_nextBtn();
      }
    }
  }


  function handleClick_prevBtn() {
    if (o.parentgallery && (o.parentgallery.get(0))) {
      o.parentgallery.get(0).api_goto_prev();
    } else {

      syncPlayers_gotoPrev(selfClass);
    }
  }

  function handleClick_nextBtn() {
    if (o.parentgallery && (o.parentgallery.get(0))) {
      o.parentgallery.get(0).api_goto_next();
    } else {

      syncPlayers_gotoNext(selfClass);
    }
  }
}


function syncPlayers_gotoPrev(selfClass) {


  if (selfClass._actualPlayer) {
    selfClass._actualPlayer.get(0).api_sync_players_goto_prev();

    return false;
  }


  syncPlayers_gotoItem(selfClass, -1);

}


/**
 * go to next inner playlistItem for single player
 * @returns {boolean}
 */
function syncPlayers_gotoNext(selfClass) {

  if (selfClass._actualPlayer) {
    selfClass._actualPlayer.get(0).api_sync_players_goto_next();

    return false;
  }
  syncPlayers_gotoItem(selfClass, 1);
}

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param targetIncrement
 */
function syncPlayers_gotoItem(selfClass, targetIncrement = 0) {


  let targetIndex = 0;
  if (selfClass.classFunctionalityInnerPlaylist) {
    // -- playlist Inner

    targetIndex = selfClass.playlist_inner_currNr + targetIncrement;
    if (targetIndex >= 0) {
      selfClass.classFunctionalityInnerPlaylist.playlistInner_gotoItem(targetIndex, {
        'call_from': 'api_sync_players_prev'
      });
    }
  } else {
    if (window.dzsap_syncList_players && window.dzsap_syncList_players.length > 0) {
      (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_syncPlayers_gotoItem)(selfClass, targetIncrement);
    } else {
      console.log('[dzsap] [syncPlayers] no players found')
    }
  }

  if (window.dzsap_syncList_players && window.dzsap_syncList_index >= window.dzsap_syncList_players.length) {
    window.dzsap_syncList_index = 0;
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_scrubModeWave.js":
/*!*******************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_scrubModeWave.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "scrubbar_modeWave_clearObsoleteCanvas": () => (/* binding */ scrubbar_modeWave_clearObsoleteCanvas),
/* harmony export */   "scrubbar_modeWave_setupCanvas": () => (/* binding */ scrubbar_modeWave_setupCanvas),
/* harmony export */   "scrubbar_modeWave_setupCanvas_context": () => (/* binding */ scrubbar_modeWave_setupCanvas_context),
/* harmony export */   "view_player_scrubModeWaveAdjustCurrTimeAndTotalTime": () => (/* binding */ view_player_scrubModeWaveAdjustCurrTimeAndTotalTime)
/* harmony export */ });


function scrubbar_modeWave_clearObsoleteCanvas(selfClass) {
  if (selfClass._scrubbar) {
    selfClass._scrubbar.find('.scrubbar-type-wave--canvas.transitioning-out').remove();
  }
}


function scrubbar_modeWave_setupCanvas_context(_canvas) {
  if(_canvas.get(0)){

    const _canvasContext = _canvas.get(0).getContext("2d");

    _canvasContext.imageSmoothingEnabled = false;
    _canvasContext.imageSmoothing = false;
    _canvasContext.imageSmoothingQuality = "high";
    _canvasContext.webkitImageSmoothing = false;
  }
}

function scrubbar_modeWave_setupCanvas(pargs, selfClass) {

  var margs = {
    prepare_for_transition_in: false
  }

  if (pargs) {
    margs = Object.assign(margs, pargs);
  }


  var struct_scrubBg_str = '';
  var struct_scrubProg_str = '';
  var aux_selector = '';
  var o = selfClass.initOptions;


  struct_scrubBg_str = '<canvas class="scrubbar-type-wave--canvas scrub-bg-img';
  struct_scrubBg_str += '" ></canvas>';

  struct_scrubProg_str = '<canvas class="scrubbar-type-wave--canvas scrub-prog-img';
  struct_scrubProg_str += '" ></canvas>';


  selfClass._scrubbar.find('.scrub-bg').eq(0).append(struct_scrubBg_str);
  selfClass._scrubbar.find('.scrub-prog').eq(0).append(struct_scrubProg_str);


  selfClass._scrubbarbg_canvas = selfClass._scrubbar.find('.scrub-bg-img').last();
  selfClass._scrubbarprog_canvas = selfClass._scrubbar.find('.scrub-prog-img').last();

  if (o.skinwave_enableSpectrum === 'on') {
    selfClass._scrubbarprog_canvas.hide();
  }


  scrubbar_modeWave_setupCanvas_context(selfClass._scrubbarbg_canvas);
  scrubbar_modeWave_setupCanvas_context(selfClass._scrubbarprog_canvas);


  if (margs.prepare_for_transition_in) {
    selfClass._scrubbarbg_canvas.addClass('preparing-transitioning-in');
    selfClass._scrubbarprog_canvas.addClass('preparing-transitioning-in');
    setTimeout(function () {
      selfClass._scrubbarbg_canvas.addClass('transitioning-in');
      selfClass._scrubbarprog_canvas.addClass('transitioning-in');
    }, 20);
  }
}


function view_player_scrubModeWaveAdjustCurrTimeAndTotalTime(selfClass){

  const cthis = selfClass.cthis;

  if (selfClass.scrubbarProgX < 0) {
    selfClass.scrubbarProgX = 0;
  }
  selfClass.scrubbarProgX = parseInt(selfClass.scrubbarProgX, 10);


  if (selfClass.scrubbarProgX < 2 && cthis.data('promise-to-play-footer-player-from')) {
    return false;
  }

  // -- move currTime
  selfClass.$currTime.css({
    'left': selfClass.scrubbarProgX
  });

  if (selfClass.scrubbarProgX > selfClass.scrubbarWidth - selfClass.currTime_outerWidth) {
    selfClass.$currTime.css({
      'left': selfClass.scrubbarWidth - selfClass.currTime_outerWidth
    })
  }
  if (selfClass.scrubbarProgX > selfClass.scrubbarWidth - 30 && selfClass.scrubbarWidth) {
    selfClass.$totalTime.css({
      'opacity': 1 - (((selfClass.scrubbarProgX - (selfClass.scrubbarWidth - 30)) / 30))
    });
  } else {
    if (selfClass.$totalTime.css('opacity') !== '1') {
      selfClass.$totalTime.css({
        'opacity': ''
      });
    }
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_scrubModeWave_spectrum.js":
/*!****************************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_scrubModeWave_spectrum.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_initSpectrum": () => (/* binding */ player_initSpectrum),
/* harmony export */   "player_initSpectrumOnUserAction": () => (/* binding */ player_initSpectrumOnUserAction),
/* harmony export */   "view_spectrum_drawMeter": () => (/* binding */ view_spectrum_drawMeter)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../wave-render/_wave-render-functions */ "../source/audioplayer/jsinc/wave-render/_wave-render-functions.js");



/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function player_initSpectrum(selfClass) {


  if (window.dzsap_audio_ctx === null) {
    if (typeof AudioContext !== 'undefined') {
      selfClass.spectrum_audioContext = new AudioContext();
    } else if (typeof webkitAudioContext !== 'undefined') {
      selfClass.spectrum_audioContext = new webkitAudioContext();
    } else {
      selfClass.spectrum_audioContext = null;
    }
    window.dzsap_audio_ctx = selfClass.spectrum_audioContext;
  } else {
    selfClass.spectrum_audioContext = window.dzsap_audio_ctx;
  }


  if (selfClass.spectrum_audioContext) {
    if (selfClass.spectrum_analyser === null) {

      selfClass.spectrum_analyser = selfClass.spectrum_audioContext.createAnalyser();
      selfClass.spectrum_analyser.smoothingTimeConstant = 0.3;
      selfClass.spectrum_analyser.fftSize = 512;

      if (selfClass.audioType === 'selfHosted') {
        selfClass.$mediaNode_.crossOrigin = "anonymous";
        selfClass.spectrum_mediaElementSource = selfClass.spectrum_audioContext.createMediaElementSource(selfClass.$mediaNode_);

        selfClass.spectrum_mediaElementSource.connect(selfClass.spectrum_analyser);
        if (selfClass.spectrum_audioContext.createGain) {
          selfClass.spectrum_gainNode = selfClass.spectrum_audioContext.createGain();
        }
        selfClass.spectrum_analyser.connect(selfClass.spectrum_audioContext.destination);

        selfClass.spectrum_gainNode.gain.value = 1;

        const frameCount = selfClass.spectrum_audioContext.sampleRate * 2.0;
        selfClass.spectrum_audioContext_buffer = selfClass.spectrum_audioContext.createBuffer(2, frameCount, selfClass.spectrum_audioContext.sampleRate);
      }
    }
  }


  if (selfClass._scrubbarbg_canvas) {

    selfClass.canvasWidth = selfClass._scrubbarbg_canvas.width();
    selfClass.heightCanvas = selfClass._scrubbarbg_canvas.height();


    if (selfClass.heightCanvas == 0) {
      selfClass.heightCanvas = 100;
    }

    selfClass._scrubbarbg_canvas.get(0).width = selfClass.canvasWidth;
    selfClass._scrubbarbg_canvas.get(0).height = selfClass.heightCanvas;
  }
}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function player_initSpectrumOnUserAction(selfClass) {


  selfClass.cthis.get(0).addEventListener('mousedown', handleMouseDown, {once: true});
  selfClass.cthis.get(0).addEventListener('touchdown', handleMouseDown, {once: true});

  function handleMouseDown(e) {
    player_initSpectrum(selfClass);
  }


}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param $scrubBgCanvas
 * @param {string} spectrum_fakeItMode
 * @param {number} heightCanvas
 */
const view_spectrum_drawMeter = function (selfClass, $scrubBgCanvas, spectrum_fakeItMode, heightCanvas) {


  // -- spectrum ON
  // -- easing

  let duration_viy = 20;
  let begin_viy = 0;
  let change_viy = 0;

  if (selfClass.initOptions.type === 'soundcloud' || spectrum_fakeItMode === 'on') {
    selfClass.lastArray = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.generateFakeArrayForPcm)();

  } else {


    if (selfClass.spectrum_analyser) {

      if (selfClass.isPlayerPlaying) {
        selfClass.lastArray = new Uint8Array(selfClass.spectrum_analyser.frequencyBinCount);
        selfClass.spectrum_analyser.getByteFrequencyData(selfClass.lastArray);
      }


    }
  }


  // -- normalize if pcmSource exists
  if (selfClass.pcmSource) {
    for (let i = 0; i < selfClass.lastArray.length; i++) {
      selfClass.lastArray[i] = (selfClass.lastArray[i] * 3/4 + (selfClass.pcmSource[i] /4));
    }
  }


  if (selfClass.lastArray && selfClass.lastArray.length) {
    // -- fix when some sounds end the value still not back to zero
    const len = selfClass.lastArray.length;
    for (let i = len - 1; i >= 0; i--) {

      if (i < len / 2) {

        selfClass.lastArray[i] = selfClass.lastArray[i] / 255 * heightCanvas;
      } else {

        selfClass.lastArray[i] = selfClass.lastArray[len - i] / 255 * heightCanvas;
      }

    }
    ;


    if (!selfClass.isPlayerPlaying && selfClass.pcmSource) {
      selfClass.lastArray = [...selfClass.pcmSource];
    }

    // -- normalize
    if (selfClass.isPlayerPlayingEased && selfClass.last_lastarray) {
      for (let i3 = 0; i3 < selfClass.last_lastarray.length; i3++) {
        if (selfClass.last_lastarray[i3] > heightCanvas) {
          selfClass.last_lastarray[i3] = heightCanvas;
        }
        begin_viy = selfClass.last_lastarray[i3]; // -- last value
        change_viy = selfClass.lastArray[i3] - begin_viy; // -- target value - last value
        duration_viy = 6;
        selfClass.lastArray[i3] = Math.easeIn(1, begin_viy, change_viy, duration_viy);
      }
    }
    // -- easing END


    (0,_wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_1__.draw_canvas)($scrubBgCanvas.get(0), selfClass.lastArray, '' + selfClass.initOptions.design_wave_color_bg, {
      'call_from': 'spectrum',
      selfClass,
      'skinwave_wave_mode_canvas_waves_number': parseInt(selfClass.initOptions.skinwave_wave_mode_canvas_waves_number),
      'skinwave_wave_mode_canvas_waves_padding': parseInt(selfClass.initOptions.skinwave_wave_mode_canvas_waves_padding)
    }, false)


    if (selfClass.lastArray) {
      selfClass.last_lastarray = selfClass.lastArray.slice();
    }
  }

};


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_scrubbar.js":
/*!**************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_scrubbar.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_scrubbarSetup": () => (/* binding */ player_scrubbarSetup)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _view_player_view_dimensionHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../view/player/_view_dimensionHelpers */ "../source/audioplayer/jsinc/view/player/_view_dimensionHelpers.js");



function player_scrubbarSetup(selfClass, $, o, view_drawCurrentTime, viewCalculateScrubbarWidth, play_media, seek_to) {
  const cthis = selfClass.cthis;
  selfClass._scrubbar.on('mousemove', handleMouseOnScrubbar);
  selfClass._scrubbar.on('mouseleave', handleMouseOnScrubbar);
  selfClass._scrubbar.on('click', handleMouseOnScrubbar);


  function handleMouseOnScrubbar(e) {
    var mousex = e.pageX;


    if ($(e.target).hasClass('sample-block-start') || $(e.target).hasClass('sample-block-end')) {
      return false;
    }

    if (e.type === 'mousemove') {
      selfClass._scrubbar.children('.scrubBox-hover').css({
        'left': (mousex - selfClass._scrubbar.offset().left)
      });


      if (o.scrub_show_scrub_time === 'on') {


        if (selfClass.timeModel.getVisualTotalTime()) {
          var aux = (mousex - selfClass._scrubbar.offset().left) / selfClass._scrubbar.outerWidth() * selfClass.timeModel.getVisualTotalTime();


          if (selfClass.$currTime) {
            selfClass.$currTime.html((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.formatTime)(aux));
            selfClass.$currTime.addClass('scrub-time');

          }

          selfClass.isScrubShowingCurrentTime = true;
        }
      }

    }
    if (e.type === 'mouseleave') {

      selfClass.isScrubShowingCurrentTime = false;

      if (selfClass.$currTime) {
        selfClass.$currTime.removeClass('scrub-time');

      }

      view_drawCurrentTime();

    }
    if (e.type === 'click') {


      if (cthis.hasClass('prevent-bubble')) {
        if (e && e.stopPropagation) {
          e.preventDefault();
          e.stopPropagation();
        }
      }

      viewCalculateScrubbarWidth();
      let targetPositionOnScrub = (0,_view_player_view_dimensionHelpers__WEBPACK_IMPORTED_MODULE_1__.view_calculateTargetPositionOnScrub)(selfClass, selfClass.scrubbarWidth, e);

      if (selfClass._actualPlayer) {
        setTimeout(function () {
          if (selfClass._actualPlayer.get(0) && selfClass._actualPlayer.get(0).api_pause_media) {

            selfClass._actualPlayer.get(0).api_seek_to_perc(targetPositionOnScrub / selfClass.timeModel.getVisualTotalTime(), {
              'call_from': 'from_feeder_to_feed'
            });
          }
        }, 50);
      }


      seek_to(targetPositionOnScrub, {
        'call_from': 'handleMouseOnScrubbar'
      });

      if (o.autoplay_on_scrub_click === 'on') {
        if (!selfClass.isPlayerPlaying) {
          play_media({
            'called_from': 'handleMouseOnScrubbar'
          });
        }
      }

      if (cthis.hasClass('from-wc_loop')) {
        return false;
      }
    }

  }

}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_setupMiscButtons.js":
/*!**********************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_setupMiscButtons.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_setupMiscButtons": () => (/* binding */ player_setupMiscButtons)
/* harmony export */ });
/* harmony import */ var _dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_ajax */ "../source/audioplayer/jsinc/_dzsap_ajax.js");



/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param {jQuery} $
 * @param {function} seek_to
 */
const player_setupMiscButtons = (selfClass, $, seek_to) => {
  var cthis = selfClass.cthis;

  cthis.on('click', '.dzsap-repeat-button,.btn-zoomsounds-download,.zoomsounds-btn-step-backward,.zoomsounds-btn-step-forward,.zoomsounds-btn-go-beginning,.zoomsounds-btn-slow-playback,.zoomsounds-btn-reset, .tooltip-indicator--btn-footer-playlist, .wave-download', handle_mouse);
  cthis.find('.wave-download').on('click', handle_mouse);



  cthis.on('click', '.skip-15-sec', function () {
    cthis.get(0).api_step_forward(15);
  });

  function handle_mouse(e) {
    let _target;
    const $t = $(this);

    // if ($t.hasClass('wave-download')) {
    //   (ajax_submit_download.bind(selfClass))();
    // }
    if ($t.hasClass('tooltip-indicator--btn-footer-playlist')) {

      $t.parent().find('.dzstooltip').toggleClass('active');
    }
    if ($t.hasClass('zoomsounds-btn-go-beginning')) {

      _target = cthis;
      if (selfClass._actualPlayer) {
        _target = selfClass._actualPlayer;
      }

      _target.get(0).api_seek_to(0);
    }
    if ($t.hasClass('zoomsounds-btn-step-backward')) {

      _target = cthis;
      if (selfClass._actualPlayer) {
        _target = selfClass._actualPlayer;
      }

      _target.get(0).api_step_back();
    }
    if ($t.hasClass('zoomsounds-btn-step-forward')) {

      _target = cthis;
      if (selfClass._actualPlayer) {
        _target = selfClass._actualPlayer;
      }

      _target.get(0).api_step_forward();
    }
    if ($t.hasClass('zoomsounds-btn-slow-playback')) {
      _target = cthis;
      if (selfClass._actualPlayer) {
        _target = selfClass._actualPlayer;
      }

      _target.get(0).api_playback_slow();
    }
    if ($t.hasClass('zoomsounds-btn-reset')) {
      _target = cthis;
      if (selfClass._actualPlayer) {
        _target = selfClass._actualPlayer;
      }

      _target.get(0).api_playback_reset();
    }
    if ($t.hasClass('btn-zoomsounds-download')) {
      (_dzsap_ajax__WEBPACK_IMPORTED_MODULE_0__.ajax_submit_download.bind(selfClass))();
    }
    if ($t.hasClass('dzsap-repeat-button')) {

      if (selfClass.isPlayerPlaying) {
      }
      seek_to(0, {
        call_from: "repeat"
      });
    }


  }

}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_touchFunctionality.js":
/*!************************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_touchFunctionality.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dzsap_player_touchFunctionalitySetup": () => (/* binding */ dzsap_player_touchFunctionalitySetup)
/* harmony export */ });
const dzsap_player_touchFunctionalitySetup = (selfClass, seek_to_perc, $) => {
  // -- touch controls
  var scrubbar_moving = false
    , scrubbar_moving_x = 0
    , aux3 = 0
  ;


  if (selfClass._scrubbar && selfClass._scrubbar.get(0)) {

    selfClass._scrubbar.get(0).addEventListener('touchstart', function (e) {
      if (selfClass.isPlayerPlaying) {
        scrubbar_moving = true;
      }
    }, {passive: true})
  }

  $(document).on('touchmove', function (e) {
    if (scrubbar_moving) {
      scrubbar_moving_x = e.originalEvent.touches[0].pageX;


      aux3 = scrubbar_moving_x - selfClass._scrubbar.offset().left;

      if (aux3 < 0) {
        aux3 = 0;
      }
      if (aux3 > selfClass._scrubbar.width()) {
        aux3 = selfClass._scrubbar.width();
      }

      seek_to_perc(aux3 / selfClass._scrubbar.width(), {
        call_from: "touch move"
      });


      return false;

    }
  });

  $(document).on('touchend', function (e) {
    scrubbar_moving = false;
  });
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_viewSetup.js":
/*!***************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_viewSetup.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "view_resizeEmbedded": () => (/* binding */ view_resizeEmbedded),
/* harmony export */   "view_resizeHandleTreatSkins": () => (/* binding */ view_resizeHandleTreatSkins)
/* harmony export */ });
/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
const view_resizeHandleTreatSkins = (selfClass) => {
  var isResolveThumbHeight = false

  var cthis = selfClass.cthis;
  var o = selfClass.initOptions;
  selfClass.scrubbarWidth = selfClass._scrubbar.outerWidth(false);
  if (o.design_skin === 'skin-default') {
    selfClass.scrubbarWidth = selfClass.cthisWidth;
  }
  if (o.design_skin === 'skin-pro') {
    selfClass.scrubbarWidth = selfClass.cthisWidth;
  }
  if (o.design_skin === 'skin-silver' || o.design_skin === 'skin-aria') {
    selfClass.scrubbarWidth = selfClass.cthisWidth;
    selfClass.scrubbarWidth = selfClass._scrubbar.width();
  }


  if (o.design_skin === 'skin-justthumbandbutton') {
    selfClass.cthisWidth = cthis.children('.audioplayer-inner').outerWidth();
    selfClass.scrubbarWidth = selfClass.cthisWidth;
  }
  if (o.design_skin === 'skin-redlights' || o.design_skin === 'skin-steel') {
    selfClass.scrubbarWidth = selfClass._scrubbar.width();
  }

  if (o.design_skin === 'skin-wave') {
    selfClass.scrubbarWidth = selfClass._scrubbar.outerWidth(false);

    if (selfClass._commentsHolder) {

      selfClass._commentsHolder.css({
        'width': selfClass.scrubbarWidth
      })
      selfClass._commentsHolder.addClass('active');
    }

  }

}
const view_resizeEmbedded = (selfClass) => {

  var cthis = selfClass.cthis;
  if (window.frameElement) {

    let args = {
      height: cthis.outerHeight()
    };


    if (o.embedded_iframe_id) {

      args.embedded_iframe_id = o.embedded_iframe_id;
    }


    var message = {
      name: "resizeIframe",
      params: args
    };
    window.parent.postMessage(message, '*');
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_volume.js":
/*!************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_volume.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDefaultVolume": () => (/* binding */ getDefaultVolume),
/* harmony export */   "player_volumeSetup": () => (/* binding */ player_volumeSetup),
/* harmony export */   "volume_setOnlyVisual": () => (/* binding */ volume_setOnlyVisual),
/* harmony export */   "volume_setVolume": () => (/* binding */ volume_setVolume)
/* harmony export */ });
function player_volumeSetup(selfClass, volume_lastVolume, $, o) {

  let last_vol_before_mute = 1;
  var isMuted = false;
  let volume_dragging = false;


  const cthis = selfClass.cthis;


  selfClass.$controlsVolume.on('click', '.volumeicon', volume_handleClickMuteIcon);

  selfClass.$controlsVolume.on('mousemove', volume_handleMouse);
  selfClass.$controlsVolume.on('mousedown', volume_handleMouse);


  $(document).on('mouseup', window, volume_handleMouse);

  if (o.design_skin === 'skin-silver') {
    cthis.on('click', '.volume-holder', volume_handleMouse);
  }


  function volume_handleClickMuteIcon(e) {

    if (isMuted === false) {
      last_vol_before_mute = volume_lastVolume;
      volume_setVolume(selfClass, 0, {
        call_from: "from_mute"
      });
      isMuted = true;
    } else {
      volume_setVolume(selfClass, last_vol_before_mute, {
        call_from: "from_unmute"
      });
      isMuted = false;
    }
  }




  function volume_handleMouse(e) {
    var _t = $(this);
    /**
     * from 0 to 1
     * @type number
     */
    let mouseXRelativeToVolume = null;

    if (selfClass.$controlsVolume.find('.volume_static').length) {

      mouseXRelativeToVolume = Number((e.pageX - (selfClass.$controlsVolume.find('.volume_static').eq(0).offset().left)) / (selfClass.$controlsVolume.find('.volume_static').eq(0).width()));
    }

    if (!mouseXRelativeToVolume) {
      return false;
    }
    if (e.type === 'mousemove') {
      if (volume_dragging) {

        if (_t.parent().hasClass('volume-holder') || _t.hasClass('volume-holder')) {
        }

        if (o.design_skin === 'skin-redlights') {
          mouseXRelativeToVolume *= 10;
          mouseXRelativeToVolume = Math.round(mouseXRelativeToVolume);
          mouseXRelativeToVolume /= 10;
        }


        volume_setVolume(selfClass, mouseXRelativeToVolume, {
          call_from: "set_by_mousemove"
        });
        isMuted = false;
      }

    }
    if (e.type === 'mouseleave') {

    }
    if (e.type === 'click') {

      if (_t.parent().hasClass('volume-holder')) {


        mouseXRelativeToVolume = 1 - ((e.pageY - (selfClass.$controlsVolume.find('.volume_static').eq(0).offset().top)) / (selfClass.$controlsVolume.find('.volume_static').eq(0).height()));

      }
      if (_t.hasClass('volume-holder')) {
        mouseXRelativeToVolume = 1 - ((e.pageY - (selfClass.$controlsVolume.find('.volume_static').eq(0).offset().top)) / (selfClass.$controlsVolume.find('.volume_static').eq(0).height()));


      }

      volume_setVolume(selfClass, mouseXRelativeToVolume, {
        call_from: "set_by_mouseclick"
      });
      isMuted = false;
    }

    if (e.type === 'mousedown') {

      volume_dragging = true;
      cthis.addClass('volume-dragging');


      if (_t.parent().hasClass('volume-holder')) {


        mouseXRelativeToVolume = 1 - ((e.pageY - (selfClass.$controlsVolume.find('.volume_static').eq(0).offset().top)) / (selfClass.$controlsVolume.find('.volume_static').eq(0).height()));

      }

      volume_setVolume(selfClass, mouseXRelativeToVolume, {
        call_from: "set_by_mousedown"
      });
      isMuted = false;
    }
    if (e.type === 'mouseup') {

      volume_dragging = false;
      cthis.removeClass('volume-dragging');

    }

  }

}




function volume_setOnlyVisual(selfClass, arg, margs) {
  const o = selfClass.initOptions;

  if (selfClass.$controlsVolume.hasClass('controls-volume-vertical')) {
    selfClass.$controlsVolume.find('.volume_active').eq(0).css({
      'height': (selfClass.$controlsVolume.find('.volume_static').eq(0).height() * arg)
    });
  } else {

    if (selfClass.initOptions.design_skin === 'skin-redlights') {

      selfClass.$controlsVolume.find('.volume_active').eq(0).css({
        'clip-path': 'inset(0% ' + (Math.abs(1 - arg) * 100) + '% 0% 0%)'
      });
    } else {

      selfClass.$controlsVolume.find('.volume_active').eq(0).css({
        'width': (selfClass.$controlsVolume.find('.volume_static').eq(0).width() * arg)
      });
    }
  }


  if (o.design_skin === 'skin-wave' && o.skinwave_dynamicwaves === 'on') {
    selfClass._scrubbar.find('.scrub-bg-img').eq(0).css({
      'transform': 'scaleY(' + arg + ')'
    })
    selfClass._scrubbar.find('.scrub-prog-img').eq(0).css({
      'transform': 'scaleY(' + arg + ')'
    })

  }


  if (localStorage !== null && selfClass.the_player_id) {

    localStorage.setItem('dzsap_last_volume_' + selfClass.the_player_id, arg);

  }

  selfClass.volume_lastVolume = arg;
}




/**
 * outputs a volume from 0 to 1
 * @param {DzsAudioPlayer} selfClass
 * @param {number} arg 0 <-> 1
 * @param pargs
 * @returns {boolean}
 */
function volume_setVolume(selfClass, arg, pargs) {

  var margs = {

    'call_from': 'default'
  };

  if (pargs) {
    margs = Object.assign(margs, pargs);
  }

  if (arg > 1) {
    arg = 1;
  }
  if (arg < 0) {
    arg = 0;
  }

  var o = selfClass.initOptions;
  const $ = selfClass.$;
  let volume_isSetByUser = false;


  if (margs.call_from === 'from_fake_player_feeder_from_init_loaded') {
    // -- lets prevent call from the init_loaded set_volume if the volume has been changed
    if (selfClass._sourcePlayer) {
      if (o.default_volume !== 'default') {
        volume_isSetByUser = true;
      }
      if (volume_isSetByUser) {
        return false;
      } else {
        volume_isSetByUser = true;
      }
    }
  }

  if (margs.call_from === 'set_by_mouseclick' || margs.call_from === 'set_by_mousemove') {
    volume_isSetByUser = true;
  }

  if (selfClass.audioType === 'youtube') {
    if (selfClass.$mediaNode_ && selfClass.$mediaNode_.setVolume) {
      selfClass.$mediaNode_.setVolume(arg * 100);
    }
  }
  if (selfClass.audioType === 'selfHosted') {
    if (selfClass.$mediaNode_) {

      selfClass.$mediaNode_.volume = arg;
    } else {
      if (selfClass.$mediaNode_) {
        $(selfClass.$mediaNode_).attr('preload', 'metadata');
      }
    }
  }


  volume_setOnlyVisual(selfClass, arg, margs);

  if (selfClass._sourcePlayer) {
    margs.call_from = ('from_fake_player')
    if (selfClass._sourcePlayer.get(0) && selfClass._sourcePlayer.get(0).api_visual_set_volume(arg, margs)) {
      selfClass._sourcePlayer.get(0).api_visual_set_volume(arg, margs);
    }
  }

  if (selfClass._actualPlayer) {
    if (margs.call_from !== ('from_fake_player')) {
      if (margs.call_from === 'from_init_loaded') {

        margs.call_from = ('from_fake_player_feeder_from_init_loaded')
      } else {

        margs.call_from = ('from_fake_player_feeder')
      }
      if (selfClass._actualPlayer && selfClass._actualPlayer.get(0) && selfClass._actualPlayer.get(0).api_set_volume) {
        selfClass._actualPlayer.get(0).api_set_volume(arg, margs);
      }
    }
  }

}


function getDefaultVolume(o, selfClass){

  let defaultVolume = 1;
  if (o.default_volume === 'default') {
    defaultVolume = 1;
  }

  if (isNaN(Number(o.default_volume)) === false) {
    defaultVolume = Number(o.default_volume);
  } else {
    if (o.default_volume === 'last') {
      if (localStorage !== null && selfClass.the_player_id) {
        if (localStorage.getItem('dzsap_last_volume_' + selfClass.the_player_id)) {
          defaultVolume = localStorage.getItem('dzsap_last_volume_' + selfClass.the_player_id);
        } else {
          defaultVolume = 1;
        }
      } else {
        defaultVolume = 1;
      }
    }
  }

  if (o.volume_from_gallery) {
    defaultVolume = o.volume_from_gallery;
  }

  return defaultVolume;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/features/_zoomsounds-radio-features.js":
/*!*********************************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/features/_zoomsounds-radio-features.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkIfNeedsSongNameRefresh": () => (/* binding */ checkIfNeedsSongNameRefresh),
/* harmony export */   "player_icecastOrShoutcastRefresh": () => (/* binding */ player_icecastOrShoutcastRefresh)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function checkIfNeedsSongNameRefresh(selfClass){

  if (selfClass.audioTypeSelfHosted_streamType === 'icecast' || selfClass.audioTypeSelfHosted_streamType === 'shoutcast') {
    // -- if we have icecast we can update currently playing song


    if (selfClass.audioTypeSelfHosted_streamType === 'icecast' || (selfClass.radio_isGoingToUpdateArtistName || selfClass.radio_isGoingToUpdateSongName)) {

      player_icecastOrShoutcastRefresh(selfClass);
    }
    setInterval(function () {
      player_icecastOrShoutcastRefresh(selfClass);
    }, 10000)
  }
}


function player_icecastOrShoutcastRefresh(selfClass) {


  let url = selfClass.cthis.attr('data-source');

  if (selfClass.audioTypeSelfHosted_streamType === 'shoutcast') {
    url = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.add_query_arg)(selfClass.urlToAjaxHandler, 'action', 'dzsap_shoutcast_get_streamtitle');
    url = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.add_query_arg)(url, 'source', (selfClass.data_source));
  }


  jQuery.ajax({
    type: "GET",
    url: url,
    crossDomain: true,
    success: function (response) {

      if (response.documentElement && response.documentElement.innerHTML) {
        response = response.documentElement.innerHTML;
      }


      let regex_title = '';
      let regex_creator = '';
      let new_title = '';
      let new_artist = '';

      if (selfClass.audioTypeSelfHosted_streamType === 'icecast') {

        var regex_location = /<location>(.*?)<\/location>/g

        var regexMatches = null;
        if (regexMatches = regex_location.exec(response)) {


          if (regexMatches[1] !== selfClass.data_source) {
            selfClass.data_source = regexMatches[1];
            selfClass.setup_media({
              'called_from': 'icecast setup'
            });
          }
        }
      }

      if (selfClass.radio_isGoingToUpdateSongName) {
        if (selfClass.audioTypeSelfHosted_streamType === 'icecast') {
          regex_title = /<title>(.*?)<\/title>/g

          if (regexMatches = regex_title.exec(response)) {
            new_title = regexMatches[1];
          }
        }
        if (selfClass.audioTypeSelfHosted_streamType === 'shoutcast') {
          new_title = response;
        }

      }
      if (selfClass.radio_isGoingToUpdateArtistName) {
        if (selfClass.audioTypeSelfHosted_streamType === 'icecast') {

          regex_creator = /<creator>(.*?)<\/creator>/g;

          if (regexMatches = regex_creator.exec(response)) {
            new_artist = regexMatches[1];
          }
        }
        if (selfClass.audioTypeSelfHosted_streamType === 'shoutcast') {
        }
      }

      if (selfClass.radio_isGoingToUpdateSongName) {
        selfClass._metaArtistCon.find('.the-name').html(new_title);
      }

      if (selfClass.radio_isGoingToUpdateArtistName) {
        selfClass._metaArtistCon.find('.the-artist').html(new_artist)
      }
    },
    error: function (err) {

    }
  });

}


/***/ }),

/***/ "../source/audioplayer/jsinc/view/player/_view_dimensionHelpers.js":
/*!*************************************************************************!*\
  !*** ../source/audioplayer/jsinc/view/player/_view_dimensionHelpers.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "view_calculateTargetPositionOnScrub": () => (/* binding */ view_calculateTargetPositionOnScrub)
/* harmony export */ });
function view_calculateTargetPositionOnScrub(selfClass, scrubbarWidth, e) {
  let targetPositionOnScrub = ((e.pageX - (selfClass._scrubbar.offset().left)) / (scrubbarWidth) * selfClass.timeModel.getVisualTotalTime());


  if (selfClass.sample_time_start > 0) {
    targetPositionOnScrub -= selfClass.sample_time_start;
  }


  return targetPositionOnScrub;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/view/player/_view_playerStructure.js":
/*!************************************************************************!*\
  !*** ../source/audioplayer/jsinc/view/player/_view_playerStructure.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "player_constructArtistAndSongCon": () => (/* binding */ player_constructArtistAndSongCon),
/* harmony export */   "player_setupStructure_thumbnailCon": () => (/* binding */ player_setupStructure_thumbnailCon)
/* harmony export */ });
/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function player_setupStructure_thumbnailCon(selfClass){


  var cthis = selfClass.cthis;
  var o = selfClass.initOptions;

  if (cthis.attr('data-thumb')) {
    cthis.addClass('has-thumb');
    var aux_thumb_con_str = '';

    if (cthis.attr('data-thumb_link')) {
      aux_thumb_con_str += '<a href="' + cthis.attr('data-thumb_link') + '"';
    } else {
      aux_thumb_con_str += '<div';
    }
    aux_thumb_con_str += ' class="the-thumb-con"><div class="the-thumb" style=" background-image:url(' + cthis.attr('data-thumb') + ')"></div>';


    if (cthis.attr('data-thumb_link')) {
      aux_thumb_con_str += '</a>';
    } else {
      aux_thumb_con_str += '</div>';
    }


    if (cthis.children('.the-thumb-con').length) {
      aux_thumb_con_str = cthis.children('.the-thumb-con').eq(0);
    }


    if (o.design_skin !== 'skin-customcontrols') {
      if (o.design_skin === 'skin-wave' && (selfClass.skinwave_mode === 'small' || selfClass.skinwave_mode === 'alternate')) {

        if (selfClass.skinwave_mode === 'alternate') {
          selfClass._audioplayerInner.prepend(aux_thumb_con_str);
        } else {

          selfClass._apControlsLeft.prepend(aux_thumb_con_str);
        }
      } else if (o.design_skin === 'skin-steel') {
        selfClass._apControlsLeft.prepend(aux_thumb_con_str);
      } else {

        selfClass._audioplayerInner.prepend(aux_thumb_con_str);
      }
    }

  } else {

    cthis.removeClass('has-thumb');
  }
}

function player_constructArtistAndSongCon(margs) {

  var selfClass = this;

  if (selfClass.cthis.find('.meta-artist').length === 0) {
    if (selfClass.cthis.find('.feed-artist-name').length || selfClass.cthis.find('.feed-song-name').length) {
      let structHtmlMeta = '<span class="meta-artist player-artistAndSong">';
      if (selfClass.cthis.find('.feed-artist-name').length) {
        structHtmlMeta += '<span class="the-artist">' + selfClass.cthis.find('.feed-artist-name').eq(0).html() + '</span>';
      }
      if (selfClass.cthis.find('.feed-song-name').length) {
        structHtmlMeta += '<span class="the-name player-meta--songname">' + selfClass.cthis.find('.feed-song-name').eq(0).html() + '</span>';
      }
      structHtmlMeta += '</span>';
      selfClass.cthis.append(structHtmlMeta);
    }
  }

  if (selfClass.cthis.attr("data-type") === 'fake') {
    if (selfClass.cthis.find('.meta-artist').length === 0) {
      selfClass.cthis.append('<span class="meta-artist"><span class="the-artist"></span><span class="the-name"></span></span>')
    }
  }

  if (!selfClass._metaArtistCon || margs.call_from === 'reconstruct') {

    if (selfClass.cthis.children('.meta-artist').length > 0) {
      if (selfClass.cthis.hasClass('skin-wave-mode-alternate')) {
        if (selfClass._conControls.children().last().hasClass('clear')) {
          selfClass._conControls.children().last().remove();
        }
        selfClass._conControls.append(selfClass.cthis.children('.meta-artist'));
      } else {
        if (selfClass._audioplayerInner) {
          selfClass._audioplayerInner.append(selfClass.cthis.children('.meta-artist'));
        }
      }
    }


    selfClass._audioplayerInner.find('.meta-artist').eq(0).wrap('<div class="meta-artist-con"></div>');


    selfClass._metaArtistCon = selfClass._audioplayerInner.find('.meta-artist-con').eq(0);


    const o = selfClass.initOptions;


    if (selfClass._apControls.find('.ap-controls-right').length > 0) {
      selfClass._apControlsRight = selfClass.cthis.find('.ap-controls-right').eq(0);
    }
    if (selfClass._apControls.find('.ap-controls-left').length > 0) {
      selfClass._apControlsLeft = selfClass._apControls.find('.ap-controls-left').eq(0);
    }


    if (o.design_skin === 'skin-pro') {
      selfClass._apControlsRight = selfClass.cthis.find('.con-controls--right').eq(0)
    }

    if (o.design_skin === 'skin-wave') {


      if (selfClass.cthis.find('.dzsap-repeat-button').length) {
        selfClass.cthis.find('.dzsap-repeat-button').after(selfClass._metaArtistCon);
      } else {


        if (selfClass.cthis.find('.dzsap-loop-button').length && selfClass.cthis.find('.dzsap-loop-button').eq(0).parent().hasClass('feed-dzsap-for-extra-html-right') === false) {
          selfClass.cthis.find('.dzsap-loop-button').after(selfClass._metaArtistCon);
        } else {

          selfClass._conPlayPauseCon.after(selfClass._metaArtistCon);
        }
      }

      if (selfClass.skinwave_mode === 'alternate') {
        selfClass._apControlsRight.before(selfClass._metaArtistCon);
      }


    }
    if (o.design_skin === 'skin-aria') {
      selfClass._apControlsRight.prepend(selfClass._metaArtistCon);
    }
    if (o.design_skin === 'skin-redlights' || o.design_skin === 'skin-steel') {

      selfClass._apControlsRight.prepend(selfClass._metaArtistCon);


    }
    if (o.design_skin === 'skin-silver') {
      selfClass._apControlsRight.append(selfClass._metaArtistCon);
    }
    if (o.design_skin === 'skin-default') {
      selfClass._apControlsRight.before(selfClass._metaArtistCon);
    }


  }


}


/***/ }),

/***/ "../source/audioplayer/jsinc/wave-render/_wave-render-functions.js":
/*!*************************************************************************!*\
  !*** ../source/audioplayer/jsinc/wave-render/_wave-render-functions.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "draw_canvas": () => (/* binding */ draw_canvas),
/* harmony export */   "scrubModeWave__checkIfWeShouldTryToGetPcm": () => (/* binding */ scrubModeWave__checkIfWeShouldTryToGetPcm),
/* harmony export */   "scrubModeWave__view_transitionIn": () => (/* binding */ scrubModeWave__view_transitionIn),
/* harmony export */   "view_drawCanvases": () => (/* binding */ view_drawCanvases)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../player/_player_scrubModeWave */ "../source/audioplayer/jsinc/player/_player_scrubModeWave.js");






window.dzsap_wavesurfer_load_attempt = 0;
window.dzsap_wavesurfer_is_trying_to_generate = null;


var dzsapWaveRender = undefined;

/**
 * called on init_loaded
 * @param selfClass
 * @param pargs
 * @returns {boolean}
 */
function scrubModeWave__checkIfWeShouldTryToGetPcm(selfClass, pargs) {


  var margs = {
    'call_from': 'default'
    , 'call_attempt': 0
  };
  if (pargs) {
    margs = jQuery.extend(margs, pargs);
  }


  // -- retry
  if (window.dzsap_wavesurfer_is_trying_to_generate) {
    setTimeout(function () {

      margs.call_attempt++;
      if (margs.call_attempt < 10) {
        scrubModeWave__checkIfWeShouldTryToGetPcm(selfClass, margs);
        ;
      }
    }, 1000)
    return false;
  }


  if (selfClass.isPcmRequiredToGenerate) {

    if (isWeCanGeneratePcm(selfClass)) {

      window.dzsap_wavesurfer_is_trying_to_generate = selfClass;


      window.dzsap_get_base_url();

      let wavesurferUrl = window.dzsap_base_url ? window.dzsap_base_url + 'parts/wavesurfer/dzsap-wave-generate.js' : _configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.URL_WAVESURFER_HELPER_BACKUP;


      window.scrubModeWave__view_transitionIn = scrubModeWave__view_transitionIn;


      (0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_2__.loadScriptIfItDoesNotExist)(wavesurferUrl, window.scrubModeWave__initedGenerateWave).then((resolveStr) => {


        scrubModeWave__initGenerateWaveData(selfClass);
      });
    }
  }
}

function isWeCanGeneratePcm(selfClass) {

  if (selfClass.isAlreadyHasRealPcm) {
    return false;
  }
  return selfClass.data_source != 'fake';

}

function view_drawCanvases(selfClass, argpcm, calledFrom) {
  var o = selfClass.initOptions;

  draw_canvas(selfClass._scrubbarbg_canvas.get(0), argpcm, "#" + o.design_wave_color_bg, {
    call_from: calledFrom + '_bg',
    selfClass,
    'skinwave_wave_mode_canvas_waves_number': parseInt(o.skinwave_wave_mode_canvas_waves_number, 10),
    'skinwave_wave_mode_canvas_waves_padding': parseInt(o.skinwave_wave_mode_canvas_waves_padding, 10)
  });
  draw_canvas(selfClass._scrubbarprog_canvas.get(0), argpcm, '#' + o.design_wave_color_progress, {
      call_from: calledFrom + '_prog',
      selfClass,
      'skinwave_wave_mode_canvas_waves_number': parseInt(o.skinwave_wave_mode_canvas_waves_number, 10),
      'skinwave_wave_mode_canvas_waves_padding': parseInt(o.skinwave_wave_mode_canvas_waves_padding, 10),
    },
    true);
}


/**
 * called on isPcmRequiredToGenerate ( init_loaded )  / change_media
 * @param selfClass
 * @param argpcm
 */
function scrubModeWave__view_transitionIn(selfClass, argpcm) {


  selfClass._scrubbar.find('.scrub-bg-img,.scrub-prog-img').removeClass('transitioning-in');
  selfClass._scrubbar.find('.scrub-bg-img,.scrub-prog-img').addClass('transitioning-out');
  ;

  (0,_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_3__.scrubbar_modeWave_setupCanvas)({
    'prepare_for_transition_in': true
  }, selfClass);

  view_drawCanvases(selfClass, argpcm, 'canvas_generate_wave_data_animate_pcm');


  setTimeout(() => {
    (0,_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_3__.scrubbar_modeWave_clearObsoleteCanvas)(selfClass);
  }, 300);

  // -- warning - not always real pcm
  selfClass.isAlreadyHasRealPcm = true;
  selfClass.scrubbar_reveal();
}


/**
 * aggregate wave array based on max
 * @param waveArrayTemp
 * @returns {array}
 */
function waveCalculateWaveArray(waveArrayTemp) {
  let max = 0;
  let waveArrayNew = [];
  let barIndex = 0;

  let waveArray = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.string_jsonConvertToArray)(waveArrayTemp);


  // -- normalizing
  for (barIndex = 0; barIndex < waveArray.length; barIndex++) {
    if ((waveArray[barIndex]) > max) {
      max = (waveArray[barIndex]);
    }
  }

  for (barIndex = 0; barIndex < waveArray.length; barIndex++) {
    waveArrayNew[barIndex] = parseFloat(Math.abs(waveArray[barIndex]) / Number(max));
  }
  // -- end normalize

  waveArray = waveArrayNew;

  return waveArray;

}


function view_drawBars(_canvasContext, isReflection, isProgressScrubContext, hexcolor, barCount, waveArray, widthCanvas, heightCanvas, reflection_size, playerOptions, margs, selfClass, bar_space) {
  let isWithinSample = false;
  var searched_index = null;
  var lastBarHeight = 0;
  var gradient = null;
  var spectrum_isBarWithinProgress = false; // -- color the bar in progress colors


  hexcolor = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.sanitizeToHexColor)(hexcolor);
  // -- left right gradient
  var temp_hex = hexcolor;
  temp_hex = temp_hex.replace('#', '');
  var hexcolors = []; // -- hex colors array
  if (temp_hex.indexOf(',') > -1) {
    hexcolors = temp_hex.split(',');
  }


  if (barCount == 1) {
    barCount = widthCanvas / barCount;
  }
  if (barCount == 2) {
    barCount = widthCanvas / 2;
  }
  if (barCount == 3) {
    barCount = (widthCanvas) / 3;
  }


  if (widthCanvas / barCount < 1) {
    barCount = Math.ceil(barCount / 3);
  }


  var widthBar = Math.ceil(widthCanvas / barCount);
  var sizeRatioNormal = 1 - reflection_size;


  if (widthBar == 0) {
    widthBar = 1;
    bar_space = 0;
  }
  if (widthBar == 1) {
    bar_space = bar_space / 2;
  }


  var progress_hexcolor = '';
  var progress_hexcolors = '';


  if (margs.call_from == 'spectrum') {
    progress_hexcolor = playerOptions.design_wave_color_progress;
    progress_hexcolor = progress_hexcolor.replace('#', '');
    progress_hexcolors = []; // -- hex colors array
    if (progress_hexcolor.indexOf(',') > -1) {
      progress_hexcolors = progress_hexcolor.split(',');

    }
  }

  for (let barIndex = 0; barIndex < barCount; barIndex++) {
    isWithinSample = false;
    _canvasContext.save();


    searched_index = Math.ceil(barIndex * (waveArray.length / barCount));

    // -- we'll try to prevent
    if (barIndex < barCount / 5) {
      if (waveArray[searched_index] < 0.1) {
        waveArray[searched_index] = 0.1;
      }
    }
    if (waveArray.length > barCount * 2.5 && barIndex > 0 && barIndex < waveArray.length - 1) {
      waveArray[searched_index] = Math.abs(waveArray[searched_index] + waveArray[searched_index - 1] + waveArray[searched_index + 1]) / 3
    }
    // -- normalize end


    let targetRatio = sizeRatioNormal;
    if (isReflection) {
      targetRatio = reflection_size;
    }

    let barHeight = Math.abs(waveArray[searched_index] * heightCanvas * targetRatio);


    if (playerOptions.skinwave_wave_mode_canvas_normalize == 'on') {
      if (isNaN(lastBarHeight)) {
        lastBarHeight = 0;
      }
      barHeight = barHeight / 1.5 + lastBarHeight / 2.5;
    }
    lastBarHeight = barHeight;


    _canvasContext.lineWidth = 0;
    barHeight = Math.floor(barHeight);


    const barPositionTop = isReflection ? heightCanvas * sizeRatioNormal : Math.ceil(heightCanvas * targetRatio - barHeight);


    _canvasContext.beginPath();
    _canvasContext.rect(barIndex * widthBar, barPositionTop, widthBar - bar_space, barHeight);


    if (margs.call_from == 'spectrum') {
      if (barIndex / barCount < selfClass.timeCurrent / selfClass.timeTotal) {
        spectrum_isBarWithinProgress = true;
      } else {
        spectrum_isBarWithinProgress = false;
      }
    }


    if (selfClass.isSample) {
      isWithinSample = isBeforeOrAfterSample(barIndex, barCount, selfClass);
    }


    if (spectrum_isBarWithinProgress) {
      if (isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto') {
        _canvasContext.fillStyle = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)(progress_hexcolor, 0.25);
      } else {
        _canvasContext.fillStyle = isWithinSample ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)(progress_hexcolor, 0.5) : '#' + progress_hexcolor;
      }


      if (progress_hexcolors.length) {

        const startColor = isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto' ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)('#' + progress_hexcolors[0], 0.25) : '#' + progress_hexcolors[0];
        const endColor = isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto' ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)('#' + progress_hexcolors[1], 0.25) : '#' + progress_hexcolors[1];

        gradient = _canvasContext.createLinearGradient(0, 0, 0, heightCanvas);
        gradient.addColorStop(0, startColor);
        gradient.addColorStop(1, endColor);
        _canvasContext.fillStyle = gradient;
      }

    } else {
      /**
       * normal
       */


      if (isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto') {
        _canvasContext.fillStyle = (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)(hexcolor, 0.25);
      } else {

        _canvasContext.fillStyle = isWithinSample ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)(hexcolor, 0.5) : '' + hexcolor;
      }

      // -- if we have gradient
      if (hexcolors.length) {
        const startColor = isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto' ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.utils_sanitizeToColor)(hexcolors[0]), 0.25) : '' + (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.utils_sanitizeToColor)(hexcolors[0]);
        const endColor = isReflection && playerOptions.skinwave_wave_mode_canvas_mode !== 'reflecto' ? (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.hexToRgb)((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.utils_sanitizeToColor)(hexcolors[1]), 0.25) : '' + (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.utils_sanitizeToColor)(hexcolors[1]);

        gradient = _canvasContext.createLinearGradient(0, 0, 0, heightCanvas);
        gradient.addColorStop(0, startColor);
        gradient.addColorStop(1, endColor);
        _canvasContext.fillStyle = gradient;
      }


    }


    if (!(isWithinSample && isProgressScrubContext)) {


      _canvasContext.fill();
      _canvasContext.closePath();
    }


    _canvasContext.restore();

  }

}


/**
 * draw with different color
 * @returns {boolean}
 * @param {number} currBarIndex
 * @param {number} barCount
 * @param {DzsAudioPlayer} selfClass
 */
function isBeforeOrAfterSample(currBarIndex, barCount, selfClass) {


  if ((currBarIndex / barCount < selfClass.timeModel.sampleTimeStart / selfClass.timeModel.sampleTimeTotal) || currBarIndex / barCount > selfClass.timeModel.sampleTimeEnd / selfClass.timeModel.sampleTimeTotal) {

    return true;
  }
  return false;
}

/**
 * draw canvas here
 * @param $canvas_
 * @param pcm_arr
 * @param hexcolor
 * @param pargs
 * @param {boolean} isProgressScrubContext
 * @returns {boolean}
 */
function draw_canvas($canvas_, pcm_arr, hexcolor, pargs, isProgressScrubContext = false) {
  let margs = {
    'call_from': 'default',
    'is_sample': false,
    'selfClass': null,
    'sample_time_start': 0,
    'sample_time_end': 0,
    'sample_time_total': 0,
    'skinwave_wave_mode_canvas_waves_number': 2,
    'skinwave_wave_mode_canvas_waves_padding': 1,
  };

  const $ = jQuery;
  if (pargs) {
    margs = Object.assign(margs, pargs);
  }


  var _canvas = $($canvas_);
  var __canvas = $canvas_;

  if (_canvas.get(0)) {


    var {selfClass, skinwave_wave_mode_canvas_waves_number, skinwave_wave_mode_canvas_waves_padding} = margs;
    let playerOptions = {};
    var _canvasContext = _canvas.get(0).getContext("2d");
    var waveArrayTemp = pcm_arr;
    var widthCanvas;
    var heightCanvas;

    let waveArray = [];


    // -- sanitize
    if (isNaN(Number(skinwave_wave_mode_canvas_waves_number))) {
      skinwave_wave_mode_canvas_waves_number = 2;
    }

    if (isNaN(Number(skinwave_wave_mode_canvas_waves_padding))) {
      if (skinwave_wave_mode_canvas_waves_number !== 1) {
        skinwave_wave_mode_canvas_waves_padding = 1;
      } else {
        skinwave_wave_mode_canvas_waves_padding = 0;
      }
    }

    if (selfClass) {
      playerOptions = selfClass.initOptions;
    }


    let barCount = skinwave_wave_mode_canvas_waves_number;
    let bar_space = skinwave_wave_mode_canvas_waves_padding;


    if (_canvas && _canvas.get(0)) {

    } else {
      return false;
    }


    if (selfClass && selfClass._scrubbar) {
      if (selfClass._scrubbarprog_canvas) {
        selfClass._scrubbarbg_canvas.width(selfClass._scrubbar.width());
        selfClass._scrubbarprog_canvas.width(selfClass._scrubbar.width());
        $canvas_.width = selfClass._scrubbar.width();
        $canvas_.height = selfClass._scrubbar.height();
      }
    }


    waveArray = waveCalculateWaveArray(waveArrayTemp);


    if (selfClass) {
      __canvas.width = selfClass._scrubbar.width();
    }

    widthCanvas = __canvas.width;
    heightCanvas = __canvas.height;


    const reflection_size = parseFloat(playerOptions.skinwave_wave_mode_canvas_reflection_size);


    // -- left right gradient END


    _canvasContext.clearRect(0, 0, widthCanvas, heightCanvas);


    view_drawBars(_canvasContext, false, isProgressScrubContext, hexcolor, barCount, waveArray, widthCanvas, heightCanvas, reflection_size, playerOptions, margs, selfClass, bar_space)
    if (reflection_size > 0) {
      view_drawBars(_canvasContext, true, isProgressScrubContext, hexcolor, barCount, waveArray, widthCanvas, heightCanvas, reflection_size, playerOptions, margs, selfClass, bar_space)
    }

    // -- reflection
    setTimeout(function () {
      selfClass.scrubbar_reveal();
    }, 100)
  }


}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!*******************************************************!*\
  !*** ../source/audioplayer/audioplayer.sourcepack.js ***!
  \*******************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./jsinc/_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./jsinc/media/_media_functions */ "../source/audioplayer/jsinc/media/_media_functions.js");
/* harmony import */ var _jsinc_dzsap_time_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./jsinc/_dzsap_time_model */ "../source/audioplayer/jsinc/_dzsap_time_model.js");
/* harmony import */ var _jsinc_dzsap_ajax__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./jsinc/_dzsap_ajax */ "../source/audioplayer/jsinc/_dzsap_ajax.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./configs/_constants */ "../source/audioplayer/configs/_constants.js");
/* harmony import */ var _jsinc_helper_classes_ClassMetaParts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./jsinc/helper-classes/_ClassMetaParts */ "../source/audioplayer/jsinc/helper-classes/_ClassMetaParts.js");
/* harmony import */ var _jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./jsinc/_dzsap_svgs */ "../source/audioplayer/jsinc/_dzsap_svgs.js");
/* harmony import */ var _jsinc_dzsap_misc__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./jsinc/_dzsap_misc */ "../source/audioplayer/jsinc/_dzsap_misc.js");
/* harmony import */ var _jsinc_components_structure__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./jsinc/components/_structure */ "../source/audioplayer/jsinc/components/_structure.js");
/* harmony import */ var _jsinc_wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./jsinc/wave-render/_wave-render-functions */ "../source/audioplayer/jsinc/wave-render/_wave-render-functions.js");
/* harmony import */ var _configs_settingsPlayer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./configs/_settingsPlayer */ "../source/audioplayer/configs/_settingsPlayer.js");
/* harmony import */ var _jsinc_player_player_one_time_setups__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./jsinc/player/_player-one-time-setups */ "../source/audioplayer/jsinc/player/_player-one-time-setups.js");
/* harmony import */ var _jsinc_player_player_keyboard__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./jsinc/player/_player_keyboard */ "../source/audioplayer/jsinc/player/_player_keyboard.js");
/* harmony import */ var _jsinc_player_features_zoomsounds_radio_features__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./jsinc/player/features/_zoomsounds-radio-features */ "../source/audioplayer/jsinc/player/features/_zoomsounds-radio-features.js");
/* harmony import */ var _jsinc_player_player_scrubModeWave_spectrum__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./jsinc/player/_player_scrubModeWave_spectrum */ "../source/audioplayer/jsinc/player/_player_scrubModeWave_spectrum.js");
/* harmony import */ var _jsinc_player_player_commentsSelector__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./jsinc/player/_player_commentsSelector */ "../source/audioplayer/jsinc/player/_player_commentsSelector.js");
/* harmony import */ var _jsinc_player_player_commentsSelector__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_jsinc_player_player_commentsSelector__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _jsinc_player_player_setupMiscButtons__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./jsinc/player/_player_setupMiscButtons */ "../source/audioplayer/jsinc/player/_player_setupMiscButtons.js");
/* harmony import */ var _jsinc_player_player_touchFunctionality__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./jsinc/player/_player_touchFunctionality */ "../source/audioplayer/jsinc/player/_player_touchFunctionality.js");
/* harmony import */ var _jsinc_player_player_menuState__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./jsinc/player/_player_menuState */ "../source/audioplayer/jsinc/player/_player_menuState.js");
/* harmony import */ var _jsinc_player_player_nextPrevButtons__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./jsinc/player/_player_nextPrevButtons */ "../source/audioplayer/jsinc/player/_player_nextPrevButtons.js");
/* harmony import */ var _jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./jsinc/player/_player_volume */ "../source/audioplayer/jsinc/player/_player_volume.js");
/* harmony import */ var _jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./jsinc/player/_player_feederFunctions */ "../source/audioplayer/jsinc/player/_player_feederFunctions.js");
/* harmony import */ var _jsinc_player_player_scrubbar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./jsinc/player/_player_scrubbar */ "../source/audioplayer/jsinc/player/_player_scrubbar.js");
/* harmony import */ var _jsinc_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./jsinc/player/_player_scrubModeWave */ "../source/audioplayer/jsinc/player/_player_scrubModeWave.js");
/* harmony import */ var _jsinc_player_player_viewSetup__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./jsinc/player/_player_viewSetup */ "../source/audioplayer/jsinc/player/_player_viewSetup.js");
/* harmony import */ var _jsinc_view_player_view_playerStructure__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./jsinc/view/player/_view_playerStructure */ "../source/audioplayer/jsinc/view/player/_view_playerStructure.js");
/* harmony import */ var _jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./jsinc/player/_player_config */ "../source/audioplayer/jsinc/player/_player_config.js");
/*
 * Author: Audio Player with Playlist
 * Website: https://digitalzoomstudio.net/
 * Portfolio: https://bit.ly/nM4R6u
 * Version: 6.41
 * */function _typeof(obj){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(obj){return typeof obj}:function(obj){return obj&&"function"==typeof Symbol&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj},_typeof(obj)}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function")}}function _defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,_toPropertyKey(descriptor.key),descriptor)}}function _createClass(Constructor,protoProps,staticProps){if(protoProps)_defineProperties(Constructor.prototype,protoProps);if(staticProps)_defineProperties(Constructor,staticProps);Object.defineProperty(Constructor,"prototype",{writable:false});return Constructor}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return _typeof(key)==="symbol"?key:String(key)}function _toPrimitive(input,hint){if(_typeof(input)!=="object"||input===null)return input;var prim=input[Symbol.toPrimitive];if(prim!==undefined){var res=prim.call(input,hint||"default");if(_typeof(res)!=="object")return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return(hint==="string"?String:Number)(input)}/** list for autoplay -- this is for the players */window.dzsap_list=[];var dzsap_globalidind=1;window.dzsap_inited=true;window.loading_multi_sharer=false;window.dzsap_player_interrupted_by_dzsap=null;window.dzsap_audio_ctx=null;window.dzsap__style=null;window.dzsap_sticktobottom_con=null;window.dzsap_self_options={};window.dzsap_generating_pcm=false;window.dzsap_box_main_con=null;window.dzsap_lasto=null;/** list for sync -- used for next .. prev .. footer playlist */window.dzsap_syncList_players=[];window.dzsap_syncList_index=0;// -- used for next .. prev .. footer playlist
window.dzsap_base_url="";window.dzsap_player_index=0;// -- the player index on the page
/** announcers can subscribe to this action */if(!window.dzsap_action_play_listeners){window.dzsap_action_play_listeners=[]}/**
 * @property {boolean} isAlreadyHasRealPcm
 * @property {boolean} isPcmRequiredToGenerate
 * @property {boolean} isMultiSharer
 * @property {string} identifier_pcm
 * @property {string} urlToAjaxHandler
 * @property {array<number>} pcmSource
 * @property {array<number>} last_lastArray
 * @property {object} last_lastArray
 * @property {AnalyserNode} spectrum_analyser
 * @property {HTMLElement} _sourcePlayer
 * @property {HTMLElement} $mediaNode_
 * @constructor
 * @public
 */var DzsAudioPlayer=/*#__PURE__*/function(){function DzsAudioPlayer(argThis,argOptions,$){_classCallCheck(this,DzsAudioPlayer);this.argThis=argThis;this.argOptions=Object.assign({},argOptions);this.$=$;this.cthis=null;this.ajax_view_submitted="auto";this.increment_views=0;this.the_player_id="";this.currIp="127.0.0.1";this.index_extrahtml_toloads=0;this.starrating_alreadyrated=-1;this.data_source="";this.pcmSource=null;this.urlToAjaxHandler=null;this.playFrom="";this._actualPlayer=null;this._audioplayerInner=null;this._metaArtistCon=null;this._conControls=null;this._conPlayPauseCon=null;this._apControls=null;this._apControlsLeft=null;this._apControlsRight=null;this._commentsHolder=null;this.$mediaNode_=null;this._scrubbar=null;this._scrubbarbg_canvas=null;this._scrubBgCanvasCtx=null;this._scrubbarprog_canvas=null;this.$feed_fakeButton=null;this._sourcePlayer=null;this.$theMedia=null;this.$conPlayPause=null;// -- [selector] .con-playpause
this.$conControls=null;this.$$scrubbProg=null;this.$controlsVolume=null;this.$currTime=null;this.$parentPlaylist=null;this.$totalTime=null;this.$commentsWritter=null;this.$commentsChildren=null;this.$commentsSelector=null;this.$embedButton=null;/** a reflection object for triggering the player from outside */this.$reflectionVisualObject=null;this.audioType="normal";this.audioTypeSelfHosted_streamType="";this.skinwave_mode="normal";this.action_audio_comment=null;// -- set a outer ended function ( for example for tracking your analytics
this.commentPositionPerc=0;// -- the % at which the comment will be placed
this.spectrum_audioContext=null;this.spectrum_audioContextBufferSource=null;this.spectrum_audioContext_buffer=null;this.spectrum_mediaElementSource=null;this.spectrum_analyser=null;this.spectrum_gainNode=null;this.isMultiSharer=false;this.hasInitialPcmData=false;this.lastArray=null;this.last_lastArray=null;this.isPlayerPlaying=false;/** leaves a easing before ending play */this.isPlayerPlayingEased=false;this.isPlayerPlayingEasedInterval=null;this.actualDataTypeOfMedia="audio";// "audio" or
this.youtube_retryPlayTimeout=0;this.lastTimeInSeconds=0;this.inter_checkReady=0;this.cthisWidth=0;// -- sticky player
this.isStickyPlayer=false;this.$stickToBottomContainer=null;// -- pcm
this.uniqueId="";this.identifier_pcm="";// -- can be either player id or source if player id is not set
this.isAlreadyHasRealPcm=false;this.isPcmTryingToGenerate=false;this.isPlayPromised=false;// -- we are promising generating on meta load
this.isCanvasFirstDrawn=false;// -- the first draw on canvas
this.isPlayerLoaded=false;this.original_real_mp3="";// -- this is the original real mp3 for sainvg and identifying in the database
// -- theme specific
this.skin_minimal_canvasplay=null;this.classFunctionalityInnerPlaylist=null;this.feedEmbedCode="";this.youtube_currentId=0;this.youtube_isInited=false;this.extraHtmlAreas={bottom:"",afterArtist:"",controlsLeft:"",controlsRight:""};// -- time vars
this.sample_time_start=0;this.sample_time_end=0;this.sample_time_total=0;this.playlist_inner_currNr=0;this.canvasWidth=null;this.heightCanvas=null;this.timeCurrent=0;// -- *deprecated
this.timeModel=new _jsinc_dzsap_time_model__WEBPACK_IMPORTED_MODULE_3__.PlayerTime(this);this.isSample=false;this.isSafeToChangeTrack=false;// -- only after 2 seconds of init is it safe to change track
this.isMediaEnded=false;/** is first setuped media */this.isSetupedMedia=false;this.isSentCacheTotalTime=false;this.isPcmRequiredToGenerate=false;this.radio_isGoingToUpdateSongName=false;this.radio_isGoingToUpdateArtistName=false;this.mediaProtectionStatus="unprotected";this.classMetaParts=new _jsinc_helper_classes_ClassMetaParts__WEBPACK_IMPORTED_MODULE_6__._ClassMetaParts(this);this.inter_isEnded=0;argThis.SelfInstance=this;this.classInit()}_createClass(DzsAudioPlayer,[{key:"set_sourcePlayer",value:function set_sourcePlayer($arg){if($arg){if($arg.get(0)!=this.cthis.get(0)){this._sourcePlayer=$arg}}else{this._sourcePlayer=$arg}}},{key:"reinit_beforeChangeMedia",value:function reinit_beforeChangeMedia(){this.hasInitialPcmData=false;this.isPcmRequiredToGenerate=false;this.isAlreadyHasRealPcm=false;this.cthis.attr("data-pcm","")}},{key:"reinit_resetMetrics",value:function reinit_resetMetrics(){this.isPlayerLoaded=false}},{key:"service_checkIfWeShouldUpdateTotalTime",value:function service_checkIfWeShouldUpdateTotalTime(){(0,_jsinc_dzsap_ajax__WEBPACK_IMPORTED_MODULE_4__.ajax_submit_total_time)(this)}},{key:"classInit",value:function classInit(){var $=this.$;var o=this.argOptions;var cthis=$(this.argThis);var selfClass=this;selfClass.cthis=cthis;selfClass.initOptions=o;selfClass.volume_lastVolume=1;selfClass.isScrubShowingCurrentTime=false;selfClass.scrubbarWidth=0;selfClass.scrubbarProgX=0;selfClass.currTime_outerWidth=0;var cthisId="ap1";var ww,th// -- controls width
;var isDestroyed=false,isDestroyedForRebuffer=false,media_isLoopActive=false// -- if loop_active the track will loop
,curr_time_first_set=false,isListenersSetup=false;var last_time_total=0,player_index_in_gallery=-1// -- the player index in gallery
;var inter_60_secs_contor=0,inter_trigger_resize;var data_station_main_url="";var is_under_400=false;// resize thumb height
var skin_minimal_button_size=0;var action_audio_end=null,action_audio_play=null,action_audio_play2=null,action_audio_pause=null;var isRenderingFrame=false,isRenderingFrameInterval=null,spectrum_fakeItMode="auto";var draw_canvas_inter=0;window.dzsap_player_index++;selfClass.timeModel.getSampleTimesFromDom();init();function init(){if(cthis.hasClass("dzsap-inited")){return false}selfClass.play_media_visual=play_media_visual;selfClass.play_media=play_media;selfClass.pause_media=pause_media;selfClass.pause_media_visual=pause_media_visual;selfClass.seek_to=seek_to;selfClass.reinit=reinit;selfClass.handle_end=media_handleEnd;selfClass.init_loaded=init_loaded;selfClass.scrubbar_reveal=scrubbar_reveal;selfClass.calculate_dims_time=calculate_dims_time;selfClass.check_multisharer=check_multisharer;selfClass.setup_structure_scrub=setup_structure_scrub;selfClass.setup_structure_sanitizers=setup_structure_sanitizers;selfClass.destroy_cmedia=function(){(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.destroy_cmedia)(selfClass)};selfClass.view_drawCurrentTime=view_drawCurrentTime;selfClass.setupStructure_thumbnailCon=setupStructure_thumbnailCon;selfClass.setup_pcm_random_for_now=view_wave_setupRandomPcm;selfClass.handleResize=view_handleResize;selfClass.destroy_media=function(){(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.destroy_media)(selfClass,pause_media)};cthis.css({"opacity":""});cthis.addClass("dzsap-inited");window.dzsap_player_index++;if(o.parentgallery){selfClass.$parentPlaylist=o.parentgallery}selfClass.keyboard_controls=(0,_jsinc_player_player_keyboard__WEBPACK_IMPORTED_MODULE_13__.dzsap_generate_keyboard_controls)();(0,_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.configureAudioPlayerOptionsInitial)(cthis,o,selfClass);if(o.loop==="on"){media_isLoopActive=true}_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.player_detect_skinwave_mode.bind(selfClass)();if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzsap_is_mobile)()){$("body").addClass("is-mobile");if(o.mobile_delete==="on"){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_delete)(selfClass)}// -- disable fakeplayer on mobile for some reason
if(o.mobile_disable_fakeplayer==="on"){selfClass.cthis.attr("data-fakeplayer","")}}(0,_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.player_viewApplySkinWaveModes)(selfClass);(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.playerFunctions)(selfClass,"detectIds");if(cthis.attr("data-fakeplayer")){(0,_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.player_determineActualPlayer)(selfClass)}selfClass.cthis.addClass("scrubbar-type-"+o.scrubbar_type);(0,_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.player_determineHtmlAreas)(selfClass);// -- syncPlayers build
if(window.dzsap_settings.syncPlayers_buildList==="on"){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_syncPlayers_buildList)()}(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_getPlayFromTime)(selfClass);(0,_jsinc_player_player_config__WEBPACK_IMPORTED_MODULE_27__.player_adjustIdentifiers)(selfClass);(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_identifySource)(selfClass);(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_identifyTypes)(selfClass);if(selfClass.audioType==="youtube"){window.dzsap_get_base_url();var scriptUrl=window.dzsap_base_url?window.dzsap_base_url+"/parts/youtube/dzsap-youtube-functions.js":"";(0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.loadScriptIfItDoesNotExist)(scriptUrl,window.dzsap_youtube_functions_inited).then(function(resolveStr){window.dzsap_youtube_functions_init(selfClass)})}selfClass.audioTypeSelfHosted_streamType="";if(selfClass.audioType==="selfHosted"){if(cthis.attr("data-streamtype")&&cthis.attr("data-streamtype")!=="off"){selfClass.audioTypeSelfHosted_streamType=cthis.attr("data-streamtype");data_station_main_url=selfClass.data_source;cthis.addClass("is-radio-type")}else{selfClass.audioTypeSelfHosted_streamType=""}}// -- no shoutcast autoupdate at the moment 2 3 4 5 6 7 8
if(selfClass.audioTypeSelfHosted_streamType==="shoutcast"){// -- todo: we
}// -- we disable the function if audioplayer inited
if(cthis.hasClass("audioplayer")){return}if(cthis.attr("id")!==undefined){cthisId=cthis.attr("id")}else{cthisId="ap"+dzsap_globalidind++}selfClass.youtube_currentId="ytplayer_"+cthisId;cthis.removeClass("audioplayer-tobe");cthis.addClass("audioplayer");view_drawScrubProgress();setTimeout(function(){view_drawScrubProgress()},1000);// -- ios does not support volume controls so just let it die
// -- .. or autoplay FORCE STAFF
if(o.cueMedia==="off"){// -- cue is forcing autoplay on
cthis.addClass("cue-off");o.autoplay="on"}//====sound cloud INTEGRATION //
if(selfClass.audioType==="soundcloud"){(0,_jsinc_dzsap_misc__WEBPACK_IMPORTED_MODULE_8__.retrieve_soundcloud_url)(selfClass)}// -- END soundcloud INTEGRATION//
(0,_jsinc_components_structure__WEBPACK_IMPORTED_MODULE_9__.setup_structure)(selfClass,{});//  -- inside init()
// --   trying to access the youtube api with ios did not work
if(o.scrubbar_type==="wave"&&(selfClass.audioType==="selfHosted"||selfClass.audioType==="soundcloud"||selfClass.audioType==="fake")&&o.skinwave_comments_enable==="on"){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_part_comments_loaded,function(){window.comments_setupCommentsInitial(selfClass)})}if(o.autoplay==="on"&&o.cueMedia==="on"){selfClass.increment_views=1}// -- soundcloud will setupmedia when api done
if(o.cueMedia==="on"&&selfClass.audioType!=="soundcloud"){if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()||(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()){cthis.find(".playbtn").on("click",play_media)}if(selfClass.data_source&&selfClass.data_source.indexOf("{{generatenonce}}")>-1){selfClass.mediaProtectionStatus="fetchingProtection";(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_service_getSourceProtection)(selfClass).then(function(response){if(response){cthis.attr("data-source",response);setup_media({"called_from":"nonce generated","newSource":response});selfClass.mediaProtectionStatus="protectedMode"}})}else{var isGoingToSetupMediaNow=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_isGoingToSetupMediaNow)(selfClass);if(selfClass.audioType==="selfHosted"){(0,_jsinc_player_features_zoomsounds_radio_features__WEBPACK_IMPORTED_MODULE_14__.checkIfNeedsSongNameRefresh)(selfClass)}if(isGoingToSetupMediaNow){setup_media({"called_from":"normal setup media .. --- icecast must wait"})}}}else{cthis.find(".playbtn").on("click",handleClickForSetupMedia);cthis.find(".scrubbar").on("click",handleClickForSetupMedia);view_handleResize(null,{called_from:"init"})}// -- we call the api functions here
(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_determineStickToBottomContainer)(selfClass);(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_stickToBottomContainerDetermineClasses)(selfClass);selfClass.timeModel.initObjects();// -- api calls
selfClass.setup_media=setup_media;cthis.get(0).classInstance=selfClass;cthis.get(0).api_init_loaded=init_loaded;// -- force resize event
cthis.get(0).api_destroy=destroy_it;// -- destroy the player and the listeners
cthis.get(0).api_play=play_media;// -- play the media
cthis.get(0).api_set_volume=function(arg,pargs){(0,_jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__.volume_setVolume)(selfClass,arg,pargs)};// -- set a volume
cthis.get(0).api_get_last_vol=volume_getLast;// -- play the media
cthis.get(0).api_get_source=function(){return selfClass.data_source};// -- play the media
cthis.get(0).api_click_for_setup_media=handleClickForSetupMedia;// -- play the media
cthis.get(0).api_handleResize=view_handleResize;// -- force resize event
cthis.get(0).api_set_playback_speed=set_playback_speed;// -- set the playback speed, only works for local hosted mp3
cthis.get(0).api_seek_to_perc=seek_to_perc;// -- seek to percentage ( for example seek to 0.5 skips to half of the song )
cthis.get(0).api_seek_to=seek_to;// -- seek to percentage ( for example seek to 0.5 skips to half of the song )
cthis.get(0).api_seek_to_visual=seek_to_visual;// -- seek to perchange but only visually ( does not actually skip to that ) , good for a fake player
cthis.get(0).api_visual_set_volume=function(arg,pargs){(0,_jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__.volume_setOnlyVisual)(selfClass,arg,pargs)};// -- set a volume
cthis.get(0).api_destroy_listeners=destroy_listeners;// -- set a volume
cthis.get(0).api_pause_media=pause_media;// -- pause the media
cthis.get(0).api_get_media_isLoopActive=function(){return media_isLoopActive};// -- pause the media
cthis.get(0).api_media_toggleLoop=media_toggleLoop;// -- pause the media
cthis.get(0).api_pause_media_visual=pause_media_visual;// -- pause the media, but only visually
cthis.get(0).api_play_media=play_media;// -- play the media
cthis.get(0).api_play_media_visual=play_media_visual;// -- play the media, but only visually
cthis.get(0).api_handle_end=media_handleEnd;// -- play the media, but only visually
cthis.get(0).api_change_visual_target=change_visual_target;// -- play the media, but only visually
cthis.get(0).api_change_design_color_highlight=view_updateColorHighlight;// -- play the media, but only visually
cthis.get(0).api_draw_scrub_prog=view_drawScrubProgress;// -- render the scrub progress
cthis.get(0).api_draw_curr_time=view_drawCurrentTime;// -- render the current time
cthis.get(0).api_get_times=selfClass.timeModel.refreshTimes;// -- refresh the current time
cthis.get(0).api_check_time=handleEnterFrame;// -- do actions required in the current frame
cthis.get(0).api_sync_players_goto_next=function(){(0,_jsinc_player_player_nextPrevButtons__WEBPACK_IMPORTED_MODULE_20__.syncPlayers_gotoNext)(selfClass)};// -- in the sync playlist, go to the next song
cthis.get(0).api_sync_players_goto_prev=function(){(0,_jsinc_player_player_nextPrevButtons__WEBPACK_IMPORTED_MODULE_20__.syncPlayers_gotoPrev)(selfClass)};// -- in the sync playlist, go to the previous song
cthis.get(0).api_step_back=function(nrSeconds){if(!nrSeconds){nrSeconds=selfClass.keyboard_controls.step_back_amount}seek_to(selfClass.timeCurrent-nrSeconds)};cthis.get(0).api_step_forward=function(nrSeconds){if(nrSeconds){}else{nrSeconds=selfClass.keyboard_controls.step_back_amount}seek_to(selfClass.timeCurrent+nrSeconds)};// --
/**
       *
       * @param {number} argSpeed  - 0 to 1
       */cthis.get(0).api_playback_speed=function(argSpeed){if(selfClass.$mediaNode_&&selfClass.$mediaNode_.playbackRate){selfClass.$mediaNode_.playbackRate=argSpeed}};// -- slow to 2/3 of the current song
cthis.get(0).api_set_action_audio_play=function(arg){action_audio_play=arg};// -- set action on audio play
cthis.get(0).api_set_action_audio_pause=function(arg){action_audio_pause=arg};// -- set action on audio pause
cthis.get(0).api_set_action_audio_end=function(arg){action_audio_end=arg;cthis.data("has-action-end","on")};// -- set action on audio end
cthis.get(0).api_set_action_audio_comment=function(arg){selfClass.action_audio_comment=arg};// -- set the function to call on audio song comment
cthis.get(0).api_try_to_submit_view=service_submitView;// -- try to submit a new play analytic
(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_part_mediaChange_loaded,function(){window.dzsap_part_mediaChange_init(selfClass,$)});if(o.action_audio_play){action_audio_play=o.action_audio_play}if(o.action_audio_pause){action_audio_pause=o.action_audio_pause}if(o.action_audio_play2){action_audio_play2=o.action_audio_play2}if(o.action_audio_end){action_audio_end=o.action_audio_end;cthis.data("has-action-end","on")}handleEnterFrame({"fire_only_once":true});if(o.design_skin==="skin-minimal"){handleEnterFrame({"fire_only_once":true})}(0,_jsinc_player_player_setupMiscButtons__WEBPACK_IMPORTED_MODULE_17__.player_setupMiscButtons)(selfClass,$,seek_to);cthis.on("click",".dzsap-loop-button",handle_mouse);cthis.on("mouseenter",handle_mouse);cthis.on("mouseleave",handle_mouse);selfClass.$conPlayPause.on("click",handleClick_playPause);$(window).on("resize.dzsap",view_handleResize);view_handleResize(null,{called_from:"init"});(0,_jsinc_player_player_touchFunctionality__WEBPACK_IMPORTED_MODULE_18__.dzsap_player_touchFunctionalitySetup)(selfClass,seek_to_perc,$);if(o.skinwave_comments_mode_outer_selector){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_part_comments_loaded,function(){window.player_commentsSelectorInit(selfClass,$,cthis,o)})}(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_part_starRatings_loaded,function(){window.dzsap_init_starRatings_from_dzsap(selfClass)});setTimeout(function(){view_handleResize(null,{called_from:"init_timeout"});if(o.skinwave_wave_mode==="canvas"){calculate_dims_time();setTimeout(function(){calculate_dims_time()},100)}},100);(0,_jsinc_player_player_menuState__WEBPACK_IMPORTED_MODULE_19__.player_menuStateSetup)(cthis,o);(0,_jsinc_player_player_nextPrevButtons__WEBPACK_IMPORTED_MODULE_20__.player_nextPrevButtonsSetup)(selfClass,cthis,o)}function calculate_dims_time(){var reflection_size=parseFloat(o.skinwave_wave_mode_canvas_reflection_size);reflection_size=1-reflection_size;var scrubbarh=selfClass._scrubbar.height();if(selfClass.initOptions.scrubbar_type==="wave"){if(selfClass.skinwave_mode==="small"){scrubbarh=60}if(selfClass._commentsHolder){if(reflection_size===0){selfClass._commentsHolder.css("top",selfClass._scrubbar.offset().top-cthis.offset().top+scrubbarh*reflection_size-selfClass._commentsHolder.height())}else{selfClass._commentsHolder.css("top",selfClass._scrubbar.offset().top-selfClass._scrubbar.parent().offset().top+scrubbarh*reflection_size);selfClass.$commentsWritter.css("top",selfClass._scrubbar.offset().top-selfClass._scrubbar.parent().offset().top+scrubbarh*reflection_size)}}if(o.design_skin==="skin-wave"){if(selfClass.$currTime){selfClass.$currTime.css("top",scrubbarh*reflection_size-selfClass.$currTime.outerHeight())}if(selfClass.$totalTime){selfClass.$totalTime.css("top",scrubbarh*reflection_size-selfClass.$totalTime.outerHeight())}}}cthis.attr("data-reflection-size",reflection_size)}/**
     * change the visual target, the main is the main player selfClass.isPlayerPlaying and the visual target is the player which is a visual representation of this
     * @param arg
     * @param pargs
     */function change_visual_target(arg,pargs){var margs={};if(pargs){margs=$.extend(margs,pargs)}if(selfClass._sourcePlayer&&selfClass._sourcePlayer.get(0)&&selfClass._sourcePlayer.get(0).api_pause_media_visual){selfClass._sourcePlayer.get(0).api_pause_media_visual({"call_from":"change_visual_target"})}selfClass.set_sourcePlayer(arg);var $sourcePlayer_=selfClass._sourcePlayer.get(0);if(selfClass.isPlayerPlaying){if(selfClass._sourcePlayer&&$sourcePlayer_&&$sourcePlayer_.api_play_media_visual){$sourcePlayer_.api_play_media_visual()}}if($sourcePlayer_&&$sourcePlayer_.api_draw_curr_time){$sourcePlayer_.api_set_timeVisualCurrent(selfClass.timeCurrent);$sourcePlayer_.api_get_times({"call_from":" change visual target .. in api "});$sourcePlayer_.api_check_time({"fire_only_once":true});$sourcePlayer_.api_draw_curr_time();$sourcePlayer_.api_draw_scrub_prog()}setTimeout(function(){if($sourcePlayer_&&$sourcePlayer_.api_draw_curr_time){$sourcePlayer_.api_get_times();$sourcePlayer_.api_check_time({"fire_only_once":true});$sourcePlayer_.api_draw_curr_time();$sourcePlayer_.api_draw_scrub_prog()}},800)}function view_updateColorHighlight(arg){o.design_wave_color_progress=arg;if(o.skinwave_wave_mode==="canvas"){(0,_jsinc_wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_10__.view_drawCanvases)(selfClass,cthis.attr("data-pcm"),"canvas_change_pcm")}}/**
     * called in init_loaded()
     */function reinit(){if(selfClass.audioType==="normal"||selfClass.audioType==="detect"||selfClass.audioType==="audio"){selfClass.audioType="selfHosted"}}function destroy_listeners(){if(isDestroyed){return false}isRenderingFrame=false}function destroy_it(){if(isDestroyed){return false}if(selfClass.isPlayerPlaying){pause_media()}$(window).off("resize.dzsap");cthis.remove();cthis=null;isDestroyed=true}function handleClickForSetupMedia(e,pargs){var margs={"do_not_autoplay":false};if(pargs){margs=$.extend(margs,pargs)}cthis.find(".playbtn").unbind("click",handleClickForSetupMedia);cthis.find(".scrubbar").unbind("click",handleClickForSetupMedia);setup_media(margs);if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()||(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()){play_media({"called_from":"click_for_setup_media"})}}function init_checkIfReady(pargs){var margs={"do_not_autoplay":false};if(selfClass._actualPlayer&&(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()){return false}if(pargs){margs=$.extend(margs,pargs)}if(selfClass.audioType==="youtube"){init_loaded(margs)}else{if(typeof selfClass.$mediaNode_!=="undefined"&&selfClass.$mediaNode_){if(selfClass.$mediaNode_.nodeName!=="AUDIO"||o.type==="shoutcast"){init_loaded(margs)}else{if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_safari)()){if(selfClass.$mediaNode_.readyState>=1){if(selfClass.isPlayerLoaded===false){}init_loaded(margs);clearInterval(selfClass.inter_checkReady);if(o.action_audio_loaded_metadata){o.action_audio_loaded_metadata(cthis)}}}else{if(selfClass.$mediaNode_.readyState>=2){if(selfClass.isPlayerLoaded===false){}init_loaded(margs);clearInterval(selfClass.inter_checkReady);if(o.action_audio_loaded_metadata){o.action_audio_loaded_metadata(cthis)}}}}}}}function scrubbar_reveal(){setTimeout(function(){selfClass.cthis.addClass("scrubbar-loaded")},1000)}function setupStructure_thumbnailCon(){(0,_jsinc_view_player_view_playerStructure__WEBPACK_IMPORTED_MODULE_26__.player_setupStructure_thumbnailCon)(selfClass)}function setup_structure_sanitizers(){if(cthis.hasClass("zoomsounds-wrapper-bg-bellow")&&cthis.find(".dzsap-wrapper-buts").length===0){cthis.append("<div class=\"temp-wrapper\"></div>");cthis.find(".temp-wrapper").append(selfClass.extraHtmlAreas.controlsRight);cthis.find(".temp-wrapper").children("*:not(.dzsap-wrapper-but)").remove();cthis.find(".temp-wrapper > .dzsap-wrapper-but").unwrap();cthis.find(".dzsap-wrapper-but").each(function(){var aux=$(this).html();aux=aux.replace("{{heart_svg}}","\t&hearts;");aux=aux.replace("{{svg_share_icon}}",_jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_7__.svg_share_icon);if($(this).get(0)&&$(this).get(0).outerHTML.indexOf("dzsap-multisharer-but")>-1){selfClass.isMultiSharer=true}$(this).html(aux)}).wrapAll("<div class=\"dzsap-wrapper-buts\"></div>")}if(o.design_skin==="skin-customcontrols"){cthis.html(String(cthis.html()).replace("{{svg_play_icon}}",_jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_7__.playbtn_svg));cthis.html(String(cthis.html()).replace("{{svg_pause_icon}}",_jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_7__.pausebtn_svg))}}/**
     * called if we have .dzsap-multisharer-but in html
     */function check_multisharer(){// -- we setup a box main here as a child of body
selfClass.cthis.find(".dzsap-multisharer-but").data("cthis",cthis);selfClass.cthis.data("embed_code",selfClass.feedEmbedCode)}function view_wave_setupRandomPcm(pargs){var margs={call_from:"default"};if(pargs){margs=$.extend(margs,pargs)}var default_pcm=[];if(!(o.pcm_data_try_to_generate==="on"&&o.pcm_data_try_to_generate_wait_for_real_pcm==="on")){for(var i3=0;i3<200;i3++){default_pcm[i3]=Number(Math.random()).toFixed(2)}default_pcm=JSON.stringify(default_pcm);cthis.addClass("rnd-pcm-for-now");cthis.attr("data-pcm",default_pcm)}(0,_jsinc_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_24__.scrubbar_modeWave_setupCanvas)({},selfClass)}/**
     * called from setup_structure
     */function setup_structure_scrub(){if(o.skinwave_enableSpectrum==="on"){// -- spectrum ON
(0,_jsinc_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_24__.scrubbar_modeWave_setupCanvas)({},selfClass);// -- old spectrum code
selfClass._scrubbarbg_canvas=selfClass.cthis.find(".scrub-bg-img").eq(0);selfClass._scrubBgCanvasCtx=selfClass._scrubbarbg_canvas.get(0).getContext("2d")}else{if(o.skinwave_wave_mode==="canvas"){if(cthis.attr("data-pcm")){(0,_jsinc_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_24__.scrubbar_modeWave_setupCanvas)({},selfClass)}else{view_wave_setupRandomPcm()}}}};/**
     * order -> init, setup_media, init_loaded
     * called from init() if not icecast or soundcloud
     * @param pargs
     * @returns {boolean}
     */function setup_media(pargs){(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.mediaSetup)(selfClass,pargs,init_loaded,pause_media,init_checkIfReady,handleClick_playPause)}function setup_listeners(){if(isListenersSetup){return false}isListenersSetup=true;// -- adding scrubbar listeners
selfClass._scrubbar.unbind("mousemove");selfClass._scrubbar.unbind("mouseleave");selfClass._scrubbar.unbind("click");(0,_jsinc_player_player_scrubbar__WEBPACK_IMPORTED_MODULE_23__.player_scrubbarSetup)(selfClass,$,o,view_drawCurrentTime,viewCalculateScrubbarWidth,play_media,seek_to);(0,_jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__.player_volumeSetup)(selfClass,selfClass.volume_lastVolume,$,o);cthis.find(".playbtn").unbind("click");setTimeout(view_handleResize,300);setTimeout(view_handleResize,2000);if(o.settings_trigger_resize>0){inter_trigger_resize=setInterval(view_handleResize,o.settings_trigger_resize)}cthis.addClass("listeners-setuped");return false}function volume_getLast(){return selfClass.volume_lastVolume}/**
     * init laoded
     * @param pargs
     */function init_loaded(pargs){if(cthis.hasClass("dzsap-loaded")){return}var margs={"do_not_autoplay":false,"call_from":"init"};if(pargs){margs=$.extend(margs,pargs)}setTimeout(function(){selfClass.isSafeToChangeTrack=true},5000);clearInterval(selfClass.inter_checkReady);clearTimeout(selfClass.inter_checkReady);setup_listeners();setTimeout(function(){if(selfClass.$currTime&&selfClass.$currTime.outerWidth()>0){selfClass.currTime_outerWidth=selfClass.$currTime.outerWidth()}},1000);// -- this comes from cue off, no pcm data
if(selfClass.isPcmRequiredToGenerate){(0,_jsinc_wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_10__.scrubModeWave__checkIfWeShouldTryToGetPcm)(selfClass,{called_from:"init_loaded()"})}if(selfClass.audioType!=="fake"&&margs.call_from!=="force_reload_change_media"){if(o.settings_exclude_from_list!=="on"&&dzsap_list&&dzsap_list.indexOf(cthis)===-1){if(selfClass._actualPlayer===null){dzsap_list.push(cthis)}}if(o.type_audio_stop_buffer_on_unfocus==="on"){cthis.data("type_audio_stop_buffer_on_unfocus","on");cthis.get(0).api_destroy_for_rebuffer=function(){if(o.type==="audio"){selfClass.playFrom=selfClass.$mediaNode_.currentTime}(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.destroy_media)(selfClass,pause_media);isDestroyedForRebuffer=true}}}if(selfClass.ajax_view_submitted==="auto"){setTimeout(function(){if(selfClass.ajax_view_submitted==="auto"){selfClass.ajax_view_submitted="off"}},1000)}selfClass.isPlayerLoaded=true;if(selfClass.data_source!==_configs_constants__WEBPACK_IMPORTED_MODULE_5__.DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED){cthis.addClass(_configs_constants__WEBPACK_IMPORTED_MODULE_5__.DZSAP_PLAYER_CLASS_LOADED);if(selfClass.isStickyPlayer){if(window["dzsap_stickyPlayer_show"]){setTimeout(function(){dzsap_stickyPlayer_show(selfClass)},500)}}}(0,_jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__.volume_setVolume)(selfClass,(0,_jsinc_player_player_volume__WEBPACK_IMPORTED_MODULE_21__.getDefaultVolume)(o,selfClass),{call_from:"from_init_loaded"});if((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.isInt)(selfClass.playFrom)){seek_to(selfClass.playFrom,{call_from:"from_playfrom"})}if(selfClass.playFrom===_configs_constants__WEBPACK_IMPORTED_MODULE_5__.DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS){// -- here we save last position
if(typeof Storage!=="undefined"){setTimeout(function(){selfClass.playFrom_ready=true});if(typeof localStorage["dzsap_"+selfClass.the_player_id+"_lastpos"]!=="undefined"){seek_to(localStorage["dzsap_"+selfClass.the_player_id+"_lastpos"],{"call_from":"last_pos"})}}}if(margs.do_not_autoplay!==true){if(o.autoplay==="on"&&o.cueMedia==="on"){play_media({"called_from":"do not autoplay not true ( init_loaded() ) "})}}if(selfClass.$mediaNode_&&selfClass.$mediaNode_.duration){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_view_addMetaLoaded)(selfClass)}reinit();handleEnterFrame({"fire_only_once":false});if(o.autoplay==="off"){isRenderingFrame=false}cthis.addClass("init-loaded");setTimeout(function(){selfClass.timeModel.refreshTimes({"call_from":"set timeout 500"});handleEnterFrame({"fire_only_once":true});cthis.find(".wave-download").on("click",handle_mouse)},500);setTimeout(function(){selfClass.timeModel.refreshTimes({"call_from":"set timeout 1000"});handleEnterFrame({"fire_only_once":true})},1000);if(inter_60_secs_contor===0&&o.action_video_contor_60secs){inter_60_secs_contor=setInterval(count_60secs,30000)}}function count_60secs(){if(o.action_video_contor_60secs&&cthis.hasClass("is-playing")){o.action_video_contor_60secs(cthis,"")}}/**
     *
     * @param {boolean} isGoingToActivate
     */function media_toggleLoop(isGoingToActivate){media_isLoopActive=isGoingToActivate}function handle_mouse(e){var $t=$(this);if(e.type==="click"){if($t.hasClass("wave-download")){_jsinc_dzsap_ajax__WEBPACK_IMPORTED_MODULE_4__.ajax_submit_download.bind(selfClass)()}if($t.hasClass("dzsap-loop-button")){if($t.hasClass("active")){$t.removeClass("active");media_isLoopActive=false}else{$t.addClass("active");media_isLoopActive=true}}}if(e.type==="mouseover"){}if(e.type==="mouseenter"){if(o.preview_on_hover==="on"){seek_to_perc(0);play_media({"called_from":"preview_on_hover"})}window.dzsap_mouseover=true}if(e.type==="mouseleave"){if(o.preview_on_hover==="on"){seek_to_perc(0);pause_media()}window.dzsap_mouseover=false}}function view_drawCurrentTime(){// -- draw current time -- called onEnterFrame when playing
var currentTime=selfClass.timeModel.getVisualCurrentTime();var totalTime=selfClass.timeModel.getVisualTotalTime();if(selfClass.initOptions.scrubbar_type==="wave"){if(selfClass.initOptions.skinwave_enableSpectrum==="on"){if(!selfClass.isPlayerPlayingEased){return false}(0,_jsinc_player_player_scrubModeWave_spectrum__WEBPACK_IMPORTED_MODULE_15__.view_spectrum_drawMeter)(selfClass,selfClass._scrubbarbg_canvas,spectrum_fakeItMode,selfClass.heightCanvas);// -- end spectrum
}if(selfClass.$currTime&&selfClass.$currTime.length){if(selfClass.initOptions.skinwave_timer_static!=="on"){(0,_jsinc_player_player_scrubModeWave__WEBPACK_IMPORTED_MODULE_24__.view_player_scrubModeWaveAdjustCurrTimeAndTotalTime)(selfClass)}}}if(totalTime!==last_time_total){view_updateTotalTime(totalTime)}if(selfClass.$currTime){if(selfClass.isScrubShowingCurrentTime===false){selfClass.$currTime.html((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.formatTime)(currentTime))}if(selfClass.timeModel.getVisualTotalTime()&&selfClass.timeModel.getVisualTotalTime()>-1){selfClass.cthis.addClass("time-total-visible")}}if(selfClass.spectrum_audioContext){if(selfClass.$totalTime){selfClass.$totalTime.html((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.formatTime)(totalTime))}}}function view_updateTotalTime(totalTime){if(selfClass.$totalTime){selfClass.$totalTime.html((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.formatTime)(totalTime));selfClass.$totalTime.fadeIn("fast")}}/**
     * draw the scrub width
     * @returns {void}
     */function view_drawScrubProgress(){var currentTime=selfClass.timeModel.getVisualCurrentTime();var totalTime=selfClass.timeModel.getVisualTotalTime();selfClass.scrubbarProgX=currentTime/totalTime*selfClass.scrubbarWidth;if(isNaN(selfClass.scrubbarProgX)){selfClass.scrubbarProgX=0}if(selfClass.scrubbarProgX>selfClass.scrubbarWidth){selfClass.scrubbarProgX=selfClass.scrubbarWidth}if(currentTime<0){selfClass.scrubbarProgX=0}if(totalTime===0||isNaN(totalTime)){selfClass.scrubbarProgX=0}if(selfClass.scrubbarProgX<2&&cthis.data("promise-to-play-footer-player-from")){return}if(selfClass.spectrum_audioContext_buffer===null){if(selfClass.$$scrubbProg){selfClass.$$scrubbProg.style.width=parseInt(selfClass.scrubbarProgX,10)+"px"}}}/**
     * fired on requestAnimationFrame
     * @param pargs
     * @returns {boolean}
     */function handleEnterFrame(pargs){// -- enter frame
var margs=$.extend({"fire_only_once":false},pargs||{});if(isDestroyed){return false}selfClass.timeModel.refreshTimes({"call_from":"checK_time"});if(selfClass.audioType==="selfHosted"){}view_drawScrubProgress();selfClass.timeModel.processCurrentFrame();// -- skin minimal
if(o.design_skin==="skin-minimal"){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_view_player_skinMinimal_drawFrame,function(){window.dzsap_view_player_skinMinimal_drawFrame(selfClass,selfClass.scrubbarProgX)})}// -- enter_frame
view_drawCurrentTime();if(margs.fire_only_once!==true){requestAnimationFrame(handleEnterFrame)}}function handleClick_playPause(e){if(cthis.hasClass("prevent-bubble")){if(e&&e.stopPropagation){e.preventDefault();e.stopPropagation()}}var $conPlayPause=$(this);var isToggleCancelled=false;if(!cthis.hasClass("listeners-setuped")){$(selfClass.$mediaNode_).attr("preload","auto");setup_listeners();init_loaded();var inter_checkTotalTime=setInterval(function(){if(selfClass.$mediaNode_&&selfClass.$mediaNode_.duration&&isNaN(selfClass.$mediaNode_.duration)===false){clearInterval(inter_checkTotalTime)}},1000)}if(o.design_skin==="skin-minimal"){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.waitForScriptToBeAvailableThenExecute)(window.dzsap_skin_minimal_inited,function(){window.dzsap_view_player_skinMinimal_onClickPlayPause(selfClass,$conPlayPause,seek_to_perc,handleEnterFrame,e,togglePlayPause)});isToggleCancelled=true}if(!isToggleCancelled){togglePlayPause()}return false}function togglePlayPause(){if(!selfClass.isPlayerPlaying){play_media({"called_from":"click_playpause"})}else{pause_media()}}/**
     *
     * @param pargs
     * @returns {boolean|void}
     */function media_handleEnd(pargs){(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.media_handleEventEnd)(selfClass,pargs,media_isLoopActive,seek_to,play_media,pause_media,o,_jsinc_player_player_nextPrevButtons__WEBPACK_IMPORTED_MODULE_20__.syncPlayers_gotoNext,action_audio_end)}function view_handleResize(e,pargs){if(cthis){}ww=$(window).width();selfClass.cthisWidth=cthis.width();th=cthis.height();if(selfClass._scrubbarbg_canvas&&typeof selfClass._scrubbarbg_canvas.width==="function"){selfClass.canvasWidth=selfClass._scrubbarbg_canvas.width();selfClass.heightCanvas=selfClass._scrubbarbg_canvas.height()}if(selfClass.cthisWidth<=720){cthis.addClass("under-720")}else{cthis.removeClass("under-720")}if(selfClass.cthisWidth<=500){// -- width under 500
cthis.addClass("under-500")}else{// -- width under 500
cthis.removeClass("under-500")}(0,_jsinc_player_player_viewSetup__WEBPACK_IMPORTED_MODULE_25__.view_resizeHandleTreatSkins)(selfClass);// -- display none + overflow hidden hack does not work .. yeah
if(cthis.css("display")!=="none"){selfClass._scrubbar.find(".scrub-bg-img").eq(0).css({"width":selfClass._scrubbar.children(".scrub-bg").width()});selfClass._scrubbar.find(".scrub-prog-img").eq(0).css({"width":selfClass._scrubbar.children(".scrub-bg").width()})}cthis.removeClass("under-240 under-400");if(selfClass.cthisWidth<=240){cthis.addClass("under-240")}if(selfClass.cthisWidth<=500){cthis.addClass("under-400");if(is_under_400===false){is_under_400=true}if(selfClass.$controlsVolume){}}else{if(is_under_400===true){is_under_400=false}}var aux2=50;// -- skin-wave
if(o.design_skin==="skin-wave"){// ---------- calculate dims small
if(selfClass.skinwave_mode==="small"){selfClass.scrubbarWidth=selfClass._scrubbar.width()}if(o.skinwave_wave_mode==="canvas"){if(cthis.attr("data-pcm")){if(selfClass._scrubbarbg_canvas.width()===100){selfClass._scrubbarbg_canvas.width(selfClass._scrubbar.width())}if(selfClass.data_source!=="fake"){// -- if inter definied then clear timeout and call
if(draw_canvas_inter){clearTimeout(draw_canvas_inter);draw_canvas_inter=setTimeout(draw_canvas_inter_func,300)}else{draw_canvas_inter_func();draw_canvas_inter=1}}}}}if(["skin-minimal","skin-minion"].indexOf(o.design_skin)>-1){if(window.dzsap_skinFunctions_handleResize[o.design_skin]){window.dzsap_skinFunctions_handleResize[o.design_skin](selfClass)}}if(o.design_skin==="skin-default"){if(selfClass.$currTime){if(selfClass._metaArtistCon.css("display")==="none"){selfClass._metaArtistCon_w=0}if(isNaN(selfClass._metaArtistCon_l)){selfClass._metaArtistCon_l=20}}}if(o.embedded==="on"){(0,_jsinc_player_player_viewSetup__WEBPACK_IMPORTED_MODULE_25__.view_resizeEmbedded)(selfClass)}view_drawScrubProgress();if(o.settings_trigger_resize>0){if(o.parentgallery&&$(o.parentgallery).get(0)!==undefined&&$(o.parentgallery).get(0).api_handleResize!==undefined){$(o.parentgallery).get(0).api_handleResize()}}}function draw_canvas_inter_func(){(0,_jsinc_wave_render_wave_render_functions__WEBPACK_IMPORTED_MODULE_10__.view_drawCanvases)(selfClass,cthis.attr("data-pcm"),"canvas_normal_pcm");draw_canvas_inter=0}function viewCalculateScrubbarWidth(){if(selfClass.scrubbarWidth===0){selfClass.scrubbarWidth=selfClass._scrubbar.width()}if(selfClass.scrubbarWidth===0){selfClass.scrubbarWidth=300}}function seek_to_perc(argperc,pargs){seek_to(argperc*selfClass.timeModel.getVisualTotalTime(),pargs)}/**
     * seek to seconds
     * @param targetTimeMediaScrub - number of seconds
     * @param pargs -- optiona arguments
     * @returns {boolean}
     */function seek_to(targetTimeMediaScrub){var pargs=arguments.length>1&&arguments[1]!==undefined?arguments[1]:{};var margs={"call_from":"default","deeplinking":"off"// -- default or "auto" or "user action"
,"call_from_type":"default"// -- default or "auto" or "user action"
};if(pargs){margs=$.extend(margs,pargs)}if(margs.call_from==="from_feeder_to_feed"){}if(margs.deeplinking==="on"){var newlink=add_query_arg(window.location.href,"audio_time",targetTimeMediaScrub);var stateObj={foo:"bar"};history.pushState(stateObj,null,newlink)}targetTimeMediaScrub=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.sanitizeToIntFromPointTime)(targetTimeMediaScrub);targetTimeMediaScrub=selfClass.timeModel.getActualTargetTime(targetTimeMediaScrub);if(selfClass._actualPlayer){(0,_jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__.player_feederSeekTo)(selfClass,margs,targetTimeMediaScrub);return false}if(selfClass.audioType==="youtube"){try{selfClass.$mediaNode_.seekTo(targetTimeMediaScrub)}catch(err){}}handleEnterFrame({"fire_only_once":true});setTimeout(function(){handleEnterFrame({"fire_only_once":true})},20);if(selfClass.audioType==="selfHosted"){if(false){}else{if(selfClass.$mediaNode_&&typeof selfClass.$mediaNode_.currentTime!=="undefined"){try{selfClass.$mediaNode_.currentTime=targetTimeMediaScrub}catch(e){}}return false}}}/**
     * seek to ( only visual )
     * @param argperc
     */function seek_to_visual(argperc){curr_time_first_set=true;handleEnterFrame({"fire_only_once":true});setTimeout(function(){handleEnterFrame({"fire_only_once":true})},20)}/**
     * playback speed
     * @param {float} arg 0 - 10
     */function set_playback_speed(arg){if(selfClass.audioType==="youtube"){selfClass.$mediaNode_.setPlaybackRate(arg)}if(selfClass.audioType==="selfHosted"){selfClass.$mediaNode_.playbackRate=arg}}function pause_media_visual(pargs){var margs={"call_from":"default"};if(pargs){margs=$.extend(margs,pargs)}selfClass.$conPlayPause.removeClass("playing");cthis.removeClass("is-playing");selfClass.isPlayerPlaying=false;clearTimeout(selfClass.isPlayerPlayingEasedInterval);selfClass.isPlayerPlayingEasedInterval=setTimeout(function(){selfClass.isPlayerPlayingEased=false},_configs_constants__WEBPACK_IMPORTED_MODULE_5__.DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT);if(cthis.parent().hasClass("zoomsounds-wrapper-bg-center")){cthis.parent().removeClass("is-playing")}if(selfClass.$reflectionVisualObject){selfClass.$reflectionVisualObject.removeClass("is-playing")}if(o.parentgallery){o.parentgallery.removeClass("player-is-playing")}clearTimeout(isRenderingFrameInterval);isRenderingFrameInterval=setTimeout(function(){isRenderingFrame=false},_configs_constants__WEBPACK_IMPORTED_MODULE_5__.DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT);if(action_audio_pause){action_audio_pause(cthis)}}function pause_media(pargs){var margs={"audioapi_setlasttime":true,"donot_change_media":false,"call_actual_player":true};if(isDestroyed){return false}if(pargs){margs=$.extend(margs,pargs)}pause_media_visual({"call_from":"pause_media"});if(margs.call_actual_player&&margs.donot_change_media!==true){if(selfClass._actualPlayer!==null){(0,_jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__.player_actualPlayerPause)(selfClass);return}}(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.media_pause)(selfClass,function(){if(selfClass._sourcePlayer){(0,_jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__.player_sourcePlayerPauseVisual)(selfClass)}})}function play_media_visual(margs){selfClass.isPlayerPlaying=true;clearTimeout(selfClass.isPlayerPlayingEasedInterval);selfClass.isPlayerPlayingEased=true;clearTimeout(isRenderingFrameInterval);isRenderingFrame=true;cthis.addClass("is-playing");cthis.addClass("first-played");if(selfClass.$reflectionVisualObject){selfClass.$reflectionVisualObject.addClass("is-playing")}if(o.parentgallery){o.parentgallery.addClass("player-is-playing")}if(selfClass.classFunctionalityInnerPlaylist){selfClass.classFunctionalityInnerPlaylist.player_determineSyncPlayersIndex(selfClass,selfClass._sourcePlayer)}(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.view_player_globalDetermineSyncPlayersIndex)(selfClass);(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.view_player_playMiscEffects)(selfClass);if(selfClass.isStickyPlayer){if(window["dzsap_stickyPlayer_show"]){dzsap_stickyPlayer_show(selfClass)}}if(action_audio_play){action_audio_play(cthis)}if(action_audio_play2){action_audio_play2(cthis)}}function play_media(pargs){var margs={"api_report_play_media":true,"called_from":"default","retry_call":0};if(pargs){margs=$.extend(margs,pargs)}if(!selfClass.isSetupedMedia){setup_media({"called_from":margs.called_from+"[play_media .. not setuped]"})}if(margs.called_from==="api_sync_players_prev"){player_index_in_gallery=cthis.parent().children(".audioplayer,.audioplayer-tobe").index(cthis);if(o.parentgallery&&o.parentgallery.get(0)&&o.parentgallery.get(0).api_goto_item){o.parentgallery.get(0).api_goto_item(player_index_in_gallery)}}if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)()&&selfClass.spectrum_audioContext_buffer==="waiting"||selfClass.mediaProtectionStatus==="fetchingProtection"){setTimeout(function(){if(!pargs){pargs={}}pargs.call_from_aux="waiting audioCtx_buffer or ios";play_media(pargs)},500);return false}if(margs.called_from==="click_playpause"){// -- lets setup the playlist
}if(!cthis.hasClass("media-setuped")&&selfClass._actualPlayer===null){console.log("[dzsap][warning] media not setuped, there might be issues",cthis.attr("id"))}if(margs.called_from.indexOf("feed_to_feeder")>-1){if(!cthis.hasClass("dzsap-loaded")){init_loaded();var delay=300;if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()){delay=0}if(margs.call_from_aux!=="with delay"){if(delay){setTimeout(function(){margs.call_from_aux="with delay";play_media(margs)},delay)}else{play_media(margs)}return false}}}(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.player_stopOtherPlayers)(dzsap_list,selfClass);if(isDestroyedForRebuffer){setup_media({"called_from":"play_media() .. destroyed for rebuffer"});if((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.isInt)(selfClass.playFrom)){seek_to(selfClass.playFrom,{"call_from":"destroyed_for_rebuffer_playfrom"})}isDestroyedForRebuffer=false}// -- media functions
if(selfClass._sourcePlayer){(0,_jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__.player_sourcePlayerPlayVisual)(selfClass)}if(selfClass._actualPlayer){var output=(0,_jsinc_player_player_feederFunctions__WEBPACK_IMPORTED_MODULE_22__.player_actualPlayerPlay)(selfClass,margs,seek_to);if(output.itShouldReturn){return}}if(selfClass.audioType==="youtube"){dzsap_youtube_playMedia(selfClass,margs,selfClass.youtube_currentId)}if(selfClass.audioType==="selfHosted"){}if(selfClass.audioType==="youtube"){play_media_visual(margs)}(0,_jsinc_media_media_functions__WEBPACK_IMPORTED_MODULE_2__.media_tryToPlay)(selfClass,function(){play_media_visual(margs);if(o.skinwave_enableSpectrum==="on"){(0,_jsinc_player_player_scrubModeWave_spectrum__WEBPACK_IMPORTED_MODULE_15__.player_initSpectrum)(selfClass)}if(selfClass._sourcePlayer){window.dzsap_currplayer_focused=selfClass._sourcePlayer.get(0);if(selfClass._sourcePlayer.get(0)&&selfClass._sourcePlayer.get(0).api_pause_media_visual){selfClass._sourcePlayer.get(0).api_try_to_submit_view()}}else{window.dzsap_currplayer_focused=cthis.get(0);service_submitView()}if(selfClass.keyboard_controls.play_trigger_step_back==="on"){if(dzsap_currplayer_focused){dzsap_currplayer_focused.api_step_back(selfClass.keyboard_controls.step_back_amount)}}},function(err){console.log("error autoplay playing -  ",err);setTimeout(function(){pause_media();console.log("trying to pause")},30)})}function service_submitView(){if(selfClass.ajax_view_submitted==="auto"){selfClass.ajax_view_submitted="off"}if(selfClass.ajax_view_submitted==="off"){_jsinc_dzsap_ajax__WEBPACK_IMPORTED_MODULE_4__.ajax_submit_views.bind(selfClass)()}}}}]);return DzsAudioPlayer}();function register_dzsap_plugin(){if(!window.dzsap_settings){window.dzsap_settings={}}(function($){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.assignHelperFunctionsToJquery)($);// -- define player here
$.fn.audioplayer=function(argOptions){var finalOptions={};var defaultOptions=Object.assign({},_configs_settingsPlayer__WEBPACK_IMPORTED_MODULE_11__.defaultPlayerOptions);finalOptions=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.convertPluginOptionsToFinalOptions)(this,defaultOptions,argOptions);this.each(function(){return new DzsAudioPlayer(this,Object.assign({},finalOptions),$)})}})(jQuery)}window.dzsap_singleton_ready_calls_is_called=false;/**
 * not reliable
 */window.dzsap_get_base_url=function(){window.dzsap_base_url=window.dzsap_settings&&window.dzsap_settings.pluginurl?window.dzsap_settings.pluginurl:(0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.getBaseUrl)("dzsap_base_url","audioplayer.js")};window.dzsap_currplayer_focused=null;window.dzsap_currplayer_from_share=null;window.dzsap_mouseover=false;window.dzsap_init_allPlayers=function($){var $feed_dzsapConfigs=$(".dzsap-feed--dzsap-configs");if($feed_dzsapConfigs.length){window.dzsap_apconfigs=JSON.parse($feed_dzsapConfigs.last().html())}$(".audioplayer.auto-init,.audioplayer-tobe.auto-init").each(function(){var $playerTarget=$(this);if($playerTarget.hasClass("audioplayer-tobe")){if(window.dzsap_init){dzsap_init($playerTarget)}}})};(0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.dzsap_jQueryInit)().then(function(){register_dzsap_plugin();window.dzsap_get_base_url();jQuery(document).ready(function($){// -- defined gallery here
// --
// AUDIO GALLERY
// --
// -- main call
if(!window.dzsap_singleton_ready_calls_is_called){(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.dzsap_singleton_ready_calls)()}(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.jQueryAuxBindings)($);window.dzsap_init_allPlayers($)});if(!window.dzsap_player_isOneTimeSetuped){(0,_jsinc_player_player_one_time_setups__WEBPACK_IMPORTED_MODULE_12__.dzsap_oneTimeSetups)();window.dzsap_player_isOneTimeSetuped=true}}).catch(function(err){console.log(err)});window.dzsap_init=function(selector,settings){jQuery(selector).audioplayer(Object.assign({},settings));window.dzsap_lasto=settings};(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.playerRegisterWindowFunctions)();
})();

/******/ })()
;
//# sourceMappingURL=audioplayer.js.map