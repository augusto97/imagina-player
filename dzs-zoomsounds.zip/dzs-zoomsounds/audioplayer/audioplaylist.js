/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../source/audioplayer/configs/_constants.js":
/*!***************************************************!*\
  !*** ../source/audioplayer/configs/_constants.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConstantsDzsAp": () => (/* binding */ ConstantsDzsAp),
/* harmony export */   "DEBUG_STYLE_PLAY_FUNCTIONS": () => (/* binding */ DEBUG_STYLE_PLAY_FUNCTIONS),
/* harmony export */   "DZSAP_AJAX_ACTION_LIKE": () => (/* binding */ DZSAP_AJAX_ACTION_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_AJAX_LIKE": () => (/* binding */ DZSAP_CLASS_NAME_AJAX_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_FEED_EMBED_CODE": () => (/* binding */ DZSAP_CLASS_NAME_FEED_EMBED_CODE),
/* harmony export */   "DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS": () => (/* binding */ DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOOTER_PLAYER": () => (/* binding */ DZSAP_PLAYER_CLASS_FOOTER_PLAYER),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW": () => (/* binding */ DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW),
/* harmony export */   "DZSAP_PLAYER_CLASS_LOADED": () => (/* binding */ DZSAP_PLAYER_CLASS_LOADED),
/* harmony export */   "DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED": () => (/* binding */ DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_KEYBOARD": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_KEYBOARD),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS),
/* harmony export */   "DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT": () => (/* binding */ DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT),
/* harmony export */   "DZSAP_VIEW_SONG_CHANGER_CLASS": () => (/* binding */ DZSAP_VIEW_SONG_CHANGER_CLASS),
/* harmony export */   "WAVESURFER_MAX_TIMEOUT": () => (/* binding */ WAVESURFER_MAX_TIMEOUT)
/* harmony export */ });
const DEBUG_STYLE_PLAY_FUNCTIONS = 'background-color: #daffda; color: #222222;';
const WAVESURFER_MAX_TIMEOUT = 20000;

const ConstantsDzsAp = {
  PLAYLIST_TRANSITION_DURATION: 300,
  'DEBUG_STYLE_1': 'background-color: #aaa022; color: #222222;',
  'DEBUG_STYLE_2': 'background-color: #7c3b8e; color: #ffffff;',
  'DEBUG_STYLE_3': 'background-color: #3a696b; color: #eeeeee;',
  'DEBUG_STYLE_ERROR': 'background-color: #3a696b; color: #eeeeee;',
  URL_WAVESURFER_HELPER_BACKUP: 'https://zoomthe.me/assets/dzsap-wave-generate.js',
  WAVESURFER_MAX_TIMEOUT,
  DEBUG_STYLE_PLAY_FUNCTIONS,
  URL_JQUERY: 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js',
  ERRORED_OUT_CLASS: 'errored-out',
  ERRORED_OUT_MAX_ATTEMPTS: 5
}

const DZSAP_PLAYER_CLASS_FOOTER_PLAYER = 'dzsap_footer';
const DZSAP_PLAYER_CLASS_LOADED = 'dzsap-loaded';
const DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW = 'audioplayer-loaded';
const DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom';
const DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom-placeholder';
const DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED = 'fake';
const DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS = 'last';
const DZSAP_CLASS_NAME_AJAX_LIKE = 'btn-like';
const DZSAP_CLASS_NAME_FEED_EMBED_CODE = 'feed-dzsap--embed-code';

const DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS = '#dzsap-main-settings';
const DZSAP_SCRIPT_SELECTOR_KEYBOARD = '#dzsap-keyboard-controls';
const DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT = 500;
const DZSAP_AJAX_ACTION_LIKE = 'dzsap_submit_like';
const DZSAP_VIEW_SONG_CHANGER_CLASS = 'audioplayer-song-changer';


/***/ }),

/***/ "../source/audioplayer/configs/_settingsPlaylist.js":
/*!**********************************************************!*\
  !*** ../source/audioplayer/configs/_settingsPlaylist.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default_opts": () => (/* binding */ default_opts)
/* harmony export */ });
const default_opts = {
  design_skin: 'skin-default', // -- "skin-default" or "skin-aura" or "skin-wave"
  cueFirstMedia: 'on', // -- preload the mp3 to the first item
  autoplay: 'off', // -- autoplay the first item
  autoplayNext: 'on', // -- autoplay items after the first item
  settings_enable_linking: 'off',  // -- use html5 history to remember last position in the gallery

  design_menu_position: 'bottom',
  navigation_method: 'mouseover', // -- 'mouseover', 'full', 'legacyscroll' or 'dzsscroll'
  design_menu_state: 'open',  // -- options are "open" or "closed", this sets the initial state of the menu, even if the initial state is "closed", it can still be opened by a button if you set design_menu_show_player_state_button to "on"
  design_menu_show_player_state_button: 'off',  // -- show a button that allows to hide or show the menu
  design_menu_width: 'default',
  design_menu_height: 'default',
  design_menu_space: 'default',
  settings_php_handler: '', // -- link to publisher.php ( auto assigned in wordpress to admin-ajax.php )
  design_menuitem_width: 'default',
  design_menuitem_height: 'default',
  design_menuitem_space: 'default',

  disable_menu_navigation: 'off',
  loop_playlist: 'on',
  menu_facebook_share: 'auto' // -- mousemove or scroller or all
  , enable_easing: 'off' // -- enable easing for menu animation
  , settings_ap: 'default' // -- string or array
  , playlistTransition: 'fade' // -- fade or direct
  , embedded: 'off',
  mode_showall_layout: 'one-per-row' // or "two-per-row" or "three-per-row"
  , settings_mode: 'mode-normal' // -- mode-normal or mode-showall
  , settings_mode_showall_show_number: 'on' // mode-normal or mode-showall
  , mode_normal_video_mode: 'auto' // -- auto or "one" ( only one audio player )

};



/***/ }),

/***/ "../source/audioplayer/js_common/_dzs_helpers.js":
/*!*******************************************************!*\
  !*** ../source/audioplayer/js_common/_dzs_helpers.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decode_json": () => (/* binding */ decode_json),
/* harmony export */   "dzsap_jQueryInit": () => (/* binding */ dzsap_jQueryInit),
/* harmony export */   "getBaseUrl": () => (/* binding */ getBaseUrl),
/* harmony export */   "getRelativeX": () => (/* binding */ getRelativeX),
/* harmony export */   "isInt": () => (/* binding */ isInt),
/* harmony export */   "isValid": () => (/* binding */ isValid),
/* harmony export */   "loadScriptIfItDoesNotExist": () => (/* binding */ loadScriptIfItDoesNotExist),
/* harmony export */   "sanitizeToCssPx": () => (/* binding */ sanitizeToCssPx),
/* harmony export */   "setupTooltip": () => (/* binding */ setupTooltip),
/* harmony export */   "simpleStringify": () => (/* binding */ simpleStringify),
/* harmony export */   "string_curateClassName": () => (/* binding */ string_curateClassName)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const decode_json = function (arg) {
  var fout = {};

  if (arg) {

    try {

      fout = JSON.parse(arg);
    } catch (err) {

      return null;
    }
  }

  return fout;
}
async function dzsap_jQueryInit(callback, reject) {

  return new Promise((resolve, reject) => {

    if (window.jQuery) {
      resolve('jQuery loaded');
    } else {
      const script = document.createElement('script');
      script.onload = function () {
        if (window.jQuery) {
          resolve('jQuery loaded');
        } else {
          reject('error loading');
        }
      };
      script.src = _configs_constants__WEBPACK_IMPORTED_MODULE_0__.ConstantsDzsAp.URL_JQUERY;

      document.head.appendChild(script);
    }

    setTimeout(() => {
      reject('error loading');
    }, 15000);
  })
}
/**
 *
 * @param {string} arg
 * @return {string}
 */
function string_curateClassName(arg){

  arg = arg.replace('feed-dzsap', '');
  arg = arg.replace('feed-dzsap--extra-html', '');
  return arg;
}


function simpleStringify (object){
  if (object && typeof object === 'object') {
    object = copyWithoutCircularReferences([object], object);
  }
  return JSON.stringify(object);

  function copyWithoutCircularReferences(references, object) {
    const cleanObject = {};
    Object.keys(object).forEach(function(key) {
      var value = object[key];
      if (value && typeof value === 'object') {
        if (references.indexOf(value) < 0) {
          references.push(value);
          cleanObject[key] = copyWithoutCircularReferences(references, value);
          references.pop();
        } else {
          cleanObject[key] = '###_Circular_###';
        }
      } else if (typeof value !== 'function') {
        cleanObject[key] = value;
      }
    });
    return cleanObject;
  }
}

const loadScriptIfItDoesNotExist = (scriptSrc, checkForVar) => {
  return new Promise((resolve, reject) => {
    if (checkForVar) {
      resolve('loadfromvar');
      return;
    }

    var script = document.createElement('script');
    script.onload = function () {
      resolve('loadfromload');
    };
    script.onerror = function () {
      reject();
    };
    script.src = scriptSrc;

    document.head.appendChild(script);
  })
}


const getBaseUrl = (baseUrlVar, scriptName) => {
  if (window[baseUrlVar]) {
    return window[baseUrlVar];
  }

  let scripts = document.getElementsByTagName("script");
  for (var scriptKey in scripts) {
    if (scripts[scriptKey] && scripts[scriptKey].src && String(scripts[scriptKey].src).indexOf(scriptName) > -1) {
      break;
    }
  }
  var baseUrl_arr = String(scripts[scriptKey].src).split('/');
  baseUrl_arr.splice(-1, 1);
  const result = string_addTrailingSlash(baseUrl_arr.join('/'));
  window[baseUrlVar] = result+'/';
  return result;
}

function string_addTrailingSlash(url){
  var lastChar = url.substr(-1); // Selects the last character
  if (lastChar != '/') {         // If the last character is not a slash
    url = url + '/';            // Append a slash to it.
  }
  return url;
}
const sanitizeToCssPx = (arg) => {

  if (String(arg).indexOf('%') > -1 || String(arg).indexOf('em') > -1 || String(arg).indexOf('px') > -1 || String(arg).indexOf('auto') > -1) {
    return arg;
  }
  return arg + 'px';
}


const setupTooltip = (args) => {

  var mainArgs = Object.assign({
    tooltipInnerHTML: '',
    tooltipIndicatorText: '',
    tooltipConClass: '',
  }, args)

  return `<div class="dzstooltip-con ${mainArgs.tooltipConClass}"><span class="dzstooltip main-tooltip   talign-end arrow-bottom style-rounded color-dark-light  dims-set transition-slidedown " style="width: 280px;"><span class="dzstooltip--inner">${mainArgs.tooltipInnerHTML}</span> </span></span><span class="tooltip-indicator">${mainArgs.tooltipIndicatorText}</span></div>`;
}


const isInt = function (n) {
  return typeof n == 'number' && Math.round(n) % 1 == 0;
}

const isValid = function (n) {
  return typeof n != 'undefined' && n != '';
}


function getRelativeX (mouseX, $el_) {
  if (jQuery) {
    return mouseX - jQuery($el_).offset().left;
  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_helpers.js":
/*!*****************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_helpers.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "add_query_arg": () => (/* binding */ add_query_arg),
/* harmony export */   "assignHelperFunctionsToJquery": () => (/* binding */ assignHelperFunctionsToJquery),
/* harmony export */   "assignPcmData": () => (/* binding */ assignPcmData),
/* harmony export */   "can_canvas": () => (/* binding */ can_canvas),
/* harmony export */   "can_history_api": () => (/* binding */ can_history_api),
/* harmony export */   "convertPluginOptionsToFinalOptions": () => (/* binding */ convertPluginOptionsToFinalOptions),
/* harmony export */   "dzs_clean_string": () => (/* binding */ dzs_clean_string),
/* harmony export */   "dzsapInitjQueryRegisters": () => (/* binding */ dzsapInitjQueryRegisters),
/* harmony export */   "dzsap_generate_keyboard_tooltip": () => (/* binding */ dzsap_generate_keyboard_tooltip),
/* harmony export */   "dzsap_is_mobile": () => (/* binding */ dzsap_is_mobile),
/* harmony export */   "dzsap_singleton_ready_calls": () => (/* binding */ dzsap_singleton_ready_calls),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "generateFakeArrayForPcm": () => (/* binding */ generateFakeArrayForPcm),
/* harmony export */   "get_query_arg": () => (/* binding */ get_query_arg),
/* harmony export */   "hexToRgb": () => (/* binding */ hexToRgb),
/* harmony export */   "htmlEncode": () => (/* binding */ htmlEncode),
/* harmony export */   "is_android": () => (/* binding */ is_android),
/* harmony export */   "is_android_good": () => (/* binding */ is_android_good),
/* harmony export */   "is_ios": () => (/* binding */ is_ios),
/* harmony export */   "is_safari": () => (/* binding */ is_safari),
/* harmony export */   "jQueryAuxBindings": () => (/* binding */ jQueryAuxBindings),
/* harmony export */   "playerFunctions": () => (/* binding */ playerFunctions),
/* harmony export */   "playerRegisterWindowFunctions": () => (/* binding */ playerRegisterWindowFunctions),
/* harmony export */   "player_checkIfWeShouldShowAComment": () => (/* binding */ player_checkIfWeShouldShowAComment),
/* harmony export */   "player_delete": () => (/* binding */ player_delete),
/* harmony export */   "player_determineStickToBottomContainer": () => (/* binding */ player_determineStickToBottomContainer),
/* harmony export */   "player_getPlayFromTime": () => (/* binding */ player_getPlayFromTime),
/* harmony export */   "player_identifySource": () => (/* binding */ player_identifySource),
/* harmony export */   "player_identifyTypes": () => (/* binding */ player_identifyTypes),
/* harmony export */   "player_isGoingToSetupMediaNow": () => (/* binding */ player_isGoingToSetupMediaNow),
/* harmony export */   "player_radio_isNameUpdatable": () => (/* binding */ player_radio_isNameUpdatable),
/* harmony export */   "player_reinit_findIfPcmNeedsGenerating": () => (/* binding */ player_reinit_findIfPcmNeedsGenerating),
/* harmony export */   "player_service_getSourceProtection": () => (/* binding */ player_service_getSourceProtection),
/* harmony export */   "player_stickToBottomContainerDetermineClasses": () => (/* binding */ player_stickToBottomContainerDetermineClasses),
/* harmony export */   "player_stopOtherPlayers": () => (/* binding */ player_stopOtherPlayers),
/* harmony export */   "player_syncPlayers_buildList": () => (/* binding */ player_syncPlayers_buildList),
/* harmony export */   "player_syncPlayers_gotoItem": () => (/* binding */ player_syncPlayers_gotoItem),
/* harmony export */   "player_view_addMetaLoaded": () => (/* binding */ player_view_addMetaLoaded),
/* harmony export */   "registerTextWidth": () => (/* binding */ registerTextWidth),
/* harmony export */   "sanitizeObjectForChangeMediaArgs": () => (/* binding */ sanitizeObjectForChangeMediaArgs),
/* harmony export */   "sanitizeToHexColor": () => (/* binding */ sanitizeToHexColor),
/* harmony export */   "sanitizeToIntFromPointTime": () => (/* binding */ sanitizeToIntFromPointTime),
/* harmony export */   "select_all": () => (/* binding */ select_all),
/* harmony export */   "string_jsonConvertToArray": () => (/* binding */ string_jsonConvertToArray),
/* harmony export */   "utils_sanitizeToColor": () => (/* binding */ utils_sanitizeToColor),
/* harmony export */   "view_player_globalDetermineSyncPlayersIndex": () => (/* binding */ view_player_globalDetermineSyncPlayersIndex),
/* harmony export */   "view_player_playMiscEffects": () => (/* binding */ view_player_playMiscEffects),
/* harmony export */   "waitForScriptToBeAvailableThenExecute": () => (/* binding */ waitForScriptToBeAvailableThenExecute)
/* harmony export */ });
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./player/_player_keyboard */ "../source/audioplayer/jsinc/player/_player_keyboard.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");





function formatTime(arg) {

  var s = Math.round(arg);
  var m = 0;
  var h = 0;
  if (s > 0) {
    while (s > 3599 && s < 3000000 && isFinite(s)) {
      h++;
      s -= 3600;
    }
    while (s > 59 && s < 3000000 && isFinite(s)) {
      m++;
      s -= 60;
    }
    if (h) {

      return String((h < 10 ? "0" : "") + h + ":" + String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s));
    }
    return String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s);
  } else {
    return "00:00";
  }
}

function can_history_api() {
  return !!(window.history && history.pushState);
}

function dzs_clean_string(arg) {

  if (arg) {

    arg = arg.replace(/[^A-Za-z0-9\-]/g, '');

    arg = arg.replace(/\./g, '');
    return arg;
  }

  return '';


}


function get_query_arg(purl, key) {
  if (purl) {

    if (String(purl).indexOf(key + '=') > -1) {

      var regexS = "[?&]" + key + "=.+";
      var regex = new RegExp(regexS);
      var regtest = regex.exec(purl);


      if (regtest != null) {
        var splitterS = regtest[0];
        if (splitterS.indexOf('&') > -1) {
          var aux = splitterS.split('&');
          splitterS = aux[1];
        }

        var splitter = splitterS.split('=');


        return splitter[1];

      }

    }

  } else {
  }
}

function add_query_arg(purl, key, value) {

  key = encodeURIComponent(key);
  value = encodeURIComponent(value);

  if (!(purl)) {
    purl = '';
  }
  var s = purl;
  var pair = key + "=" + value;

  var r = new RegExp("(&|\\?)" + key + "=[^\&]*");

  s = s.replace(r, "$1" + pair);

  if (s.indexOf(key + '=') > -1) {


  } else {
    if (s.indexOf('?') > -1) {
      s += '&' + pair;
    } else {
      s += '?' + pair;
    }
  }


  if (value === 'NaN') {
    var regex_attr = new RegExp('[\?|\&]' + key + '=' + value);
    s = s.replace(regex_attr, '');


    if (s.indexOf('?') === -1 && s.indexOf('&') > -1) {
      s = s.replace('&', '?');
    }
  }

  return s;
}


function dzsap_is_mobile() {


  return is_ios() || is_android();
}

function is_ios() {

  return ((navigator.platform.indexOf("iPhone") !== -1) || (navigator.platform.indexOf("iPod") !== -1) || (navigator.platform.indexOf("iPad") !== -1));
}


function can_canvas() {

  var oCanvas = document.createElement("canvas");
  return !!oCanvas.getContext("2d");

}

function is_safari() {
  return Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
}


function is_android() {
  var ua = navigator.userAgent.toLowerCase();

  return (ua.indexOf("android") > -1);
}

function select_all(el) {
  if (typeof window.getSelection !== "undefined" && typeof document.createRange !== "undefined") {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  } else if (typeof document.selection !== "undefined" && typeof document.body.createTextRange !== "undefined") {
    var textRange = document.body.createTextRange();
    textRange.moveToElementText(el);
    textRange.select();
  }
}

function is_android_good() {


}

function htmlEncode(arg) {
  return jQuery('<div/>').text(arg).html();
}

function dzsap_generate_keyboard_tooltip(keyboard_controls, lab) {


  let structureDzsTooltipCommentAfterSubmit = '<span class="dzstooltip color-dark-light talign-start transition-slidein arrow-bottom style-default" style="width: auto;  white-space:nowrap;"><span class="dzstooltip--inner">' + 'Shortcut' + ': ' + keyboard_controls[lab] + '</span></span>';

  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('32', 'space');
  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('27', 'escape');

  return structureDzsTooltipCommentAfterSubmit;


}


/**
 *
 * @param hex
 * @param {number|null} targetAlpha 0-1
 * @returns {string}
 */
function hexToRgb(hex, targetAlpha = null) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  var str = '';
  if (result) {
    result = {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    };


    var alpha = 1;

    if (targetAlpha !== null) {
      alpha = targetAlpha;
    }


    str = 'rgba(' + result.r + ',' + result.g + ',' + result.b + ',' + alpha + ')';
  }


  return str;


}

function assignHelperFunctionsToJquery($) {


  Math.easeIn = function (t, b, c, d) {
    return -c * (t /= d) * (t - 2) + b;
  };


  /**
   *
   * @param {string} argfind
   * @param {string} arg
   * @returns {string}
   */
  const checkIfHasClass = (argfind, arg) => {

    if (!argfind) {
      var regex = new RegExp('class="(.*?)"');
      var auxarr = regex.exec(arg);


      if (auxarr && auxarr[1]) {
        argfind = '.' + auxarr[1];
      }
    }

    return argfind;
  }
  $.fn.prependOnce = function (arg, argfind) {
    var _t = $(this)


    argfind = checkIfHasClass(argfind, arg);


    if (_t.children(argfind).length < 1) {
      _t.prepend(arg);
      return true;
    }
    return false;
  };
  $.fn.appendOnce = function (arg, argfind) {
    var _t = $(this)

    argfind = checkIfHasClass(argfind, arg);

    if (_t.children(argfind).length < 1) {
      _t.append(arg);
      return true;
    }
    return false;
  };
};


function registerTextWidth($) {

  $.fn.textWidth = function () {
    var _t = jQuery(this);
    var html_org = _t.html();
    if (_t[0].nodeName === 'INPUT') {
      html_org = _t.val();
    }
    var html_calcS = '<span class="forcalc">' + html_org + '</span>';
    jQuery('body').append(html_calcS);
    var _lastspan = jQuery('span.forcalc').last();

    _lastspan.css({
      'font-size': _t.css('font-size'),
      'font-family': _t.css('font-family')
    })
    var width = _lastspan.width();

    _lastspan.remove();
    return width;
  };
}

function player_checkIfWeShouldShowAComment(selfClass, real_time_curr, real_time_total) {

  var $ = jQuery;
  var timer_curr_perc = Math.round((real_time_curr / real_time_total) * 100) / 100;
  if (selfClass.audioType === 'fake') {
    timer_curr_perc = Math.round((selfClass.timeCurrent / selfClass.timeTotal) * 100) / 100;
  }
  if (selfClass._commentsHolder) {
    selfClass._commentsHolder.children().each(function () {
      var _t = $(this);
      if (_t.hasClass('dzstooltip-con')) {
        var _t_posx = _t.offset().left - selfClass._commentsHolder.offset().left;


        var aux = Math.round((parseFloat(_t_posx) / selfClass._commentsHolder.outerWidth()) * 100) / 100;


        if (aux) {

          if (Math.abs(aux - timer_curr_perc) < 0.02) {
            selfClass._commentsHolder.find('.dzstooltip').removeClass('active');
            _t.find('.dzstooltip').addClass('active');
          } else {
            _t.find('.dzstooltip').removeClass('active');
          }
        }
      }
    })
  }
}


function sanitizeObjectForChangeMediaArgs(_sourceForChange) {

  var changeMediaArgs = {};
  var _feed_fakePlayer = _sourceForChange;

  var lab = '';

  if (_sourceForChange.data('original-settings')) {
    return _sourceForChange.data('original-settings');
  }


  changeMediaArgs.source = null;
  if (_feed_fakePlayer.attr('data-source')) {
    changeMediaArgs.source = _feed_fakePlayer.attr('data-source')
  } else {

    if (_feed_fakePlayer.attr('href')) {
      changeMediaArgs.source = _feed_fakePlayer.attr('href');
    }
  }

  if (_feed_fakePlayer.attr('data-pcm')) {
    changeMediaArgs.pcm = _feed_fakePlayer.attr('data-pcm');
  }


  lab = 'thumb';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }

  lab = 'playerid';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }
  lab = 'type';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }


  if (_feed_fakePlayer.attr('data-thumb_link')) {
    changeMediaArgs.thumb_link = _sourceForChange.attr('data-thumb_link');
  }


  if (_sourceForChange.find('.meta-artist').length > 0 || _sourceForChange.find('.meta-artist-con').length > 0) {

    changeMediaArgs.artist = _sourceForChange.find('.the-artist').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.the-name').eq(0).html();
  }


  if (_sourceForChange.attr('data-thumb_for_parent')) {
    changeMediaArgs.thumb = _sourceForChange.attr('data-thumb_for_parent');
  }


  if (_sourceForChange.find('.feed-song-name').length > 0 || _sourceForChange.find('.feed-artist-name').length > 0) {
    changeMediaArgs.artist = _sourceForChange.find('.feed-artist-name').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.feed-song-name').eq(0).html();
  }


  return changeMediaArgs;
}


function utils_sanitizeToColor(colorString) {
  if (colorString.indexOf('#') === -1 && colorString.indexOf('rgb') === -1 && colorString.indexOf('hsl') === -1) {
    return '#' + colorString;
  }
  return colorString;
}

function dzsapInitjQueryRegisters() {
}

function player_radio_isNameUpdatable(selfClass, radio_update_song_name, targetKey) {

  if (selfClass._metaArtistCon.find(targetKey).length && selfClass._metaArtistCon.find(targetKey).eq(0).text().length > 0) {

    if (selfClass._metaArtistCon.find(targetKey).eq(0).html().indexOf('{{update}}') > -1) {
      return true;
    }
  }


  return false;
}

function playerRegisterWindowFunctions() {


  window['dzsap_functions'] = {};
  window['dzsap_functions']['send_total_time'] = function (argtime, argcthis) {


    if (argtime && argtime !== Infinity) {
      const data = {
        action: 'dzsap_send_total_time_for_track',
        id_track: argcthis.attr('data-playerid'),
        postdata: Math.ceil(argtime)
      };
      jQuery.post(window.dzsap_ajaxurl, data, function (response) {
      });
    }

  }


  window.dzs_open_social_link = function (arg, argthis) {
    var leftPosition, topPosition;
    var w = 500, h = 500;

    leftPosition = (window.screen.width / 2) - ((w / 2) + 10);

    topPosition = (window.screen.height / 2) - ((h / 2) + 50);
    var windowFeatures = "status=no,height=" + h + ",width=" + w + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";


    arg = arg.replace('{{replacewithcurrurl}}', encodeURIComponent(window.location.href));

    if (argthis && argthis.attr) {
      arg = arg.replace(/{{replacewithdataurl}}/g, argthis.attr('data-url'));
    }

    const locationHref = window.location.href;


    const auxa = locationHref.split('?');

    let cid = '';
    let cid_gallery = '';


    if (argthis) {

    } else {
      if (window.dzsap_currplayer_from_share) {

        argthis = window.dzsap_currplayer_from_share;
      }
    }


    if (argthis) {

      const $ = jQuery;

      if ($(argthis).hasClass('audioplayer')) {
        cid = $(argthis).parent().children().index(argthis);
        cid_gallery = $(argthis).parent().parent().parent().attr('id');
      } else {
        if (jQuery(argthis).parent().parent().attr('data-menu-index')) {

          cid = jQuery(argthis).parent().parent().attr('data-menu-index');
        }
        if (jQuery(argthis).parent().parent().attr('data-gallery-id')) {

          cid_gallery = jQuery(argthis).parent().parent().attr('data-gallery-id');
        }
      }

    }


    var shareurl = encodeURIComponent(auxa[0] + '?fromsharer=on&audiogallery_startitem_' + cid_gallery + '=' + cid + '');
    arg = arg.replace('{{shareurl}}', shareurl);


    window.open(arg, "sharer", windowFeatures);
  }


  window.dzsap_wp_send_contor_60_secs = function (argcthis, argtitle) {

    var data = {
      video_title: argtitle

      , video_analytics_id: argcthis.attr('data-playerid')
      , curr_user: window.dzsap_curr_user
    };
    var theajaxurl = 'index.php?action=ajax_dzsap_submit_contor_60_secs';

    if (window.dzsap_settings.dzsap_site_url) {

      theajaxurl = dzsap_settings.dzsap_site_url + theajaxurl;
    }


    jQuery.ajax({
      type: "POST",
      url: theajaxurl,
      data: data,
      success: function (response) {


      },
      error: function (arg) {

      }
    });
  }


  window.dzsap_init_multisharer = function () {


  }


}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function assignPcmData(selfClass) {

  selfClass.pcmSource = string_jsonConvertToArray(selfClass.cthis.attr('data-pcm'));
  if (selfClass.initOptions.skinwave_enableSpectrum === 'on') {
    var pcmSourceLen = selfClass.pcmSource.length;
    var desiredSize = 256;

    for (var i = 0; i < pcmSourceLen; i++) {
      if (i > desiredSize) {
        continue;
      }
      selfClass.pcmSource[i] = selfClass.pcmSource[i * pcmSourceLen / desiredSize] * desiredSize;
    }
    selfClass.pcmSource.splice(desiredSize, pcmSourceLen - desiredSize); // removes 3rd element of array
  }
}

function string_jsonConvertToArray(ar_str) {
  let waves = [];
  if (typeof (ar_str) == 'object') {
    waves = ar_str;
  } else {
    try {
      waves = JSON.parse(ar_str);
    } catch (err) {

    }
  }

  return waves;
}

/**
 * should be called only once on init
 */
function dzsap_singleton_ready_calls() {

  window.dzsap_singleton_ready_calls_is_called = true;


  let $feed_dzsapMainSettings = null;
  const $feed_dzsapMainSettingsAll = document.querySelectorAll('.dzsap-main-settings');
  if ($feed_dzsapMainSettingsAll.length) {
    $feed_dzsapMainSettings = $feed_dzsapMainSettingsAll[$feed_dzsapMainSettingsAll.length - 1];
  }
  if ($feed_dzsapMainSettings) {
    window.dzsap_settings = JSON.parse($feed_dzsapMainSettings.innerHTML);
    window.ajaxurl = window.dzsap_settings.ajax_url;
    window.dzsap_curr_user = window.dzsap_settings.dzsap_curr_user;
  }


  jQuery('body').append('<style class="dzsap--style"></style>');


  window.dzsap__style = jQuery('.dzsap--style');


  jQuery('audio.zoomsounds-from-audio').each(function () {
    var _t = jQuery(this);
    _t.after('<div class="audioplayer-tobe auto-init skin-silver" data-source="' + _t.attr('src') + '"></div>');
    _t.remove();
  })

  jQuery(document).on('focus.dzsap', 'input', function () {
    window.dzsap_currplayer_focused = null;
  })

  registerTextWidth(jQuery);

  (0,_player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__.dzsap_keyboardSetup)();
}

function jQueryAuxBindings($) {


  function handleClick_onGlobalZoomSoundsButton(e) {
    const $t = $(this);


    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if ($t.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS)) {
      const _c = $($t.attr('data-fakeplayer')).eq(0);


      if (_c && _c.get(0) && _c.get(0).api_change_media) {
        _c.get(0).api_change_media($t, {
          'feeder_type': 'button'
          , 'call_from': 'changed ' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS
        });
      }

      return false;
    }


  }


  $(document).off('click.dzsap_metas')
  $(document).on('click.dzsap_metas', '.' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS, handleClick_onGlobalZoomSoundsButton)


}


/**
 * for .zoomsounds-wrapper-bg-center
 * @param selfClass
 */
function view_player_playMiscEffects(selfClass) {

  selfClass.$conPlayPause.addClass('playing');

  if (selfClass.cthis.parent().hasClass('zoomsounds-wrapper-bg-center')) {
    selfClass.cthis.parent().addClass('is-playing');
  }
}


function view_player_globalDetermineSyncPlayersIndex(selfClass) {

  if (selfClass._sourcePlayer === null && window.dzsap_syncList_players) {
    window.dzsap_syncList_players.forEach(($syncPlayer, index) => {
      if (selfClass.cthis.attr('data-playerid') == $syncPlayer.attr('data-playerid')) {
        window.dzsap_syncList_index = index;
      }
    })
  }
}


function player_view_addMetaLoaded(selfClass) {

  selfClass.cthis.addClass('meta-loaded');
  selfClass.cthis.removeClass('meta-fake');
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
    selfClass._sourcePlayer.removeClass('meta-fake');
  }
  if (selfClass.$totalTime) {

    selfClass.timeModel.refreshTimes();
    selfClass.$totalTime.html(formatTime(selfClass.timeModel.getVisualTotalTime()));
  }
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
  }
}


function htmlEntities(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function waitForScriptToBeAvailableThenExecute(verifyVar, callbackFn) {

  new Promise((resolve, reject) => {

    let checkInterval = 0;

    function checkIfVarExists() {
      if (verifyVar) {
        clearInterval(checkInterval);
        resolve('var exists');
      }
    }

    checkIfVarExists()
    checkInterval = setInterval(checkIfVarExists, 300);
    setTimeout(() => {
      reject('timeout');
    }, 5000);

  }).then((resolve => {
    callbackFn(resolve);
  })).catch((err) => {
  })
}


function player_reinit_findIfPcmNeedsGenerating(selfClass) {
  const o = selfClass.initOptions;

  if (selfClass.cthis.attr('data-pcm')) {
    selfClass.hasInitialPcmData = true;
  }

  if (!selfClass.hasInitialPcmData && o.skinwave_wave_mode === 'canvas' && (o.design_skin === 'skin-wave' || selfClass.cthis.attr('data-fakeplayer'))) {
    selfClass.isPcmRequiredToGenerate = true;
  }


  if (o.scrubbar_type === 'wave') {
    if (o.is_inited_from_playlist) {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (o.scrubbar_type_wave__has_reveal_animation === 'on') {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (selfClass.isPcmRequiredToGenerate) {
      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
  }
}


function playerFunctions(selfClass, functionType) {
  var o = selfClass.initOptions;

  if (functionType === 'detectIds') {


    if (o.skinwave_comments_playerid === '') {
      if (typeof (selfClass.cthis.attr('id')) !== 'undefined') {
        selfClass.the_player_id = selfClass.cthis.attr('id');
      }
    }


    if (selfClass.the_player_id == '') {

      if (selfClass.cthis.attr('data-computed-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-computed-playerid');
      }
      if (selfClass.cthis.attr('data-real-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-real-playerid');
      }
    }
    selfClass.uniqueId = selfClass.the_player_id;

    if (typeof selfClass.uniqueId === 'string') {
      selfClass.uniqueId = selfClass.uniqueId.replace('ap', '');
    }
    selfClass.identifier_pcm = selfClass.uniqueId;


    if (selfClass.uniqueId === '') {
      o.skinwave_comments_enable = 'off';
    }

  }
}

function player_delete(selfClass) {

  var _con = null;
  if (selfClass.cthis.parent().parent().hasClass('dzsap-sticktobottom')) {
    _con = selfClass.cthis.parent().parent();
  }
  if (_con) {
    if (_con.prev().hasClass("dzsap-sticktobottom-placeholder")) {
      _con.prev().remove();
    }
    _con.remove();
  }
  selfClass.cthis.remove();
  return false;
}


function sanitizeToHexColor(hexcolor) {
  if (hexcolor.indexOf('#') === -1) {
    hexcolor = '#' + hexcolor;
  }
  return hexcolor;
}

function player_identifySource(selfClass) {

  selfClass.data_source = selfClass.cthis.attr('data-source') || '';
}

function player_identifyTypes(selfClass) {


  var o = selfClass.initOptions;
  const cthis = selfClass.cthis;
  if (cthis.attr('data-type') === 'youtube') {
    o.type = 'youtube';
    selfClass.audioType = 'youtube';
  }
  if (cthis.attr('data-type') === 'soundcloud') {
    o.type = 'soundcloud';
    selfClass.audioType = 'soundcloud';

    o.skinwave_enableSpectrum = 'off';
    cthis.removeClass('skin-wave-is-spectrum');
  }
  if (cthis.attr('data-type') === 'mediafile') {
    o.type = 'audio';
    selfClass.audioType = 'audio';
  }

  if (cthis.attr('data-type') === 'shoutcast') {
    o.type = 'shoutcast';
    selfClass.audioType = 'audio';
    o.disable_timer = 'on';
    o.skinwave_enableSpectrum = 'off';

    if (!cthis.attr('data-streamtype')) {

      selfClass.audioTypeSelfHosted_streamType = 'shoutcast';
    }


    if (o.design_skin === 'skin-default') {
      o.disable_scrub = 'on';
    }

  }


  if (selfClass.audioType === 'audio' || selfClass.audioType === 'normal' || selfClass.audioType === '') {
    selfClass.audioType = 'selfHosted';
  }


  if (String(selfClass.data_source).indexOf('https://soundcloud.com/') > -1) {
    selfClass.audioType = 'soundcloud';
  }
}


function player_getPlayFromTime(selfClass) {

  selfClass.playFrom = selfClass.initOptions.playfrom;

  if ((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__.isValid)(selfClass.cthis.attr('data-playfrom'))) {
    selfClass.playFrom = selfClass.cthis.attr('data-playfrom');
  }

  if (isNaN(parseInt(selfClass.playFrom, 10)) === false) {
    selfClass.playFrom = parseInt(selfClass.playFrom, 10);
  }


  if (selfClass.playFrom === 'off' || selfClass.playFrom === '') {
    if (get_query_arg(window.location.href, 'audio_time')) {
      selfClass.playFrom = sanitizeToIntFromPointTime(get_query_arg(window.location.href, 'audio_time'));
    }
  }

  if (selfClass.timeModel.sampleTimeStart) {
    if (selfClass.playFrom < selfClass.timeModel.sampleTimeStart) {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
    if (typeof selfClass.playFrom === 'string') {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
  }
}


function sanitizeToIntFromPointTime(arg) {


  arg = String(arg).replace('%3A', ':');
  arg = String(arg).replace('#', '');

  if (arg && String(arg).indexOf(':') > -1) {

    var arr = /(\d.*):(\d.*)/g.exec(arg);


    var m = parseInt(arr[1], 10);
    var s = parseInt(arr[2], 10);


    return (m * 60) + s;
  } else {
    return Number(arg);
  }
}


/**
 * called in player init()
 * @param {DzsAudioPlayer} selfClass
 */
function player_determineStickToBottomContainer(selfClass) {

  let $conTest = selfClass.cthis.parent();


  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;

  }
  $conTest = selfClass.cthis.parent().parent();
  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;
  }
}


/**
 *
 * todo: maybe move
 * @param {DzsAudioPlayer} selfClass
 */
function player_stickToBottomContainerDetermineClasses(selfClass) {

  if (selfClass.$stickToBottomContainer) {
    if (selfClass.cthis.hasClass('theme-dark')) {
      selfClass.$stickToBottomContainer.addClass('theme-dark');
    }

    setTimeout(function () {

      selfClass.$stickToBottomContainer.addClass('inited');
    }, 500)


  }

}

function player_service_getSourceProtection(selfClass) {

  return new Promise((resolve, reject) => {

    jQuery.ajax({
      type: "POST",
      url: selfClass.data_source,
      data: {},
      success: function (response) {
        resolve(response);
      },
      error: function (err) {
        reject(err);
      }
    });
  })
}

function player_isGoingToSetupMediaNow(selfClass) {
  return selfClass.audioTypeSelfHosted_streamType !== 'icecast' && selfClass.audioType !== 'youtube';
}


function player_stopOtherPlayers(dzsap_list, selfClass) {

  let i = 0;
  for (i = 0; i < dzsap_list.length; i++) {

    if (dzsap_list[i].get(0) && dzsap_list[i].get(0).api_pause_media && (dzsap_list[i].get(0) != selfClass.cthis.get(0))) {


      if (dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') && dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') === 'on') {
        dzsap_list[i].get(0).api_destroy_for_rebuffer();
      } else {
        dzsap_list[i].get(0).api_pause_media({
          'audioapi_setlasttime': false
        });
      }
    }
  }
}


function player_syncPlayers_gotoItem(selfClass, targetIncrement) {
  if (window.dzsap_settings.syncPlayers_autoplayEnabled) {

    for (let keySyncPlayer in window.dzsap_syncList_players) {
      let $playerInSyncList = selfClass.cthis;

      if (selfClass._sourcePlayer) {
        $playerInSyncList = selfClass._sourcePlayer;
      }


      if (window.dzsap_syncList_players[keySyncPlayer].get(0) === $playerInSyncList.get(0)) {

        keySyncPlayer = parseInt(keySyncPlayer, 10);
        let targetIndex = window.dzsap_syncList_index + targetIncrement;
        if (targetIndex >= 0 && targetIndex < window.dzsap_syncList_players.length) {
          const $currentSyncPlayer_ = window.dzsap_syncList_players[targetIndex].get(0);


          if ($currentSyncPlayer_ && $currentSyncPlayer_.api_play_media) {
            setTimeout(function () {
              $currentSyncPlayer_.api_play_media({
                'called_from': 'api_sync_players_prev'
              });
            }, 200);

          }
        }
      }
    }
  }

}

function player_syncPlayers_buildList() {

  if (!window.syncPlayers_isDzsapListBuilt) {

    window.dzsap_syncList_players = [];

    window.syncPlayers_isDzsapListBuilt = true;

    jQuery('.audioplayer.is-single-player,.audioplayer-tobe.is-single-player').each(function () {
      const _t23 = jQuery(this);


      if (_t23.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_FOOTER_PLAYER)) {
        return;
      }


      if (_t23.attr('data-do-not-include-in-list') !== 'on') {
        window.dzsap_syncList_players.push(_t23);
      }
    })


    clearTimeout(window.syncPlayers_buildTimeout);

    window.syncPlayers_buildTimeout = setTimeout(function () {
      window.syncPlayers_isDzsapListBuilt = false;
    }, 500);

  }

}


function convertPluginOptionsToFinalOptions(elThis, defaultOptions, argOptions = null, searchedAttr = 'data-options', $es) {

  var finalOptions = null;
  var tempOptions = {};
  var isSetFromJson = false;

  if ($es === undefined) {
    $es = jQuery;
  }


  var $elThis = $es(elThis);

  const isArgOptionsDefinedViaJs = Boolean(argOptions && typeof argOptions === 'object' && Object.keys(argOptions).length);


  if (isArgOptionsDefinedViaJs) {
    tempOptions = argOptions;
  } else {
    if ($elThis.attr(searchedAttr)) {
      try {
        tempOptions = JSON.parse($elThis.attr(searchedAttr));
        isSetFromJson = true;
      } catch (err) {
        console.log('err - ',err);

      }
    }
    if (!isSetFromJson) {
      if (typeof $elThis.attr(searchedAttr) != 'undefined' && $elThis.attr('data-options') != '') {
        let aux = $elThis.attr(searchedAttr);
        aux = 'var aux_opts = ' + aux;
        eval(aux);
        tempOptions = Object.assign({}, argOptions);
      }
    }
  }
  finalOptions = Object.assign(defaultOptions, tempOptions);

  return finalOptions;
}

function generateFakeArrayForPcm() {


  var maxlen = 256;

  var arr = [];

  for (let it1 = 0; it1 < maxlen; it1++) {
    arr[it1] = Math.random() * 100;

  }

  return arr;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_svgs.js":
/*!**************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_svgs.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pausebtn_svg": () => (/* binding */ pausebtn_svg),
/* harmony export */   "playbtn_svg": () => (/* binding */ playbtn_svg),
/* harmony export */   "svg_embed_btn": () => (/* binding */ svg_embed_btn),
/* harmony export */   "svg_menu_state": () => (/* binding */ svg_menu_state),
/* harmony export */   "svg_next_btn": () => (/* binding */ svg_next_btn),
/* harmony export */   "svg_prev_btn": () => (/* binding */ svg_prev_btn),
/* harmony export */   "svg_share_icon": () => (/* binding */ svg_share_icon)
/* harmony export */ });



const playbtn_svg = '<svg class="svg-icon" version="1.2" baseProfile="tiny" id="Layer_1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="25px" height="30px" viewBox="0 0 25 30" xml:space="preserve"> <path d="M24.156,13.195L2.406,0.25C2.141,0.094,1.867,0,1.555,0C0.703,0,0.008,0.703,0.008,1.562H0v26.875h0.008 C0.008,29.297,0.703,30,1.555,30c0.32,0,0.586-0.109,0.875-0.266l21.727-12.93C24.672,16.375,25,15.727,25,15 S24.672,13.633,24.156,13.195z"/> </svg>';
const pausebtn_svg = '<svg class="svg-icon" version="1.1" id="Layer_3" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="12px" height="13px" viewBox="0 0 13.415 16.333" enable-background="new 0 0 13.415 16.333" xml:space="preserve"> <path fill="#D2D6DB" d="M4.868,14.59c0,0.549-0.591,0.997-1.322,0.997H2.2c-0.731,0-1.322-0.448-1.322-0.997V1.618 c0-0.55,0.592-0.997,1.322-0.997h1.346c0.731,0,1.322,0.447,1.322,0.997V14.59z"/> <path fill="#D2D6DB" d="M12.118,14.59c0,0.549-0.593,0.997-1.324,0.997H9.448c-0.729,0-1.322-0.448-1.322-0.997V1.619 c0-0.55,0.593-0.997,1.322-0.997h1.346c0.731,0,1.324,0.447,1.324,0.997V14.59z"/> </svg>';





const svg_share_icon = '<svg class="svg-icon" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" width="512px" height="512px" viewBox="0 0 511.626 511.627" style="enable-background:new 0 0 511.626 511.627;" xml:space="preserve"> <g> <path d="M506.206,179.012L360.025,32.834c-3.617-3.617-7.898-5.426-12.847-5.426s-9.233,1.809-12.847,5.426 c-3.617,3.619-5.428,7.902-5.428,12.85v73.089h-63.953c-135.716,0-218.984,38.354-249.823,115.06C5.042,259.335,0,291.03,0,328.907 c0,31.594,12.087,74.514,36.259,128.762c0.57,1.335,1.566,3.614,2.996,6.849c1.429,3.233,2.712,6.088,3.854,8.565 c1.146,2.471,2.384,4.565,3.715,6.276c2.282,3.237,4.948,4.859,7.994,4.859c2.855,0,5.092-0.951,6.711-2.854 c1.615-1.902,2.424-4.284,2.424-7.132c0-1.718-0.238-4.236-0.715-7.569c-0.476-3.333-0.715-5.564-0.715-6.708 c-0.953-12.938-1.429-24.653-1.429-35.114c0-19.223,1.668-36.449,4.996-51.675c3.333-15.229,7.948-28.407,13.85-39.543 c5.901-11.14,13.512-20.745,22.841-28.835c9.325-8.09,19.364-14.702,30.118-19.842c10.756-5.141,23.413-9.186,37.974-12.135 c14.56-2.95,29.215-4.997,43.968-6.14s31.455-1.711,50.109-1.711h63.953v73.091c0,4.948,1.807,9.232,5.421,12.847 c3.62,3.613,7.901,5.424,12.847,5.424c4.948,0,9.232-1.811,12.854-5.424l146.178-146.183c3.617-3.617,5.424-7.898,5.424-12.847 C511.626,186.92,509.82,182.636,506.206,179.012z" fill="#696969"/> </g></svg> ';





const svg_prev_btn = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="14px" height="14px" viewBox="0 0 12.5 12.817" enable-background="new 0 0 12.5 12.817" xml:space="preserve"> <g> <g> <g> <path fill="#D2D6DB" d="M2.581,7.375c-0.744-0.462-1.413-0.94-1.486-1.061C1.021,6.194,1.867,5.586,2.632,5.158l2.35-1.313 c0.765-0.427,1.505-0.782,1.646-0.789s0.257,1.03,0.257,1.905V7.87c0,0.876-0.051,1.692-0.112,1.817 C6.711,9.81,5.776,9.361,5.032,8.898L2.581,7.375z"/> </g> </g> </g> <g> <g> <g> <path fill="#D2D6DB" d="M6.307,7.57C5.413,7.014,4.61,6.441,4.521,6.295C4.432,6.15,5.447,5.42,6.366,4.906l2.82-1.577 c0.919-0.513,1.809-0.939,1.979-0.947s0.309,1.236,0.309,2.288v3.493c0,1.053-0.061,2.033-0.135,2.182S10.144,9.955,9.25,9.4 L6.307,7.57z"/> </g> </g> </g> </svg>';
const svg_next_btn = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="14px" height="14px" viewBox="0 0 12.5 12.817" enable-background="new 0 0 12.5 12.817" xml:space="preserve"> <g> <g> <g> <path fill="#D2D6DB" d="M9.874,5.443c0.744,0.462,1.414,0.939,1.486,1.06c0.074,0.121-0.771,0.729-1.535,1.156L7.482,8.967 C6.719,9.394,5.978,9.75,5.837,9.756C5.696,9.761,5.581,8.726,5.581,7.851V4.952c0-0.875,0.05-1.693,0.112-1.816 c0.062-0.124,0.995,0.326,1.739,0.788L9.874,5.443z"/> </g> </g> </g> <g> <g> <g> <path fill="#D2D6DB" d="M6.155,5.248c0.893,0.556,1.696,1.129,1.786,1.274c0.088,0.145-0.928,0.875-1.847,1.389l-2.811,1.57 c-0.918,0.514-1.808,0.939-1.978,0.947c-0.169,0.008-0.308-1.234-0.308-2.287V4.66c0-1.052,0.061-2.034,0.135-2.182 s1.195,0.391,2.089,0.947L6.155,5.248z"/> </g> </g> </g> </svg>';





const svg_menu_state = '<svg class="svg-icon" version="1.1" id="Layer_2" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="13.25px" height="13.915px" viewBox="0 0 13.25 13.915" enable-background="new 0 0 13.25 13.915" xml:space="preserve"> <path d="M1.327,4.346c-0.058,0-0.104-0.052-0.104-0.115V2.222c0-0.063,0.046-0.115,0.104-0.115H11.58 c0.059,0,0.105,0.052,0.105,0.115v2.009c0,0.063-0.046,0.115-0.105,0.115H1.327z"/> <path d="M1.351,8.177c-0.058,0-0.104-0.051-0.104-0.115V6.054c0-0.064,0.046-0.115,0.104-0.115h10.252 c0.058,0,0.105,0.051,0.105,0.115v2.009c0,0.063-0.047,0.115-0.105,0.115H1.351z"/> <path d="M1.351,12.182c-0.058,0-0.104-0.05-0.104-0.115v-2.009c0-0.064,0.046-0.115,0.104-0.115h10.252 c0.058,0,0.105,0.051,0.105,0.115v2.009c0,0.064-0.047,0.115-0.105,0.115H1.351z"/> </svg>';
const svg_embed_btn = '<svg class="svg-icon" version="1.2" baseProfile="tiny" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="15px" height="15px" viewBox="0 0 15 15" xml:space="preserve"> <g id="Layer_1"> <polygon fill="#E6E7E8" points="1.221,7.067 0.494,5.422 4.963,1.12 5.69,2.767 "/> <polygon fill="#E6E7E8" points="0.5,5.358 1.657,4.263 3.944,10.578 2.787,11.676 "/> <polygon fill="#E6E7E8" points="13.588,9.597 14.887,8.34 12.268,2.672 10.969,3.93 "/> <polygon fill="#E6E7E8" points="14.903,8.278 14.22,6.829 9.714,11.837 10.397,13.287 "/> </g> <g id="Layer_2"> <rect x="6.416" y="1.713" transform="matrix(0.9663 0.2575 -0.2575 0.9663 2.1699 -1.6329)" fill="#E6E7E8" width="1.805" height="11.509"/> </g> </svg>';






/***/ }),

/***/ "../source/audioplayer/jsinc/components/_nav.js":
/*!******************************************************!*\
  !*** ../source/audioplayer/jsinc/components/_nav.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZoomSoundsNav": () => (/* binding */ ZoomSoundsNav)
/* harmony export */ });
/* harmony import */ var _dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");





const ZoomSoundsNav = class {

  constructor(parentGallery) {
    this.parentGallery = parentGallery;

    this.structZoomsoundsNav = '';
    this._navMain = null;
    this._navClipper = null;
    this.cgallery = null;

    this.size_navMainClipSize = null;
    this.size_navMainTotalSize = null;
    this.finish_viy = 0;

    this.init();


  }

  init() {

    var selfGallery = this.parentGallery;

    this.structZoomsoundsNav = '<div class="nav-main zoomsounds-nav ' + selfGallery.initOptions.design_skin + ' navigation-method-' + selfGallery.initOptions.navigation_method + '"><div class="nav-clipper"></div></div>';


    // -- let us do some sanitize
    if (this.parentGallery.initOptions.navigation_method === 'full') {
      this.parentGallery.initOptions.design_menu_height = 'auto';
    }

  }

  init_ready() {



    const self = this;
    var selfGallery = this.parentGallery;

    if (selfGallery.initOptions.disable_menu_navigation == 'on') {
      this._navMain.hide();
    }

    if(!isNaN(Number(selfGallery.initOptions.design_menu_height))){
      this._navMain.css({
        'height': (0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_1__.sanitizeToCssPx)(selfGallery.initOptions.design_menu_height)
      })
    }

    if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() || (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)()) {
      this._navMain.css({
        'overflow': 'auto'
      })
    }


    if (selfGallery.initOptions.design_menu_state == 'closed') {
      this._navMain.css({
        'height': 0
      })
      this.cgallery.removeClass('menu-opened');
      this.cgallery.addClass('menu-closed');
    } else {
      this.cgallery.addClass('menu-opened');
      this.cgallery.removeClass('menu-closed');
    }


    this._navClipper.on('click', '.menu-item', click_menuitem);


    function click_menuitem(e) {
      var _t = jQuery(this);

      if (e.type == 'click') {
        if (_t.hasClass('menu-item')) {
          var ind = _t.parent().children().index(_t);

          selfGallery.goto_item(ind);
        }
      }

    }


  }


  get_structZoomsoundsNav() {
    return this.structZoomsoundsNav;
  }

  set_elements(_navMain, _navClipper, cgallery) {
    this._navMain = _navMain;
    this._navClipper = _navClipper;
    this.cgallery = cgallery;
  }

  calculateDims() {

    this.size_navMainClipSize = this._navMain.height();
    this.size_navMainTotalSize = this._navClipper.outerHeight();

    const self = this;

    if (this.parentGallery.initOptions.navigation_method === 'mouseover') {



      if (this.size_navMainTotalSize > this.size_navMainClipSize && this.size_navMainClipSize > 0) {
        this._navMain.off('mousemove', navMain_mousemove);
        this._navMain.on('mousemove', navMain_mousemove);
      } else {
        this._navMain.off('mousemove', navMain_mousemove);
      }
    }

    function navMain_mousemove(e) {

      var aux_error = 20; //==erroring for the menu scroll
      var $ = jQuery;
      var _t = $(this);
      var mx = e.pageX - _t.offset().left;
      var my = e.pageY - _t.offset().top;


      if (self.size_navMainTotalSize <= self.size_navMainClipSize) {
        return;
      }

      self.size_navMainClipSize = self._navMain.outerHeight();



      var vix = 0;
      var viy = 0;

      viy = (my / self.size_navMainClipSize) * -(self.size_navMainTotalSize - self.size_navMainClipSize + 10 + aux_error * 2) + aux_error;

      if (viy > 0) {
        viy = 0;
      }
      if (viy < -(self.size_navMainTotalSize - self.size_navMainClipSize + 10)) {
        viy = -(self.size_navMainTotalSize - self.size_navMainClipSize + 10);
      }

      self.finish_viy = viy;




      if ((0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_ios)() == false && (0,_dzsap_helpers__WEBPACK_IMPORTED_MODULE_0__.is_android)() == false) {
        if (self.parentGallery.initOptions.enable_easing != 'on') {

          self._navClipper.css({
            'transform': 'translateY(' + self.finish_viy + 'px)'
          });
        }
      }


    }

  }



  toggle_menu_state() {

    const self = this;

    if (this._navMain.height() == 0) {
      this._navMain.css({
        'height': this.parentGallery.initOptions.design_menu_height
      })


      this.cgallery.removeClass('menu-closed');
      this.cgallery.addClass('menu-opened');
    } else {

      this._navMain.css({
        'height': 0
      })
      this.cgallery.removeClass('menu-opened');
      this.cgallery.addClass('menu-closed');
    }
    setTimeout(function () {
      self.parentGallery.handleResize();
    }, 400); // -- animation delay

  }

  parseTrackData(track_data) {
    var foundnr = 0;
    var self = this;
    this._navMain.find('.menu-item-views').each(function () {
      var _t2 = $(this);

      var aux_html = _t2.html();

      var reg_findid = /{{views_(.*?)}}/g;


      var aux = reg_findid.exec(aux_html);



      var id = '';
      if (aux && aux[1]) {

        id = aux[1];

        for (var i in track_data) {



          if (id == track_data[i].label || id == 'ap' + track_data[i].label) {
            aux_html = aux_html.replace(aux[0], track_data[i].views);
            foundnr++;
            break;
          }
        }


        _t2.html(aux_html);

      }


    })

    if (foundnr < track_data.length) {

      self._navMain.find('.menu-item-views').each(function () {

        var _t2 = jQuery(this);

        var aux_html = _t2.html();
        var reg_findid = /{{views_(.*?)}}/g;

        var aux = reg_findid.exec(aux_html);

        if (aux && aux[0]) {

          aux_html = aux_html.replace(aux[0], 0);
          _t2.html(aux_html);
        }

      })
    }


  }
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_keyboard.js":
/*!**************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_keyboard.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dzsap_generate_keyboard_controls": () => (/* binding */ dzsap_generate_keyboard_controls),
/* harmony export */   "dzsap_keyboardSetup": () => (/* binding */ dzsap_keyboardSetup),
/* harmony export */   "handle_keypresses": () => (/* binding */ handle_keypresses)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const dzsap_generate_keyboard_controls = function () {
  let keyboard_controls = {
    'play_trigger_step_back': 'off'
    , 'step_back_amount': '5'
    , 'step_back': '37'
    , 'step_forward': '39'
    , 'sync_players_goto_next': ''
    , 'sync_players_goto_prev': ''
    , 'pause_play': '32'
    , 'show_tooltips': 'off'
  }


  const $keyboardControlsInfo = jQuery(_configs_constants__WEBPACK_IMPORTED_MODULE_0__.DZSAP_SCRIPT_SELECTOR_KEYBOARD);
  if ($keyboardControlsInfo.length) {
    window.dzsap_keyboard_controls = JSON.parse($keyboardControlsInfo.html());
  }

  if (window.dzsap_keyboard_controls) {
    keyboard_controls = jQuery.extend(keyboard_controls, window.dzsap_keyboard_controls);
  }

  keyboard_controls.step_back_amount = Number(keyboard_controls.step_back_amount);


  return keyboard_controls;
};


function handle_keypresses(e) {

  if (window.dzsap_isTextFieldFocused) {
    return;
  }


  function isKeyPressed(checkKeyCode) {
    let isKeyPressed = false;
    if (checkKeyCode.indexOf('ctrl+') > -1) {
      if (e.ctrlKey) {
        checkKeyCode = checkKeyCode.replace('ctrl+', '');
        if (e.keyCode === Number(checkKeyCode)) {
          isKeyPressed = true;
        }
      }
    } else {
      if (e.keyCode === Number(checkKeyCode)) {
        isKeyPressed = true;
      }
    }
    return isKeyPressed;
  }

  var $ = jQuery;

  const keyboard_controls = $.extend({}, dzsap_generate_keyboard_controls());


  if (dzsap_currplayer_focused && dzsap_currplayer_focused.api_pause_media) {

    if (isKeyPressed(keyboard_controls.pause_play)) {
      if (!$(dzsap_currplayer_focused).hasClass('comments-writer-active')) {
        if ($(dzsap_currplayer_focused).hasClass('is-playing')) {
          dzsap_currplayer_focused.api_pause_media();
        } else {
          dzsap_currplayer_focused.api_play_media();
        }

        if (window.dzsap_mouseover) {
          e.preventDefault();
          return false;
        }
      }
    }

    if (isKeyPressed(keyboard_controls.step_back)) {
      dzsap_currplayer_focused.api_step_back(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.step_forward)) {
      dzsap_currplayer_focused.api_step_forward(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.sync_players_goto_next)) {
      dzsap_currplayer_focused.api_sync_players_goto_next();
    }


    if (isKeyPressed(keyboard_controls.sync_players_goto_prev)) {
      dzsap_currplayer_focused.api_sync_players_goto_prev();
    }


  }
}


/**
 * called in singleton
 */
const dzsap_keyboardSetup = () => {

  let $ = jQuery;

  window.dzsap_isTextFieldFocused = false;

  $(document).off('keydown.dzsapkeyup');
  $(document).on('keydown.dzsapkeyup', handle_keypresses);


  $(document).on('focus blur', 'textarea,input', function (e) {

    if (e.type == 'focusin' || e.type == 'focus') {

      window.dzsap_isTextFieldFocused = true;
    }
    if (e.type == 'focusout' || e.type == 'blur') {

      window.dzsap_isTextFieldFocused = false;
    }
  });


  $(document).on('keydown blur', '.zoomsounds-search-field', function (e) {
    const _t = $(e.currentTarget);

    setTimeout(function () {

      if (_t) {
        let $audioGallery = $('.audiogallery').eq(0);
        if (_t.attr('data-target')) {
          $audioGallery = $(_t.attr('data-target'));
        }
        if ($audioGallery.get(0) && $audioGallery.get(0).api_filter) {
          $audioGallery.get(0).api_filter('title', _t.val());
        }
      }
    }, 100);

  });
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*********************************************************!*\
  !*** ../source/audioplayer/audioplaylist.sourcepack.js ***!
  \*********************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./jsinc/_dzsap_svgs */ "../source/audioplayer/jsinc/_dzsap_svgs.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./configs/_constants */ "../source/audioplayer/configs/_constants.js");
/* harmony import */ var _configs_settingsPlaylist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./configs/_settingsPlaylist */ "../source/audioplayer/configs/_settingsPlaylist.js");
/* harmony import */ var _jsinc_components_nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./jsinc/components/_nav */ "../source/audioplayer/jsinc/components/_nav.js");
/* harmony import */ var _jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./jsinc/_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
function ownKeys(object,enumerableOnly){var keys=Object.keys(object);if(Object.getOwnPropertySymbols){var symbols=Object.getOwnPropertySymbols(object);enumerableOnly&&(symbols=symbols.filter(function(sym){return Object.getOwnPropertyDescriptor(object,sym).enumerable})),keys.push.apply(keys,symbols)}return keys}function _objectSpread(target){for(var i=1;i<arguments.length;i++){var source=null!=arguments[i]?arguments[i]:{};i%2?ownKeys(Object(source),!0).forEach(function(key){_defineProperty(target,key,source[key])}):Object.getOwnPropertyDescriptors?Object.defineProperties(target,Object.getOwnPropertyDescriptors(source)):ownKeys(Object(source)).forEach(function(key){Object.defineProperty(target,key,Object.getOwnPropertyDescriptor(source,key))})}return target}function _defineProperty(obj,key,value){key=_toPropertyKey(key);if(key in obj){Object.defineProperty(obj,key,{value:value,enumerable:true,configurable:true,writable:true})}else{obj[key]=value}return obj}function _typeof(obj){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(obj){return typeof obj}:function(obj){return obj&&"function"==typeof Symbol&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj},_typeof(obj)}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function")}}function _defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,_toPropertyKey(descriptor.key),descriptor)}}function _createClass(Constructor,protoProps,staticProps){if(protoProps)_defineProperties(Constructor.prototype,protoProps);if(staticProps)_defineProperties(Constructor,staticProps);Object.defineProperty(Constructor,"prototype",{writable:false});return Constructor}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return _typeof(key)==="symbol"?key:String(key)}function _toPrimitive(input,hint){if(_typeof(input)!=="object"||input===null)return input;var prim=input[Symbol.toPrimitive];if(prim!==undefined){var res=prim.call(input,hint||"default");if(_typeof(res)!=="object")return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return(hint==="string"?String:Number)(input)}var DzsApPlaylist=/*#__PURE__*/function(){function DzsApPlaylist(argThis,argOptions,$){_classCallCheck(this,DzsApPlaylist);this.argThis=argThis;this.argOptions=argOptions;this.$=$;this.navClass=null;this.init()}_createClass(DzsApPlaylist,[{key:"init",value:function init(){var $=this.$;var selfGallery=this;var o=selfGallery.argOptions;var cgallery=$(selfGallery.argThis);var cid="ag1";var currNr=-1// -- the current player that is playing
,lastCurrNr=0,nrChildren=0,tempNr=0;var i=0;var dzsap_currplayer_focused=null;var _sliderMain,_sliderClipper,_navMain,_navClipper;var busy=false,first=true,destroyed=true,skin_redlight_give_controls_right_to_all_players=false// -- if the mode is mode-showall and the skin of the player is redlights, then make all players with controls right
;var trying_to_get_track_data=false;var arr_menuitems=[];var track_data=[];// -- the whole track data views / likes etc.
var str_alertBeforeRate="You need to comment or rate before downloading.";var duration_viy=20;var target_viy=0;var begin_viy=0;var change_viy=0;selfGallery.goto_item=goto_item;selfGallery.handleResize=handleResize;selfGallery.initOptions=o;if(window.dzsap_settings&&typeof window.dzsap_settings.str_alertBeforeRate!="undefined"){str_alertBeforeRate=window.dzsap_settings.str_alertBeforeRate}cgallery.get(0).currNr_2=-1;// -- we use this as backup currNR for mode-showall ( hack )
init();function init(){// -- init gallery here
if(o.settings_ap==="default"){if(cgallery.attr("data-player-options")){o.settings_ap=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.convertPluginOptionsToFinalOptions)(cgallery.get(0),{},null,"data-player-options")}else{var _firstPlayer=cgallery.find(".audioplayer, .audioplayer-tobe").eq(0);if(_firstPlayer){o.settings_ap=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.convertPluginOptionsToFinalOptions)(_firstPlayer.get(0),{},null)}}}else{if(typeof o.settings_ap=="string"&&window.dzsap_apconfigs){if(_typeof(window.dzsap_apconfigs[o.settings_ap])==="object"){o.settings_ap=_objectSpread({},window.dzsap_apconfigs[o.settings_ap])}}}if(o.settings_ap==="default"||typeof o.settings_ap==="string"){o.settings_ap={}}if(o.design_menu_width==="default"){o.design_menu_width="100%"}if(o.design_menu_height==="default"){o.design_menu_height="200"}if(cgallery.hasClass("skin-wave")){o.design_skin="skin-wave"}if(cgallery.hasClass("skin-default")){o.design_skin="skin-default"}if(cgallery.hasClass("skin-aura")){o.design_skin="skin-aura"}cgallery.addClass(o.settings_mode);cgallery.append("<div class=\"slider-main\"><div class=\"slider-clipper\"></div></div>");cgallery.addClass("menu-position-"+o.design_menu_position);_sliderMain=cgallery.find(".slider-main").eq(0);var lengthAudioPlayersInPlaylist=cgallery.find(".items").children(".audioplayer-tobe").length;// --- if there is a single audio player in the gallery - theres no point of a menu
o.settings_ap.disable_player_navigation=o.disable_player_navigation;if(lengthAudioPlayersInPlaylist===0||lengthAudioPlayersInPlaylist===1){o.design_menu_position="none";o.settings_ap.disable_player_navigation="on"}selfGallery.navClass=new _jsinc_components_nav__WEBPACK_IMPORTED_MODULE_3__.ZoomSoundsNav(selfGallery);if(o.design_menu_position==="top"){_sliderMain.before(selfGallery.navClass.get_structZoomsoundsNav())}if(o.design_menu_position==="bottom"){_sliderMain.after(selfGallery.navClass.get_structZoomsoundsNav())}if(o.settings_php_handler){}else{if(o.settings_ap.settings_php_handler){o.settings_php_handler=o.settings_ap.settings_php_handler}}if(_typeof(cgallery.attr("id"))){cid=cgallery.attr("id")}else{var ind=0;while($("ag"+ind).length===0){ind++}cid="ag"+ind;cgallery.attr("id",cid)}_sliderClipper=cgallery.find(".slider-clipper").eq(0);_navMain=cgallery.find(".nav-main").eq(0);_navClipper=cgallery.find(".nav-clipper").eq(0);if(cgallery.children(".extra-html").length){cgallery.append(cgallery.children(".extra-html"))}if(o.settings_mode==="mode-showall"){_sliderClipper.addClass("layout-"+o.mode_showall_layout)}selfGallery.navClass.set_elements(_navMain,_navClipper,cgallery);reinit();selfGallery.navClass.init_ready();parse_track_data();if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.can_history_api)()===false){o.settings_enable_linking="off"}$(window).on("resize",handleResize);handleResize();setTimeout(handleResize,1000);cgallery.get(0).api_skin_redlights_give_controls_right_to_all=function(){skin_redlight_give_controls_right_to_all_players=true};if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.get_query_arg)(window.location.href,"audiogallery_startitem_"+cid)){tempNr=Number((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.get_query_arg)(window.location.href,"audiogallery_startitem_"+cid));lastCurrNr=tempNr;if(Number((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.get_query_arg)(window.location.href,"audiogallery_startitem_"+cid))&&Number((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.get_query_arg)(window.location.href,"audiogallery_startitem_"+cid))>0){// -- caution .. coming from share link will trigger autoplay!!!
if(o.force_autoplay_when_coming_from_share_link=="on"){o.autoplay="on"}}}if(o.settings_mode=="mode-normal"){goto_item(tempNr,{"called_from":"init"})}if(o.settings_mode==="mode-showall"){// -- mode-showall
_sliderClipper.children().each(function(){var _t=$(this);var ind=_t.parent().children(".audioplayer,.audioplayer-tobe").index(_t);if(_t.hasClass("audioplayer-tobe")){var player_args=Object.assign({},o.settings_ap);player_args.parentgallery=cgallery;player_args.call_from="mode show-all";player_args.action_audio_play=mode_showall_listen_for_play;// -- showall
_t.audioplayer(player_args);ind=String(ind+1);if(ind.length<2){ind="0"+ind}if(o.mode_showall_layout==="one-per-row"&&o.settings_mode_showall_show_number!=="off"){_t.before("<div class=\"number-wrapper\"><span class=\"the-number\">"+ind+"</span></div>");_t.after("<div class=\"clear for-number-wrapper\"></div>")}}});if($.fn.isotope&&o.mode_showall_layout!=="one-per-row"){// -- we have isotope
_sliderClipper.find(".audioplayer,.audioplayer-tobe").addClass("isotope-item");setTimeout(function(){_sliderClipper.prepend("<div class=\"grid-sizer\"></div>");_sliderClipper.isotope({// options
itemSelector:".isotope-item",layoutMode:"fitRows",percentPosition:true,masonry:{columnWidth:".grid-sizer"}});_sliderClipper.addClass("isotoped");setTimeout(function(){_sliderClipper.isotope("layout")},900)},_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.PLAYLIST_TRANSITION_DURATION);_sliderClipper.append("<div class=\"clear\"></div>")}if(skin_redlight_give_controls_right_to_all_players){_sliderClipper.children(".audioplayer").each(function(){var _t=$(this);if(_t.find(".ap-controls-right").eq(0).prev().hasClass("controls-right")===false){_t.find(".ap-controls-right").eq(0).before("<div class=\"controls-right\"> </div>")}})}}cgallery.find(".download-after-rate").on("click",click_downloadAfterRate);cgallery.get(0).api_regenerate_sync_players_with_this_playlist=regenerate_sync_players_with_this_playlist;cgallery.get(0).api_goto_next=goto_next;cgallery.get(0).api_goto_prev=goto_prev;cgallery.get(0).api_goto_item=goto_item;cgallery.get(0).api_gallery_handle_end=handlePlaylistSongEnd;cgallery.get(0).api_toggle_menu_state=toggle_menu_state;cgallery.get(0).api_handleResize=handleResize;cgallery.get(0).api_player_commentSubmitted=player_commentSubmitted;cgallery.get(0).api_player_rateSubmitted=player_rateSubmitted;cgallery.get(0).api_reinit=reinit;cgallery.get(0).api_play_curr_media=play_curr_media;cgallery.get(0).api_get_nr_children=get_nr_children;cgallery.get(0).api_init_player_from_gallery=init_player_from_gallery;cgallery.get(0).api_filter=filterPlayersInPlaylist;cgallery.get(0).api_destroy=destroy_gallery;cgallery.get(0).SelfPlaylist=selfGallery;setInterval(calculate_on_interval,1000);setTimeout(init_loaded,700);if(o.enable_easing=="on"){handle_frame()}cgallery.addClass("dzsag-inited");cgallery.addClass("transition-"+o.playlistTransition);cgallery.addClass("playlist-transition-"+o.playlistTransition)}function destroy_gallery(){if(destroyed){return false}cgallery.remove();cgallery=null;destroyed=true}function filterPlayersInPlaylist(filterBy,searchedString){if(!filterBy){filterBy="title"}/**
       *
       * @param $audioPlayer_
       * @returns {boolean} true if found
       */var filterForIsotope=function filterForIsotope($audioPlayer_){var $audioPlayer=$($audioPlayer_);var referenceVal="";if(filterBy==="title"){referenceVal=$audioPlayer.find(".the-name").text()}if(searchedString===""){return true}return referenceVal.toLowerCase().indexOf(searchedString.toLowerCase())>-1};_sliderClipper.children().each(function(){var isAccordingToSearch=filterForIsotope(this);if(isAccordingToSearch){$(this).addClass("is-according-to-search")}else{$(this).removeClass("is-according-to-search")}if(_sliderClipper.hasClass("isotoped")){_sliderClipper.isotope({filter:".is-according-to-search"})}else{if(isAccordingToSearch){$(this).fadeIn("fast")}else{$(this).fadeOut("fast")}}})}function regenerate_sync_players_with_this_playlist(){// -- in case we play from playlist we overwrite whole footer playlist
window.dzsap_syncList_players=[];_sliderClipper.children(".audioplayer,.audioplayer-tobe").each(function(){var _t=$(this);_t.addClass("feeded-whole-playlist");if(_t.attr("data-do-not-include-in-list")!="on"){window.dzsap_syncList_players.push(_t)}})}function init_parse_track_data(){if(trying_to_get_track_data){return false}trying_to_get_track_data=true;var data={action:"dzsap_get_views_all",postdata:"1"};if(o.settings_php_handler){$.ajax({type:"POST",url:o.settings_php_handler,data:data,success:function success(response){cgallery.attr("data-track-data",response);parse_track_data()},error:function error(arg){}})}}function parse_track_data(){if(cgallery.attr("data-track-data")){try{track_data=JSON.parse(cgallery.attr("data-track-data"))}catch(err){console.log(err)}if(track_data&&track_data.length){selfGallery.navClass.parseTrackData(track_data)}}}function get_nr_children(){return nrChildren}function find_player_id(arg){if(arg.attr("data-player-id")){return arg.attr("data-player-id")}else{if(arg.attr("id")){return arg.attr("id")}else{if(arg.attr("data-source")){return (0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.dzs_clean_string)(arg.attr("data-source"))}}}}function generateMenuItemObjects(notInitedPlayers){var arr_menuitems=[];notInitedPlayers.each(function(){var _c=$(this);var menuDescriptionHtml="";if(_c.find(".menu-description").length&&_c.find(".menu-description").eq(0).html()){menuDescriptionHtml=_c.find(".menu-description").html()}else{menuDescriptionHtml="";if(_c.find(".feed-artist-name").length||_c.find(".feed-song-name").length){menuDescriptionHtml="";if(_c.attr("data-thumb")){menuDescriptionHtml+="<div class=\"menu-item-thumb-con\"><div class=\"menu-item-thumb\" style=\"background-image: url(".concat(_c.attr("data-thumb"),")\"></div></div>")}menuDescriptionHtml+="<div class=\"menu-artist-info\"><span class=\"the-artist\">".concat(_c.find(".feed-artist-name").html(),"</span><span class=\"the-name\">").concat(_c.find(".feed-song-name").html(),"</span></div>")}}var menuItemObject={"menu_description":menuDescriptionHtml,"player_id":find_player_id(_c)};arr_menuitems.push(menuItemObject)});return arr_menuitems}function reinit(){var notInitedPlayers=cgallery.find(".items").eq(0).children(".audioplayer-tobe");arr_menuitems=[];arr_menuitems=generateMenuItemObjects(notInitedPlayers);_sliderClipper.append(notInitedPlayers);for(i=0;i<arr_menuitems.length;i++){var extra_class="";if(arr_menuitems[i].menu_description&&arr_menuitems[i].menu_description.indexOf("<div class=\"menu-item-thumb-con\"><div class=\"menu-item-thumb\" style=\"")==-1){extra_class+=" no-thumb"}var aux="<div class=\"menu-item"+extra_class+"\"  data-menu-index=\""+i+"\" data-gallery-id=\""+cid+"\" data-playerid=\""+arr_menuitems[i].player_id+"\">";if(cgallery.hasClass("skin-aura")){aux+="<div class=\"menu-item-number\">"+ ++nrChildren+"</div>"}aux+=arr_menuitems[i].menu_description;if(cgallery.hasClass("skin-aura")&&String(arr_menuitems[i].menu_description).indexOf("menu-item-views")==1){if(track_data&&track_data.length>0){aux+="<div class=\"menu-item-views\"></div>"}else{init_parse_track_data();aux+="<div class=\"menu-item-views\">"+_jsinc_dzsap_svgs__WEBPACK_IMPORTED_MODULE_0__.playbtn_svg+" "+"<span class=\"the-count\">{{views_"+arr_menuitems[i].player_id+"}}"+"</span></div>"}}aux+="</div>";_navClipper.append(aux);if(cgallery.hasClass("skin-aura")){if(arr_menuitems[i]&&arr_menuitems[i].menu_description&&arr_menuitems[i].menu_description.indexOf("float-right")>-1){_navClipper.children().last().addClass("has-extra-info")}}}}function init_loaded(){// -- gallery
cgallery.addClass("dzsag-loaded")}function click_downloadAfterRate(){var _t=$(this);if(!_t.hasClass("active")){alert(str_alertBeforeRate);return false}}function play_curr_media(){if(typeof _sliderClipper.children().eq(currNr).get(0)!="undefined"){if(typeof _sliderClipper.children().eq(currNr).get(0).api_play_media!="undefined"){_sliderClipper.children().eq(currNr).get(0).api_play_media({"call_from":"play_curr_media_gallery"})}}}function mode_showall_listen_for_play(arg){if(o.settings_mode=="mode-showall"){var ind=_sliderClipper.children(".audioplayer,.audioplayer-tobe").index(arg);currNr=ind;cgallery.get(0).currNr_2=ind}}function handle_frame(){// -- cgallery
if(isNaN(target_viy)){target_viy=0}if(duration_viy===0){requestAnimationFrame(handle_frame);return false}begin_viy=target_viy;change_viy=selfGallery.navClass.finish_viy-begin_viy;target_viy=Number(Math.easeIn(1,begin_viy,change_viy,duration_viy).toFixed(4));if((0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.is_ios)()==false&&(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.is_android)()==false){_navClipper.css({"transform":"translateY("+target_viy+"px)"})}requestAnimationFrame(handle_frame)}function toggle_menu_state(){selfGallery.navClass.toggle_menu_state()}function handlePlaylistSongEnd(){console.log("handlePlaylistSongEnd() ",o);if(o.autoplayNext=="on"){goto_next()}}function player_commentSubmitted(){_navClipper.children(".menu-item").eq(currNr).find(".download-after-rate").addClass("active")}function player_rateSubmitted(){_navClipper.children(".menu-item").eq(currNr).find(".download-after-rate").addClass("active")}function calculateDims(){if(o.settings_mode!="mode-showall"&&!_sliderClipper.hasClass("isotoped")&&o.mode_normal_video_mode!="one"){// -- mode normal, not isotope
if(_sliderClipper.children().eq(currNr).hasClass("zoomsounds-wrapper-bg-bellow")==false){_sliderClipper.css("height",_sliderClipper.children().eq(currNr).outerHeight())}}if(!_sliderClipper.hasClass("isotoped")){// -- not isotope
setTimeout(function(){_sliderClipper.css("height","auto")},_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.PLAYLIST_TRANSITION_DURATION)}selfGallery.navClass.calculateDims();if(o.embedded=="on"){if(window.frameElement){window.frameElement.height=cgallery.height()}}}function calculate_on_interval(){// -- @called on setInterval
selfGallery.navClass.calculateDims();// -- this is for player ? todo ...
// if (0 && o.gallery_gapless_play == 'on') {
//
//   if (o.parentgallery && cthis.hasClass('active-from-gallery')) {
//     var _c = o.parentgallery;
//
//
//     var _cach = _sliderClipper.children().eq(Number(_c.data('currNr')) + 1);
//
//
//     if (!(_cach.data('gapless-inited') == true)) {
//
//       var args = {
//         preload_method: "auto"
//         , "autoplay": "off"
//         , "call_from": "gapless_play"
//       }
//
//
//       _c.get(0).api_init_player_from_gallery(_cach, args);
//
//       _cach.data('gapless-inited', true);
//
//       setTimeout(function () {
//         _cach.get(0).api_handleResize();
//       }, 1000)
//     }
//   }
// }
}function handleResize(){if(o.settings_mode!=="mode-showall"&&_sliderClipper.hasClass("isotoped")===false){setTimeout(function(){_sliderClipper.css("height",_sliderClipper.children().eq(currNr).outerHeight())},500)}calculateDims()}function transition_end(newCurrNr){_sliderClipper.children().eq(lastCurrNr).removeClass("transitioning-out");_sliderClipper.children().eq(newCurrNr).removeClass("transitioning-in");lastCurrNr=currNr;busy=false}function transition_bg_end(){cgallery.parent().children(".the-bg").eq(0).remove();busy=false}function goto_prev(){tempNr=currNr;tempNr--;var isGoingToItem=true;if(tempNr<0){tempNr=_sliderClipper.children().length-1;if(o.loop_playlist=="off"){isGoingToItem=false}}if(isGoingToItem){goto_item(tempNr)}}function goto_next(){tempNr=currNr;var isGoingToItem=true;if(o.settings_mode=="mode-showall"){tempNr=cgallery.get(0).currNr_2}tempNr++;if(tempNr>=_sliderClipper.children().length){tempNr=0;if(o.loop_playlist=="off"){isGoingToItem=false}}if(isGoingToItem){goto_item(tempNr)}}function goto_item(newCurrNr,pargs){var margs={"ignore_arg_currNr_check":false,"ignore_linking":false// -- does not change the link if set to true
,donotopenlink:"off",called_from:"default"};if(pargs){margs=$.extend(margs,pargs)}if(busy==true){return}if(newCurrNr=="last"){newCurrNr=_sliderClipper.children().length-1}if(Boolean(currNr==newCurrNr)){if(_sliderClipper&&_sliderClipper.children().eq(currNr).get(0)&&_sliderClipper.children().eq(currNr).get(0).api_play_media){_sliderClipper.children().eq(currNr).get(0).api_play_media({"call_from":"gallery"})}return}var _audioplayerToBeActive=_sliderClipper.children(".audioplayer,.audioplayer-tobe").eq(newCurrNr);var currNr_last_vol="";if(currNr>-1){if(typeof _sliderClipper.children().eq(currNr).get(0)!="undefined"){if(typeof _sliderClipper.children().eq(currNr).get(0).api_pause_media!="undefined"){_sliderClipper.children().eq(currNr).get(0).api_pause_media()}if(typeof _sliderClipper.children().eq(currNr).get(0).api_get_last_vol!="undefined"){currNr_last_vol=_sliderClipper.children().eq(currNr).get(0).api_get_last_vol()}}_navClipper.children().removeClass("active active-from-gallery");if(o.mode_normal_video_mode=="one"){}else{if(o.settings_mode!="mode-showall"){_sliderClipper.children().eq(currNr).removeClass("active active-from-gallery");_navClipper.children().eq(currNr).removeClass("active active-from-gallery")}}}// --  setting settings
if(o.settings_ap.design_skin==="sameasgallery"){o.settings_ap.design_skin=o.design_skin}// -- if this is  the first audio
if(currNr==-1&&o.autoplay=="on"){o.settings_ap.autoplay="on"}// -- if this is not the first audio
if(currNr>-1&&o.autoplayNext=="on"){o.settings_ap.autoplay="on"}o.settings_ap.parentgallery=cgallery;o.settings_ap.design_menu_show_player_state_button=o.design_menu_show_player_state_button;o.settings_ap.cue="on";if(first==true){if(o.cueFirstMedia=="off"){o.settings_ap.cue="off"}first=false}// -- setting settings END
var args_player=$.extend({},o.settings_ap);args_player.volume_from_gallery=currNr_last_vol;args_player.call_from="gotoItem";args_player.player_navigation=o.player_navigation;if(o.mode_normal_video_mode=="one"&&newCurrNr>-1&&margs.called_from!="init"){// -- video mode -> one
var _c=_sliderClipper.children().eq(0).get(0);_audioplayerToBeActive=_sliderClipper.children().eq(0);if(_c){if(_c.api_play_media){_c.api_change_media(_sliderClipper.children().eq(newCurrNr),{"called_from":"goto_item -- mode_normal_video_mode()","modeOneGalleryIndex":newCurrNr,"source_player_do_not_update":"on"});if(o.autoplayNext=="on"){setTimeout(function(){_c.api_play_media()},200)}}}}else{// -- init player from gallery
init_player_from_gallery(_audioplayerToBeActive,args_player)}// -- actions after init
if(o.autoplayNext==="on"){if(o.settings_mode==="mode-showall"){currNr=cgallery.get(0).currNr_2}if(!!(currNr>-1&&_audioplayerToBeActive.get(0)&&_audioplayerToBeActive.get(0).api_play)){_audioplayerToBeActive.get(0).api_play()}}if(o.settings_ap.playfrom===undefined||o.settings_ap.playfrom==="0"){if(_audioplayerToBeActive.get(0)&&_audioplayerToBeActive.get(0).api_seek_to){_audioplayerToBeActive.get(0).api_seek_to(0,{call_from:"playlist_seek_from_0"})}else{console.log("_audioplayerToBeActive not found - ",_audioplayerToBeActive)}}// -- end actions after init
dzsap_currplayer_focused=_audioplayerToBeActive.get(0);if(o.settings_mode!=="mode-showall"){_sliderClipper.children().eq(currNr).addClass("transitioning-out");_audioplayerToBeActive.removeClass("transitioning-out-complete");_audioplayerToBeActive.addClass("transitioning-in");setTimeout(function(_arg){_arg.addClass("transitioning-out-complete")},_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.PLAYLIST_TRANSITION_DURATION,_sliderClipper.children().eq(currNr));if(_audioplayerToBeActive.attr("data-type")!="link"){if(margs.ignore_linking==false&&o.settings_enable_linking=="on"){var stateObj={foo:"bar"};history.pushState(stateObj,null,(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.add_query_arg)(window.location.href,"audiogallery_startitem_"+cid,newCurrNr))}}if(o.playlistTransition==="fade"){setTimeout(transition_end,_configs_constants__WEBPACK_IMPORTED_MODULE_1__.ConstantsDzsAp.PLAYLIST_TRANSITION_DURATION,newCurrNr);busy=true}if(o.playlistTransition==="direct"){transition_end(newCurrNr)}}_audioplayerToBeActive.addClass("active active-from-gallery");_navClipper.children().eq(newCurrNr).addClass("active active-from-gallery");// -- background parent
var bgimage="";if(_audioplayerToBeActive.attr("data-bgimage")){bgimage=_audioplayerToBeActive.attr("data-bgimage")}if(_audioplayerToBeActive.attr("data-wrapper-image")){bgimage=_audioplayerToBeActive.attr("data-wrapper-image")}if(bgimage&&cgallery.parent().hasClass("ap-wrapper")&&cgallery.parent().children(".the-bg").length>0){cgallery.parent().children(".the-bg").eq(0).after("<div class=\"the-bg\" style=\"background-image: url("+bgimage+");\"></div>");cgallery.parent().children(".the-bg").eq(0).css({"opacity":1});cgallery.parent().children(".the-bg").eq(1).css({"opacity":0});cgallery.parent().children(".the-bg").eq(1).animate({"opacity":1},{queue:false,duration:1000,complete:transition_bg_end,step:function step(){busy=true}});busy=true}if(o.settings_mode!="mode-showall"){currNr=newCurrNr;cgallery.data("currNr",currNr)}if(_sliderClipper.children().eq(currNr).get(0)&&_sliderClipper.children().eq(currNr).get(0).api_handleResize&&_sliderClipper.children().eq(currNr).hasClass("media-setuped")){_sliderClipper.children().eq(currNr).get(0).api_handleResize()}calculateDims()}function init_player_from_gallery(_cache,pargs){var player_args=$.extend({},o.settings_ap);if(pargs){player_args=$.extend(player_args,pargs)}if(_cache.hasClass("audioplayer-tobe")){o.settings_ap.call_from="init player from gallery";player_args.is_inited_from_playlist=true;_cache.audioplayer(player_args)}}}}]);return DzsApPlaylist}();var registerToJqueryPlaylist=function registerToJqueryPlaylist($){$.fn.audiogallery=function(argOptions){var finalOptions={};var defaultOptions=_objectSpread({},_configs_settingsPlaylist__WEBPACK_IMPORTED_MODULE_2__.default_opts);finalOptions=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_4__.convertPluginOptionsToFinalOptions)(this,defaultOptions,argOptions);this.each(function(){this.linkedClassInstance=new DzsApPlaylist(this,finalOptions,$)})};window.dzsag_init=function(selector,settings){$(selector).audiogallery(Object.assign({},settings))}};(0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_5__.dzsap_jQueryInit)().then(function(){registerToJqueryPlaylist(jQuery);jQuery(document).ready(function($){window.dzsap_init_allGalleries($)})});window.dzsap_init_allGalleries=function($){var $feed_dzsapConfigs=document.querySelectorAll(".dzsap-feed--dzsap-configs");if($feed_dzsapConfigs&&$feed_dzsapConfigs.length){try{window.dzsap_apconfigs=JSON.parse($feed_dzsapConfigs[$feed_dzsapConfigs.length-1].innerHTML)}catch(err){console.log(err)}}// -- load audio player
(0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_5__.loadScriptIfItDoesNotExist)("","dzsap_inited").then(function(){$(".audiogallery.auto-init").each(function(){var $currGallery=$(this);if(!$currGallery.hasClass("dzsag-inited")){if(window.dzsag_init){dzsag_init($currGallery)}}})})};
})();

/******/ })()
;
//# sourceMappingURL=audioplaylist.js.map