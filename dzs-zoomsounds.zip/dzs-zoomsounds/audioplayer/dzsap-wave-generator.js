/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../source/audioplayer/configs/_constants.js":
/*!***************************************************!*\
  !*** ../source/audioplayer/configs/_constants.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConstantsDzsAp": () => (/* binding */ ConstantsDzsAp),
/* harmony export */   "DEBUG_STYLE_PLAY_FUNCTIONS": () => (/* binding */ DEBUG_STYLE_PLAY_FUNCTIONS),
/* harmony export */   "DZSAP_AJAX_ACTION_LIKE": () => (/* binding */ DZSAP_AJAX_ACTION_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_AJAX_LIKE": () => (/* binding */ DZSAP_CLASS_NAME_AJAX_LIKE),
/* harmony export */   "DZSAP_CLASS_NAME_FEED_EMBED_CODE": () => (/* binding */ DZSAP_CLASS_NAME_FEED_EMBED_CODE),
/* harmony export */   "DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS": () => (/* binding */ DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOOTER_PLAYER": () => (/* binding */ DZSAP_PLAYER_CLASS_FOOTER_PLAYER),
/* harmony export */   "DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW": () => (/* binding */ DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW),
/* harmony export */   "DZSAP_PLAYER_CLASS_LOADED": () => (/* binding */ DZSAP_PLAYER_CLASS_LOADED),
/* harmony export */   "DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM": () => (/* binding */ DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM),
/* harmony export */   "DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED": () => (/* binding */ DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_KEYBOARD": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_KEYBOARD),
/* harmony export */   "DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS": () => (/* binding */ DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS),
/* harmony export */   "DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT": () => (/* binding */ DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT),
/* harmony export */   "DZSAP_VIEW_SONG_CHANGER_CLASS": () => (/* binding */ DZSAP_VIEW_SONG_CHANGER_CLASS),
/* harmony export */   "WAVESURFER_MAX_TIMEOUT": () => (/* binding */ WAVESURFER_MAX_TIMEOUT)
/* harmony export */ });
const DEBUG_STYLE_PLAY_FUNCTIONS = 'background-color: #daffda; color: #222222;';
const WAVESURFER_MAX_TIMEOUT = 20000;

const ConstantsDzsAp = {
  PLAYLIST_TRANSITION_DURATION: 300,
  'DEBUG_STYLE_1': 'background-color: #aaa022; color: #222222;',
  'DEBUG_STYLE_2': 'background-color: #7c3b8e; color: #ffffff;',
  'DEBUG_STYLE_3': 'background-color: #3a696b; color: #eeeeee;',
  'DEBUG_STYLE_ERROR': 'background-color: #3a696b; color: #eeeeee;',
  URL_WAVESURFER_HELPER_BACKUP: 'https://zoomthe.me/assets/dzsap-wave-generate.js',
  WAVESURFER_MAX_TIMEOUT,
  DEBUG_STYLE_PLAY_FUNCTIONS,
  URL_JQUERY: 'https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js',
  ERRORED_OUT_CLASS: 'errored-out',
  ERRORED_OUT_MAX_ATTEMPTS: 5
}

const DZSAP_PLAYER_CLASS_FOOTER_PLAYER = 'dzsap_footer';
const DZSAP_PLAYER_CLASS_LOADED = 'dzsap-loaded';
const DZSAP_PLAYER_CLASS_FOR_STICK_TO_BOTTOM_SHOW = 'audioplayer-loaded';
const DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom';
const DZSAP_PLAYER_PLACEHOLDER_CLASS_STICK_TO_BOTTOM = 'dzsap-sticktobottom-placeholder';
const DZSAP_PLAYER_TYPE_FOR_ACCEPTING_FEED = 'fake';
const DZSAP_PLAYER_ATTR_PLAY_FROM_LAST_POS = 'last';
const DZSAP_CLASS_NAME_AJAX_LIKE = 'btn-like';
const DZSAP_CLASS_NAME_FEED_EMBED_CODE = 'feed-dzsap--embed-code';

const DZSAP_SCRIPT_SELECTOR_MAIN_SETTINGS = '#dzsap-main-settings';
const DZSAP_SCRIPT_SELECTOR_KEYBOARD = '#dzsap-keyboard-controls';
const DZSAP_VIEW_PLAYER_PLAYING_EASED_TIMEOUT = 500;
const DZSAP_AJAX_ACTION_LIKE = 'dzsap_submit_like';
const DZSAP_VIEW_SONG_CHANGER_CLASS = 'audioplayer-song-changer';


/***/ }),

/***/ "../source/audioplayer/js_common/_dzs_helpers.js":
/*!*******************************************************!*\
  !*** ../source/audioplayer/js_common/_dzs_helpers.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decode_json": () => (/* binding */ decode_json),
/* harmony export */   "dzsap_jQueryInit": () => (/* binding */ dzsap_jQueryInit),
/* harmony export */   "getBaseUrl": () => (/* binding */ getBaseUrl),
/* harmony export */   "getRelativeX": () => (/* binding */ getRelativeX),
/* harmony export */   "isInt": () => (/* binding */ isInt),
/* harmony export */   "isValid": () => (/* binding */ isValid),
/* harmony export */   "loadScriptIfItDoesNotExist": () => (/* binding */ loadScriptIfItDoesNotExist),
/* harmony export */   "sanitizeToCssPx": () => (/* binding */ sanitizeToCssPx),
/* harmony export */   "setupTooltip": () => (/* binding */ setupTooltip),
/* harmony export */   "simpleStringify": () => (/* binding */ simpleStringify),
/* harmony export */   "string_curateClassName": () => (/* binding */ string_curateClassName)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const decode_json = function (arg) {
  var fout = {};

  if (arg) {

    try {

      fout = JSON.parse(arg);
    } catch (err) {

      return null;
    }
  }

  return fout;
}
async function dzsap_jQueryInit(callback, reject) {

  return new Promise((resolve, reject) => {

    if (window.jQuery) {
      resolve('jQuery loaded');
    } else {
      const script = document.createElement('script');
      script.onload = function () {
        if (window.jQuery) {
          resolve('jQuery loaded');
        } else {
          reject('error loading');
        }
      };
      script.src = _configs_constants__WEBPACK_IMPORTED_MODULE_0__.ConstantsDzsAp.URL_JQUERY;

      document.head.appendChild(script);
    }

    setTimeout(() => {
      reject('error loading');
    }, 15000);
  })
}
/**
 *
 * @param {string} arg
 * @return {string}
 */
function string_curateClassName(arg){

  arg = arg.replace('feed-dzsap', '');
  arg = arg.replace('feed-dzsap--extra-html', '');
  return arg;
}


function simpleStringify (object){
  if (object && typeof object === 'object') {
    object = copyWithoutCircularReferences([object], object);
  }
  return JSON.stringify(object);

  function copyWithoutCircularReferences(references, object) {
    const cleanObject = {};
    Object.keys(object).forEach(function(key) {
      var value = object[key];
      if (value && typeof value === 'object') {
        if (references.indexOf(value) < 0) {
          references.push(value);
          cleanObject[key] = copyWithoutCircularReferences(references, value);
          references.pop();
        } else {
          cleanObject[key] = '###_Circular_###';
        }
      } else if (typeof value !== 'function') {
        cleanObject[key] = value;
      }
    });
    return cleanObject;
  }
}

const loadScriptIfItDoesNotExist = (scriptSrc, checkForVar) => {
  return new Promise((resolve, reject) => {
    if (checkForVar) {
      resolve('loadfromvar');
      return;
    }

    var script = document.createElement('script');
    script.onload = function () {
      resolve('loadfromload');
    };
    script.onerror = function () {
      reject();
    };
    script.src = scriptSrc;

    document.head.appendChild(script);
  })
}


const getBaseUrl = (baseUrlVar, scriptName) => {
  if (window[baseUrlVar]) {
    return window[baseUrlVar];
  }

  let scripts = document.getElementsByTagName("script");
  for (var scriptKey in scripts) {
    if (scripts[scriptKey] && scripts[scriptKey].src && String(scripts[scriptKey].src).indexOf(scriptName) > -1) {
      break;
    }
  }
  var baseUrl_arr = String(scripts[scriptKey].src).split('/');
  baseUrl_arr.splice(-1, 1);
  const result = string_addTrailingSlash(baseUrl_arr.join('/'));
  window[baseUrlVar] = result+'/';
  return result;
}

function string_addTrailingSlash(url){
  var lastChar = url.substr(-1); // Selects the last character
  if (lastChar != '/') {         // If the last character is not a slash
    url = url + '/';            // Append a slash to it.
  }
  return url;
}
const sanitizeToCssPx = (arg) => {

  if (String(arg).indexOf('%') > -1 || String(arg).indexOf('em') > -1 || String(arg).indexOf('px') > -1 || String(arg).indexOf('auto') > -1) {
    return arg;
  }
  return arg + 'px';
}


const setupTooltip = (args) => {

  var mainArgs = Object.assign({
    tooltipInnerHTML: '',
    tooltipIndicatorText: '',
    tooltipConClass: '',
  }, args)

  return `<div class="dzstooltip-con ${mainArgs.tooltipConClass}"><span class="dzstooltip main-tooltip   talign-end arrow-bottom style-rounded color-dark-light  dims-set transition-slidedown " style="width: 280px;"><span class="dzstooltip--inner">${mainArgs.tooltipInnerHTML}</span> </span></span><span class="tooltip-indicator">${mainArgs.tooltipIndicatorText}</span></div>`;
}


const isInt = function (n) {
  return typeof n == 'number' && Math.round(n) % 1 == 0;
}

const isValid = function (n) {
  return typeof n != 'undefined' && n != '';
}


function getRelativeX (mouseX, $el_) {
  if (jQuery) {
    return mouseX - jQuery($el_).offset().left;
  }
}


/***/ }),

/***/ "../source/audioplayer/js_common/_esjquery.js":
/*!****************************************************!*\
  !*** ../source/audioplayer/js_common/_esjquery.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$es": () => (/* binding */ $es),
/* harmony export */   "documentReady": () => (/* binding */ documentReady)
/* harmony export */ });
/**
 * v1.0.0
 * @type {esJquery}
 */
let esJquery = class {

  /**
   *
   * @param {string|esJquery} selector
   */
  constructor(selector) {

    if (typeof selector == 'string') {

      this.$el = document.querySelector(selector);
      this.$els = document.querySelectorAll(selector);
    } else {

      this.$el = selector;

      if (isNodeList(selector)) {
        this.$el = selector[0];
      }
      this.$els = [];

      if (isNodeList(selector)) {

        selector.forEach((_el) => {

          this.$els.push(_el);
        })
      } else {

        this.$els.push(this.$el);
      }


    }
  }

  /**
   *
   * @param {number} indexNr
   * @returns {esJquery}
   */
  eq(indexNr) {

    if (this.$els.length < indexNr - 1) {
      return $es(this.$els[this.$els.length - 1]);
    }
    return $es(this.$els[indexNr]);

  }

  length() {

    return this.$els.length;

  }

  hide() {

    this.$els.forEach(function (el) {
      el.style.display = 'none';
    });
  }

  clone() {
    // -- @only works on first element
    const cln = this.$el.cloneNode(true);
    this.$el.parentNode.appendChild(cln)
    return cln;
  }

  show() {

    this.$els.forEach(function (el) {
      el.style.display = '';
    });
  }

  /**
   *
   * @param {string} arg
   * @return {esJquery}
   */
  addClass(arg) {
    this.$els.forEach(function (el3) {
      if (el3) {
        el3.classList.add(arg);
      }
    });
    return this;
  }

  /**
   *
   * @param {string} arg
   * @return {esJquery}
   */
  removeClass(arg) {


    this.$els.forEach(function (el3) {
      const classesToRemove = arg.split(' ');
      classesToRemove.forEach((classToRemove) => {

        if (el3) {
          el3.classList.remove(classToRemove);
        }
      })
    });
    return this;
  }

  /**
   *
   * @param {string} html
   * @return {esJquery}
   */
  prepend(html) {
    if (typeof html == 'string') {

      const _tempKid = document.createElement("div");


      this.$els.forEach(function (el) {
        try {

          el.appendChild(_tempKid);
          el.insertBefore(_tempKid, el.firstChild);
          _tempKid.outerHTML = html;
        } catch (err) {
          console.error('something went wrong .. ', err, this, el);
        }
      })
    }
  }

  /**
   *
   * @param {number} index
   * @returns {Element}
   */
  get(index) {
    if (index === 0) {
      return this.$el;
    }
  }

  /**
   *
   * @param {function} callback
   */
  each(callback) {
    this.$els.forEach((el) => {
        callback.bind(el)($es(el));
      }
    )
  }

  text() {
    if (arguments.length === 0) {

      return this.$el.textContent;
    } else {

      this.$el.textContent = arguments[0];

      return this;
    }
  }

  /**
   *
   * @param {string} selector
   * @return {esJquery}
   */
  find(selector) {

    if (this.$el) {
      return new esJquery(this.$el.querySelectorAll(selector));
    }
    return new esJquery(this.$el);
  }

  /**
   *
   * @param {string} html
   * @return {esJquery}
   */
  append(html) {
    if (typeof html == 'string') {

      const _tempKid = document.createElement("div");
      _tempKid.innerHTML = html;


      this.$els.forEach(function (el) {
        try {
          el.appendChild(_tempKid);
        } catch (err) {
          console.error('something went wrong .. ', err, this, el);
        }
      })
    }
  }

  /**
   *
   * @param {string} actionType
   */
  trigger(actionType) {

    var event = new CustomEvent(actionType, {
      bubbles: true, detail: 'event'
    });

    this.$el.dispatchEvent(event);
  }

  /**
   *
   * @param {string} eventName
   * @param {string|function} sel
   * @param {string|function} handler
   * @return {esJquery}
   */
  on(eventName, sel, handler) {
    const isSelTheHandler = typeof sel === 'function';
    const theHandler = isSelTheHandler ? sel : handler;


    if (this.$el) {

      this.$el.addEventListener(eventName, function (event) {

        if (isSelTheHandler) {
          theHandler.call(this.$el, event);
          return;
        }
        let t = event.target;
        while (t && t !== this) {
          if (t.matches(sel)) {
            theHandler.call(t, event);
          }
          t = t.parentNode;
        }
      });
    }
    return $es(this);
  }

  /**
   *
   * @param {string} arg
   * @return {esJquery}
   */
  hasClass(arg) {
    if (this.$el) {

      return this.$el.classList.contains(arg);
    }
    return $es(null);
  }

  html() {

    const attrArgs = arguments;
    if (attrArgs.length === 0) {
      return this.$el.innerHTML;
    }
    if (attrArgs.length === 1) {

      if (this.$el) {
        this.$el.innerHTML = attrArgs[0];
      }

      return this;
    }
  }

  getLast() {

    if (this.$els.length) {
      return $es(this.$els[this.$els.length - 1]);
    }
    return null;
  }

  val() {
    const attrArgs = arguments;
    if (attrArgs.length === 0) {
      return this.$el.value ? this.$el.value : '';
    }
    if (attrArgs.length === 1) {

      this.$els.forEach(function (el) {
        if (el) {
          console.log('arguments - ', attrArgs);
          el.value = attrArgs[0];
        }
      });
    }
    return this;


  }

  attr() {
    const attrArgs = arguments;
    if (attrArgs.length === 0) {
      console.log('no attrArgs.. ');
    }
    if (attrArgs.length === 1) {
      return this.$el.getAttribute(attrArgs[0]);
    }
    if (attrArgs.length === 2) {
      this.$els.forEach(function (el) {
        if (el) {
          el.setAttribute(attrArgs[0], attrArgs[1]);
        }
      });
    }

    return $es(this.$el);


  }

  css() {
    const self = this;
    const attrArgs = arguments;
    if (attrArgs.length === 0) {
      console.log('no attrArgs.. ');
    }
    if (attrArgs.length === 1) {
      return this.$el.getAttribute(attrArgs[0]);
    }
    if (attrArgs.length === 2) {

      this.$els.forEach(function (el) {
        if (el) {
          console.log('toCamel case - ', self._toCamelCase(attrArgs[0]), attrArgs[1]);
          el.style[self._toCamelCase(attrArgs[0])] = attrArgs[1];
        }
      })

      console.log(this.$el);

    }

    return $es(this.$el);


  }

  _toCamelCase(s) {
    return s.replace(/-./g, x => x[1].toUpperCase())
  }

  remove() {
    this.$el.remove();
  }

  parent() {

    if (this.$el) {

      return $es(this.$el.parentNode);
    }
    return $es(null);
  }

  prev() {

    return $es(this.$el.previousElementSibling);
  }

  /**
   *
   * @returns {Element}
   */
  getEl() {

    return this.$el;
  }

  children() {
    return $es(this.$el.childNodes);
  }

  serialize() {
    var form = this.$el;
    var field, query = '';
    if (typeof form == 'object' && form.nodeName === "FORM") {
      for (let i = 0; i <= form.elements.length - 1; i++) {
        field = form.elements[i];
        if (field.name && field.type !== 'file' && field.type !== 'reset') {
          if (field.type === 'select-multiple') {
            for (let j = 0; j <= form.elements[i].options.length - 1; j++) {
              if (field.options[j].selected) {
                query += '&' + field.name + "=" + encodeURIComponent(field.options[j].value).replace(/%20/g, '+');
              }
            }
          } else {
            if ((field.type !== 'submit' && field.type !== 'button')) {
              if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
                query += '&' + field.name + "=" + encodeURIComponent(field.value).replace(/%20/g, '+');
              }
            }
          }
        }
      }
    }
    return query.substr(1);
  }
};

function isNodeList(nodes) {
  var stringRepr = Object.prototype.toString.call(nodes);

  return typeof nodes === 'object' &&
    /^\[object (HTMLCollection|NodeList|Object)\]$/.test(stringRepr) &&
    (typeof nodes.length === 'number') &&
    (nodes.length === 0 || (typeof nodes[0] === "object" && nodes[0].nodeType > 0));
}

/**
 * jQuery, but in es6
 * @returns {esJquery} esjQuery
 * @param arg
 */
const $es = (arg) => {


  return new esJquery(arg)
};


function documentReady(callback) {
  new Promise((resolutionFunc, rejectionFunc) => {
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
      resolutionFunc('interactive')
    }
    document.addEventListener('DOMContentLoaded', () => {
      resolutionFunc('DOMContentLoaded')
    }, false);
    setTimeout(() => {
      resolutionFunc('timeout')
    }, 5000);
  }).then(resolution => {
    callback(resolution);
  }).catch(err => {
    callback(err)
  });
}


window.es_document_ready = documentReady;

/** call ajax function
 * {
    'type':'GET',
    'url':'/',
    'data':{},
    'success':null
  }
 */
window.es_ajax = function (pargs) {
  var margs = {
    'method': 'GET',
    'url': '/',
    'data': {},
    'success': null
  };

  if (pargs) {
    margs = Object.assign(margs, pargs);
  }

  let xhr = new XMLHttpRequest();

  xhr.open(margs.method, margs.url);
  var form_data = new FormData();

  for (var key in margs.data) {
    form_data.append(key, margs.data[key]);
  }

  xhr.send(form_data);
  xhr.addEventListener('load', handle_loaded);

  function handle_loaded(e) {

    if (xhr.status !== 200) {

      if (margs.error) {
        margs.error(e, this);
      }
    } else { // show the result
      if (margs.success) {
        margs.success(e, this);
      }
    }
  }


}

window.get_query_arg = function (purl, key) {
  if (purl.indexOf(key + '=') > -1) {
    var regexS = "[?&]" + key + "(.+?)(?=&|$)";
    var regex = new RegExp(regexS);
    var regtest = regex.exec(purl);


    if (regtest != null) {


      if (regtest[1]) {
        return regtest[1].replace(/=/g, '');
      } else {
        return '';
      }


    }
  }
}


/**
 *
 * @param {string} purl
 * @param {string} key
 * @param {string} value
 * @returns {*}
 */
window.add_query_arg = function (purl, key, value) {
  key = encodeURIComponent(key);
  value = encodeURIComponent(value);


  var s = purl;
  var pair = key + "=" + value;

  var r = new RegExp("(&|\\?)" + key + "=[^\&]*");


  s = s.replace(r, "$1" + pair);
  var addition = '';
  if (s.indexOf(key + '=') > -1) {


  } else {
    if (s.indexOf('?') > -1) {
      addition = '&' + pair;
    } else {
      addition = '?' + pair;
    }
    s += addition;
  }

  if (value === 'NaN') {
    var regex_attr = new RegExp('[\?|\&]' + key + '=' + value);
    s = s.replace(regex_attr, '');
  }


  return s;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/_dzsap_helpers.js":
/*!*****************************************************!*\
  !*** ../source/audioplayer/jsinc/_dzsap_helpers.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "add_query_arg": () => (/* binding */ add_query_arg),
/* harmony export */   "assignHelperFunctionsToJquery": () => (/* binding */ assignHelperFunctionsToJquery),
/* harmony export */   "assignPcmData": () => (/* binding */ assignPcmData),
/* harmony export */   "can_canvas": () => (/* binding */ can_canvas),
/* harmony export */   "can_history_api": () => (/* binding */ can_history_api),
/* harmony export */   "convertPluginOptionsToFinalOptions": () => (/* binding */ convertPluginOptionsToFinalOptions),
/* harmony export */   "dzs_clean_string": () => (/* binding */ dzs_clean_string),
/* harmony export */   "dzsapInitjQueryRegisters": () => (/* binding */ dzsapInitjQueryRegisters),
/* harmony export */   "dzsap_generate_keyboard_tooltip": () => (/* binding */ dzsap_generate_keyboard_tooltip),
/* harmony export */   "dzsap_is_mobile": () => (/* binding */ dzsap_is_mobile),
/* harmony export */   "dzsap_singleton_ready_calls": () => (/* binding */ dzsap_singleton_ready_calls),
/* harmony export */   "formatTime": () => (/* binding */ formatTime),
/* harmony export */   "generateFakeArrayForPcm": () => (/* binding */ generateFakeArrayForPcm),
/* harmony export */   "get_query_arg": () => (/* binding */ get_query_arg),
/* harmony export */   "hexToRgb": () => (/* binding */ hexToRgb),
/* harmony export */   "htmlEncode": () => (/* binding */ htmlEncode),
/* harmony export */   "is_android": () => (/* binding */ is_android),
/* harmony export */   "is_android_good": () => (/* binding */ is_android_good),
/* harmony export */   "is_ios": () => (/* binding */ is_ios),
/* harmony export */   "is_safari": () => (/* binding */ is_safari),
/* harmony export */   "jQueryAuxBindings": () => (/* binding */ jQueryAuxBindings),
/* harmony export */   "playerFunctions": () => (/* binding */ playerFunctions),
/* harmony export */   "playerRegisterWindowFunctions": () => (/* binding */ playerRegisterWindowFunctions),
/* harmony export */   "player_checkIfWeShouldShowAComment": () => (/* binding */ player_checkIfWeShouldShowAComment),
/* harmony export */   "player_delete": () => (/* binding */ player_delete),
/* harmony export */   "player_determineStickToBottomContainer": () => (/* binding */ player_determineStickToBottomContainer),
/* harmony export */   "player_getPlayFromTime": () => (/* binding */ player_getPlayFromTime),
/* harmony export */   "player_identifySource": () => (/* binding */ player_identifySource),
/* harmony export */   "player_identifyTypes": () => (/* binding */ player_identifyTypes),
/* harmony export */   "player_isGoingToSetupMediaNow": () => (/* binding */ player_isGoingToSetupMediaNow),
/* harmony export */   "player_radio_isNameUpdatable": () => (/* binding */ player_radio_isNameUpdatable),
/* harmony export */   "player_reinit_findIfPcmNeedsGenerating": () => (/* binding */ player_reinit_findIfPcmNeedsGenerating),
/* harmony export */   "player_service_getSourceProtection": () => (/* binding */ player_service_getSourceProtection),
/* harmony export */   "player_stickToBottomContainerDetermineClasses": () => (/* binding */ player_stickToBottomContainerDetermineClasses),
/* harmony export */   "player_stopOtherPlayers": () => (/* binding */ player_stopOtherPlayers),
/* harmony export */   "player_syncPlayers_buildList": () => (/* binding */ player_syncPlayers_buildList),
/* harmony export */   "player_syncPlayers_gotoItem": () => (/* binding */ player_syncPlayers_gotoItem),
/* harmony export */   "player_view_addMetaLoaded": () => (/* binding */ player_view_addMetaLoaded),
/* harmony export */   "registerTextWidth": () => (/* binding */ registerTextWidth),
/* harmony export */   "sanitizeObjectForChangeMediaArgs": () => (/* binding */ sanitizeObjectForChangeMediaArgs),
/* harmony export */   "sanitizeToHexColor": () => (/* binding */ sanitizeToHexColor),
/* harmony export */   "sanitizeToIntFromPointTime": () => (/* binding */ sanitizeToIntFromPointTime),
/* harmony export */   "select_all": () => (/* binding */ select_all),
/* harmony export */   "string_jsonConvertToArray": () => (/* binding */ string_jsonConvertToArray),
/* harmony export */   "utils_sanitizeToColor": () => (/* binding */ utils_sanitizeToColor),
/* harmony export */   "view_player_globalDetermineSyncPlayersIndex": () => (/* binding */ view_player_globalDetermineSyncPlayersIndex),
/* harmony export */   "view_player_playMiscEffects": () => (/* binding */ view_player_playMiscEffects),
/* harmony export */   "waitForScriptToBeAvailableThenExecute": () => (/* binding */ waitForScriptToBeAvailableThenExecute)
/* harmony export */ });
/* harmony import */ var _js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../js_common/_dzs_helpers */ "../source/audioplayer/js_common/_dzs_helpers.js");
/* harmony import */ var _player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./player/_player_keyboard */ "../source/audioplayer/jsinc/player/_player_keyboard.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../configs/_constants */ "../source/audioplayer/configs/_constants.js");





function formatTime(arg) {

  var s = Math.round(arg);
  var m = 0;
  var h = 0;
  if (s > 0) {
    while (s > 3599 && s < 3000000 && isFinite(s)) {
      h++;
      s -= 3600;
    }
    while (s > 59 && s < 3000000 && isFinite(s)) {
      m++;
      s -= 60;
    }
    if (h) {

      return String((h < 10 ? "0" : "") + h + ":" + String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s));
    }
    return String((m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s);
  } else {
    return "00:00";
  }
}

function can_history_api() {
  return !!(window.history && history.pushState);
}

function dzs_clean_string(arg) {

  if (arg) {

    arg = arg.replace(/[^A-Za-z0-9\-]/g, '');

    arg = arg.replace(/\./g, '');
    return arg;
  }

  return '';


}


function get_query_arg(purl, key) {
  if (purl) {

    if (String(purl).indexOf(key + '=') > -1) {

      var regexS = "[?&]" + key + "=.+";
      var regex = new RegExp(regexS);
      var regtest = regex.exec(purl);


      if (regtest != null) {
        var splitterS = regtest[0];
        if (splitterS.indexOf('&') > -1) {
          var aux = splitterS.split('&');
          splitterS = aux[1];
        }

        var splitter = splitterS.split('=');


        return splitter[1];

      }

    }

  } else {
  }
}

function add_query_arg(purl, key, value) {

  key = encodeURIComponent(key);
  value = encodeURIComponent(value);

  if (!(purl)) {
    purl = '';
  }
  var s = purl;
  var pair = key + "=" + value;

  var r = new RegExp("(&|\\?)" + key + "=[^\&]*");

  s = s.replace(r, "$1" + pair);

  if (s.indexOf(key + '=') > -1) {


  } else {
    if (s.indexOf('?') > -1) {
      s += '&' + pair;
    } else {
      s += '?' + pair;
    }
  }


  if (value === 'NaN') {
    var regex_attr = new RegExp('[\?|\&]' + key + '=' + value);
    s = s.replace(regex_attr, '');


    if (s.indexOf('?') === -1 && s.indexOf('&') > -1) {
      s = s.replace('&', '?');
    }
  }

  return s;
}


function dzsap_is_mobile() {


  return is_ios() || is_android();
}

function is_ios() {

  return ((navigator.platform.indexOf("iPhone") !== -1) || (navigator.platform.indexOf("iPod") !== -1) || (navigator.platform.indexOf("iPad") !== -1));
}


function can_canvas() {

  var oCanvas = document.createElement("canvas");
  return !!oCanvas.getContext("2d");

}

function is_safari() {
  return Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
}


function is_android() {
  var ua = navigator.userAgent.toLowerCase();

  return (ua.indexOf("android") > -1);
}

function select_all(el) {
  if (typeof window.getSelection !== "undefined" && typeof document.createRange !== "undefined") {
    var range = document.createRange();
    range.selectNodeContents(el);
    var sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  } else if (typeof document.selection !== "undefined" && typeof document.body.createTextRange !== "undefined") {
    var textRange = document.body.createTextRange();
    textRange.moveToElementText(el);
    textRange.select();
  }
}

function is_android_good() {


}

function htmlEncode(arg) {
  return jQuery('<div/>').text(arg).html();
}

function dzsap_generate_keyboard_tooltip(keyboard_controls, lab) {


  let structureDzsTooltipCommentAfterSubmit = '<span class="dzstooltip color-dark-light talign-start transition-slidein arrow-bottom style-default" style="width: auto;  white-space:nowrap;"><span class="dzstooltip--inner">' + 'Shortcut' + ': ' + keyboard_controls[lab] + '</span></span>';

  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('32', 'space');
  structureDzsTooltipCommentAfterSubmit = structureDzsTooltipCommentAfterSubmit.replace('27', 'escape');

  return structureDzsTooltipCommentAfterSubmit;


}


/**
 *
 * @param hex
 * @param {number|null} targetAlpha 0-1
 * @returns {string}
 */
function hexToRgb(hex, targetAlpha = null) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  var str = '';
  if (result) {
    result = {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    };


    var alpha = 1;

    if (targetAlpha !== null) {
      alpha = targetAlpha;
    }


    str = 'rgba(' + result.r + ',' + result.g + ',' + result.b + ',' + alpha + ')';
  }


  return str;


}

function assignHelperFunctionsToJquery($) {


  Math.easeIn = function (t, b, c, d) {
    return -c * (t /= d) * (t - 2) + b;
  };


  /**
   *
   * @param {string} argfind
   * @param {string} arg
   * @returns {string}
   */
  const checkIfHasClass = (argfind, arg) => {

    if (!argfind) {
      var regex = new RegExp('class="(.*?)"');
      var auxarr = regex.exec(arg);


      if (auxarr && auxarr[1]) {
        argfind = '.' + auxarr[1];
      }
    }

    return argfind;
  }
  $.fn.prependOnce = function (arg, argfind) {
    var _t = $(this)


    argfind = checkIfHasClass(argfind, arg);


    if (_t.children(argfind).length < 1) {
      _t.prepend(arg);
      return true;
    }
    return false;
  };
  $.fn.appendOnce = function (arg, argfind) {
    var _t = $(this)

    argfind = checkIfHasClass(argfind, arg);

    if (_t.children(argfind).length < 1) {
      _t.append(arg);
      return true;
    }
    return false;
  };
};


function registerTextWidth($) {

  $.fn.textWidth = function () {
    var _t = jQuery(this);
    var html_org = _t.html();
    if (_t[0].nodeName === 'INPUT') {
      html_org = _t.val();
    }
    var html_calcS = '<span class="forcalc">' + html_org + '</span>';
    jQuery('body').append(html_calcS);
    var _lastspan = jQuery('span.forcalc').last();

    _lastspan.css({
      'font-size': _t.css('font-size'),
      'font-family': _t.css('font-family')
    })
    var width = _lastspan.width();

    _lastspan.remove();
    return width;
  };
}

function player_checkIfWeShouldShowAComment(selfClass, real_time_curr, real_time_total) {

  var $ = jQuery;
  var timer_curr_perc = Math.round((real_time_curr / real_time_total) * 100) / 100;
  if (selfClass.audioType === 'fake') {
    timer_curr_perc = Math.round((selfClass.timeCurrent / selfClass.timeTotal) * 100) / 100;
  }
  if (selfClass._commentsHolder) {
    selfClass._commentsHolder.children().each(function () {
      var _t = $(this);
      if (_t.hasClass('dzstooltip-con')) {
        var _t_posx = _t.offset().left - selfClass._commentsHolder.offset().left;


        var aux = Math.round((parseFloat(_t_posx) / selfClass._commentsHolder.outerWidth()) * 100) / 100;


        if (aux) {

          if (Math.abs(aux - timer_curr_perc) < 0.02) {
            selfClass._commentsHolder.find('.dzstooltip').removeClass('active');
            _t.find('.dzstooltip').addClass('active');
          } else {
            _t.find('.dzstooltip').removeClass('active');
          }
        }
      }
    })
  }
}


function sanitizeObjectForChangeMediaArgs(_sourceForChange) {

  var changeMediaArgs = {};
  var _feed_fakePlayer = _sourceForChange;

  var lab = '';

  if (_sourceForChange.data('original-settings')) {
    return _sourceForChange.data('original-settings');
  }


  changeMediaArgs.source = null;
  if (_feed_fakePlayer.attr('data-source')) {
    changeMediaArgs.source = _feed_fakePlayer.attr('data-source')
  } else {

    if (_feed_fakePlayer.attr('href')) {
      changeMediaArgs.source = _feed_fakePlayer.attr('href');
    }
  }

  if (_feed_fakePlayer.attr('data-pcm')) {
    changeMediaArgs.pcm = _feed_fakePlayer.attr('data-pcm');
  }


  lab = 'thumb';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }

  lab = 'playerid';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }
  lab = 'type';
  if (_feed_fakePlayer.attr('data-' + lab)) {
    changeMediaArgs[lab] = _sourceForChange.attr('data-' + lab);
  }


  if (_feed_fakePlayer.attr('data-thumb_link')) {
    changeMediaArgs.thumb_link = _sourceForChange.attr('data-thumb_link');
  }


  if (_sourceForChange.find('.meta-artist').length > 0 || _sourceForChange.find('.meta-artist-con').length > 0) {

    changeMediaArgs.artist = _sourceForChange.find('.the-artist').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.the-name').eq(0).html();
  }


  if (_sourceForChange.attr('data-thumb_for_parent')) {
    changeMediaArgs.thumb = _sourceForChange.attr('data-thumb_for_parent');
  }


  if (_sourceForChange.find('.feed-song-name').length > 0 || _sourceForChange.find('.feed-artist-name').length > 0) {
    changeMediaArgs.artist = _sourceForChange.find('.feed-artist-name').eq(0).html();
    changeMediaArgs.song_name = _sourceForChange.find('.feed-song-name').eq(0).html();
  }


  return changeMediaArgs;
}


function utils_sanitizeToColor(colorString) {
  if (colorString.indexOf('#') === -1 && colorString.indexOf('rgb') === -1 && colorString.indexOf('hsl') === -1) {
    return '#' + colorString;
  }
  return colorString;
}

function dzsapInitjQueryRegisters() {
}

function player_radio_isNameUpdatable(selfClass, radio_update_song_name, targetKey) {

  if (selfClass._metaArtistCon.find(targetKey).length && selfClass._metaArtistCon.find(targetKey).eq(0).text().length > 0) {

    if (selfClass._metaArtistCon.find(targetKey).eq(0).html().indexOf('{{update}}') > -1) {
      return true;
    }
  }


  return false;
}

function playerRegisterWindowFunctions() {


  window['dzsap_functions'] = {};
  window['dzsap_functions']['send_total_time'] = function (argtime, argcthis) {


    if (argtime && argtime !== Infinity) {
      const data = {
        action: 'dzsap_send_total_time_for_track',
        id_track: argcthis.attr('data-playerid'),
        postdata: Math.ceil(argtime)
      };
      jQuery.post(window.dzsap_ajaxurl, data, function (response) {
      });
    }

  }


  window.dzs_open_social_link = function (arg, argthis) {
    var leftPosition, topPosition;
    var w = 500, h = 500;

    leftPosition = (window.screen.width / 2) - ((w / 2) + 10);

    topPosition = (window.screen.height / 2) - ((h / 2) + 50);
    var windowFeatures = "status=no,height=" + h + ",width=" + w + ",resizable=yes,left=" + leftPosition + ",top=" + topPosition + ",screenX=" + leftPosition + ",screenY=" + topPosition + ",toolbar=no,menubar=no,scrollbars=no,location=no,directories=no";


    arg = arg.replace('{{replacewithcurrurl}}', encodeURIComponent(window.location.href));

    if (argthis && argthis.attr) {
      arg = arg.replace(/{{replacewithdataurl}}/g, argthis.attr('data-url'));
    }

    const locationHref = window.location.href;


    const auxa = locationHref.split('?');

    let cid = '';
    let cid_gallery = '';


    if (argthis) {

    } else {
      if (window.dzsap_currplayer_from_share) {

        argthis = window.dzsap_currplayer_from_share;
      }
    }


    if (argthis) {

      const $ = jQuery;

      if ($(argthis).hasClass('audioplayer')) {
        cid = $(argthis).parent().children().index(argthis);
        cid_gallery = $(argthis).parent().parent().parent().attr('id');
      } else {
        if (jQuery(argthis).parent().parent().attr('data-menu-index')) {

          cid = jQuery(argthis).parent().parent().attr('data-menu-index');
        }
        if (jQuery(argthis).parent().parent().attr('data-gallery-id')) {

          cid_gallery = jQuery(argthis).parent().parent().attr('data-gallery-id');
        }
      }

    }


    var shareurl = encodeURIComponent(auxa[0] + '?fromsharer=on&audiogallery_startitem_' + cid_gallery + '=' + cid + '');
    arg = arg.replace('{{shareurl}}', shareurl);


    window.open(arg, "sharer", windowFeatures);
  }


  window.dzsap_wp_send_contor_60_secs = function (argcthis, argtitle) {

    var data = {
      video_title: argtitle

      , video_analytics_id: argcthis.attr('data-playerid')
      , curr_user: window.dzsap_curr_user
    };
    var theajaxurl = 'index.php?action=ajax_dzsap_submit_contor_60_secs';

    if (window.dzsap_settings.dzsap_site_url) {

      theajaxurl = dzsap_settings.dzsap_site_url + theajaxurl;
    }


    jQuery.ajax({
      type: "POST",
      url: theajaxurl,
      data: data,
      success: function (response) {


      },
      error: function (arg) {

      }
    });
  }


  window.dzsap_init_multisharer = function () {


  }


}


/**
 *
 * @param {DzsAudioPlayer} selfClass
 */
function assignPcmData(selfClass) {

  selfClass.pcmSource = string_jsonConvertToArray(selfClass.cthis.attr('data-pcm'));
  if (selfClass.initOptions.skinwave_enableSpectrum === 'on') {
    var pcmSourceLen = selfClass.pcmSource.length;
    var desiredSize = 256;

    for (var i = 0; i < pcmSourceLen; i++) {
      if (i > desiredSize) {
        continue;
      }
      selfClass.pcmSource[i] = selfClass.pcmSource[i * pcmSourceLen / desiredSize] * desiredSize;
    }
    selfClass.pcmSource.splice(desiredSize, pcmSourceLen - desiredSize); // removes 3rd element of array
  }
}

function string_jsonConvertToArray(ar_str) {
  let waves = [];
  if (typeof (ar_str) == 'object') {
    waves = ar_str;
  } else {
    try {
      waves = JSON.parse(ar_str);
    } catch (err) {

    }
  }

  return waves;
}

/**
 * should be called only once on init
 */
function dzsap_singleton_ready_calls() {

  window.dzsap_singleton_ready_calls_is_called = true;


  let $feed_dzsapMainSettings = null;
  const $feed_dzsapMainSettingsAll = document.querySelectorAll('.dzsap-main-settings');
  if ($feed_dzsapMainSettingsAll.length) {
    $feed_dzsapMainSettings = $feed_dzsapMainSettingsAll[$feed_dzsapMainSettingsAll.length - 1];
  }
  if ($feed_dzsapMainSettings) {
    window.dzsap_settings = JSON.parse($feed_dzsapMainSettings.innerHTML);
    window.ajaxurl = window.dzsap_settings.ajax_url;
    window.dzsap_curr_user = window.dzsap_settings.dzsap_curr_user;
  }


  jQuery('body').append('<style class="dzsap--style"></style>');


  window.dzsap__style = jQuery('.dzsap--style');


  jQuery('audio.zoomsounds-from-audio').each(function () {
    var _t = jQuery(this);
    _t.after('<div class="audioplayer-tobe auto-init skin-silver" data-source="' + _t.attr('src') + '"></div>');
    _t.remove();
  })

  jQuery(document).on('focus.dzsap', 'input', function () {
    window.dzsap_currplayer_focused = null;
  })

  registerTextWidth(jQuery);

  (0,_player_player_keyboard__WEBPACK_IMPORTED_MODULE_1__.dzsap_keyboardSetup)();
}

function jQueryAuxBindings($) {


  function handleClick_onGlobalZoomSoundsButton(e) {
    const $t = $(this);


    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if ($t.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS)) {
      const _c = $($t.attr('data-fakeplayer')).eq(0);


      if (_c && _c.get(0) && _c.get(0).api_change_media) {
        _c.get(0).api_change_media($t, {
          'feeder_type': 'button'
          , 'call_from': 'changed ' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS
        });
      }

      return false;
    }


  }


  $(document).off('click.dzsap_metas')
  $(document).on('click.dzsap_metas', '.' + _configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_VIEW_SONG_CHANGER_CLASS, handleClick_onGlobalZoomSoundsButton)


}


/**
 * for .zoomsounds-wrapper-bg-center
 * @param selfClass
 */
function view_player_playMiscEffects(selfClass) {

  selfClass.$conPlayPause.addClass('playing');

  if (selfClass.cthis.parent().hasClass('zoomsounds-wrapper-bg-center')) {
    selfClass.cthis.parent().addClass('is-playing');
  }
}


function view_player_globalDetermineSyncPlayersIndex(selfClass) {

  if (selfClass._sourcePlayer === null && window.dzsap_syncList_players) {
    window.dzsap_syncList_players.forEach(($syncPlayer, index) => {
      if (selfClass.cthis.attr('data-playerid') == $syncPlayer.attr('data-playerid')) {
        window.dzsap_syncList_index = index;
      }
    })
  }
}


function player_view_addMetaLoaded(selfClass) {

  selfClass.cthis.addClass('meta-loaded');
  selfClass.cthis.removeClass('meta-fake');
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
    selfClass._sourcePlayer.removeClass('meta-fake');
  }
  if (selfClass.$totalTime) {

    selfClass.timeModel.refreshTimes();
    selfClass.$totalTime.html(formatTime(selfClass.timeModel.getVisualTotalTime()));
  }
  if (selfClass._sourcePlayer) {
    selfClass._sourcePlayer.addClass('meta-loaded');
  }
}


function htmlEntities(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function waitForScriptToBeAvailableThenExecute(verifyVar, callbackFn) {

  new Promise((resolve, reject) => {

    let checkInterval = 0;

    function checkIfVarExists() {
      if (verifyVar) {
        clearInterval(checkInterval);
        resolve('var exists');
      }
    }

    checkIfVarExists()
    checkInterval = setInterval(checkIfVarExists, 300);
    setTimeout(() => {
      reject('timeout');
    }, 5000);

  }).then((resolve => {
    callbackFn(resolve);
  })).catch((err) => {
  })
}


function player_reinit_findIfPcmNeedsGenerating(selfClass) {
  const o = selfClass.initOptions;

  if (selfClass.cthis.attr('data-pcm')) {
    selfClass.hasInitialPcmData = true;
  }

  if (!selfClass.hasInitialPcmData && o.skinwave_wave_mode === 'canvas' && (o.design_skin === 'skin-wave' || selfClass.cthis.attr('data-fakeplayer'))) {
    selfClass.isPcmRequiredToGenerate = true;
  }


  if (o.scrubbar_type === 'wave') {
    if (o.is_inited_from_playlist) {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (o.scrubbar_type_wave__has_reveal_animation === 'on') {

      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
    if (selfClass.isPcmRequiredToGenerate) {
      selfClass.cthis.addClass('scrubbar-type-wave--has-reveal-animation');
    }
  }
}


function playerFunctions(selfClass, functionType) {
  var o = selfClass.initOptions;

  if (functionType === 'detectIds') {


    if (o.skinwave_comments_playerid === '') {
      if (typeof (selfClass.cthis.attr('id')) !== 'undefined') {
        selfClass.the_player_id = selfClass.cthis.attr('id');
      }
    }


    if (selfClass.the_player_id == '') {

      if (selfClass.cthis.attr('data-computed-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-computed-playerid');
      }
      if (selfClass.cthis.attr('data-real-playerid')) {
        selfClass.the_player_id = selfClass.cthis.attr('data-real-playerid');
      }
    }
    selfClass.uniqueId = selfClass.the_player_id;

    if (typeof selfClass.uniqueId === 'string') {
      selfClass.uniqueId = selfClass.uniqueId.replace('ap', '');
    }
    selfClass.identifier_pcm = selfClass.uniqueId;


    if (selfClass.uniqueId === '') {
      o.skinwave_comments_enable = 'off';
    }

  }
}

function player_delete(selfClass) {

  var _con = null;
  if (selfClass.cthis.parent().parent().hasClass('dzsap-sticktobottom')) {
    _con = selfClass.cthis.parent().parent();
  }
  if (_con) {
    if (_con.prev().hasClass("dzsap-sticktobottom-placeholder")) {
      _con.prev().remove();
    }
    _con.remove();
  }
  selfClass.cthis.remove();
  return false;
}


function sanitizeToHexColor(hexcolor) {
  if (hexcolor.indexOf('#') === -1) {
    hexcolor = '#' + hexcolor;
  }
  return hexcolor;
}

function player_identifySource(selfClass) {

  selfClass.data_source = selfClass.cthis.attr('data-source') || '';
}

function player_identifyTypes(selfClass) {


  var o = selfClass.initOptions;
  const cthis = selfClass.cthis;
  if (cthis.attr('data-type') === 'youtube') {
    o.type = 'youtube';
    selfClass.audioType = 'youtube';
  }
  if (cthis.attr('data-type') === 'soundcloud') {
    o.type = 'soundcloud';
    selfClass.audioType = 'soundcloud';

    o.skinwave_enableSpectrum = 'off';
    cthis.removeClass('skin-wave-is-spectrum');
  }
  if (cthis.attr('data-type') === 'mediafile') {
    o.type = 'audio';
    selfClass.audioType = 'audio';
  }

  if (cthis.attr('data-type') === 'shoutcast') {
    o.type = 'shoutcast';
    selfClass.audioType = 'audio';
    o.disable_timer = 'on';
    o.skinwave_enableSpectrum = 'off';

    if (!cthis.attr('data-streamtype')) {

      selfClass.audioTypeSelfHosted_streamType = 'shoutcast';
    }


    if (o.design_skin === 'skin-default') {
      o.disable_scrub = 'on';
    }

  }


  if (selfClass.audioType === 'audio' || selfClass.audioType === 'normal' || selfClass.audioType === '') {
    selfClass.audioType = 'selfHosted';
  }


  if (String(selfClass.data_source).indexOf('https://soundcloud.com/') > -1) {
    selfClass.audioType = 'soundcloud';
  }
}


function player_getPlayFromTime(selfClass) {

  selfClass.playFrom = selfClass.initOptions.playfrom;

  if ((0,_js_common_dzs_helpers__WEBPACK_IMPORTED_MODULE_0__.isValid)(selfClass.cthis.attr('data-playfrom'))) {
    selfClass.playFrom = selfClass.cthis.attr('data-playfrom');
  }

  if (isNaN(parseInt(selfClass.playFrom, 10)) === false) {
    selfClass.playFrom = parseInt(selfClass.playFrom, 10);
  }


  if (selfClass.playFrom === 'off' || selfClass.playFrom === '') {
    if (get_query_arg(window.location.href, 'audio_time')) {
      selfClass.playFrom = sanitizeToIntFromPointTime(get_query_arg(window.location.href, 'audio_time'));
    }
  }

  if (selfClass.timeModel.sampleTimeStart) {
    if (selfClass.playFrom < selfClass.timeModel.sampleTimeStart) {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
    if (typeof selfClass.playFrom === 'string') {
      selfClass.playFrom = selfClass.timeModel.sampleTimeStart;
    }
  }
}


function sanitizeToIntFromPointTime(arg) {


  arg = String(arg).replace('%3A', ':');
  arg = String(arg).replace('#', '');

  if (arg && String(arg).indexOf(':') > -1) {

    var arr = /(\d.*):(\d.*)/g.exec(arg);


    var m = parseInt(arr[1], 10);
    var s = parseInt(arr[2], 10);


    return (m * 60) + s;
  } else {
    return Number(arg);
  }
}


/**
 * called in player init()
 * @param {DzsAudioPlayer} selfClass
 */
function player_determineStickToBottomContainer(selfClass) {

  let $conTest = selfClass.cthis.parent();


  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;

  }
  $conTest = selfClass.cthis.parent().parent();
  if ($conTest.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_STICK_TO_BOTTOM)) {
    selfClass.$stickToBottomContainer = $conTest;
    selfClass.isStickyPlayer = true;
  }
}


/**
 *
 * todo: maybe move
 * @param {DzsAudioPlayer} selfClass
 */
function player_stickToBottomContainerDetermineClasses(selfClass) {

  if (selfClass.$stickToBottomContainer) {
    if (selfClass.cthis.hasClass('theme-dark')) {
      selfClass.$stickToBottomContainer.addClass('theme-dark');
    }

    setTimeout(function () {

      selfClass.$stickToBottomContainer.addClass('inited');
    }, 500)


  }

}

function player_service_getSourceProtection(selfClass) {

  return new Promise((resolve, reject) => {

    jQuery.ajax({
      type: "POST",
      url: selfClass.data_source,
      data: {},
      success: function (response) {
        resolve(response);
      },
      error: function (err) {
        reject(err);
      }
    });
  })
}

function player_isGoingToSetupMediaNow(selfClass) {
  return selfClass.audioTypeSelfHosted_streamType !== 'icecast' && selfClass.audioType !== 'youtube';
}


function player_stopOtherPlayers(dzsap_list, selfClass) {

  let i = 0;
  for (i = 0; i < dzsap_list.length; i++) {

    if (dzsap_list[i].get(0) && dzsap_list[i].get(0).api_pause_media && (dzsap_list[i].get(0) != selfClass.cthis.get(0))) {


      if (dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') && dzsap_list[i].data('type_audio_stop_buffer_on_unfocus') === 'on') {
        dzsap_list[i].get(0).api_destroy_for_rebuffer();
      } else {
        dzsap_list[i].get(0).api_pause_media({
          'audioapi_setlasttime': false
        });
      }
    }
  }
}


function player_syncPlayers_gotoItem(selfClass, targetIncrement) {
  if (window.dzsap_settings.syncPlayers_autoplayEnabled) {

    for (let keySyncPlayer in window.dzsap_syncList_players) {
      let $playerInSyncList = selfClass.cthis;

      if (selfClass._sourcePlayer) {
        $playerInSyncList = selfClass._sourcePlayer;
      }


      if (window.dzsap_syncList_players[keySyncPlayer].get(0) === $playerInSyncList.get(0)) {

        keySyncPlayer = parseInt(keySyncPlayer, 10);
        let targetIndex = window.dzsap_syncList_index + targetIncrement;
        if (targetIndex >= 0 && targetIndex < window.dzsap_syncList_players.length) {
          const $currentSyncPlayer_ = window.dzsap_syncList_players[targetIndex].get(0);


          if ($currentSyncPlayer_ && $currentSyncPlayer_.api_play_media) {
            setTimeout(function () {
              $currentSyncPlayer_.api_play_media({
                'called_from': 'api_sync_players_prev'
              });
            }, 200);

          }
        }
      }
    }
  }

}

function player_syncPlayers_buildList() {

  if (!window.syncPlayers_isDzsapListBuilt) {

    window.dzsap_syncList_players = [];

    window.syncPlayers_isDzsapListBuilt = true;

    jQuery('.audioplayer.is-single-player,.audioplayer-tobe.is-single-player').each(function () {
      const _t23 = jQuery(this);


      if (_t23.hasClass(_configs_constants__WEBPACK_IMPORTED_MODULE_2__.DZSAP_PLAYER_CLASS_FOOTER_PLAYER)) {
        return;
      }


      if (_t23.attr('data-do-not-include-in-list') !== 'on') {
        window.dzsap_syncList_players.push(_t23);
      }
    })


    clearTimeout(window.syncPlayers_buildTimeout);

    window.syncPlayers_buildTimeout = setTimeout(function () {
      window.syncPlayers_isDzsapListBuilt = false;
    }, 500);

  }

}


function convertPluginOptionsToFinalOptions(elThis, defaultOptions, argOptions = null, searchedAttr = 'data-options', $es) {

  var finalOptions = null;
  var tempOptions = {};
  var isSetFromJson = false;

  if ($es === undefined) {
    $es = jQuery;
  }


  var $elThis = $es(elThis);

  const isArgOptionsDefinedViaJs = Boolean(argOptions && typeof argOptions === 'object' && Object.keys(argOptions).length);


  if (isArgOptionsDefinedViaJs) {
    tempOptions = argOptions;
  } else {
    if ($elThis.attr(searchedAttr)) {
      try {
        tempOptions = JSON.parse($elThis.attr(searchedAttr));
        isSetFromJson = true;
      } catch (err) {
        console.log('err - ',err);

      }
    }
    if (!isSetFromJson) {
      if (typeof $elThis.attr(searchedAttr) != 'undefined' && $elThis.attr('data-options') != '') {
        let aux = $elThis.attr(searchedAttr);
        aux = 'var aux_opts = ' + aux;
        eval(aux);
        tempOptions = Object.assign({}, argOptions);
      }
    }
  }
  finalOptions = Object.assign(defaultOptions, tempOptions);

  return finalOptions;
}

function generateFakeArrayForPcm() {


  var maxlen = 256;

  var arr = [];

  for (let it1 = 0; it1 < maxlen; it1++) {
    arr[it1] = Math.random() * 100;

  }

  return arr;
}


/***/ }),

/***/ "../source/audioplayer/jsinc/player/_player_keyboard.js":
/*!**************************************************************!*\
  !*** ../source/audioplayer/jsinc/player/_player_keyboard.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dzsap_generate_keyboard_controls": () => (/* binding */ dzsap_generate_keyboard_controls),
/* harmony export */   "dzsap_keyboardSetup": () => (/* binding */ dzsap_keyboardSetup),
/* harmony export */   "handle_keypresses": () => (/* binding */ handle_keypresses)
/* harmony export */ });
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../configs/_constants */ "../source/audioplayer/configs/_constants.js");


const dzsap_generate_keyboard_controls = function () {
  let keyboard_controls = {
    'play_trigger_step_back': 'off'
    , 'step_back_amount': '5'
    , 'step_back': '37'
    , 'step_forward': '39'
    , 'sync_players_goto_next': ''
    , 'sync_players_goto_prev': ''
    , 'pause_play': '32'
    , 'show_tooltips': 'off'
  }


  const $keyboardControlsInfo = jQuery(_configs_constants__WEBPACK_IMPORTED_MODULE_0__.DZSAP_SCRIPT_SELECTOR_KEYBOARD);
  if ($keyboardControlsInfo.length) {
    window.dzsap_keyboard_controls = JSON.parse($keyboardControlsInfo.html());
  }

  if (window.dzsap_keyboard_controls) {
    keyboard_controls = jQuery.extend(keyboard_controls, window.dzsap_keyboard_controls);
  }

  keyboard_controls.step_back_amount = Number(keyboard_controls.step_back_amount);


  return keyboard_controls;
};


function handle_keypresses(e) {

  if (window.dzsap_isTextFieldFocused) {
    return;
  }


  function isKeyPressed(checkKeyCode) {
    let isKeyPressed = false;
    if (checkKeyCode.indexOf('ctrl+') > -1) {
      if (e.ctrlKey) {
        checkKeyCode = checkKeyCode.replace('ctrl+', '');
        if (e.keyCode === Number(checkKeyCode)) {
          isKeyPressed = true;
        }
      }
    } else {
      if (e.keyCode === Number(checkKeyCode)) {
        isKeyPressed = true;
      }
    }
    return isKeyPressed;
  }

  var $ = jQuery;

  const keyboard_controls = $.extend({}, dzsap_generate_keyboard_controls());


  if (dzsap_currplayer_focused && dzsap_currplayer_focused.api_pause_media) {

    if (isKeyPressed(keyboard_controls.pause_play)) {
      if (!$(dzsap_currplayer_focused).hasClass('comments-writer-active')) {
        if ($(dzsap_currplayer_focused).hasClass('is-playing')) {
          dzsap_currplayer_focused.api_pause_media();
        } else {
          dzsap_currplayer_focused.api_play_media();
        }

        if (window.dzsap_mouseover) {
          e.preventDefault();
          return false;
        }
      }
    }

    if (isKeyPressed(keyboard_controls.step_back)) {
      dzsap_currplayer_focused.api_step_back(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.step_forward)) {
      dzsap_currplayer_focused.api_step_forward(keyboard_controls.step_back_amount);
    }

    if (isKeyPressed(keyboard_controls.sync_players_goto_next)) {
      dzsap_currplayer_focused.api_sync_players_goto_next();
    }


    if (isKeyPressed(keyboard_controls.sync_players_goto_prev)) {
      dzsap_currplayer_focused.api_sync_players_goto_prev();
    }


  }
}


/**
 * called in singleton
 */
const dzsap_keyboardSetup = () => {

  let $ = jQuery;

  window.dzsap_isTextFieldFocused = false;

  $(document).off('keydown.dzsapkeyup');
  $(document).on('keydown.dzsapkeyup', handle_keypresses);


  $(document).on('focus blur', 'textarea,input', function (e) {

    if (e.type == 'focusin' || e.type == 'focus') {

      window.dzsap_isTextFieldFocused = true;
    }
    if (e.type == 'focusout' || e.type == 'blur') {

      window.dzsap_isTextFieldFocused = false;
    }
  });


  $(document).on('keydown blur', '.zoomsounds-search-field', function (e) {
    const _t = $(e.currentTarget);

    setTimeout(function () {

      if (_t) {
        let $audioGallery = $('.audiogallery').eq(0);
        if (_t.attr('data-target')) {
          $audioGallery = $(_t.attr('data-target'));
        }
        if ($audioGallery.get(0) && $audioGallery.get(0).api_filter) {
          $audioGallery.get(0).api_filter('title', _t.val());
        }
      }
    }, 100);

  });
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!****************************************************************!*\
  !*** ../source/audioplayer/dzsap-wave-generator.sourcepack.js ***!
  \****************************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./js_common/_esjquery */ "../source/audioplayer/js_common/_esjquery.js");
/* harmony import */ var _configs_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./configs/_constants */ "../source/audioplayer/configs/_constants.js");
/* harmony import */ var _jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./jsinc/_dzsap_helpers */ "../source/audioplayer/jsinc/_dzsap_helpers.js");
/*
* deprecated
 * */function _regeneratorRuntime(){"use strict";/*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */_regeneratorRuntime=function _regeneratorRuntime(){return exports};var exports={},Op=Object.prototype,hasOwn=Op.hasOwnProperty,defineProperty=Object.defineProperty||function(obj,key,desc){obj[key]=desc.value},$Symbol="function"==typeof Symbol?Symbol:{},iteratorSymbol=$Symbol.iterator||"@@iterator",asyncIteratorSymbol=$Symbol.asyncIterator||"@@asyncIterator",toStringTagSymbol=$Symbol.toStringTag||"@@toStringTag";function define(obj,key,value){return Object.defineProperty(obj,key,{value:value,enumerable:!0,configurable:!0,writable:!0}),obj[key]}try{define({},"")}catch(err){define=function define(obj,key,value){return obj[key]=value}}function wrap(innerFn,outerFn,self,tryLocsList){var protoGenerator=outerFn&&outerFn.prototype instanceof Generator?outerFn:Generator,generator=Object.create(protoGenerator.prototype),context=new Context(tryLocsList||[]);return defineProperty(generator,"_invoke",{value:makeInvokeMethod(innerFn,self,context)}),generator}function tryCatch(fn,obj,arg){try{return{type:"normal",arg:fn.call(obj,arg)}}catch(err){return{type:"throw",arg:err}}}exports.wrap=wrap;var ContinueSentinel={};function Generator(){}function GeneratorFunction(){}function GeneratorFunctionPrototype(){}var IteratorPrototype={};define(IteratorPrototype,iteratorSymbol,function(){return this});var getProto=Object.getPrototypeOf,NativeIteratorPrototype=getProto&&getProto(getProto(values([])));NativeIteratorPrototype&&NativeIteratorPrototype!==Op&&hasOwn.call(NativeIteratorPrototype,iteratorSymbol)&&(IteratorPrototype=NativeIteratorPrototype);var Gp=GeneratorFunctionPrototype.prototype=Generator.prototype=Object.create(IteratorPrototype);function defineIteratorMethods(prototype){["next","throw","return"].forEach(function(method){define(prototype,method,function(arg){return this._invoke(method,arg)})})}function AsyncIterator(generator,PromiseImpl){function invoke(method,arg,resolve,reject){var record=tryCatch(generator[method],generator,arg);if("throw"!==record.type){var result=record.arg,value=result.value;return value&&"object"==_typeof(value)&&hasOwn.call(value,"__await")?PromiseImpl.resolve(value.__await).then(function(value){invoke("next",value,resolve,reject)},function(err){invoke("throw",err,resolve,reject)}):PromiseImpl.resolve(value).then(function(unwrapped){result.value=unwrapped,resolve(result)},function(error){return invoke("throw",error,resolve,reject)})}reject(record.arg)}var previousPromise;defineProperty(this,"_invoke",{value:function value(method,arg){function callInvokeWithMethodAndArg(){return new PromiseImpl(function(resolve,reject){invoke(method,arg,resolve,reject)})}return previousPromise=previousPromise?previousPromise.then(callInvokeWithMethodAndArg,callInvokeWithMethodAndArg):callInvokeWithMethodAndArg()}})}function makeInvokeMethod(innerFn,self,context){var state="suspendedStart";return function(method,arg){if("executing"===state)throw new Error("Generator is already running");if("completed"===state){if("throw"===method)throw arg;return doneResult()}for(context.method=method,context.arg=arg;;){var delegate=context.delegate;if(delegate){var delegateResult=maybeInvokeDelegate(delegate,context);if(delegateResult){if(delegateResult===ContinueSentinel)continue;return delegateResult}}if("next"===context.method)context.sent=context._sent=context.arg;else if("throw"===context.method){if("suspendedStart"===state)throw state="completed",context.arg;context.dispatchException(context.arg)}else"return"===context.method&&context.abrupt("return",context.arg);state="executing";var record=tryCatch(innerFn,self,context);if("normal"===record.type){if(state=context.done?"completed":"suspendedYield",record.arg===ContinueSentinel)continue;return{value:record.arg,done:context.done}}"throw"===record.type&&(state="completed",context.method="throw",context.arg=record.arg)}}}function maybeInvokeDelegate(delegate,context){var methodName=context.method,method=delegate.iterator[methodName];if(undefined===method)return context.delegate=null,"throw"===methodName&&delegate.iterator.return&&(context.method="return",context.arg=undefined,maybeInvokeDelegate(delegate,context),"throw"===context.method)||"return"!==methodName&&(context.method="throw",context.arg=new TypeError("The iterator does not provide a '"+methodName+"' method")),ContinueSentinel;var record=tryCatch(method,delegate.iterator,context.arg);if("throw"===record.type)return context.method="throw",context.arg=record.arg,context.delegate=null,ContinueSentinel;var info=record.arg;return info?info.done?(context[delegate.resultName]=info.value,context.next=delegate.nextLoc,"return"!==context.method&&(context.method="next",context.arg=undefined),context.delegate=null,ContinueSentinel):info:(context.method="throw",context.arg=new TypeError("iterator result is not an object"),context.delegate=null,ContinueSentinel)}function pushTryEntry(locs){var entry={tryLoc:locs[0]};1 in locs&&(entry.catchLoc=locs[1]),2 in locs&&(entry.finallyLoc=locs[2],entry.afterLoc=locs[3]),this.tryEntries.push(entry)}function resetTryEntry(entry){var record=entry.completion||{};record.type="normal",delete record.arg,entry.completion=record}function Context(tryLocsList){this.tryEntries=[{tryLoc:"root"}],tryLocsList.forEach(pushTryEntry,this),this.reset(!0)}function values(iterable){if(iterable){var iteratorMethod=iterable[iteratorSymbol];if(iteratorMethod)return iteratorMethod.call(iterable);if("function"==typeof iterable.next)return iterable;if(!isNaN(iterable.length)){var i=-1,next=function next(){for(;++i<iterable.length;)if(hasOwn.call(iterable,i))return next.value=iterable[i],next.done=!1,next;return next.value=undefined,next.done=!0,next};return next.next=next}}return{next:doneResult}}function doneResult(){return{value:undefined,done:!0}}return GeneratorFunction.prototype=GeneratorFunctionPrototype,defineProperty(Gp,"constructor",{value:GeneratorFunctionPrototype,configurable:!0}),defineProperty(GeneratorFunctionPrototype,"constructor",{value:GeneratorFunction,configurable:!0}),GeneratorFunction.displayName=define(GeneratorFunctionPrototype,toStringTagSymbol,"GeneratorFunction"),exports.isGeneratorFunction=function(genFun){var ctor="function"==typeof genFun&&genFun.constructor;return!!ctor&&(ctor===GeneratorFunction||"GeneratorFunction"===(ctor.displayName||ctor.name))},exports.mark=function(genFun){return Object.setPrototypeOf?Object.setPrototypeOf(genFun,GeneratorFunctionPrototype):(genFun.__proto__=GeneratorFunctionPrototype,define(genFun,toStringTagSymbol,"GeneratorFunction")),genFun.prototype=Object.create(Gp),genFun},exports.awrap=function(arg){return{__await:arg}},defineIteratorMethods(AsyncIterator.prototype),define(AsyncIterator.prototype,asyncIteratorSymbol,function(){return this}),exports.AsyncIterator=AsyncIterator,exports.async=function(innerFn,outerFn,self,tryLocsList,PromiseImpl){void 0===PromiseImpl&&(PromiseImpl=Promise);var iter=new AsyncIterator(wrap(innerFn,outerFn,self,tryLocsList),PromiseImpl);return exports.isGeneratorFunction(outerFn)?iter:iter.next().then(function(result){return result.done?result.value:iter.next()})},defineIteratorMethods(Gp),define(Gp,toStringTagSymbol,"Generator"),define(Gp,iteratorSymbol,function(){return this}),define(Gp,"toString",function(){return"[object Generator]"}),exports.keys=function(val){var object=Object(val),keys=[];for(var key in object)keys.push(key);return keys.reverse(),function next(){for(;keys.length;){var key=keys.pop();if(key in object)return next.value=key,next.done=!1,next}return next.done=!0,next}},exports.values=values,Context.prototype={constructor:Context,reset:function reset(skipTempReset){if(this.prev=0,this.next=0,this.sent=this._sent=undefined,this.done=!1,this.delegate=null,this.method="next",this.arg=undefined,this.tryEntries.forEach(resetTryEntry),!skipTempReset)for(var name in this)"t"===name.charAt(0)&&hasOwn.call(this,name)&&!isNaN(+name.slice(1))&&(this[name]=undefined)},stop:function stop(){this.done=!0;var rootRecord=this.tryEntries[0].completion;if("throw"===rootRecord.type)throw rootRecord.arg;return this.rval},dispatchException:function dispatchException(exception){if(this.done)throw exception;var context=this;function handle(loc,caught){return record.type="throw",record.arg=exception,context.next=loc,caught&&(context.method="next",context.arg=undefined),!!caught}for(var i=this.tryEntries.length-1;i>=0;--i){var entry=this.tryEntries[i],record=entry.completion;if("root"===entry.tryLoc)return handle("end");if(entry.tryLoc<=this.prev){var hasCatch=hasOwn.call(entry,"catchLoc"),hasFinally=hasOwn.call(entry,"finallyLoc");if(hasCatch&&hasFinally){if(this.prev<entry.catchLoc)return handle(entry.catchLoc,!0);if(this.prev<entry.finallyLoc)return handle(entry.finallyLoc)}else if(hasCatch){if(this.prev<entry.catchLoc)return handle(entry.catchLoc,!0)}else{if(!hasFinally)throw new Error("try statement without catch or finally");if(this.prev<entry.finallyLoc)return handle(entry.finallyLoc)}}}},abrupt:function abrupt(type,arg){for(var i=this.tryEntries.length-1;i>=0;--i){var entry=this.tryEntries[i];if(entry.tryLoc<=this.prev&&hasOwn.call(entry,"finallyLoc")&&this.prev<entry.finallyLoc){var finallyEntry=entry;break}}finallyEntry&&("break"===type||"continue"===type)&&finallyEntry.tryLoc<=arg&&arg<=finallyEntry.finallyLoc&&(finallyEntry=null);var record=finallyEntry?finallyEntry.completion:{};return record.type=type,record.arg=arg,finallyEntry?(this.method="next",this.next=finallyEntry.finallyLoc,ContinueSentinel):this.complete(record)},complete:function complete(record,afterLoc){if("throw"===record.type)throw record.arg;return"break"===record.type||"continue"===record.type?this.next=record.arg:"return"===record.type?(this.rval=this.arg=record.arg,this.method="return",this.next="end"):"normal"===record.type&&afterLoc&&(this.next=afterLoc),ContinueSentinel},finish:function finish(finallyLoc){for(var i=this.tryEntries.length-1;i>=0;--i){var entry=this.tryEntries[i];if(entry.finallyLoc===finallyLoc)return this.complete(entry.completion,entry.afterLoc),resetTryEntry(entry),ContinueSentinel}},catch:function _catch(tryLoc){for(var i=this.tryEntries.length-1;i>=0;--i){var entry=this.tryEntries[i];if(entry.tryLoc===tryLoc){var record=entry.completion;if("throw"===record.type){var thrown=record.arg;resetTryEntry(entry)}return thrown}}throw new Error("illegal catch attempt")},delegateYield:function delegateYield(iterable,resultName,nextLoc){return this.delegate={iterator:values(iterable),resultName:resultName,nextLoc:nextLoc},"next"===this.method&&(this.arg=undefined),ContinueSentinel}},exports}function asyncGeneratorStep(gen,resolve,reject,_next,_throw,key,arg){try{var info=gen[key](arg);var value=info.value}catch(error){reject(error);return}if(info.done){resolve(value)}else{Promise.resolve(value).then(_next,_throw)}}function _asyncToGenerator(fn){return function(){var self=this,args=arguments;return new Promise(function(resolve,reject){var gen=fn.apply(self,args);function _next(value){asyncGeneratorStep(gen,resolve,reject,_next,_throw,"next",value)}function _throw(err){asyncGeneratorStep(gen,resolve,reject,_next,_throw,"throw",err)}_next(undefined)})}}function _typeof(obj){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(obj){return typeof obj}:function(obj){return obj&&"function"==typeof Symbol&&obj.constructor===Symbol&&obj!==Symbol.prototype?"symbol":typeof obj},_typeof(obj)}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function")}}function _defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,_toPropertyKey(descriptor.key),descriptor)}}function _createClass(Constructor,protoProps,staticProps){if(protoProps)_defineProperties(Constructor.prototype,protoProps);if(staticProps)_defineProperties(Constructor,staticProps);Object.defineProperty(Constructor,"prototype",{writable:false});return Constructor}function _toPropertyKey(arg){var key=_toPrimitive(arg,"string");return _typeof(key)==="symbol"?key:String(key)}function _toPrimitive(input,hint){if(_typeof(input)!=="object"||input===null)return input;var prim=input[Symbol.toPrimitive];if(prim!==undefined){var res=prim.call(input,hint||"default");if(_typeof(res)!=="object")return res;throw new TypeError("@@toPrimitive must return a primitive value.")}return(hint==="string"?String:Number)(input)}var WaveGenerator=/*#__PURE__*/function(){function WaveGenerator($waveGenerator_){_classCallCheck(this,WaveGenerator);this.initOptions={};this.dataSource="";this.$waveGenerator_=$waveGenerator_;this.$waveGenerator=(0,_js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__.$es)($waveGenerator_);this.$wavedataField=null;this.$status=null;this.init()}_createClass(WaveGenerator,[{key:"init",value:function init(){var finalOptions={};var defaultOptions=Object.assign({source:"",selectorWaveData:""},{});finalOptions=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_2__.convertPluginOptionsToFinalOptions)(this.$waveGenerator_,defaultOptions,null,"data-options",_js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__.$es);var selfClass=this;selfClass.initOptions=finalOptions;selfClass.$status=selfClass.$waveGenerator.find(".dzsap-wave-generator--status");if(selfClass.initOptions.source){selfClass.dataSource=selfClass.initOptions.source}if(selfClass.initOptions.selectorWaveData){selfClass.$wavedataField=(0,_js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__.$es)(selfClass.initOptions.selectorWaveData)}selfClass.$status.html("generating waveforms");if(selfClass.dataSource){promise_waveGenerate(selfClass.$waveGenerator.find(".dzsap-wave-generator--wave").get(0),selfClass.dataSource).then(function(resolve){selfClass.$status.html("");try{if(resolve.pcm_data){if(selfClass.$wavedataField){selfClass.$wavedataField.val(resolve.pcm_data);if(dzsap_settings.dzsap_wave_generate_auto==="on"&&get_query_arg(window.location.href,"dzsap_wave_generate_auto")==="on"){window.dzsap_admin_waveforms_submitPcmData(document.querySelector(".track-waveform-meta"))}}}}catch(err){console.log(err)}})}}}]);return WaveGenerator}();window.es_document_ready(function(){(0,_js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__.$es)(".dzsap-wave-generator.auto-init").each(function($el){var generator=new WaveGenerator($el.get(0))})});function get_query_arg(purl,key){if(purl.indexOf(key+"=")>-1){var regexS="[?&]"+key+"=.+";var regex=new RegExp(regexS);var regtest=regex.exec(purl);if(regtest!=null){var splitterS=regtest[0];if(splitterS.indexOf("&")>-1){var aux=splitterS.split("&");splitterS=aux[1]}var splitter=splitterS.split("=");return splitter[1]}}}window.dzsap_generating_pcm=false;var promise_waveGenerate=/*#__PURE__*/function(){var _ref=_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee2($container_,sourceMp3,pargs){var margs,self;return _regeneratorRuntime().wrap(function _callee2$(_context2){while(1)switch(_context2.prev=_context2.next){case 0:margs=Object.assign({called_from:"default",preferBackendPeaks:true,wavesurfer_pcm_length:200},pargs);self=this;return _context2.abrupt("return",new Promise(function(resolvePcm,rejectPcm){function wavesurfer_renderPcm(){return _wavesurfer_renderPcm.apply(this,arguments)}function _wavesurfer_renderPcm(){_wavesurfer_renderPcm=_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee(){var asyncRenderPcm;return _regeneratorRuntime().wrap(function _callee$(_context){while(1)switch(_context.prev=_context.next){case 0:asyncRenderPcm=function _asyncRenderPcm(resolve,reject){// -- make sure we are generating only once
if(window.dzsap_generating_pcm){setTimeout(function(){asyncRenderPcm(resolve,reject)},1000);return false}window.dzsap_generating_pcm=true;var wavesurferConId="wavesurfer_"+Math.ceil(Math.random()*10000);if(!$container_){$container_=document.body}(0,_js_common_esjquery__WEBPACK_IMPORTED_MODULE_0__.$es)($container_).append("<div id=\"".concat(wavesurferConId,"\"></div>"));var ctx=document.createElement("canvas").getContext("2d");var linGrad=ctx.createLinearGradient(0,64,0,200);linGrad.addColorStop(0.5,"rgb(107,95,95)");linGrad.addColorStop(0.5,"rgb(119,115,115)");var wavesurfer=WaveSurfer.create({container:"#"+wavesurferConId,normalize:true,pixelRatio:1,waveColor:linGrad,progressColor:"hsla(200, 100%, 30%, 0.5)",cursorColor:"#fff",// This parameter makes the waveform look like SoundCloud's player
barWidth:2});wavesurfer.on("loading",function(percents){$container_.parentNode.querySelector(".dzsap-wave-generator--status").innerHTML=percents+"%"});try{wavesurfer.load(sourceMp3)}catch(err){console.log("[wavesurfer] WAVE SURFER NO LOAD")}wavesurfer.on("ready",function(){var accuracy=100;var pcmDataArr=[];var pcmDataString="";if(wavesurfer&&wavesurfer.exportPCM){if(margs.preferBackendPeaks!==true){pcmDataArr=wavesurfer.exportPCM(margs.wavesurfer_pcm_length,accuracy,true)}var isPcmDataArrValid=false;console.log("pcmDataString - ",pcmDataString);try{pcmDataArr=JSON.parse(pcmDataString);for(var i in pcmDataArr){if(pcmDataArr[i]!==null&&pcmDataArr[i]!==0&&pcmDataArr[i]!=="0"){isPcmDataArrValid=true;break}}}catch(err){isPcmDataArrValid=false}if(!isPcmDataArrValid){pcmDataArr=wavesurfer.backend.getPeaks(margs.wavesurfer_pcm_length,0,margs.wavesurfer_pcm_length)}for(var _i in pcmDataArr){if(pcmDataArr[_i]!==null&&pcmDataArr[_i]!==0&&pcmDataArr[_i]!=="0"){pcmDataArr[_i]=Math.abs(Number(Number(pcmDataArr[_i]).toFixed(2)))}}}else{pcmDataArr=(0,_jsinc_dzsap_helpers__WEBPACK_IMPORTED_MODULE_2__.generateFakeArrayForPcm)()}pcmDataString=JSON.stringify(pcmDataArr);resolve({resolve_type:"success",pcm_data:pcmDataString})});wavesurfer.on("error",function(err,err2){console.log("err - ",err);reject({error_type:"wavesurfer_error",error_message:err})});setTimeout(function(){reject({error_type:"wavesurfer_timeout",error_message:"timeout"})},_configs_constants__WEBPACK_IMPORTED_MODULE_1__.WAVESURFER_MAX_TIMEOUT)};return _context.abrupt("return",new Promise(function(resolve,reject){asyncRenderPcm(resolve,reject)}));case 2:case"end":return _context.stop();}},_callee)}));return _wavesurfer_renderPcm.apply(this,arguments)}wavesurfer_renderPcm().then(function(responsePcm){console.log("%c [dzsap] [wave] success while generating pcm - ",_configs_constants__WEBPACK_IMPORTED_MODULE_1__.DEBUG_STYLE_PLAY_FUNCTIONS,responsePcm);resolvePcm(responsePcm)}).catch(function(err){var default_pcm=[];for(var i3=0;i3<200;i3++){default_pcm[i3]=Math.abs(Number(Math.random()).toFixed(2))}default_pcm=JSON.stringify(default_pcm);console.log("%c [dzsap] [wave] error while generating pcm - ",_configs_constants__WEBPACK_IMPORTED_MODULE_1__.DEBUG_STYLE_PLAY_FUNCTIONS,err,err.error_message);resolvePcm(default_pcm)})}));case 3:case"end":return _context2.stop();}},_callee2,this)}));return function promise_waveGenerate(_x,_x2,_x3){return _ref.apply(this,arguments)}}();
})();

/******/ })()
;
//# sourceMappingURL=dzsap-wave-generator.js.map