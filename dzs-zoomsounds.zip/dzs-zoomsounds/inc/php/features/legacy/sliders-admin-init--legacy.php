<?php



$new_term_id = '';
$new_term = null;
$original_slug = '';


if (isset($sliderObj['settings'])) {

  $sliderSettings = $sliderObj['settings'];
  $reference_term_name = $sliderSettings['id'];
  $reference_term_slug = $sliderSettings['id'];

  $original_name = $reference_term_name;
  $original_slug = $reference_term_slug;


  $new_term_slug = $reference_term_slug;
  $new_term_name = $reference_term_name;


  $ind = 1;
  $breaker = 100;


  $term = term_exists($new_term_slug, $taxonomyName);
  if ($term !== 0 && $term !== null) {
    while (1) {

      $term = term_exists($new_term_slug, $taxonomyName);
      if ($term !== 0 && $term !== null) {

        $ind++;
        $new_term_slug = $original_slug . '-' . $ind;
      } else {
        break;
      }

      $breaker--;

      if ($breaker < 0) {
        break;
      }
    }

    $ind++;
    $new_term_name = $original_name . '-' . $ind;
    $new_term_slug = $original_slug . '-' . $ind;
  }


  $new_term = wp_insert_term(
    $new_term_name, // the term
    $taxonomyName, // the taxonomy
    array(
      'slug' => $new_term_slug,
    )
  );


  if (is_array($new_term)) {

    $new_term_id = $new_term['term_id'];
  } else {
    error_log(' .. the name is ' . $new_term_name);
    error_log(print_r($new_term, true));
  }


  $new_term_id = null;

  if (isset($new_term['term_id'])) {
    $new_term_id = $new_term['term_id'];
  }


  if($new_term_id){

    $term_meta = array_merge(array(), $sliderSettings);

    unset($term_meta['items']);


    update_option("taxonomy_$new_term_id", $term_meta);

    foreach ($sliderObj as $lab => $songItem) {
      if ($lab === 'settings') {
        continue;
      } else {
        // -- item

        $argsForImport = array_merge(array(), $songItem);



        $argsForImport['term'] = $new_term_slug;
        $argsForImport['taxonomy'] = $taxonomyName;

        $source = $songItem['source'];
        $artistName = '';
        $songTitle = $original_slug . '-' . $lab;
        if(isset($songItem['menu_songname'])){
          $songTitle = $songItem['menu_songname'];
        }
        if(isset($songItem['menu_artistname'])){
          $artistName = $songItem['menu_artistname'];
        }
        if(!$source){
          if(isset($songItem['linktomediafile']) && $songItem['linktomediafile']){
            $source = $songItem['linktomediafile'];
          }
        }

        if(isset($songItem['thumb']) && $songItem['thumb']){
          $argsForImport[DZSAP_META_ITEM_OPTION_PREFIX.'thumb'] = $songItem['thumb'];
        }

        $argsForImport[DZSAP_META_ITEM_OPTION_PREFIX.'source'] = $source;
        $argsForImport['post_name'] = $songTitle;
        $argsForImport['post_title'] = $songTitle;
        $argsForImport[DZSAP_META_OPTION_PREFIX.'artistname'] = $artistName;






        foreach ($dzsap->options_item_meta as $oim) {
          if (isset($oim['name'])) {
            $long_name = $oim['name'];
            $short_name = str_replace(DZSAP_META_OPTION_PREFIX, '', $oim['name']);
            if (isset($argsForImport[$short_name])) {
              $argsForImport[$long_name] = $argsForImport[$short_name];
            }
          }
        }


        $dzsap->ajax_functions->import_demo_insert_post_complete($argsForImport);

      }


    }
  }

}

