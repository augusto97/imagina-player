<?php

if (!function_exists('dzsap_sanitize_param_list')) {

  function dzsap_sanitize_param_list($paramIds): string {

    $ids = explode(',', $paramIds);
    $ids = array_map('sanitize_text_field', $ids);
    return implode(',', $ids);
  }
}
