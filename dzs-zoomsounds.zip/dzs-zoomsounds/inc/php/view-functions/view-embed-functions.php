<?php
function dzsap_view_embed_init_listeners(){




  add_action('wp_enqueue_scripts', 'dzsap_view_embed_handle_wp_enqueue_scripts', 500);
}

function dzsap_view_embed_handle_wp_enqueue_scripts(){

  if (isset($_GET['action'])) {
    if ($_GET['action'] == DZSAP_VIEW_EMBED_CODE) {
      DZSZoomSoundsHelper::enqueueMainScrips();

      wp_enqueue_style('dzsap-shortcode-zoomsounds-embed', DZSAP_BASE_URL.'inc/style/shortcodes/dzs-zoomsounds-embed.css');
      wp_enqueue_script('dzsap-shortcode-zoomsounds-embed', DZSAP_BASE_URL.'inc/js/shortcodes/zoomsounds-embed.js');
    }
  }
}



/**
 * user for embed - prints the container
 * @throws Exception
 */
function dzsap_view_embed_generateHtml() {

  global $dzsap;





  echo '<div class="zoomsounds-embed-con">';



  $type = isset($_GET['type']) ? sanitize_key($_GET['type']) : '';


  // Only allow known types
  if (!in_array($type, array('gallery', 'playlist', 'player'), true)) {
    echo 'Invalid type.';
    echo '</div>';
    return;
  }


  $shortcodePlayerAtts = array(
    'embedded' => 'on',
  );


  // Optional db param
  if (isset($_GET['db'])) {
    $shortcodePlayerAtts['db'] = sanitize_text_field($_GET['db']);
  }



  if ($type === 'gallery') {
    if (!isset($_GET['id'])) {
      echo 'Missing ID.';
      echo '</div>';
      return;
    }

    $shortcodePlayerAtts['id'] = sanitize_text_field($_GET['id']);


    echo $dzsap->classView->shortcode_playlist_main($shortcodePlayerAtts);

  }
  if ($type === 'playlist') {
    // Sanitize CSV list
    if (isset($_GET['ids'])) {
      $shortcodePlayerAtts['ids'] = dzsap_sanitize_param_list($_GET['ids']);
    }

    echo $dzsap->classView->shortcode_playlist_main($shortcodePlayerAtts);

  }


  if ($type === 'player') {


    if (!isset($_GET['margs'])) {
      echo 'Missing args.';
      echo '</div>';
      return;
    }

    $raw = $_GET['margs'];
    $decoded = base64_decode($raw, true); // strict mode

    if ($decoded === false) {
      echo 'Invalid base64.';
      echo '</div>';
      return;
    }

    $parsed = json_decode(stripslashes($decoded), true);
    if (!is_array($parsed)) {
      echo 'Invalid JSON.';
      echo '</div>';
      return;
    }





    // Sanitize all shortcode args
    $sanitized_margs = array();
    foreach ($parsed as $key => $val) {
      $sanitized_key = sanitize_key($key);
      if (is_scalar($val)) {
        $sanitized_margs[$sanitized_key] = sanitize_text_field($val);
      }
    }

    $sanitized_margs['embedded'] = 'on';
    $sanitized_margs['extra_classes'] = 'test';
    $sanitized_margs['called_from'] = 'embed';



    echo $dzsap->classView->shortcode_player($sanitized_margs);

  }
  echo '</div>';
}
