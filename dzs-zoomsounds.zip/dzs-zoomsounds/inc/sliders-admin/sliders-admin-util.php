<?php

function dzs_sliders_admin_generate_item($po, $translationDomain, $thumbMetaKey, $metaCategoriesLng) {


  $fout = '';
  $thumb = '';
  $thumb_from_meta = '';
  // -- we need real location, not insert-id
  $struct_uploader = '<div class="dzs-wordpress-uploader "><a rel="nofollow" href="#" class="button-secondary">' . esc_html__('Upload', $translationDomain) . '</a></div>';


  $po_id = '';
  if ($po && is_int($po->ID)) {

    $thumb = DZSZoomSoundsHelper::get_post_thumb_src($po->ID);

    $po_id = $po->ID;




    $thumb_from_meta = get_post_meta($po->ID, $thumbMetaKey, true);
  }

  if ($thumb_from_meta) {

    $thumb = $thumb_from_meta;
  }

  $thumb_url = '';
  if ($thumb) {
    $thumb_url = DZSZoomSoundsHelper::getImageSourceFromId($thumb);
  }


  if ($po_id) {

    $fout .= '<div class="slider-item dzstooltip-con for-click';

    if ($po && $po->ID == 'placeholder') {
      $fout .= ' slider-item--placeholder';
    }

    $fout .= '" data-id="' . $po->ID . '">';





    $fout .= '<div class="divimage" style="background-image:url(' . $thumb_url . ');"></div>';
    $fout .= '<div class="slider-item--title" >' . $po->post_title . '</div>';

    $fout .= '<div class="delete-btn item-control-btn"><i class="fa fa-times-circle-o"></i></div>
<div class="clone-item-btn item-control-btn"><i class="fa fa-clone"></i></div>
<div class="dzstooltip dzstooltip--sliders-admin   arrow-top talign-start style-rounded color-dark-light ">
<div class="dzstooltip--selector-top"></div>
<div class="dzstooltip--inner">
<div class="dzstooltip--content">';


    $fout .= '<div class="dzs-tabs dzs-tabs-meta-item  skin-default " data-options=\'{ "design_tabsposition" : "top","design_transition": "fade","design_tabswidth": "default","toggle_breakpoint" : "200","settings_appendWholeContent": "true","toggle_type": "accordion"}
\' style=\'padding: 0;\'>
<div class="dzs-tab-tobe">
<div class="tab-menu ">' . esc_html__("General", $translationDomain) . '
    </div>
<div class="tab-content tab-content-item-meta-cat-main">
' . dzs_sliders_admin_generate_item_meta_cat('main', $po) . '
    </div>
    </div>';


    foreach ($metaCategoriesLng as $lab => $val) {
      ob_start();
      ?>
      <div class="dzs-tab-tobe">
      <div class="tab-menu ">
        <?php
        echo($val);
        ?>
      </div>
      <div class="tab-content tab-content-cat-<?php echo $lab; ?>">


        <?php
        echo dzs_sliders_admin_generate_item_meta_cat($lab, $po);
        ?>


      </div>
      </div><?php
      $fout .= ob_get_clean();
    }

    $fout .= '</div>';// -- end tabs


    $fout .= '</div>';
    $fout .= '</div>';
    $fout .= '</div>';
    $fout .= '</div>';
  }

  return $fout;
}


function dzs_sliders_admin_generate_item_meta_cat($categoryKey, $po, $pargs = array()) {

  // -- generate options for sliders admin category
  global $dzsap;


  $margs = array(

    'for_shortcode_generator' => false,
    'for_item_meta' => false,
  );

  $margs = array_merge($margs, $pargs);

  $fout = '';
  // -- we need real location, not insert-id
  $struct_uploader = '<div class="dzs-wordpress-uploader ">
<a rel="nofollow" href="#" class="button-secondary">' . esc_html__('Upload', DZSAP_ID) . '</a>
</div>';


  // -- generate item category ( for sliders admin )
  foreach ($dzsap->options_item_meta as $lab => $optionItem) {


    $optionItem = array_merge(array(
      'category' => '',
      'no_preview' => '',
      'it_is_for' => 'item_meta',
      'input_extra_classes' => '',
    ), $optionItem);



    // -- some sanitizing
    if ($optionItem['type'] == 'image') {
      $optionItem['type'] = 'attach';
    }


    if (isset($optionItem['options'])) {
      if (isset($optionItem['choices']) == false) {
        $optionItem['choices'] = $optionItem['options'];
      }
    }

    if (!($optionItem['category'] == $categoryKey)) {
      if ($categoryKey == 'main') {
        if ($optionItem['category'] == '') {
        } else {
          continue;
        }
      } else {
        continue;
      }
    }

    if (dzs_is_option_for_this($optionItem, 'shortcode_generator')) {
      if ($margs['for_shortcode_generator'] == false) {
        continue;
      }
    }

    if (dzs_is_option_for_this($optionItem, 'for_item_meta_only')) {
      if ($margs['for_item_meta'] == false) {
        continue;
      }
    }


    if ($optionItem['type'] == 'dzs_row') {
      $fout .= '<section class="dzs-row">';
      continue;

    }
    if ($optionItem['type'] == 'dzs_col_md_6') {
      $fout .= '<section class="dzs-col-md-6">';
      continue;

    }
    if ($optionItem['type'] == 'dzs_col_md_12') {
      $fout .= '<section class="dzs-col-md-6">';
      continue;

    }

    if ($optionItem['type'] == 'dzs_row_end') {
      $fout .= '</section><!--dzs row end-->';
      continue;

    }
    if ($optionItem['type'] == 'dzs_col_md_6_end') {
      $fout .= '</section><!--dzs dzs_col_md_6_end end-->';
      continue;

    }
    if ($optionItem['type'] == 'dzs_col_md_12_end') {
      $fout .= '</section><!--dzs dzs_col_md_12_end end-->';
      continue;

    }
    if ($optionItem['type'] == 'custom_html') {
      $fout .= $optionItem['custom_html'];
      continue;

    }


    $fout .= '<div class="setting ';
    $option_name = $optionItem['name'];



    if ($optionItem['type'] == 'attach') {
      $fout .= ' setting-upload';
    }

    $fout .= '" ';

    $fout .= ' data-option-name="' . $option_name . '"';

    if (isset($optionItem['dependency']) && $optionItem['dependency']) {
      $fout .= ' data-dependency=\'' . json_encode($optionItem['dependency']) . '\'';
    }


    $fout .= '>';


    if ((strpos($option_name, 'item_source') || $option_name == 'source')) {



      $lab_aux = 'dzsap_meta_source_attachment_id';
      $val_aux = '';
      if ($po) {

        $val_aux = get_post_meta($po->ID, $lab_aux, true);
      }


      $class = 'setting-field shortcode-field';

      if ($margs['for_shortcode_generator']) {
        $class .= ' insert-id';
      }

      // -- source

      $class .= $optionItem['input_extra_classes'];

      $fout .= DZSHelpers::generate_input_text($lab_aux, array(
        'class' => $class,
        'seekval' => $val_aux,
        'input_type' => 'hidden',
      ));
    }

    $fout .= '<h5 class="setting-label setting-label-item-meta-cat">' . $optionItem['title'] . '</h5>';


    if ($optionItem['type'] == 'attach') {


      if ($optionItem['no_preview'] != 'on') {
        $fout .= '<span class="uploader-preview"></span>';
      }
    }


    if ($margs['for_shortcode_generator']) {
      $option_name = str_replace('dzsap_meta_item_', '', $option_name);
      $option_name = str_replace('dzsap_meta_', '', $option_name);

      if ($option_name == 'the_post_title') {
        $option_name = 'songname';
      }
    }

    $extraattr_input = '';

    if (isset($optionItem['extraattr_input']) && $optionItem['extraattr_input']) {
      $extraattr_input .= $optionItem['extraattr_input'];
    }

    $val = '';

    if ($po && is_int($po->ID)) {

      $val = get_post_meta($po->ID, $option_name, true);
    }

    if ($po && $option_name == 'the_post_title') {
      $val = $po->post_title;
    }
    if ($po && $option_name == 'post_content') {
      $val = $po->post_content;
    }

    $class = 'setting-field medium';

    if ($optionItem['type'] == 'attach') {
      $class .= ' uploader-target';
    }

    if ($margs['for_shortcode_generator']) {
      $class .= ' shortcode-field';
    }


    $class .= $optionItem['input_extra_classes'];


    if ($optionItem['type'] == 'attach') {


      if (isset($optionItem['upload_type']) && $optionItem['upload_type']) {
        $class .= ' upload-type-' . $optionItem['upload_type'];
      }
      $class .= 'setting-field shortcode-field';

      if ($option_name == 'source' && $margs['for_shortcode_generator']) {
        $class .= ' insert-id';
      }

      $fout .= DZSHelpers::generate_input_text($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($optionItem['type'] == 'text') {
      $fout .= DZSHelpers::generate_input_text($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($optionItem['type'] == 'textarea') {
      $fout .= DZSHelpers::generate_input_textarea($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'extraattr' => $extraattr_input,
      ));
    }
    if ($optionItem['type'] == 'select') {


      $class = '';

      if (isset($optionItem['class'])) {
        $class .= $optionItem['class'];
      }
      $class .= ' dzs-style-me skin-beige setting-field';

      if (isset($optionItem['select_type']) && $optionItem['select_type']) {
        $class .= ' ' . $optionItem['select_type'];
      }
      if ($margs['for_shortcode_generator']) {
        $class .= ' shortcode-field';
      }

      $fout .= DZSHelpers::generate_select($option_name, array(
        'class' => $class,
        'seekval' => $val,
        'options' => $optionItem['choices'],
        'extraattr' => $extraattr_input,
      ));

      if (isset($optionItem['select_type']) && $optionItem['select_type'] == 'opener-listbuttons') {

        $fout .= '<ul class="dzs-style-me-feeder">';

        foreach ($optionItem['choices_html'] as $oim_html) {

          $fout .= '<li>';
          $fout .= $oim_html;
          $fout .= '</li>';
        }

        $fout .= '</ul>';
      }


    }

    if ($optionItem['type'] == 'attach') {


      if (current_user_can('upload_files')) {
        $fout .= '<div class="dzs-wordpress-uploader here-uploader ">
 <a rel="nofollow" href="#" class="button-secondary';


        if (isset($optionItem['upload_btn_extra_classes']) && $optionItem['upload_btn_extra_classes']) {
          $fout .= ' ' . $optionItem['upload_btn_extra_classes'];
        }

        $fout .= '">' . esc_html__('Upload', DZSAP_ID) . '</a>
</div>';


      }

    }

    if (isset($optionItem['sidenote']) && $optionItem['sidenote']) {
      $fout .= '<div class="sidenote">' . $optionItem['sidenote'] . '</div>';
    }


    if (isset($optionItem['sidenote-2']) && $optionItem['sidenote-2']) {


      $sidenote_2_class = '';

      if (isset($optionItem['sidenote-2-class'])) {
        $sidenote_2_class = $optionItem['sidenote-2-class'];
      }
      $fout .= '<div class="sidenote-2 ' . $sidenote_2_class . '">' . $optionItem['sidenote-2'] . '</div>';
    }


    $fout .= '
                    </div>';


  }


  return $fout;
}
