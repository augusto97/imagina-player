<?php /** Silence is golden. */
