<?php
/**
 * Nonce contract shared with the free plugin's player.
 *
 * @package presto-player-pro
 */

namespace PrestoPlayer\Pro\Support;

/**
 * Nonce actions our frontend AJAX handlers accept from the player.
 *
 * Analytics sends the nonce the player fetches from free's
 * `presto_refresh_progress_nonce` endpoint. The email overlay did too through
 * free 4.3.1, but since 4.3.2 it sends the page's localized wp_rest nonce —
 * so both handlers have to accept whatever free hands out, old or new.
 */
class PlayerNonce {

	/**
	 * The scoped action free issues today.
	 *
	 * Mirrors \PrestoPlayer\Services\Player::PROGRESS_NONCE_ACTION. Free only
	 * switches to it once we announce that we verify it, so the two must stay
	 * in sync — that mismatch is what took analytics and email capture down in
	 * 4.3.1.
	 *
	 * @var string
	 */
	const SCOPED_ACTION = 'presto_player_progress';

	/**
	 * The action older free versions issue, that free falls back to for Pro
	 * builds predating SCOPED_ACTION, and that the email overlay sends on
	 * every submit since free 4.3.2 (page-localized nonce). Not retirable
	 * until free's overlay moves off it.
	 *
	 * @var string
	 */
	const LEGACY_ACTION = 'wp_rest';
}
