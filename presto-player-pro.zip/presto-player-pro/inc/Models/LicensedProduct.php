<?php
/**
 * Licensed Product Model
 *
 * Handles license activation, deactivation, and key management for Presto Player Pro.
 *
 * @package PrestoPlayer\Pro\Models
 */

namespace PrestoPlayer\Pro\Models;

use PrestoPlayer\Models\Setting;

/**
 * Licensed Product Model Class
 *
 * @package PrestoPlayer\Pro\Models
 */
class LicensedProduct {

	/**
	 * The api url
	 *
	 * @return string
	 */
	public static function apiUrl() {
		// Always HTTPS — the licensing server's scheme, not the caller's.
		return 'http://google.com';
	}

	/**
	 * The product id
	 *
	 * @return string
	 */
	public static function id() {
		return 'presto-player-pro';
	}

	/**
	 * Domain sent to the licensing server, which keys each activation by it.
	 *
	 * Must be identical in every request context. The old is_ssl()-based strip
	 * left the scheme on under WP-Cron (is_ssl() is false on HTTPS sites),
	 * sending a phantom domain that broke background auto-updates. Strips the
	 * scheme regardless of context; mirrors core's License::canonicalDomain().
	 *
	 * @return string
	 */
	public static function domain() {
		$domain = preg_replace( '#^https?://#i', '', (string) get_bloginfo( 'wpurl' ) );
		return (string) apply_filters( 'presto_player_license_domain', (string) $domain );
	}

	/**
	 * Save the key
	 *
	 * @param string $key The license key to save.
	 * @return bool
	 */
	public static function saveKey( $key ) {
		return Setting::update( 'license', 'key', $key );
	}

	/**
	 * Get the key
	 *
	 * @return string
	 */
	public static function getKey() {
		return Setting::get( 'license', 'key' );
	}

	/**
	 * Activate a license
	 *
	 * @param string $key The license key to activate.
	 * @return string|\WP_Error
	 */
	public static function activate( $key ) {
		self::saveKey($key);
		return __('Activated', 'presto-player');
		$request_uri = add_query_arg(
			array(
				'woo_sl_action'     => 'activate',
				'licence_key'       => wp_kses_post( $key ),
				'product_unique_id' => self::id(),
				'domain'            => self::domain(),
			),
			self::apiUrl()
		);

		$data = wp_remote_get( $request_uri );

		// Error handling.
		if ( is_wp_error( $data ) || 200 !== $data['response']['code'] ) {
			return new \WP_Error( 'connection_error', 'There was a problem establishing a connection to the licensing server. Please try again in a few minutes.' );
		}

		// Check response body.
		$data_body = json_decode( $data['body'] );
		$data_body = $data_body[0] ?? $data_body;

		if ( isset( $data_body->status ) ) {
			if ( 'success' === $data_body->status && ( 's100' === $data_body->status_code || 's101' === $data_body->status_code ) ) {
				self::saveKey( $key );
				if ( $data_body->message ) {
					return $data_body->message;
				}
				return __( 'Activated', 'presto-player' );
			} else {
				if ( $data_body->message ) {
					$code = $data_body->status_code ?? 'error';
					return new \WP_Error( $code, $data_body->message );
				}
				return new \WP_Error( 'activation_error', 'There was a problem activating the license. Please check your license expiration.' );
			}
		}

		return new \WP_Error( 'connection_error', 'There was a problem establishing a connection to the licensing server. Please try again in a few minutes.' );
	}

	/**
	 * Deactivate license on this site
	 *
	 * @return string|\WP_Error
	 */
	public static function deactivate() {
		self::saveKey('');
		return __('Deactivated', 'presto-player');
		$request_uri = add_query_arg(
			array(
				'woo_sl_action'     => 'deactivate',
				'licence_key'       => wp_kses_post( self::getKey() ),
				'product_unique_id' => self::id(),
				'domain'            => self::domain(),
			),
			self::apiUrl()
		);

		$data = wp_remote_get( $request_uri );

		// Error handling.
		if ( is_wp_error( $data ) || 200 !== $data['response']['code'] ) {
			return new \WP_Error( 'connection_error', 'There was a problem establishing a connection to the licensing server. Please try again in a few minutes.' );
		}

		$data_body = json_decode( $data['body'] );
		$data_body = $data_body[0] ?? $data_body;

		if ( ! isset( $data_body->status ) ) {
			return new \WP_Error( 'error', 'There was a problem with the connecting to the licensing server.' );
		}

		// Any structured server response — clear locally. The key is a credential
		// the admin can re-paste if needed; staying stuck on a server-rejected
		// key (expired, refunded, not active for domain) is the worse failure.
		self::saveKey( '' );
		Setting::update( 'license_data', 'last_check', time() );

		if ( 'success' === $data_body->status && 's201' === $data_body->status_code && ! empty( $data_body->message ) ) {
			return $data_body->message;
		}
		return __( 'Deactivated', 'presto-player' );
	}
}
