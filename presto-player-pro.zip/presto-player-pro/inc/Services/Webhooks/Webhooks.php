<?php

namespace PrestoPlayer\Pro\Services\Webhooks;

use PrestoPlayer\Models\Webhook;
use PrestoPlayer\Pro\Support\EmailProvider;

/**
 * Webhooks service.
 */
class Webhooks extends EmailProvider {

	/**
	 * The email provider key.
	 *
	 * @var string
	 */
	protected $key = 'webhooks';

	/**
	 * Register the service hooks.
	 *
	 * @return void
	 */
	public function register() {
		// required presto version
		if ( version_compare( \PrestoPlayer\Plugin::version(), '1.9.15', '<' ) ) {
			return;
		}

		add_action( 'presto_player/pro/forms/save', array( $this, 'maybeHandleSubmit' ), 10, 2 );
	}

	/**
	 * Handle the action.
	 *
	 * @param array  $data The data from the form.
	 * @param  object $preset The preset.
	 * @return void
	 */
	public function handle( $data, $preset ) {
		$webhook_id = $preset->email_collection['provider_list'];
		if ( empty( $webhook_id ) ) {
			return;
		}

		$webhook = ( new Webhook() )->get( (int) $webhook_id );

		// bail and log error.
		if ( is_wp_error( $webhook ) ) {
			return;
		}

		$url = $webhook->url;
		if ( empty( $url ) ) {
			return;
		}

		// make request for each webhook.
		$this->makeRequest( $webhook, $data );
	}

	/**
	 * Make the request.
	 *
	 * @param \SureCart\Models\Webhook $webhook Webhook model.  
	 * @param array                    $data Submission data.
	 * @return void
	 */
	public function makeRequest( $webhook, $data ) {
		if ( ! self::isSafeUrl( $webhook->url ) ) {
			return;
		}

		$key = $webhook->email_name ?? 'email';

		$headers = array( 'Content-Type' => 'application/json' );
		foreach ( $webhook->headers ?? array() as $header ) {
			if ( isset( $header['name'] ) ) {
				$headers[ esc_html( $header['name'] ) ] = esc_html( $header['value'] );
			}
		}

		wp_remote_request(
			$webhook->url,
			array(
				'headers'     => $headers,
				'method'      => $webhook->method ?? 'POST',
				'blocking'    => false,
				'redirection' => 0,
				'body'        => json_encode(
					array(
						"$key" => $data['email'],
					)
				),
			)
		);
	}

	/**
	 * Validate that a URL is safe for an outbound webhook request.
	 *
	 * @param string $url The URL to validate.
	 * @return bool
	 */
	public static function isSafeUrl( $url ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return false;
		}

		$parts = wp_parse_url( $url );
		if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		if ( ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return false;
		}

		$host = strtolower( $parts['host'] );
		$host = trim( $host, '[]' );

		// Literal IP: validate directly.
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return (bool) filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		}

		// Resolve both A and AAAA so a public-A / private-AAAA host cannot slip through.
		$ips = array();
		$v4  = @gethostbynamel( $host );
		if ( ! empty( $v4 ) ) {
			$ips = array_merge( $ips, $v4 );
		}
		$v6 = @dns_get_record( $host, DNS_AAAA );
		if ( ! empty( $v6 ) ) {
			foreach ( $v6 as $record ) {
				if ( ! empty( $record['ipv6'] ) ) {
					$ips[] = $record['ipv6'];
				}
			}
		}

		// Fail open when the host can't be resolved here (DNS functions disabled or a transient
		// lookup failure) so a legitimate webhook is never silently dropped; the request itself
		// fails if the host is truly unresolvable. Any IP we DO resolve is still checked below.
		if ( empty( $ips ) ) {
			return true;
		}

		foreach ( $ips as $ip ) {
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return false;
			}
		}

		return true;
	}
}
