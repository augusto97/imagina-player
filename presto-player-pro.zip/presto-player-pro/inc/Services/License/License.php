<?php

namespace PrestoPlayer\Pro\Services\License;

use PrestoPlayer\Pro\Models\LicensedProduct;

class License {

	protected $page_link = 'admin.php?page=presto-dashboard&tab=Settings&section=license';

	public function register() {
		add_action( 'admin_init', array( $this, 'maybeRedirect' ) );
	}

	/**
	 * Maybe redirect to license page on activation
	 *
	 * @return void
	 */
	public function maybeRedirect() {
		if ( get_transient( 'presto_player_pro_activated' ) ) {
			delete_transient( 'presto_player_pro_activated' );
			if ( ! LicensedProduct::getKey() ) {
				wp_safe_redirect( esc_url( admin_url( $this->page_link ) ) );
				exit();
			}
		}
	}
}
