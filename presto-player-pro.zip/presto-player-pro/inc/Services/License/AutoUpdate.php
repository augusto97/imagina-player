<?php

namespace PrestoPlayer\Pro\Services\License;

use PrestoPlayer\Pro\Models\LicensedProduct;
use PrestoPlayer\Pro\Plugin;

class AutoUpdate {

	private $slug        = 'presto-player-pro';
	public $plugin       = 'presto-player-pro/presto-player-pro.php';
	private $API_VERSION = 1.1;

	public function register() {
		// check for updates
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'checkForUpdate' ) );
		// Take over the Plugin info screen and load info from prestomade.com
		add_filter( 'plugins_api', array( $this, 'pluginsApiCall' ), 10, 3 );
	}

	/**
	 * Check for plugin update
	 *
	 * @param mixed $checked_data
	 * @return mixed
	 */
	public function checkForUpdate( $checked_data ) {
		global $wp_version;

		if ( ! is_object( $checked_data ) || ! isset( $checked_data->response ) ) {
			return $checked_data;
		}

		// Register as update-managed even when current. WP only treats a plugin
		// as auto-updatable while it is in the update_plugins transient (response
		// or no_update); writing only response dropped Pro from it when current.
		// Promoted to response below if a newer version exists.
		$this->setNoUpdate( $checked_data );

		$request_data = $this->prepareRequest( 'plugin_update' );
		if ( false === $request_data ) {
			return $checked_data;
		}

		// Start checking for an update
		$request_uri = add_query_arg( $request_data, LicensedProduct::apiUrl() );

		// check if cached
		$data = get_site_transient( 'presto_player_check_for_plugin_update_' . md5( $request_uri ) );
		if ( false === $data ) {
			$data = wp_remote_get(
				$request_uri,
				array(
					'timeout'    => 20,
					'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo( 'url' ),
				)
			);

			if ( is_wp_error( $data ) || 200 != $data['response']['code'] ) {
				return $checked_data;
			}

			// cache for 4 hours
			set_site_transient( 'presto_player_check_for_plugin_update_' . md5( $request_uri ), $data, 4 * HOUR_IN_SECONDS );
		}

		// get response
		$response_block = json_decode( $data['body'] );
		if ( ! is_array( $response_block ) || 1 > count( $response_block ) ) {
			return $checked_data;
		}

		// retrieve the last message within the $response_block
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = isset( $response_block->message ) ? $response_block->message : '';

		// Promote to an update only if the server reports a newer version;
		// otherwise the no_update entry registered above stands.
		if ( is_object( $response ) && ! empty( $response ) ) {
			$response = $this->postProcessResponse( $response );

			if ( ! empty( $response->new_version )
				&& version_compare( $response->new_version, Plugin::version(), '>' ) ) {
				unset( $checked_data->no_update[ $this->plugin ] );
				$checked_data->response[ $this->plugin ] = $response;
			}
		}

		return $checked_data;
	}

	/**
	 * Register the plugin in the transient's `no_update` list so WP treats it
	 * as update-managed (toggle shown, eligible for the auto-update cron).
	 *
	 * @param object $checked_data The update_plugins transient object.
	 * @return void
	 */
	private function setNoUpdate( $checked_data ) {
		if ( ! isset( $checked_data->no_update ) || ! is_array( $checked_data->no_update ) ) {
			$checked_data->no_update = array();
		}

		$checked_data->no_update[ $this->plugin ] = (object) array(
			'id'          => $this->plugin,
			'slug'        => $this->slug,
			'plugin'      => $this->plugin,
			'new_version' => Plugin::version(),
			'url'         => 'https://prestoplayer.com',
			'package'     => '',
			'icons'       => array(),
			'banners'     => array(),
			'banners_rtl' => array(),
		);
	}

	/**
	 * Fetches plugin data from prestomade.com
	 *
	 * @param false|object|array $def
	 * @param string             $action
	 * @param object             $args
	 * 
	 * @return false|object|array
	 */
	public function pluginsApiCall( $def, $action, $args ) {
		// only for our plugin
		if ( ! is_object( $args ) || ! isset( $args->slug ) || $this->slug != $args->slug ) {
			return $def;
		}

		// prepare request
		$request_data = $this->prepareRequest( $action, $args );
		if ( false === $request_data ) {
			return new \WP_Error( 'plugins_api_failed', __( 'An error occour when try to identify the pluguin.', 'presto-player-pro' ) . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>' . __( 'Try again', 'presto-player-pro' ) . '&lt;/a>' );
		}

		global $wp_version;

		// make call to server
		$request_uri = add_query_arg( $request_data, LicensedProduct::apiUrl() );
		$data        = wp_remote_get(
			$request_uri,
			array(
				'timeout'    => 20,
				'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo( 'url' ),
			)
		);

		if ( is_wp_error( $data ) || 200 != $data['response']['code'] ) {
			// On a non-200, $data is a response array (e.g. a Cloudflare 403
			// challenge page), NOT a WP_Error — calling get_error_message() on the
			// array is a hard PHP 8 fatal (#128). Only read it when $data really is
			// a WP_Error; otherwise report the HTTP status.
			$error_detail = is_wp_error( $data )
				? $data->get_error_message()
				: 'HTTP ' . (int) wp_remote_retrieve_response_code( $data );
			return new \WP_Error( 'plugins_api_failed', __( 'An Unexpected HTTP Error occurred during the API request.', 'presto-player-pro' ) . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>' . __( 'Try again', 'presto-player-pro' ) . '&lt;/a>', $error_detail );
		}

		// retrieve the last message within the $response_block
		$response_block = json_decode( $data['body'] );
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = $response_block->message;

		if ( is_object( $response ) && ! empty( $response ) ) {
			$response = $this->postProcessResponse( $response );
			return $response;
		}

		return $def;
	}

	/**
	 * Prepare request arguments
	 *
	 * @param string $action Type of action
	 * @param array  $args   Query arguments for request (kept for API compatibility)
	 * @return array
	 */
	public function prepareRequest( $action, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		global $wp_version;

		return array(
			'woo_sl_action'     => $action,
			'version'           => Plugin::version(),
			'product_unique_id' => LicensedProduct::id(),
			'licence_key'       => LicensedProduct::getKey(),
			'domain'            => LicensedProduct::domain(),
			'wp-version'        => $wp_version,
			'api_version'       => $this->API_VERSION,
		);
	}

	/**
	 * Postprocess update resonse
	 *
	 * @param object $response
	 * @return object
	 */
	public function postProcessResponse( $response ) {
		// include slug and plugin data
		$response->slug   = $this->slug;
		$response->plugin = $this->plugin;

		// if sections are being set, force array
		if ( isset( $response->sections ) ) {
			$response->sections = (array) $response->sections;
		}
		// if banners are being set, force array
		if ( isset( $response->banners ) ) {
			$response->banners = (array) $response->banners;
		}
		// if icons being set, force array
		if ( isset( $response->icons ) ) {
			$response->icons = (array) $response->icons;
		}

		return $response;
	}
}
