<?php

namespace PrestoPlayer\Pro\Services\FluentCRM;

use PrestoPlayer\Pro\Support\EmailProvider;

class FluentCRM extends EmailProvider {

	protected $key = 'fluentcrm';

	// handle if fluentcrm is active for preset
	public function handle( $data, $preset ) {
		// double check fluent is active
		if ( ! function_exists( 'FluentCrmApi' ) ) {
			return;
		}

		$email = ! empty( $data['email'] ) ? $data['email'] : '';
		if ( ! is_email( $email ) ) {
			return;
		}

		$list = ! empty( $preset->email_collection['provider_list'] ) ? $preset->email_collection['provider_list'] : '';
		$tag  = ! empty( $preset->email_collection['provider_tag'] ) ? $preset->email_collection['provider_tag'] : '';

		$contact = array( 'email' => $email );
		if ( $list ) {
			$contact['lists'] = array( $list );
		}
		if ( $tag ) {
			$contact['tags'] = array( $tag );
		}

		// Use FluentCRM's documented developer API so lists/tags are attached correctly.
		FluentCrmApi( 'contacts' )->createOrUpdate( $contact );

		return $this;
	}
}
